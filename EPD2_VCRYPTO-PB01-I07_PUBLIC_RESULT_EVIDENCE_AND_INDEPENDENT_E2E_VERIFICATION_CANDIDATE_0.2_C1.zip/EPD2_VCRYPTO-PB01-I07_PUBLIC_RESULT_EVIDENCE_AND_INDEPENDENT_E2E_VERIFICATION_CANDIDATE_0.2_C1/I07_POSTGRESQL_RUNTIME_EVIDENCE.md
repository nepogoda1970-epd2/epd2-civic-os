# I07 PostgreSQL Runtime Evidence

Acceptance runtime:

- PostgreSQL `16.14`;
- Node.js `24.19.0`;
- Go `1.23.2` for Verifier B;
- four fresh `initdb` clusters;
- migrations `001` through `010` from zero for each class.

Recorded command result: **20/20 PASS**.

Class results:

- publication + least privilege: 4/4 PASS;
- crash consistency: 4/4 PASS;
- privileged tamper: 10/10 PASS;
- hard restart + backup/restore: 2/2 PASS.

Publication uses a SERIALIZABLE transaction plus election-scoped advisory locking. Equivalent concurrent publication retries converge. Only one immutable `FINAL` row can be public. Intermediate `DRAFT` / `EVIDENCE_PERSISTED` rows are absent from the public view. PostgreSQL serialization/deadlock conflicts are retried only for SQLSTATE `40001`/`40P01` and still pass the same authoritative-chain conflict checks.

The result publisher can read the authoritative I06 decryption record and write only I07 publication state; it cannot mutate I03–I06 history. The public verifier role can read only the `FINAL` public view. No universal administrator role is introduced.

Machine-readable evidence is under `evidence/results/i07/postgresql-*.json`.

## C1 current-invocation binding

PostgreSQL acceptance schema is now `epd2.pb01.i07-postgresql-acceptance/2`. It binds the 20/20 result to the exact Node version, PostgreSQL version, candidate gate-file digest, invocation id/start/completion time, and SHA-256 run-token digest. The one-time plaintext run token exists only as a local ephemeral file after standalone `test:i07:postgres`; `validate:i07` consumes and deletes it. Therefore a packaged `postgresql-acceptance.json` cannot satisfy a later validation invocation by itself.
