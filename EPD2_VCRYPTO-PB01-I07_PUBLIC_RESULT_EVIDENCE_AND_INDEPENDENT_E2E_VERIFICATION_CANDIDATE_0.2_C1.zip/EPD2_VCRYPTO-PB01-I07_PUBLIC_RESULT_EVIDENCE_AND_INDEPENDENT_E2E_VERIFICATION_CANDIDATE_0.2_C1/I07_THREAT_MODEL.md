# I07 Threat Model

I07 assumes the accepted I01–I06 cryptographic chain and treats the production application, result publisher, coordinator and database owner as non-authoritative for result validity. A valid result is established by independently recomputing and verifying the public evidence chain.

Covered attacks include publication of another election's result, another accepted tally, stale/mixed evidence, aggregate-byte substitution, digest substitution, guardian replacement, threshold change, duplicate/missing guardian evidence, invalid or changed partial decryptions/proofs, plaintext mutation, decryption-record mutation, result mutation, concurrent conflicting publication, crash-induced partial publication, and privileged PostgreSQL rewrites.

Database permissions are defense in depth, not the integrity root. Privileged rewrites of protected bytes are detected by independent recomputation of cryptographic commitments and cross-object bindings.

The accepted PB01 limitation remains: a malicious threshold quorum is a residual trust/collusion risk. I07 does not claim that such a quorum is cryptographically impossible; it makes the published official evidence independently checkable and substitution detectable.
