# PB01-I07 C1 — Acceptance / Verification Harness Corrective

Scope: acceptance/verification harness only. No I07 crypto/result semantics changed. No I01–I06 file semantics changed.

## Defect closed

The 0.1 `validate:i07` path accepted a packaged `evidence/results/i07/postgresql-acceptance.json` without proving that PostgreSQL 16 tests belonged to the current validation invocation.

## C1 behavior

- `validate:i07` requires Node exactly `v24.19.0`.
- PostgreSQL 16.x must be present and executable, otherwise validation exits non-zero as an environment blocker.
- A packaged PostgreSQL acceptance JSON alone is insufficient.
- `test:i07:postgres` executes the 20-test real PostgreSQL battery and emits schema v2 attestation bound to:
  - a cryptographically random run token digest;
  - invocation id/start time;
  - current I07 gate-file digest;
  - exact Node and PostgreSQL versions;
  - 20/20 result.
- Standalone `test:i07:postgres` also emits a one-time local run token file. The token is not part of the archive/evidence bundle.
- A following `validate:i07` may consume that fresh token exactly once (maximum age 10 minutes), verify the attestation binding, delete the token, and finish the remaining validation gates.
- If no valid fresh one-time PostgreSQL attestation exists, `validate:i07` executes `test:i07:postgres` itself in the current invocation.
- `i07_final_validate.mjs` refuses stale/unbound PostgreSQL evidence and requires the current invocation id, start time, run token and recomputed candidate gate digest.

## Runtime result

- Node: `v24.19.0`
- PostgreSQL: `16.14`
- `test:i07:postgres`: `20/20 PASS`
- subsequent `validate:i07`: `PASS`
- wrong Node (`v22.16.0`): exit 2 / reject
- missing PostgreSQL 16: exit 2 / environment blocker
