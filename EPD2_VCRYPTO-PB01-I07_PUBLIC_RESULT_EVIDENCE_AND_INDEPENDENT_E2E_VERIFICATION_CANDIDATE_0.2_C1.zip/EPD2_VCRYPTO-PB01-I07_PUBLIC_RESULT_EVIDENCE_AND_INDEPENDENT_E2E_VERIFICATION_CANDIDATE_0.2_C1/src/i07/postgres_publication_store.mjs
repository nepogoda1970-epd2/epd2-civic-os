import pg from "pg";
import { canonicalize } from "../i02_accepted/shared/profile.mjs";
import { failI07 } from "./errors.mjs";
const {Pool}=pg;
const parse=x=>typeof x==="string"?JSON.parse(x):x;
const now=()=>new Date().toISOString().replace(/\.\d{3}Z$/u,"Z");
export class PostgresPublicResultStore{
  constructor(config){const {pool,...cfg}=config??{};this.pool=pool??new Pool(cfg);}
  async close(){await this.pool.end();}
  async commit({eid,result,bundle,failpoint=null}){
    let lastError=null;
    for(let attempt=1;attempt<=3;attempt+=1){
      try{return await this.#commitOnce({eid,result,bundle,failpoint});}
      catch(e){lastError=e;if(!["40001","40P01"].includes(e?.code)||attempt===3)throw e;await new Promise(r=>setTimeout(r,10*attempt));}
    }
    throw lastError;
  }
  async #commitOnce({eid,result,bundle,failpoint=null}){
    const client=await this.pool.connect();try{await client.query("BEGIN ISOLATION LEVEL SERIALIZABLE");await client.query("SET LOCAL lock_timeout='10s'");await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 7))",[eid]);
      const authority=await client.query("SELECT decryption_record_digest FROM pb01_i06.decryption_records WHERE election_instance_id=$1 AND completion_state='CRYPTOGRAPHICALLY_DECRYPTED_NOT_YET_PUBLISHED'",[eid]);if(authority.rowCount!==1||authority.rows[0].decryption_record_digest!==result.decryption_record_digest)failI07("I07_DECRYPTION_BINDING_FAILURE");
      const existing=await client.query("SELECT public_result_digest,public_evidence_bundle_digest,publication_state FROM pb01_i07.result_publications WHERE election_instance_id=$1",[eid]);if(existing.rowCount===1){const x=existing.rows[0];if(x.public_result_digest!==result.public_result_digest||x.public_evidence_bundle_digest!==bundle.public_evidence_bundle_digest)failI07("I07_PUBLICATION_CONFLICT");await client.query("COMMIT");return {...await this.readFinal(eid),replay:true};}
      const at=now();await client.query(`INSERT INTO pb01_i07.result_publications(election_instance_id,decryption_record_digest,public_result_digest,public_evidence_bundle_digest,public_result_canonical,public_evidence_canonical,publication_state,committed_at) VALUES($1,$2,$3,$4,$5,$6,'DRAFT',$7::timestamptz)`,[eid,result.decryption_record_digest,result.public_result_digest,bundle.public_evidence_bundle_digest,canonicalize(result),canonicalize(bundle),at]);
      await failpoint?.("after_result_persistence_before_evidence_publication_marker");
      await client.query("UPDATE pb01_i07.result_publications SET publication_state='EVIDENCE_PERSISTED' WHERE election_instance_id=$1 AND publication_state='DRAFT'",[eid]);
      await failpoint?.("after_evidence_persistence_before_final_status_transition");
      await client.query("UPDATE pb01_i07.result_publications SET publication_state='FINAL',finalized_at=$2::timestamptz WHERE election_instance_id=$1 AND publication_state='EVIDENCE_PERSISTED'",[eid,at]);
      await client.query("COMMIT");return {...await this.readFinal(eid),replay:false};
    }catch(e){try{await client.query("ROLLBACK");}catch{}throw e;}finally{client.release();}}
  async readFinal(eid){const r=await this.pool.query("SELECT * FROM pb01_i07.result_publications WHERE election_instance_id=$1 AND publication_state='FINAL'",[eid]);if(r.rowCount!==1)return null;const x=r.rows[0];return {election_instance_id:eid,decryption_record_digest:x.decryption_record_digest,public_result_digest:x.public_result_digest,public_evidence_bundle_digest:x.public_evidence_bundle_digest,result:parse(x.public_result_canonical),bundle:parse(x.public_evidence_canonical),publication_state:x.publication_state};}
  async exportPublic(eid){const r=await this.readFinal(eid);if(!r)failI07("I07_NOT_FINAL",404);return r.bundle;}
  async assertPublisherPrivileges(){const r=await this.pool.query(`SELECT current_user AS role_name,p.rolsuper,p.rolcreatedb,p.rolcreaterole,p.rolreplication,p.rolbypassrls,has_schema_privilege(current_user,'pb01_i07','USAGE') i07_usage,has_schema_privilege(current_user,'pb01_i07','CREATE') i07_create,has_table_privilege(current_user,'pb01_i07.result_publications','INSERT') result_insert,has_table_privilege(current_user,'pb01_i07.result_publications','UPDATE') result_update,has_table_privilege(current_user,'pb01_i07.result_publications','DELETE') result_delete,has_table_privilege(current_user,'pb01_i06.decryption_records','SELECT') i06_select,has_table_privilege(current_user,'pb01_i06.decryption_records','UPDATE') i06_update FROM pg_roles p WHERE p.rolname=current_user`);const x=r.rows[0];const safe=x&&!x.rolsuper&&!x.rolcreatedb&&!x.rolcreaterole&&!x.rolreplication&&!x.rolbypassrls&&x.i07_usage&&!x.i07_create&&x.result_insert&&x.result_update&&!x.result_delete&&x.i06_select&&!x.i06_update;if(!safe)throw new Error("UNSAFE_I07_PUBLISHER_PRIVILEGES");return {...x,validation:"PASS_I07_PUBLISHER_LEAST_PRIVILEGE"};}
}
