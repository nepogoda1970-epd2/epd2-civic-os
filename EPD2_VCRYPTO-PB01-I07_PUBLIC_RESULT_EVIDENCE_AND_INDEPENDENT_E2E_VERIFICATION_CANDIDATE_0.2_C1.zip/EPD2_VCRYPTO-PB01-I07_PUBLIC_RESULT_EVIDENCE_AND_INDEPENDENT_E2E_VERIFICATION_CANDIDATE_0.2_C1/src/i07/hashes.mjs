import { createHash } from "node:crypto";
import { canonicalBytes, domainHash } from "../i01_reference/pb01_profile.mjs";
import { DOMAIN_PUBLIC_EVIDENCE, DOMAIN_PUBLIC_RESULT } from "./constants.mjs";
export const rawSha256Hex=(bytes)=>createHash("sha256").update(Buffer.from(bytes)).digest("hex");
export const beleniosFingerprint=(bytes)=>createHash("sha256").update(Buffer.from(bytes)).digest("base64").replace(/=+$/u,"");
export const publicResultDigest=(value)=>domainHash(DOMAIN_PUBLIC_RESULT,canonicalBytes(value));
export const publicEvidenceDigest=(value)=>domainHash(DOMAIN_PUBLIC_EVIDENCE,canonicalBytes(value));
