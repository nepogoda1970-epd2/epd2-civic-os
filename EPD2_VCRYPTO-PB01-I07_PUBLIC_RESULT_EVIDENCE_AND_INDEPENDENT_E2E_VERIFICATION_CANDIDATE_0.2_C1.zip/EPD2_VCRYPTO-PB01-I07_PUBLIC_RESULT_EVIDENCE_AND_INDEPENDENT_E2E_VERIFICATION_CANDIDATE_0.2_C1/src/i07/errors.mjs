export class I07Error extends Error{constructor(code,status=409,detail=null){super(code);this.name="I07Error";this.code=code;this.status=status;this.detail=detail;}}
export function failI07(code,status=409,detail=null){throw new I07Error(code,status,detail);}
