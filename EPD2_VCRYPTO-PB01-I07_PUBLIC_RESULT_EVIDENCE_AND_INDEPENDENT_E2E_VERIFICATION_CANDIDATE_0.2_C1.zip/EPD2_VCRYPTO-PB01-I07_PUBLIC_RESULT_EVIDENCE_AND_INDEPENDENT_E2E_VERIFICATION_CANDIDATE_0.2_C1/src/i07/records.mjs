import { CANONICALIZATION_POLICY, CRYPTO_PROFILE } from "../i01_reference/pb01_profile.mjs";
import { verifyPublicFinalEvidence } from "../i04/finalization.mjs";
import { verifyTallyEvidence } from "../i05/tally.mjs";
import { aggregateCiphertextDigest } from "../i05/hashes.mjs";
import { verifyGuardianCeremonyRecord, verifyShareArtifact, verifyThresholdDecryptionRecord } from "../i06/records.mjs";
import { verifyPersistedElectionBinding } from "../i06/election_binding.mjs";
import { NON_BINDING_STATUS, PUBLIC_EVIDENCE_SCHEMA, PUBLIC_RESULT_SCHEMA } from "./constants.mjs";
import { failI07 } from "./errors.mjs";
import { beleniosFingerprint, publicEvidenceDigest, publicResultDigest, rawSha256Hex } from "./hashes.mjs";
const HEX=/^[0-9a-f]{64}$/u;
function same(a,b){return JSON.stringify(a)===JSON.stringify(b);}
function requireHex(x,code){if(!HEX.test(x??""))failI07(code);}
export function buildPublicResult({electionContext,electionBytes,i04Evidence,i05Evidence,i06Handoff}){
  verifyPersistedElectionBinding(electionContext,electionBytes);
  verifyPublicFinalEvidence(i04Evidence);
  verifyTallyEvidence(i05Evidence);
  const ceremony=i06Handoff.guardian_ceremony_record,record=i06Handoff.threshold_decryption_record;
  verifyGuardianCeremonyRecord(ceremony);
  verifyThresholdDecryptionRecord(record,{ceremony,tally:{tally_record_digest:i05Evidence.tally_record_digest,aggregate_ciphertext_digest:i05Evidence.aggregate_ciphertext_digest,f_final:i05Evidence.f_final}});
  const without={schema_version:PUBLIC_RESULT_SCHEMA,canonicalization_policy_version:CANONICALIZATION_POLICY,election_instance_id:electionContext.election_instance_id,crypto_profile:CRYPTO_PROFILE,belenios_election_uuid:electionContext.belenios_election_uuid,belenios_election_fingerprint:beleniosFingerprint(electionBytes),election_public_bytes_sha256:rawSha256Hex(electionBytes),f_final:i04Evidence.f_final,tally_record_digest:i05Evidence.tally_record_digest,aggregate_ciphertext_digest:i05Evidence.aggregate_ciphertext_digest,guardian_ceremony_digest:ceremony.guardian_ceremony_digest,decryption_record_digest:record.decryption_record_digest,plaintext_tally_digest:record.plaintext_tally_digest,result:record.plaintext_tally,pilot_status:NON_BINDING_STATUS};
  return {...without,public_result_digest:publicResultDigest(without)};
}
export function buildPublicEvidenceBundle({electionContext,electionBytes,i04Evidence,i05Evidence,i06Handoff,publicResult,decryptionBaseArchiveBytes}){
  const shares=[...(i06Handoff.accepted_partial_decryption_shares??[])].sort((a,b)=>Number(a.guardian_index_decimal)-Number(b.guardian_index_decimal));
  if(!decryptionBaseArchiveBytes)failI07("I07_INCOMPLETE_EVIDENCE");const archiveBytes=Buffer.from(decryptionBaseArchiveBytes);
  const without={schema_version:PUBLIC_EVIDENCE_SCHEMA,canonicalization_policy_version:CANONICALIZATION_POLICY,election_instance_id:electionContext.election_instance_id,crypto_profile:CRYPTO_PROFILE,election_public_bytes_base64url:Buffer.from(electionBytes).toString("base64url"),election_public_bytes_sha256:rawSha256Hex(electionBytes),belenios_election_fingerprint:beleniosFingerprint(electionBytes),belenios_decryption_base_archive_base64url:archiveBytes.toString("base64url"),belenios_decryption_base_archive_sha256:rawSha256Hex(archiveBytes),i04_public_final_evidence:i04Evidence,i05_tally_evidence_bundle:i05Evidence,i06_guardian_ceremony_record:i06Handoff.guardian_ceremony_record,i06_accepted_partial_decryption_shares:shares,i06_threshold_decryption_record:i06Handoff.threshold_decryption_record,public_result:publicResult,public_result_digest:publicResult.public_result_digest,pilot_status:NON_BINDING_STATUS,semantic_claim:"PUBLIC_RESULT_CRYPTOGRAPHIC_EVIDENCE_NON_BINDING_PILOT"};
  return {...without,public_evidence_bundle_digest:publicEvidenceDigest(without)};
}
export function verifyPublicEvidenceBundle(bundle,{electionContext=null}={}){
  try{
    if(!bundle||bundle.schema_version!==PUBLIC_EVIDENCE_SCHEMA||bundle.crypto_profile!==CRYPTO_PROFILE||bundle.pilot_status!==NON_BINDING_STATUS)failI07("I07_SCHEMA_INVALID");
    const {public_evidence_bundle_digest,...without}=bundle;requireHex(public_evidence_bundle_digest,"I07_SCHEMA_INVALID");if(publicEvidenceDigest(without)!==public_evidence_bundle_digest)failI07("I07_RESULT_BINDING_FAILURE");
    const electionBytes=Buffer.from(bundle.election_public_bytes_base64url,"base64url");if(rawSha256Hex(electionBytes)!==bundle.election_public_bytes_sha256||beleniosFingerprint(electionBytes)!==bundle.belenios_election_fingerprint)failI07("I07_ELECTION_BINDING_FAILURE");const archiveBytes=Buffer.from(bundle.belenios_decryption_base_archive_base64url??"","base64url");if(!archiveBytes.length||rawSha256Hex(archiveBytes)!==bundle.belenios_decryption_base_archive_sha256)failI07("I07_INCOMPLETE_EVIDENCE");
    if(electionContext)verifyPersistedElectionBinding(electionContext,electionBytes);
    const i04=bundle.i04_public_final_evidence,i05=bundle.i05_tally_evidence_bundle,c=bundle.i06_guardian_ceremony_record,r=bundle.i06_threshold_decryption_record,result=bundle.public_result;
    if(!i04||!i05||!c||!r||!result||!Array.isArray(bundle.i06_accepted_partial_decryption_shares))failI07("I07_INCOMPLETE_EVIDENCE");
    verifyPublicFinalEvidence(i04);verifyTallyEvidence(i05);verifyGuardianCeremonyRecord(c);
    const tally={tally_record_digest:i05.tally_record_digest,aggregate_ciphertext_digest:i05.aggregate_ciphertext_digest,f_final:i05.f_final};
    for(const s of bundle.i06_accepted_partial_decryption_shares)verifyShareArtifact(s,{ceremony:c,tally});
    verifyThresholdDecryptionRecord(r,{ceremony:c,tally});
    if(i04.election_instance_id!==bundle.election_instance_id||i05.election_instance_id!==bundle.election_instance_id||c.election_instance_id!==bundle.election_instance_id||r.election_instance_id!==bundle.election_instance_id||result.election_instance_id!==bundle.election_instance_id)failI07("I07_ELECTION_BINDING_FAILURE");
    const parsedElection=JSON.parse(electionBytes.toString("utf8"));const ceremonyElection=JSON.parse(Buffer.from(c.election_json_base64url,"base64url").toString("utf8"));const authoritativePk=typeof parsedElection.public_key==="string"?parsedElection.public_key:parsedElection.public_key?.y;const ceremonyPk=typeof ceremonyElection.public_key==="string"?ceremonyElection.public_key:ceremonyElection.public_key?.y;if(parsedElection.uuid!==c.belenios_election_uuid||ceremonyElection.uuid!==parsedElection.uuid||authoritativePk!==c.election_public_key||ceremonyPk!==authoritativePk||i04.cset_final.belenios_election_uuid!==parsedElection.uuid||i04.cset_final.belenios_election_fingerprint!==bundle.belenios_election_fingerprint)failI07("I07_ELECTION_BINDING_FAILURE");
    if(i04.f_final!==i05.f_final||i04.f_final!==r.f_final||i04.f_final!==result.f_final)failI07("I07_FINAL_SET_BINDING_FAILURE");
    if(i05.final_set_envelope_digest!==i04.final_set_envelope_digest||i05.cset_root!==i04.cset_root||!same(i05.ordered_ballot_digests,i04.cset_final.ordered_ballot_digests))failI07("I07_FINAL_SET_BINDING_FAILURE");
    const agg=Buffer.from(i05.aggregate_ciphertext_base64url,"base64url");if(aggregateCiphertextDigest(agg)!==i05.aggregate_ciphertext_digest||i05.aggregate_ciphertext_digest!==r.aggregate_ciphertext_digest||i05.aggregate_ciphertext_digest!==result.aggregate_ciphertext_digest)failI07("I07_TALLY_BINDING_FAILURE");
    if(c.guardian_ceremony_digest!==r.guardian_ceremony_digest||c.guardian_ceremony_digest!==result.guardian_ceremony_digest)failI07("I07_DECRYPTION_BINDING_FAILURE");
    const shareMap=new Map(bundle.i06_accepted_partial_decryption_shares.map(s=>[s.share_digest,s]));if(new Set(bundle.i06_accepted_partial_decryption_shares.map(s=>s.guardian_id)).size!==bundle.i06_accepted_partial_decryption_shares.length)failI07("I07_DECRYPTION_BINDING_FAILURE");
    if(r.ordered_threshold_share_digests.length<Number(c.threshold_decimal)||r.ordered_threshold_share_digests.some(d=>!shareMap.has(d)))failI07("I07_DECRYPTION_BINDING_FAILURE");
    const {public_result_digest,...resultWithout}=result;if(publicResultDigest(resultWithout)!==public_result_digest||public_result_digest!==bundle.public_result_digest)failI07("I07_RESULT_BINDING_FAILURE");
    if(result.tally_record_digest!==i05.tally_record_digest||result.aggregate_ciphertext_digest!==i05.aggregate_ciphertext_digest||result.decryption_record_digest!==r.decryption_record_digest||result.plaintext_tally_digest!==r.plaintext_tally_digest||!same(result.result,r.plaintext_tally)||result.pilot_status!==NON_BINDING_STATUS)failI07("I07_RESULT_BINDING_FAILURE");
    return {status:"PASS",election_instance_id:bundle.election_instance_id,election_digest:bundle.election_public_bytes_sha256,final_set_reference:i04.f_final,aggregate_digest:i05.aggregate_ciphertext_digest,ceremony_digest:c.guardian_ceremony_digest,share_digests:bundle.i06_accepted_partial_decryption_shares.map(s=>s.share_digest),plaintext_tally_digest:r.plaintext_tally_digest,decryption_record_digest:r.decryption_record_digest,public_result_digest:result.public_result_digest,public_evidence_bundle_digest};
  }catch(e){if(e?.code?.startsWith?.("I07_"))throw e;failI07("I07_RESULT_BINDING_FAILURE",409,e?.code??e?.message);}
}
