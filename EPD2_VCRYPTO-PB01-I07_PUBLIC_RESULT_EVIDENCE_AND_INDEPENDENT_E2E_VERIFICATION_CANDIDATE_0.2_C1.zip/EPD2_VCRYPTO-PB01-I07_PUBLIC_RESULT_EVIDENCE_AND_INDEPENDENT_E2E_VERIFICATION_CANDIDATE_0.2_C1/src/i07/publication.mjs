import { buildPublicEvidenceBundle, buildPublicResult, verifyPublicEvidenceBundle } from "./records.mjs";
import { canonicalBytes } from "../i01_reference/pb01_profile.mjs";
import { publicResultDigest } from "./hashes.mjs";
import { failI07 } from "./errors.mjs";
export class PublicResultPublisher{
  constructor({i04Store,i05Engine,i05Store,i06Engine,i06FinalStore,publicationStore,decryptionArchiveResolver,failpoint=null}){this.i04Store=i04Store;this.i05Engine=i05Engine;this.i05Store=i05Store;this.i06Engine=i06Engine;this.i06FinalStore=i06FinalStore;this.publicationStore=publicationStore;this.decryptionArchiveResolver=decryptionArchiveResolver;this.failpoint=failpoint;}
  async derive(eid){
    const r4=await this.i04Store.recompute(eid);if(r4.status!=="PASS")failI07("I07_FINAL_SET_BINDING_FAILURE");
    const r5=await this.i05Engine.recompute(eid);if(r5.status!=="PASS")failI07("I07_TALLY_BINDING_FAILURE");
    const r6=await this.i06Engine.recompute(eid);if(r6.status!=="PASS")failI07("I07_DECRYPTION_BINDING_FAILURE");
    const election=await this.i04Store.getElection(eid);const i04=await this.i04Store.exportPublicEvidence(eid);const i05=await this.i05Store.exportEvidence(eid);const i06=await this.i06Engine.exportI07(eid);
    if(!election||!i04||!i05||!i06)failI07("I07_INCOMPLETE_EVIDENCE",404);
    const context=election.context_json??election.context;const electionBytes=context?.upstream_election_json_base64url?Buffer.from(context.upstream_election_json_base64url,"base64url"):null;if(!electionBytes?.length)failI07("I07_INCOMPLETE_EVIDENCE");const archiveBytes=await this.decryptionArchiveResolver?.(eid);if(!archiveBytes)failI07("I07_INCOMPLETE_EVIDENCE");const result=buildPublicResult({electionContext:context,electionBytes,i04Evidence:i04,i05Evidence:i05,i06Handoff:i06});
    const bundle=buildPublicEvidenceBundle({electionContext:context,electionBytes,i04Evidence:i04,i05Evidence:i05,i06Handoff:i06,publicResult:result,decryptionBaseArchiveBytes:archiveBytes});verifyPublicEvidenceBundle(bundle,{electionContext:context});return {result,bundle};
  }
  async publish(eid){const {result,bundle}=await this.derive(eid);await this.failpoint?.("before_result_persistence");const committed=await this.publicationStore.commit({eid,result,bundle,failpoint:this.failpoint});await this.failpoint?.("after_final_status_transition");return committed;}
  async recompute(eid){const stored=await this.publicationStore.readFinal(eid);if(!stored)failI07("I07_NOT_FINAL",404);const derived=await this.derive(eid);if(stored.public_result_digest!==derived.result.public_result_digest||stored.public_evidence_bundle_digest!==derived.bundle.public_evidence_bundle_digest)failI07("I07_RESULT_BINDING_FAILURE");const {public_result_digest,...storedWithout}=stored.result??{};if(publicResultDigest(storedWithout)!==public_result_digest||public_result_digest!==stored.public_result_digest||!Buffer.from(canonicalBytes(stored.result)).equals(Buffer.from(canonicalBytes(stored.bundle?.public_result))))failI07("I07_RESULT_BINDING_FAILURE");verifyPublicEvidenceBundle(stored.bundle);return {status:"PASS",public_result_digest:stored.public_result_digest,public_evidence_bundle_digest:stored.public_evidence_bundle_digest};}
}
