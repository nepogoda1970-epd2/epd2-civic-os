# I07 Independent Verification

## Verifier A

`verifier/i07_verifier_a.mjs` is a standalone Node implementation. It does not import `src/i07` or producer validation functions. It independently implements restricted canonical serialization, domain-separated hashing, closure signature verification, I04/I05/I06 cross-binding checks, guardian/share digest checks, and calls pinned Belenios 3.3.0 directly for aggregate/result reconstruction and proof verification.

## Verifier B

`verifier/reference-go-i07/main.go` is an independent Go 1.23 implementation using only the Go standard library plus the unchanged pinned Belenios 3.3.0 executable for upstream cryptographic verification. It does not wrap Verifier A or import producer code.

## Frozen vectors

Four positive vectors are provided:

- I07-V01 — N=3/T=2 accepted threshold subset;
- I07-V02 — alternative valid threshold verification subset for the same accepted result;
- I07-V03 — all available public shares, same deterministic result;
- I07-V04 — accepted empty/zero tally.

Verifier A and B agree byte-for-byte on election digest, final-set reference, aggregate digest, ceremony digest, share digests, plaintext tally digest, decryption-record digest, public-result digest and bundle digest.

Twenty-six frozen mutation vectors cover wrong/foreign election material, final-set mismatch, aggregate changes, ceremony/guardian/threshold changes, duplicate/missing/invalid shares, proof/factor mutations, plaintext/decryption mutations, published-result substitution, stale evidence, incomplete evidence and unknown profile/schema. Both verifier paths fail closed; cryptographically re-sealed share/proof mutations reach pinned Belenios and are rejected upstream.

## Offline mode

Verifier A and Verifier B can verify a standalone downloaded bundle file. The production API is not an oracle and no network access is required.
