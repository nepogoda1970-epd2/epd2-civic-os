# I07 Residual Risks

- A malicious threshold guardian quorum remains a governance/collusion risk inherited from I06; I07 does not eliminate it.
- Evidence withholding can prevent public verification even though it cannot make incomplete evidence verify as PASS.
- Compromise of the evidence hosting/distribution layer can deny service or serve stale/mutated files; independent digest verification detects mutation but not availability loss.
- A privileged infrastructure operator can rewrite PostgreSQL, but protected rewrite is detectable by recomputation. Infrastructure availability remains residual trust.
- Public verification depends on the pinned PB01/Belenios 3.3.0 cryptographic profile and its accepted implementation/provenance.
- I07 is not a legal/governance activation gate. System status remains `NON_BINDING_PILOT`.
- Rust verifier debts carried by predecessor work are not silently closed by the Go I07 verifier; they remain governed separately for the later final verifier/release gate where applicable.
