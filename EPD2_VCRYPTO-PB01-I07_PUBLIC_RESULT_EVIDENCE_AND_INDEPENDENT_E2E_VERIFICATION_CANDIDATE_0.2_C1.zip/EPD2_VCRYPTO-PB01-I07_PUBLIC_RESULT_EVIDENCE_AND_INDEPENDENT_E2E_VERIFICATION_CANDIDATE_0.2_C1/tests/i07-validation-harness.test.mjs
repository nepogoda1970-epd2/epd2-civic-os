import test from 'node:test';
import assert from 'node:assert/strict';
import { computeBindingDigest, computeRunTokenDigest, verifyCurrentInvocationAttestation, REQUIRED_NODE_VERSION } from '../scripts/i07_postgres_attestation.mjs';

function validAttestation() {
  const token='test-run-token';
  const a={
    schema_version:'epd2.pb01.i07-postgresql-acceptance/2',
    invocation_id:'i07-current',
    invocation_started_at_utc:new Date(Date.now()-1000).toISOString(),
    completed_at_utc:new Date().toISOString(),
    candidate_gate_digest:'sha256:'+'a'.repeat(64),
    run_token_digest:computeRunTokenDigest(token),
    postgresql_version:'postgres (PostgreSQL) 16.14',
    node_version:REQUIRED_NODE_VERSION,
    fresh_clusters:4,
    migrations:'001-010 from zero per class',
    test_count:20,pass_count:20,fail_count:0,status:'PASS'
  };
  a.invocation_binding_digest=computeBindingDigest(a); return {a,token};
}

test('stale packaged PostgreSQL acceptance cannot satisfy a new validation invocation',()=>{
  const {a,token}=validAttestation();
  const r=verifyCurrentInvocationAttestation(a,{invocationId:'i07-different',startedAtUtc:a.invocation_started_at_utc,gateDigest:a.candidate_gate_digest,runToken:token});
  assert.equal(r.ok,false); assert.ok(r.errors.includes('POSTGRES_ATTESTATION_INVOCATION_MISMATCH'));
});

test('tampered PostgreSQL attestation binding is rejected',()=>{
  const {a,token}=validAttestation(); a.pass_count=19;
  const r=verifyCurrentInvocationAttestation(a,{invocationId:a.invocation_id,startedAtUtc:a.invocation_started_at_utc,gateDigest:a.candidate_gate_digest,runToken:token});
  assert.equal(r.ok,false); assert.ok(r.errors.includes('POSTGRES_ATTESTATION_BINDING_DIGEST_MISMATCH'));
});

test('current invocation 20/20 PostgreSQL 16 + exact Node attestation is accepted',()=>{
  const {a,token}=validAttestation();
  const r=verifyCurrentInvocationAttestation(a,{invocationId:a.invocation_id,startedAtUtc:a.invocation_started_at_utc,gateDigest:a.candidate_gate_digest,runToken:token});
  assert.deepEqual(r,{ok:true,errors:[]});
});
