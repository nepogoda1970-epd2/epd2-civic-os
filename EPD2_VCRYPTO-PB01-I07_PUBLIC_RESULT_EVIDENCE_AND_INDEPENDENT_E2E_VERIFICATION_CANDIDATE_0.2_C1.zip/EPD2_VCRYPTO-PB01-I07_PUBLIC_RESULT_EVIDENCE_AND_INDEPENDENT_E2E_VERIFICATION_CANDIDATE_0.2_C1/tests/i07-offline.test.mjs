import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';

const root=resolve(new URL('..',import.meta.url).pathname);
function run(cmd,args){return new Promise((resolveRun,reject)=>{const p=spawn(cmd,args,{cwd:root,stdio:['ignore','pipe','pipe'],env:{...process.env,NO_PROXY:'*',HTTP_PROXY:'http://127.0.0.1:9',HTTPS_PROXY:'http://127.0.0.1:9'}});const out=[],err=[];p.stdout.on('data',d=>out.push(d));p.stderr.on('data',d=>err.push(d));p.on('error',reject);p.on('exit',code=>code===0?resolveRun(Buffer.concat(out).toString('utf8')):reject(new Error(Buffer.concat(err).toString('utf8'))));});}

test('I07 downloaded frozen bundle verifies offline with independent Verifier A',async()=>{
  const v=JSON.parse(await readFile(join(root,'test-vectors/i07/vectors/I07-V01.json'),'utf8'));
  const d=await mkdtemp(join(tmpdir(),'i07-offline-'));
  try {
    const bundle=join(d,'bundle.json');
    await writeFile(bundle,JSON.stringify(v.bundle));
    const out=await run(process.execPath,['verifier/i07_offline_verify_a.mjs','--bundle',bundle,'--trust','verifier/i07-trust-roots.json']);
    const r=JSON.parse(out.trim());
    assert.equal(r.status,'PASS');
    assert.equal(r.offline,true);
  } finally {await rm(d,{recursive:true,force:true});}
});

test('I07 downloaded frozen bundle verifies offline with independent Go Verifier B',async()=>{
  const v=JSON.parse(await readFile(join(root,'test-vectors/i07/vectors/I07-V01.json'),'utf8'));
  const d=await mkdtemp(join(tmpdir(),'i07-offline-go-'));
  try {
    const bundle=join(d,'bundle.json'), trust=join(d,'trust.json');
    await writeFile(bundle,JSON.stringify(v.bundle));
    await writeFile(trust,await readFile(join(root,'verifier/i07-trust-roots.json')));
    const outPath=join('evidence','results','i07','offline-go-temp.json');
    await run('go',['run','verifier/reference-go-i07/main.go','--root','.', '--tool','evidence/build/belenios-tool-3.3.0-linux-x86_64','--bundle',bundle,'--trust',trust,'--out',outPath]);
    const r=JSON.parse(await readFile(join(root,outPath),'utf8'));
    assert.equal(r.status,'PASS');
    await rm(join(root,outPath),{force:true});
  } finally {await rm(d,{recursive:true,force:true});}
});
