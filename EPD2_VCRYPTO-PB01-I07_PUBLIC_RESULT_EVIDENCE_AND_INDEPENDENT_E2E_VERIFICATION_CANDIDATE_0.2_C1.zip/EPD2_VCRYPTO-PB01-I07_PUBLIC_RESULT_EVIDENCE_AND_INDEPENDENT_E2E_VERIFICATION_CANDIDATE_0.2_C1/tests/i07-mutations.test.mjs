import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {spawnSync} from 'node:child_process';
const read=async p=>JSON.parse(await readFile(p,'utf8'));
const idx=await read('test-vectors/i07/mutations/index.json');
test('Verifier A rejects all 26 frozen mutations',()=>{const r=spawnSync(process.execPath,['verifier/i07_mutation_verifier_a.mjs'],{encoding:'utf8',timeout:180000});assert.equal(r.status,0,r.stderr||r.stdout);const report=JSON.parse(requireLastJSON(r.stdout));assert.equal(report.rejected,26);assert.equal(report.status,'PASS');});
function requireLastJSON(s){const lines=s.trim().split(/\r?\n/u);return lines.at(-1);}
test('mutation index is complete and unique',()=>{assert.equal(idx.mutations.length,26);assert.equal(new Set(idx.mutations.map(x=>x.mutation_id)).size,26);assert.ok(idx.mutations.every(x=>x.expected==='REJECT'));});
