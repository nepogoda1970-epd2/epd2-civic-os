import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {verifyPublicEvidenceBundle} from '../src/i07/records.mjs';
const read=async p=>JSON.parse(await readFile(p,'utf8'));
const idx=await read('test-vectors/i07/index.json');
for(const x of idx.vectors)test(`${x.vector_id} producer structural public bundle verification`,async()=>{const v=await read(x.path);const r=verifyPublicEvidenceBundle(v.bundle);assert.equal(r.status,'PASS');assert.equal(r.public_result_digest,v.expected.public_result_digest);});
test('V01/V02/V03 publish byte-identical deterministic result',async()=>{const vs=await Promise.all(['I07-V01','I07-V02','I07-V03'].map(x=>read(`test-vectors/i07/vectors/${x}.json`)));const bytes=vs.map(v=>JSON.stringify(v.bundle.public_result));assert.equal(bytes[0],bytes[1]);assert.equal(bytes[1],bytes[2]);assert.equal(vs[0].bundle.public_result_digest,vs[2].bundle.public_result_digest);});
test('V04 is deterministic zero tally',async()=>{const v=await read('test-vectors/i07/vectors/I07-V04.json');assert.deepEqual(v.bundle.public_result.result,[['0','0','0']]);assert.equal(v.bundle.pilot_status,'NON_BINDING_PILOT');});
