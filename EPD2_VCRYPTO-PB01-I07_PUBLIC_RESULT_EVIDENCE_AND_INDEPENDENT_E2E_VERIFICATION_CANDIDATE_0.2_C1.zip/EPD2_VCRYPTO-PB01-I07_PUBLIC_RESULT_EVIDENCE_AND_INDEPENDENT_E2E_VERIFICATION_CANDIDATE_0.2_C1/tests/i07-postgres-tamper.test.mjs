import test from 'node:test';import assert from 'node:assert/strict';import {publishI07,adminPool} from './i07_postgres_helpers.mjs';
async function tamper(t,table,sql,args){const p=await adminPool();t.after(()=>p.end());await p.query(`ALTER TABLE ${table} DISABLE TRIGGER USER`);try{await p.query(sql,args);}finally{await p.query(`ALTER TABLE ${table} ENABLE TRIGGER USER`);} }
const cases=[
 ['aggregate bytes','pb01_i05.aggregates',"UPDATE pb01_i05.aggregates SET aggregate_ciphertext_bytes=aggregate_ciphertext_bytes||'\\x20'::bytea WHERE election_instance_id=$1"],
 ['guardian public key','pb01_i06.guardians',"UPDATE pb01_i06.guardians SET public_key='00' WHERE election_instance_id=$1 AND guardian_index=1"],
 ['threshold','pb01_i06.guardian_ceremonies',"UPDATE pb01_i06.guardian_ceremonies SET threshold=3 WHERE election_instance_id=$1"],
 ['accepted share artifact','pb01_i06.accepted_shares',"UPDATE pb01_i06.accepted_shares SET share_artifact_canonical=jsonb_set(share_artifact_canonical::jsonb,'{guardian_id}','\"g9999\"'::jsonb)::text WHERE election_instance_id=$1 AND guardian_index=1"],
 ['accepted share digest','pb01_i06.accepted_shares',"UPDATE pb01_i06.accepted_shares SET share_digest=repeat('0',64) WHERE election_instance_id=$1 AND guardian_index=1"],
 ['plaintext bytes','pb01_i06.decryption_records',"UPDATE pb01_i06.decryption_records SET plaintext_tally_bytes='{}'::bytea WHERE election_instance_id=$1"],
 ['plaintext digest','pb01_i06.decryption_records',"UPDATE pb01_i06.decryption_records SET plaintext_tally_digest=repeat('0',64) WHERE election_instance_id=$1"],
 ['decryption record canonical','pb01_i06.decryption_records',"UPDATE pb01_i06.decryption_records SET decryption_record_canonical=jsonb_set(decryption_record_canonical::jsonb,'{completion_state}','\"NOT_DECRYPTED\"'::jsonb)::text WHERE election_instance_id=$1"],
 ['public result canonical bytes','pb01_i07.result_publications',"UPDATE pb01_i07.result_publications SET public_result_canonical=jsonb_set(public_result_canonical::jsonb,'{pilot_status}','\"TAMPERED\"'::jsonb)::text WHERE election_instance_id=$1"],
 ['public result digest column','pb01_i07.result_publications',"UPDATE pb01_i07.result_publications SET public_result_digest=repeat('f',64) WHERE election_instance_id=$1"],
];
for(const [name,table,sql] of cases)test(`I07/PG privileged tamper ${name} is detected independently of DB permissions`,async t=>{const c=await publishI07(t);await tamper(t,table,sql,[c.eid]);await assert.rejects(c.publisher.recompute(c.eid));});
