import { createPublicKey } from 'node:crypto';
import { readFile, writeFile, mkdtemp, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import pg from 'pg';
import { createThresholdChain, freezeN3T2, shareBytes, rolePool, runProcess, pgCtlPath, pgDataDir, pgStartOptions, pgDumpPath, pgRestorePath, createdbPath, dropdbPath, pgPort } from './i06_postgres_helpers.mjs';
import { adminPool, adminUrl } from './postgres_helpers.mjs';
import { root, toolPath } from './helpers.mjs';
import { PostgresPublicResultStore } from '../src/i07/postgres_publication_store.mjs';
import { PublicResultPublisher } from '../src/i07/publication.mjs';
import { verifyBundle as verifyBundleA } from '../verifier/i07_verifier_a.mjs';
const {Pool}=pg;
function req(n){const v=process.env[n];if(!v)throw new Error(`required I07 PostgreSQL environment missing: ${n}`);return v;}
export const publisherUrl=req('EPD2_I07_PG_PUBLISHER_URL');
export const publicVerifierUrl=req('EPD2_I07_PG_VERIFIER_URL');
export {adminUrl,adminPool,rolePool,runProcess,pgCtlPath,pgDataDir,pgStartOptions,pgDumpPath,pgRestorePath,createdbPath,dropdbPath,pgPort,toolPath,root};
export async function applyI07Migrations(){const p=await adminPool();try{await p.query('DROP SCHEMA IF EXISTS pb01_i07 CASCADE');for(const n of ['009_i07_public_result','010_i07_roles'])await p.query(await readFile(join(root,'migrations/postgresql',`${n}.sql`),'utf8'));}finally{await p.end();}}
export async function completeI07Chain(t,{failpoint=null}={}){
  const c=await createThresholdChain(t);await freezeN3T2(c);await c.engine.submitShare(c.eid,'g0001',await shareBytes(1));await c.engine.submitShare(c.eid,'g0002',await shareBytes(2));
  await applyI07Migrations();
  const publicationStore=new PostgresPublicResultStore({connectionString:publisherUrl,ssl:false,max:8});publicationStore.pool.on('error',()=>{});t.after(()=>publicationStore.close());
  const archivePath=join(root,'test-vectors/i06/fixtures/n3-t2/decryption-base.bel');
  const publisher=new PublicResultPublisher({i04Store:c.i04Store,i05Engine:c.i05Engine,i05Store:c.tallyStore,i06Engine:c.engine,i06FinalStore:c.finalStore,publicationStore,decryptionArchiveResolver:async()=>readFile(archivePath),failpoint});
  const finalization=await c.i04Store.readFinalization(c.eid);const keyId=finalization.closure_authorization.key_id;const key=c.i05Engine.authorizationVerifier.keys.get(keyId);if(!key)throw new Error('missing I04 trust root');
  const trustRoots=new Map([[keyId,key]]);
  const trustJson={schema_version:'epd2.pb01.i07-trust-roots/1',closure_authority_keys:[{key_id:keyId,algorithm:'Ed25519',public_key_spki_base64:key.export({type:'spki',format:'der'}).toString('base64')}]};
  return {...c,publicationStore,publisher,trustRoots,trustJson,archivePath};
}
export async function publishI07(t,opts={}){const c=await completeI07Chain(t,opts);const published=await c.publisher.publish(c.eid);return {...c,published};}
export async function verifyExportA(chain,bundle=null){return verifyBundleA(bundle??await chain.publicationStore.exportPublic(chain.eid),{trustRoots:chain.trustRoots});}
export async function verifyExportB(chain,bundle=null){
  const tmp=await mkdtemp(join(tmpdir(),'i07-pg-vb-'));try{const bundlePath=join(tmp,'bundle.json'),trustPath=join(tmp,'trust.json'),out=join(tmp,'out.json');await writeFile(bundlePath,JSON.stringify(bundle??await chain.publicationStore.exportPublic(chain.eid))+'\n');await writeFile(trustPath,JSON.stringify(chain.trustJson)+'\n');
    // Go verifier resolves paths under --root. Put relative copies under candidate temp subtree.
    const relDir=join(root,'.i07-vb-temp-'+process.pid+'-'+Math.random().toString(16).slice(2));await import('node:fs/promises').then(async fs=>{await fs.mkdir(relDir,{recursive:true});await fs.copyFile(bundlePath,join(relDir,'bundle.json'));await fs.copyFile(trustPath,join(relDir,'trust.json'));});
    try{const rel=relDir.slice(root.length+1);await runProcess('go',['run','verifier/reference-go-i07/main.go','--root','.','--tool','evidence/build/belenios-tool-3.3.0-linux-x86_64','--bundle',`${rel}/bundle.json`,'--trust',`${rel}/trust.json`,'--out',`${rel}/out.json`],process.env);const r=JSON.parse(await readFile(join(relDir,'out.json'),'utf8'));return r;}finally{await rm(relDir,{recursive:true,force:true});}
  }finally{await rm(tmp,{recursive:true,force:true});}
}
export function verifierPool(){const p=new Pool({connectionString:publicVerifierUrl,ssl:false,max:4});p.on('error',()=>{});return p;}
