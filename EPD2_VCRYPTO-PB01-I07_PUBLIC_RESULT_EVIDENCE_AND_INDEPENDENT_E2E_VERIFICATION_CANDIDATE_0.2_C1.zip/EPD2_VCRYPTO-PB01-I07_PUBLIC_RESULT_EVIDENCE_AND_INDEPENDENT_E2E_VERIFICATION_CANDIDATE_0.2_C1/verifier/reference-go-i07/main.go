package main

import (
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
)

var tags = map[string]string{
	"accepted": "epd2.pb01.accepted-submission-manifest.v1", "checkpoint": "epd2.pb01.closure-ledger-checkpoint.v1",
	"authMsg": "epd2.pb01.closure-authorization.v1", "authEvidence": "epd2.pb01.closure-authorization-evidence.v1",
	"closure": "epd2.pb01.closure-record.v1", "cset": "epd2.pb01.cset-root.v1", "envelope": "epd2.pb01.final-set-envelope.v1",
	"fFinal": "epd2.pb01.f-final.v1", "i04Evidence": "epd2.pb01.final-set-evidence.v1",
	"tallyInput": "epd2.pb01.tally-input.v1", "aggregate": "epd2.pb01.aggregate-ciphertext.v1",
	"tallyRecord": "epd2.pb01.homomorphic-tally-record.v1", "tallyEvidence": "epd2.pb01.tally-evidence.v1",
	"pk": "epd2.pb01.guardian-public-key.v1", "gset": "epd2.pb01.guardian-set.v1", "ceremony": "epd2.pb01.guardian-ceremony.v1",
	"share": "epd2.pb01.partial-decryption-share.v1", "plain": "epd2.pb01.plaintext-tally.v1", "decRecord": "epd2.pb01.threshold-decryption-record.v1",
	"publicResult": "epd2.pb01.public-result.v1", "publicEvidence": "epd2.pb01.public-result-evidence.v1",
}

type verifierError struct{ Code string }

func (e verifierError) Error() string { return e.Code }
func req(ok bool, code string) error {
	if !ok {
		return verifierError{code}
	}
	return nil
}

func decodeJSONFile(path string) (any, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	dec := json.NewDecoder(f)
	dec.UseNumber()
	var v any
	if err := dec.Decode(&v); err != nil {
		return nil, err
	}
	var extra any
	if err := dec.Decode(&extra); err != io.EOF {
		if err == nil {
			return nil, errors.New("extra JSON value")
		}
		return nil, err
	}
	return v, nil
}
func obj(v any) map[string]any {
	m, ok := v.(map[string]any)
	if !ok {
		panic("expected object")
	}
	return m
}
func arr(v any) []any {
	a, ok := v.([]any)
	if !ok {
		panic("expected array")
	}
	return a
}
func str(v any) string {
	s, ok := v.(string)
	if !ok {
		panic("expected string")
	}
	return s
}
func maybeStr(v any) string {
	if v == nil {
		return ""
	}
	s, _ := v.(string)
	return s
}

func canonical(v any) ([]byte, error) {
	switch x := v.(type) {
	case nil:
		return []byte("null"), nil
	case bool:
		if x {
			return []byte("true"), nil
		}
		return []byte("false"), nil
	case string:
		return json.Marshal(x)
	case json.Number:
		return nil, errors.New("numbers prohibited")
	case float64, float32, int, int64, int32, uint, uint64:
		return nil, errors.New("numbers prohibited")
	case []any:
		var b bytes.Buffer
		b.WriteByte('[')
		for i, item := range x {
			if i > 0 {
				b.WriteByte(',')
			}
			c, err := canonical(item)
			if err != nil {
				return nil, err
			}
			b.Write(c)
		}
		b.WriteByte(']')
		return b.Bytes(), nil
	case map[string]any:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		var b bytes.Buffer
		b.WriteByte('{')
		for i, k := range keys {
			if i > 0 {
				b.WriteByte(',')
			}
			kb, _ := json.Marshal(k)
			b.Write(kb)
			b.WriteByte(':')
			c, err := canonical(x[k])
			if err != nil {
				return nil, err
			}
			b.Write(c)
		}
		b.WriteByte('}')
		return b.Bytes(), nil
	default:
		return nil, fmt.Errorf("unsupported canonical type %T", v)
	}
}
func without(m map[string]any, key string) map[string]any {
	out := make(map[string]any, len(m))
	for k, v := range m {
		if k != key {
			out[k] = v
		}
	}
	return out
}
func domainHash(tag string, data []byte) string {
	h := sha256.New()
	h.Write([]byte(tag))
	h.Write([]byte{0})
	h.Write(data)
	return hex.EncodeToString(h.Sum(nil))
}
func hashObj(tag string, v any) (string, error) {
	c, err := canonical(v)
	if err != nil {
		return "", err
	}
	return domainHash(tag, c), nil
}
func rawSHA(b []byte) string { s := sha256.Sum256(b); return hex.EncodeToString(s[:]) }
func fp(b []byte) string {
	s := sha256.Sum256(b)
	return strings.TrimRight(base64.StdEncoding.EncodeToString(s[:]), "=")
}
func b64url(s string) ([]byte, error) { return base64.RawURLEncoding.DecodeString(s) }
func equalCanonical(a, b any) bool {
	ca, ea := canonical(a)
	cb, eb := canonical(b)
	return ea == nil && eb == nil && bytes.Equal(ca, cb)
}
func uniqueStrings(a []string) bool {
	seen := map[string]bool{}
	for _, x := range a {
		if seen[x] {
			return false
		}
		seen[x] = true
	}
	return true
}
func stringSlice(v any) []string {
	aa := arr(v)
	out := make([]string, len(aa))
	for i, x := range aa {
		out[i] = str(x)
	}
	return out
}
func contains(ss []string, x string) bool {
	for _, s := range ss {
		if s == x {
			return true
		}
	}
	return false
}

func firstLine(b []byte) []byte {
	if i := bytes.IndexByte(b, '\n'); i >= 0 {
		return b[:i]
	}
	return b
}
func runTool(tool string, args []string, input []byte) ([]byte, error) {
	c := exec.Command(tool, args...)
	if input != nil {
		c.Stdin = bytes.NewReader(input)
	}
	var out, er bytes.Buffer
	c.Stdout = &out
	c.Stderr = &er
	err := c.Run()
	if err != nil {
		return nil, fmt.Errorf("BELENIOS:%v:%s", err, er.String())
	}
	return out.Bytes(), nil
}
func verifyUpstream(tool string, bundle map[string]any, selected []map[string]any) ([]byte, error) {
	d, err := os.MkdirTemp("", "i07-vb-")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(d)
	archive, err := b64url(str(bundle["belenios_decryption_base_archive_base64url"]))
	if err != nil {
		return nil, err
	}
	if err = os.WriteFile(filepath.Join(d, "election.bel"), archive, 0600); err != nil {
		return nil, err
	}
	out, err := runTool(tool, []string{"election", "compute-encrypted-tally", "--dir=" + d}, nil)
	if err != nil {
		return nil, err
	}
	agg := firstLine(out)
	i05 := obj(bundle["i05_tally_evidence_bundle"])
	expectedAgg, err := b64url(str(i05["aggregate_ciphertext_base64url"]))
	if err != nil {
		return nil, err
	}
	if err = req(bytes.Equal(agg, expectedAgg), "UPSTREAM_AGGREGATE_MISMATCH"); err != nil {
		return nil, err
	}
	for _, s := range selected {
		raw, err := b64url(str(s["belenios_partial_decryption_base64url"]))
		if err != nil {
			return nil, err
		}
		owner := fmt.Sprintf("{\"owner\":%s,\"payload\":\"%s\"}\n", str(s["guardian_index_decimal"]), rawSHA(raw))
		input := append(append(append([]byte{}, raw...), byte('\n')), []byte(owner)...)
		if _, err = runTool(tool, []string{"archive", "add-event", "--dir=" + d, "--type=PartialDecryption"}, input); err != nil {
			return nil, err
		}
	}
	out, err = runTool(tool, []string{"election", "compute-result", "--dir=" + d}, nil)
	if err != nil {
		return nil, err
	}
	result := firstLine(out)
	input := append(append([]byte{}, result...), byte('\n'))
	if _, err = runTool(tool, []string{"archive", "add-event", "--dir=" + d, "--type=Result"}, input); err != nil {
		return nil, err
	}
	if _, err = runTool(tool, []string{"election", "verify", "--dir=" + d}, nil); err != nil {
		return nil, err
	}
	return result, nil
}

func verifyI04(e map[string]any, trust map[string]ed25519.PublicKey) (string, error) {
	if err := req(str(e["schema_version"]) == "epd2.pb01.public-final-evidence/1" || str(e["schema_version"]) == "epd2.pb01.final-set-evidence/1", "I04_SCHEMA"); err != nil {
		return "", err
	}
	d, _ := hashObj(tags["i04Evidence"], without(e, "public_evidence_digest"))
	if err := req(d == str(e["public_evidence_digest"]), "I04_EVIDENCE_DIGEST"); err != nil {
		return "", err
	}
	a := obj(e["closure_authorization"])
	d, _ = hashObj(tags["authEvidence"], without(a, "authorization_evidence_digest"))
	if err := req(d == str(a["authorization_evidence_digest"]), "I04_AUTH_DIGEST"); err != nil {
		return "", err
	}
	key, ok := trust[str(a["key_id"])]
	if err := req(ok, "I04_TRUST_ROOT_MISSING"); err != nil {
		return "", err
	}
	stmt, err := canonical(a["statement"])
	if err != nil {
		return "", err
	}
	msg := append(append([]byte(tags["authMsg"]), 0), stmt...)
	sig, err := b64url(str(a["signature_base64url"]))
	if err != nil {
		return "", err
	}
	if err = req(ed25519.Verify(key, msg, sig), "I04_CLOSURE_SIGNATURE"); err != nil {
		return "", err
	}
	m := obj(e["accepted_manifest_at_closure"])
	d, _ = hashObj(tags["accepted"], without(m, "manifest_digest"))
	if err = req(d == str(m["manifest_digest"]), "I04_MANIFEST"); err != nil {
		return "", err
	}
	cp := obj(e["closure_ledger_checkpoint"])
	if err = req(str(m["manifest_digest"]) == str(cp["accepted_manifest_digest"]), "I04_MANIFEST_BIND"); err != nil {
		return "", err
	}
	d, _ = hashObj(tags["checkpoint"], cp)
	cr := obj(e["closure_record"])
	if err = req(d == str(cr["closure_checkpoint_digest"]), "I04_CHECKPOINT"); err != nil {
		return "", err
	}
	d, _ = hashObj(tags["closure"], cr)
	if err = req(d == str(e["closure_record_digest"]), "I04_CLOSURE_RECORD"); err != nil {
		return "", err
	}
	cs := obj(e["cset_final"])
	d, _ = hashObj(tags["cset"], cs)
	if err = req(d == str(e["cset_root"]), "I04_CSET_ROOT"); err != nil {
		return "", err
	}
	dig := stringSlice(cs["ordered_ballot_digests"])
	sorted := append([]string{}, dig...)
	sort.Slice(sorted, func(i, j int) bool {
		ai, _ := hex.DecodeString(sorted[i])
		aj, _ := hex.DecodeString(sorted[j])
		return bytes.Compare(ai, aj) < 0
	})
	if err = req(equalCanonical(toAnyStrings(sorted), cs["ordered_ballot_digests"]) && uniqueStrings(dig), "I04_CSET_ORDER"); err != nil {
		return "", err
	}
	accepted := stringSlice(m["accepted_ballot_digests"])
	for _, x := range dig {
		if err = req(contains(accepted, x), "I04_CSET_ACCEPTED"); err != nil {
			return "", err
		}
	}
	env := obj(e["final_set_envelope"])
	d, _ = hashObj(tags["envelope"], env)
	if err = req(d == str(e["final_set_envelope_digest"]), "I04_ENVELOPE"); err != nil {
		return "", err
	}
	d, _ = hashObj(tags["fFinal"], env)
	if err = req(d == str(e["f_final"]), "I04_F_FINAL"); err != nil {
		return "", err
	}
	if err = req(str(env["cset_root"]) == str(e["cset_root"]) && equalCanonical(env["ordered_ballot_digests"], cs["ordered_ballot_digests"]) && str(env["closure_record_digest"]) == str(e["closure_record_digest"]), "I04_CROSS_BIND"); err != nil {
		return "", err
	}
	return str(e["f_final"]), nil
}
func toAnyStrings(ss []string) []any {
	out := make([]any, len(ss))
	for i, s := range ss {
		out[i] = s
	}
	return out
}
func verifyI05(e map[string]any) ([]byte, error) {
	if err := req(str(e["schema_version"]) == "epd2.pb01.tally-evidence-bundle/1", "I05_SCHEMA"); err != nil {
		return nil, err
	}
	d, _ := hashObj(tags["tallyEvidence"], without(e, "tally_evidence_digest"))
	if err := req(d == str(e["tally_evidence_digest"]), "I05_EVIDENCE_DIGEST"); err != nil {
		return nil, err
	}
	m := obj(e["tally_input_manifest"])
	d, _ = hashObj(tags["tallyInput"], m)
	if err := req(d == str(e["tally_input_digest"]), "I05_INPUT_DIGEST"); err != nil {
		return nil, err
	}
	ab, err := b64url(str(e["aggregate_ciphertext_base64url"]))
	if err != nil {
		return nil, err
	}
	if err = req(domainHash(tags["aggregate"], ab) == str(e["aggregate_ciphertext_digest"]), "I05_AGG_DIGEST"); err != nil {
		return nil, err
	}
	raw, _ := json.Marshal(e["aggregate_ciphertext"])
	if err = req(bytes.Equal(ab, raw), "I05_AGG_BYTES"); err != nil {
		return nil, err
	}
	r := obj(e["homomorphic_tally_record"])
	d, _ = hashObj(tags["tallyRecord"], without(r, "tally_record_digest"))
	if err = req(d == str(r["tally_record_digest"]) && d == str(e["tally_record_digest"]), "I05_RECORD"); err != nil {
		return nil, err
	}
	if err = req(str(m["f_final"]) == str(e["f_final"]) && str(m["cset_root"]) == str(e["cset_root"]) && str(m["final_set_envelope_digest"]) == str(e["final_set_envelope_digest"]) && equalCanonical(m["ordered_ballot_digests"], e["ordered_ballot_digests"]), "I05_FINAL_SET"); err != nil {
		return nil, err
	}
	if err = req(str(r["f_final"]) == str(e["f_final"]) && str(r["cset_root"]) == str(e["cset_root"]) && str(r["tally_input_digest"]) == str(e["tally_input_digest"]) && str(r["aggregate_ciphertext_digest"]) == str(e["aggregate_ciphertext_digest"]), "I05_RECORD_BIND"); err != nil {
		return nil, err
	}
	return ab, nil
}

type i06Data struct {
	ceremony, record map[string]any
	shares           []map[string]any
	plain            []byte
	byDigest         map[string]map[string]any
}

func verifyI06(bundle map[string]any) (i06Data, error) {
	c := obj(bundle["i06_guardian_ceremony_record"])
	d, _ := hashObj(tags["ceremony"], without(c, "guardian_ceremony_digest"))
	if err := req(d == str(c["guardian_ceremony_digest"]), "I06_CEREMONY"); err != nil {
		return i06Data{}, err
	}
	gs := map[string]any{"schema_version": "epd2.pb01.guardian-set/1", "election_instance_id": c["election_instance_id"], "crypto_profile": c["crypto_profile"], "guardian_count_decimal": c["guardian_count_decimal"], "threshold_decimal": c["threshold_decimal"], "ordered_guardians": c["ordered_guardians"]}
	d, _ = hashObj(tags["gset"], gs)
	if err := req(d == str(c["guardian_set_digest"]), "I06_GSET"); err != nil {
		return i06Data{}, err
	}
	guardians := arr(c["ordered_guardians"])
	for i, gv := range guardians {
		g := obj(gv)
		expected := fmt.Sprintf("g%04d", i+1)
		if err := req(str(g["guardian_index_decimal"]) == fmt.Sprint(i+1) && str(g["guardian_id"]) == expected, "I06_GUARDIAN_ORDER"); err != nil {
			return i06Data{}, err
		}
		if err := req(domainHash(tags["pk"], []byte(str(g["public_key"]))) == str(g["public_key_digest"]), "I06_GUARDIAN_PK"); err != nil {
			return i06Data{}, err
		}
	}
	shareVals := arr(bundle["i06_accepted_partial_decryption_shares"])
	shares := make([]map[string]any, len(shareVals))
	ids := []string{}
	digs := []string{}
	by := map[string]map[string]any{}
	for i, sv := range shareVals {
		s := obj(sv)
		shares[i] = s
		ids = append(ids, str(s["guardian_id"]))
		digs = append(digs, str(s["share_digest"]))
		d, _ = hashObj(tags["share"], without(s, "share_digest"))
		if err := req(d == str(s["share_digest"]), "I06_SHARE_DIGEST"); err != nil {
			return i06Data{}, err
		}
		idx := atoi(str(s["guardian_index_decimal"]))
		if idx < 1 || idx > len(guardians) {
			return i06Data{}, verifierError{"I06_SHARE_MEMBER"}
		}
		g := obj(guardians[idx-1])
		if err := req(str(g["guardian_id"]) == str(s["guardian_id"]) && str(g["public_key_digest"]) == str(s["guardian_public_key_digest"]), "I06_SHARE_MEMBER"); err != nil {
			return i06Data{}, err
		}
		if err := req(str(s["guardian_ceremony_digest"]) == str(c["guardian_ceremony_digest"]) && str(s["election_instance_id"]) == str(c["election_instance_id"]), "I06_SHARE_ELECTION"); err != nil {
			return i06Data{}, err
		}
		by[str(s["share_digest"])] = s
	}
	if err := req(uniqueStrings(ids) && uniqueStrings(digs), "I06_DUPLICATE_GUARDIAN"); err != nil {
		return i06Data{}, err
	}
	r := obj(bundle["i06_threshold_decryption_record"])
	d, _ = hashObj(tags["decRecord"], without(r, "decryption_record_digest"))
	if err := req(d == str(r["decryption_record_digest"]), "I06_RECORD"); err != nil {
		return i06Data{}, err
	}
	pb, err := b64url(str(r["plaintext_tally_base64url"]))
	if err != nil {
		return i06Data{}, err
	}
	if err = req(domainHash(tags["plain"], pb) == str(r["plaintext_tally_digest"]), "I06_PLAIN_DIGEST"); err != nil {
		return i06Data{}, err
	}
	if err = req(str(r["guardian_ceremony_digest"]) == str(c["guardian_ceremony_digest"]), "I06_RECORD_CEREMONY"); err != nil {
		return i06Data{}, err
	}
	threshold := atoi(str(c["threshold_decimal"]))
	td := stringSlice(r["ordered_threshold_share_digests"])
	if err = req(len(td) == threshold && uniqueStrings(td), "I06_THRESHOLD"); err != nil {
		return i06Data{}, err
	}
	for _, x := range td {
		if _, ok := by[x]; !ok {
			return i06Data{}, verifierError{"I06_THRESHOLD_MEMBERSHIP"}
		}
	}
	return i06Data{c, r, shares, pb, by}, nil
}
func atoi(s string) int { var n int; fmt.Sscanf(s, "%d", &n); return n }

type Result struct {
	VectorID                   string   `json:"vector_id"`
	Status                     string   `json:"status"`
	ElectionDigest             string   `json:"election_digest"`
	FinalSetReference          string   `json:"final_set_reference"`
	AggregateDigest            string   `json:"aggregate_digest"`
	CeremonyDigest             string   `json:"ceremony_digest"`
	ShareDigests               []string `json:"share_digests"`
	PlaintextTallyDigest       string   `json:"plaintext_tally_digest"`
	DecryptionRecordDigest     string   `json:"decryption_record_digest"`
	PublicResultDigest         string   `json:"public_result_digest"`
	PublicEvidenceBundleDigest string   `json:"public_evidence_bundle_digest"`
}

func verifyBundle(tool string, b map[string]any, trust map[string]ed25519.PublicKey, indices []string) (Result, error) {
	if err := req(str(b["schema_version"]) == "epd2.pb01.public-result-evidence-bundle/1", "I07_SCHEMA"); err != nil {
		return Result{}, err
	}
	d, _ := hashObj(tags["publicEvidence"], without(b, "public_evidence_bundle_digest"))
	if err := req(d == str(b["public_evidence_bundle_digest"]), "I07_BUNDLE_DIGEST"); err != nil {
		return Result{}, err
	}
	eb, err := b64url(str(b["election_public_bytes_base64url"]))
	if err != nil {
		return Result{}, err
	}
	if err = req(rawSHA(eb) == str(b["election_public_bytes_sha256"]) && fp(eb) == str(b["belenios_election_fingerprint"]), "I07_ELECTION_BYTES"); err != nil {
		return Result{}, err
	}
	archive, err := b64url(str(b["belenios_decryption_base_archive_base64url"]))
	if err != nil {
		return Result{}, err
	}
	if err = req(rawSHA(archive) == str(b["belenios_decryption_base_archive_sha256"]), "I07_ARCHIVE_BYTES"); err != nil {
		return Result{}, err
	}
	var election map[string]any
	dec := json.NewDecoder(bytes.NewReader(eb))
	dec.UseNumber()
	if err = dec.Decode(&election); err != nil {
		return Result{}, err
	}
	i04 := obj(b["i04_public_final_evidence"])
	cs := obj(i04["cset_final"])
	if err = req(str(election["uuid"]) == str(cs["belenios_election_uuid"]) && fp(eb) == str(cs["belenios_election_fingerprint"]), "I07_ELECTION_FINGERPRINT"); err != nil {
		return Result{}, err
	}
	f, err := verifyI04(i04, trust)
	if err != nil {
		return Result{}, err
	}
	i05 := obj(b["i05_tally_evidence_bundle"])
	if _, err = verifyI05(i05); err != nil {
		return Result{}, err
	}
	i06, err := verifyI06(b)
	if err != nil {
		return Result{}, err
	}
	eid := str(b["election_instance_id"])
	pr := obj(b["public_result"])
	for _, x := range []string{str(i04["election_instance_id"]), str(i05["election_instance_id"]), str(i06.ceremony["election_instance_id"]), str(i06.record["election_instance_id"]), str(pr["election_instance_id"])} {
		if err = req(x == eid, "I07_ELECTION_CROSS_BIND"); err != nil {
			return Result{}, err
		}
	}
	ceremonyBytes, err := b64url(str(i06.ceremony["election_json_base64url"]))
	if err != nil {
		return Result{}, err
	}
	var ceremonyElection map[string]any
	cdec := json.NewDecoder(bytes.NewReader(ceremonyBytes))
	cdec.UseNumber()
	if err = cdec.Decode(&ceremonyElection); err != nil {
		return Result{}, err
	}
	epk := str(election["public_key"])
	cpk := str(ceremonyElection["public_key"])
	if err = req(str(i06.ceremony["belenios_election_uuid"]) == str(election["uuid"]) && str(ceremonyElection["uuid"]) == str(election["uuid"]) && str(i06.ceremony["election_public_key"]) == epk && cpk == epk, "I07_ELECTION_CEREMONY_BIND"); err != nil {
		return Result{}, err
	}
	if err = req(f == str(i05["f_final"]) && f == str(i06.record["f_final"]) && f == str(pr["f_final"]), "I07_FINAL_SET_CROSS_BIND"); err != nil {
		return Result{}, err
	}
	if err = req(str(i04["cset_root"]) == str(i05["cset_root"]) && str(i04["final_set_envelope_digest"]) == str(i05["final_set_envelope_digest"]) && equalCanonical(cs["ordered_ballot_digests"], i05["ordered_ballot_digests"]), "I07_FINAL_SET_CROSS_BIND"); err != nil {
		return Result{}, err
	}
	if err = req(str(i05["tally_record_digest"]) == str(i06.record["tally_record_digest"]) && str(i05["aggregate_ciphertext_digest"]) == str(i06.record["aggregate_ciphertext_digest"]), "I07_TALLY_CROSS_BIND"); err != nil {
		return Result{}, err
	}
	d, _ = hashObj(tags["publicResult"], without(pr, "public_result_digest"))
	if err = req(d == str(pr["public_result_digest"]) && d == str(b["public_result_digest"]), "I07_RESULT_DIGEST"); err != nil {
		return Result{}, err
	}
	if err = req(str(pr["tally_record_digest"]) == str(i05["tally_record_digest"]) && str(pr["aggregate_ciphertext_digest"]) == str(i05["aggregate_ciphertext_digest"]) && str(pr["decryption_record_digest"]) == str(i06.record["decryption_record_digest"]) && str(pr["plaintext_tally_digest"]) == str(i06.record["plaintext_tally_digest"]) && equalCanonical(pr["result"], i06.record["plaintext_tally"]) && str(pr["pilot_status"]) == "NON_BINDING_PILOT", "I07_RESULT_BIND"); err != nil {
		return Result{}, err
	}
	var selected []map[string]any
	if len(indices) > 0 {
		set := map[string]bool{}
		for _, x := range indices {
			set[x] = true
		}
		for _, s := range i06.shares {
			if set[str(s["guardian_index_decimal"])] {
				selected = append(selected, s)
			}
		}
		if err = req(len(selected) == len(set), "I07_ALT_SUBSET_MISSING"); err != nil {
			return Result{}, err
		}
	} else {
		for _, sd := range stringSlice(i06.record["ordered_threshold_share_digests"]) {
			selected = append(selected, i06.byDigest[sd])
		}
	}
	if err = req(len(selected) >= atoi(str(i06.ceremony["threshold_decimal"])), "I07_THRESHOLD_UNSATISFIED"); err != nil {
		return Result{}, err
	}
	up, err := verifyUpstream(tool, b, selected)
	if err != nil {
		return Result{}, err
	}
	if err = req(bytes.Equal(up, i06.plain), "I07_UPSTREAM_PLAINTEXT"); err != nil {
		return Result{}, err
	}
	sd := make([]string, len(i06.shares))
	for i, s := range i06.shares {
		sd[i] = str(s["share_digest"])
	}
	return Result{"", "PASS", str(b["election_public_bytes_sha256"]), f, str(i05["aggregate_ciphertext_digest"]), str(i06.ceremony["guardian_ceremony_digest"]), sd, str(i06.record["plaintext_tally_digest"]), str(i06.record["decryption_record_digest"]), str(pr["public_result_digest"]), str(b["public_evidence_bundle_digest"])}, nil
}

func verifyBundleSafe(tool string, b map[string]any, trust map[string]ed25519.PublicKey, indices []string) (r Result, err error) {
	defer func() {
		if x := recover(); x != nil {
			err = fmt.Errorf("PANIC_REJECT:%v", x)
		}
	}()
	return verifyBundle(tool, b, trust, indices)
}

type MutationResult struct {
	MutationID string `json:"mutation_id"`
	Status     string `json:"status"`
	Reason     string `json:"reason,omitempty"`
}

func resolvePath(root, p string) string {
	if filepath.IsAbs(p) {
		return p
	}
	return filepath.Join(root, p)
}

func main() {
	root := flag.String("root", ".", "candidate root")
	toolArg := flag.String("tool", "", "belenios tool")
	out := flag.String("out", "evidence/results/i07/verifier-b.json", "output")
	bundlePath := flag.String("bundle", "", "verify one public evidence bundle JSON")
	trustPath := flag.String("trust", "verifier/i07-trust-roots.json", "closure trust roots JSON")
	flag.Parse()
	tool := *toolArg
	if tool == "" {
		tool = resolvePath(*root, "evidence/build/belenios-tool-3.3.0-linux-x86_64")
	}
	tv, err := decodeJSONFile(resolvePath(*root, *trustPath))
	if err != nil {
		panic(err)
	}
	trust := map[string]ed25519.PublicKey{}
	for _, kv := range arr(obj(tv)["closure_authority_keys"]) {
		k := obj(kv)
		der, err := base64.StdEncoding.DecodeString(str(k["public_key_spki_base64"]))
		if err != nil {
			panic(err)
		}
		pkAny, err := x509.ParsePKIXPublicKey(der)
		if err != nil {
			panic(err)
		}
		pk, ok := pkAny.(ed25519.PublicKey)
		if !ok {
			panic("trust root not Ed25519")
		}
		trust[str(k["key_id"])] = pk
	}
	if *bundlePath != "" {
		bv, e := decodeJSONFile(resolvePath(*root, *bundlePath))
		if e != nil {
			panic(e)
		}
		var b map[string]any
		if x, ok := bv.(map[string]any); ok {
			if inner, exists := x["bundle"]; exists {
				b = obj(inner)
			} else {
				b = x
			}
		} else {
			panic("bundle JSON must be object")
		}
		r, e := verifyBundleSafe(tool, b, trust, nil)
		if e != nil {
			fmt.Fprintln(os.Stderr, e)
			os.Exit(1)
		}
		r.VectorID = "SINGLE-BUNDLE"
		report := map[string]any{"schema_version": "epd2.pb01.i07-verifier-b-single-result/1", "verifier": "independent-go-verifier-b", "producer_imports": false, "wraps_verifier_a": false, "vector_results": []Result{r}, "status": "PASS"}
		data, _ := json.MarshalIndent(report, "", "  ")
		data = append(data, '\n')
		if err = os.MkdirAll(filepath.Dir(filepath.Join(*root, *out)), 0755); err != nil {
			panic(err)
		}
		if err = os.WriteFile(filepath.Join(*root, *out), data, 0644); err != nil {
			panic(err)
		}
		fmt.Print(string(data))
		return
	}

	iv, err := decodeJSONFile(filepath.Join(*root, "test-vectors/i07/index.json"))
	if err != nil {
		panic(err)
	}
	var results []Result
	for _, itv := range arr(obj(iv)["vectors"]) {
		it := obj(itv)
		vv, err := decodeJSONFile(filepath.Join(*root, str(it["path"])))
		if err != nil {
			panic(err)
		}
		v := obj(vv)
		inds := stringSlice(v["verification_guardian_indices"])
		r, err := verifyBundleSafe(tool, obj(v["bundle"]), trust, inds)
		if err != nil {
			fmt.Fprintf(os.Stderr, "%s: %v\n", str(v["vector_id"]), err)
			os.Exit(1)
		}
		r.VectorID = str(v["vector_id"])
		results = append(results, r)
	}
	mutationResults := []MutationResult{}
	mutationIndexPath := filepath.Join(*root, "test-vectors/i07/mutations/index.json")
	if mv, e := decodeJSONFile(mutationIndexPath); e == nil {
		for _, itv := range arr(obj(mv)["mutations"]) {
			it := obj(itv)
			vv, e := decodeJSONFile(filepath.Join(*root, str(it["path"])))
			if e != nil {
				panic(e)
			}
			m := obj(vv)
			_, e = verifyBundleSafe(tool, obj(m["bundle"]), trust, nil)
			if e == nil {
				mutationResults = append(mutationResults, MutationResult{MutationID: str(m["mutation_id"]), Status: "UNEXPECTED_PASS"})
			} else {
				mutationResults = append(mutationResults, MutationResult{MutationID: str(m["mutation_id"]), Status: "REJECT", Reason: e.Error()})
			}
		}
	}
	rejected := 0
	for _, m := range mutationResults {
		if m.Status == "REJECT" {
			rejected++
		}
	}
	status := "PASS"
	if len(mutationResults) > 0 && rejected != len(mutationResults) {
		status = "FAIL"
	}
	report := map[string]any{"schema_version": "epd2.pb01.i07-verifier-b-result/1", "verifier": "independent-go-verifier-b", "producer_imports": false, "wraps_verifier_a": false, "vector_count": fmt.Sprint(len(results)), "vector_results": results, "mutation_count": fmt.Sprint(len(mutationResults)), "mutations_rejected": fmt.Sprint(rejected), "mutation_results": mutationResults, "status": status}
	data, _ := json.MarshalIndent(report, "", "  ")
	data = append(data, '\n')
	if err = os.MkdirAll(filepath.Dir(filepath.Join(*root, *out)), 0755); err != nil {
		panic(err)
	}
	if err = os.WriteFile(filepath.Join(*root, *out), data, 0644); err != nil {
		panic(err)
	}
	fmt.Print(string(data))
	if status != "PASS" {
		os.Exit(1)
	}
}
