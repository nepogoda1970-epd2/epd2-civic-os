// PB01-I07 offline Verifier A CLI. Reads only local evidence/trust files.
import { createPublicKey } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { verifyBundle } from './i07_verifier_a.mjs';

function args(argv){
  const out={};
  for(let i=2;i<argv.length;i++){
    const a=argv[i];
    if(a==='--bundle'||a==='--trust'||a==='--guardians') out[a.slice(2)]=argv[++i];
    else throw new Error(`unknown argument: ${a}`);
  }
  if(!out.bundle||!out.trust) throw new Error('usage: node verifier/i07_offline_verify_a.mjs --bundle <bundle.json> --trust <trust-roots.json> [--guardians 1,2]');
  return out;
}

try {
  const a=args(process.argv);
  const bundle=JSON.parse(await readFile(resolve(a.bundle),'utf8'));
  const trustData=JSON.parse(await readFile(resolve(a.trust),'utf8'));
  if(trustData.schema_version!=='epd2.pb01.i07-trust-roots/1') throw new Error('TRUST_ROOT_SCHEMA');
  const trust=new Map(trustData.closure_authority_keys.map(k=>[
    k.key_id,
    createPublicKey({key:Buffer.from(k.public_key_spki_base64,'base64'),format:'der',type:'spki'})
  ]));
  const verificationGuardianIndices=a.guardians?a.guardians.split(',').filter(Boolean):null;
  const result=await verifyBundle(bundle,{trustRoots:trust,verificationGuardianIndices});
  console.log(JSON.stringify({verifier:'independent-node-verifier-a-offline',offline:true,...result}));
} catch (error) {
  console.error(JSON.stringify({verifier:'independent-node-verifier-a-offline',offline:true,status:'FAIL',reason:String(error?.message??error)}));
  process.exit(1);
}
