import { createPublicKey } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { verifyBundle } from './i07_verifier_a.mjs';
const root=new URL('../',import.meta.url);
const read=async p=>JSON.parse(await readFile(new URL(p,root),'utf8'));
const trustData=await read('verifier/i07-trust-roots.json');
const trust=new Map(trustData.closure_authority_keys.map(k=>[k.key_id,createPublicKey({key:Buffer.from(k.public_key_spki_base64,'base64'),format:'der',type:'spki'})]));
const idx=await read('test-vectors/i07/mutations/index.json');const results=[];
for(const x of idx.mutations){const m=await read(x.path);try{await verifyBundle(m.bundle,{trustRoots:trust});results.push({mutation_id:m.mutation_id,status:'UNEXPECTED_PASS'});}catch(e){results.push({mutation_id:m.mutation_id,status:'REJECT',reason:e?.message??String(e)});}}
const report={schema_version:'epd2.pb01.i07-mutation-verifier-a-result/1',verifier:'independent-node-verifier-a',mutation_count:results.length,rejected:results.filter(x=>x.status==='REJECT').length,results,status:results.every(x=>x.status==='REJECT')?'PASS':'FAIL'};
await mkdir(new URL('evidence/results/i07/',root),{recursive:true});await writeFile(new URL('evidence/results/i07/mutation-verifier-a.json',root),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));if(report.status!=='PASS')process.exit(1);
