# PB01-I07 Acceptance Report

## Classification

**PB01-I07 — ACCEPTED / Outcome A — I07 ESTABLISHED**

This is developer evidence for independent acceptance; it does not activate binding voting. `NON_BINDING_PILOT` remains unchanged.

## Results

- Positive I07 vectors: 4/4 PASS.
- Local/offline/static I07 tests: 12/12 PASS.
- Verifier A: 4/4 PASS.
- Verifier B: 4/4 PASS; 26/26 mutations REJECT.
- Mutation Verifier A: 26/26 REJECT.
- Cross-language byte agreement: PASS for all required digests/verdicts.
- PostgreSQL 16.14 / Node 24.19.0: 20/20 PASS.
- Concurrency/publication atomicity: PASS.
- CRASH publication points: 4/4 PASS.
- Privileged tamper classes: 10/10 PASS.
- Hard restart: PASS.
- Backup/restore: PASS; canonical bundle preserved and both verifiers PASS.
- Least privilege: PASS.
- Offline verification: PASS for both independent verifier implementations.
- Predecessor preservation: PASS; no semantic I01–I06 file changed.
- I06 C1 exact election-byte/ballot binding and `FOREIGN_ELECTION_BALLOT`: preserved byte-for-byte.
- Dependency changes: none.

## Result semantics

Outcome A means the published non-binding pilot result is independently reconstructable and verifiable from frozen public evidence without trusting the production application/database/publisher. It does not authorize binding political voting.

## C1 acceptance-harness closure

The acceptance harness was corrected without changing I07 cryptographic/result semantics or any I01–I06 semantics. A packaged PostgreSQL acceptance JSON is no longer sufficient. The PostgreSQL run emits a v2 one-time run-token/candidate/invocation-bound attestation. `validate:i07` requires exact Node v24.19.0 and a live PostgreSQL 16 binary; it either executes the real 20-test PostgreSQL gate itself or consumes exactly once a fresh (<=10 minutes) standalone `test:i07:postgres` result whose secret run token is not packaged. Local C1 sequence: `test:i07:postgres` 20/20 PASS, then `validate:i07` PASS. Wrong Node and missing PostgreSQL both fail non-zero.
