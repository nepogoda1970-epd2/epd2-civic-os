# I07 Developer Report

Candidate filename: `EPD2_VCRYPTO-PB01-I07_PUBLIC_RESULT_EVIDENCE_AND_INDEPENDENT_E2E_VERIFICATION_CANDIDATE_0.1.zip`

Accepted predecessor: `EPD2_VCRYPTO-PB01-I06_GUARDIAN_CEREMONY_AND_THRESHOLD_DECRYPTION_CANDIDATE_0.2_C1.zip`

Accepted predecessor SHA-256: `25114f10c95664e5145e4efc7c381aba4a2d9c3edc83760ee5e9bc72e55c532e`

Final candidate archive SHA-256 is supplied in the delivery response after archive creation. It cannot be self-embedded in the archive without changing the archive hash itself.

Environment: PostgreSQL 16.14; Node.js 24.19.0; Go 1.23.2; pinned Belenios 3.3.0.

Commands executed include the required I07 local tests, Verifier A, Verifier B, cross-language agreement and the full real PostgreSQL I07 battery. The candidate exposes the required npm commands in `package.json`.

Results: 12/12 local/offline/static tests PASS; 4/4 Verifier A vectors PASS; 4/4 Verifier B vectors PASS; 26/26 frozen mutations rejected by both paths; cross-language byte agreement PASS; PostgreSQL 20/20 PASS; publication concurrency PASS; CRASH 4/4 PASS; privileged tamper 10/10 PASS; hard restart PASS; backup/restore PASS; least privilege PASS.

Predecessor regression: all 547 accepted I06 C1 files remain present. Only `package.json` (I07 command registration) and the candidate `SHA256SUMS.txt` are allowed packaging-level predecessor-file changes; cryptographic/source/schema/migration/test-vector/verifier semantics from I01–I06 are byte-preserved. Compatible Node 24 regression suites: I03 28/28, I04 4/4, I05 8/8, I06 23/23 PASS. Accepted predecessor verifier/runtime evidence is preserved byte-for-byte.

Dependencies: no npm dependency changes; `package-lock.json` byte-identical; Go Verifier B standard-library-only; pinned Belenios unchanged.

Residual risks are documented in `I07_RESIDUAL_RISKS.md`. Exact outcome: **PB01-I07 — ACCEPTED / Outcome A — I07 ESTABLISHED**. System status remains `NON_BINDING_PILOT`.

## C1 acceptance-harness corrective

C1 changes acceptance/verification harness only. `test:i07:postgres` now creates invocation/token/candidate-bound PostgreSQL evidence; `validate:i07` rejects packaged stale evidence and either consumes one fresh one-time process-bound result or executes PostgreSQL itself. Exact Node `v24.19.0` and PostgreSQL 16.x are mandatory fail-closed runtime preconditions. Local C1 execution: PostgreSQL 16.14 `20/20 PASS`, followed by `validate:i07 PASS`; wrong Node and missing PostgreSQL both reject with exit 2. I07 crypto/result semantics and I01–I06 remain unchanged.
