# I07 Dependency Report

No npm runtime or development dependency was added, removed or upgraded. `package-lock.json` is byte-for-byte identical to accepted I06 C1. Existing npm dependencies remain resolved from the predecessor's vendored tarballs.

Verifier B adds no Go module dependency: it uses the Go 1.23 standard library only. Security-critical cryptographic group/tally/decryption verification continues to use the unchanged pinned Belenios 3.3.0 executable; no Belenios crypto patch is introduced.

Existing SBOM and license artifacts are preserved. Machine-readable dependency comparison is `evidence/results/i07/dependency-audit.json`.
