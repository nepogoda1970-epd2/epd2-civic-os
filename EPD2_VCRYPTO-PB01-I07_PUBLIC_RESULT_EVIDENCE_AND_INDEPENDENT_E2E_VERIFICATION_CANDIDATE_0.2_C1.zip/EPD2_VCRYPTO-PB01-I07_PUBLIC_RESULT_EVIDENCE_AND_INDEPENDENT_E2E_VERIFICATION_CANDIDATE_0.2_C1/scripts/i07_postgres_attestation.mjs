import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import { join, relative } from 'node:path';

export const REQUIRED_NODE_VERSION = 'v24.19.0';
export const PG_ACCEPTANCE_SCHEMA = 'epd2.pb01.i07-postgresql-acceptance/2';
export const PG_BINDING_DOMAIN = 'EPD2\0PB01\0I07\0POSTGRESQL_ACCEPTANCE_BINDING\x01';

const fixedGateFiles = [
  'package.json',
  'package-lock.json',
  'migrations/postgresql/009_i07_public_result.sql',
  'migrations/postgresql/010_i07_roles.sql',
  'scripts/i07_check_predecessor.mjs',
  'scripts/i07_cross_language_agreement.mjs',
  'scripts/i07_final_validate.mjs',
  'scripts/i07_postgres_attestation.mjs',
  'scripts/i07_validate_current_run.mjs',
  'scripts/run_i07_postgres_validation.sh',
  'tests/i07-mutations.test.mjs',
  'tests/i07-offline.test.mjs',
  'tests/i07-postgres-crash.test.mjs',
  'tests/i07-postgres-publication.test.mjs',
  'tests/i07-postgres-restart-backup.test.mjs',
  'tests/i07-postgres-tamper.test.mjs',
  'tests/i07-static-security.test.mjs',
  'tests/i07-vectors.test.mjs',
  'tests/i07_postgres_helpers.mjs',
  'verifier/i07-trust-roots.json',
  'verifier/i07_mutation_verifier_a.mjs',
  'verifier/i07_offline_verify_a.mjs',
  'verifier/i07_verifier_a.mjs',
  'verifier/reference-go-i07/main.go'
];

async function collect(dir, root, out) {
  for (const entry of await readdir(join(root, dir), { withFileTypes: true })) {
    const rel = join(dir, entry.name).replaceAll('\\', '/');
    if (entry.isDirectory()) await collect(rel, root, out);
    else if (entry.isFile()) out.push(rel);
  }
}

export async function computeGateDigest(root) {
  const files = [...fixedGateFiles];
  await collect('src/i07', root, files);
  files.sort();
  const h = createHash('sha256');
  h.update('EPD2\0PB01\0I07\0CURRENT_GATE_FILES\x01\0', 'utf8');
  for (const rel of files) {
    const bytes = await readFile(join(root, rel));
    const pathBytes = Buffer.from(rel, 'utf8');
    const len = Buffer.alloc(8); len.writeBigUInt64BE(BigInt(bytes.length));
    const plen = Buffer.alloc(4); plen.writeUInt32BE(pathBytes.length);
    h.update(plen); h.update(pathBytes); h.update(len); h.update(bytes);
  }
  return `sha256:${h.digest('hex')}`;
}

export function computeRunTokenDigest(token) {
  return `sha256:${createHash('sha256').update('EPD2\0PB01\0I07\0PG_RUN_TOKEN\x01\0','utf8').update(token,'utf8').digest('hex')}`;
}

export function computeBindingDigest(attestation) {
  const fields = [
    PG_ACCEPTANCE_SCHEMA,
    attestation.invocation_id,
    attestation.invocation_started_at_utc,
    attestation.completed_at_utc,
    attestation.candidate_gate_digest,
    attestation.run_token_digest,
    attestation.postgresql_version,
    attestation.node_version,
    String(attestation.fresh_clusters),
    attestation.migrations,
    String(attestation.test_count),
    String(attestation.pass_count),
    String(attestation.fail_count),
    attestation.status
  ];
  return `sha256:${createHash('sha256').update(PG_BINDING_DOMAIN, 'utf8').update('\0').update(fields.join('\n'), 'utf8').digest('hex')}`;
}

export function verifyCurrentInvocationAttestation(attestation, expected, nowMs = Date.now()) {
  const errors = [];
  if (attestation?.schema_version !== PG_ACCEPTANCE_SCHEMA) errors.push('POSTGRES_ATTESTATION_SCHEMA_MISMATCH');
  if (!expected?.invocationId || attestation?.invocation_id !== expected.invocationId) errors.push('POSTGRES_ATTESTATION_INVOCATION_MISMATCH');
  if (!expected?.startedAtUtc || attestation?.invocation_started_at_utc !== expected.startedAtUtc) errors.push('POSTGRES_ATTESTATION_START_MISMATCH');
  if (!expected?.gateDigest || attestation?.candidate_gate_digest !== expected.gateDigest) errors.push('POSTGRES_ATTESTATION_CANDIDATE_MISMATCH');
  if (!expected?.runToken || attestation?.run_token_digest !== computeRunTokenDigest(expected.runToken)) errors.push('POSTGRES_ATTESTATION_RUN_TOKEN_MISMATCH');
  if (attestation?.node_version !== REQUIRED_NODE_VERSION) errors.push('NODE_VERSION_MISMATCH');
  if (!String(attestation?.postgresql_version ?? '').includes('PostgreSQL) 16.')) errors.push('POSTGRESQL_16_REQUIRED');
  if (attestation?.test_count !== 20 || attestation?.pass_count !== 20 || attestation?.fail_count !== 0 || attestation?.status !== 'PASS') errors.push('POSTGRESQL_GATE_NOT_20_OF_20_PASS');
  if (attestation?.fresh_clusters !== 4 || attestation?.migrations !== '001-010 from zero per class') errors.push('POSTGRESQL_GATE_ENVIRONMENT_MISMATCH');
  const startMs = Date.parse(attestation?.invocation_started_at_utc ?? '');
  const doneMs = Date.parse(attestation?.completed_at_utc ?? '');
  if (!Number.isFinite(startMs) || !Number.isFinite(doneMs) || doneMs < startMs || doneMs > nowMs + 60_000 || nowMs - doneMs > 6 * 60 * 60 * 1000) errors.push('POSTGRES_ATTESTATION_NOT_FRESH');
  if (attestation?.invocation_binding_digest !== computeBindingDigest(attestation)) errors.push('POSTGRES_ATTESTATION_BINDING_DIGEST_MISMATCH');
  return { ok: errors.length === 0, errors };
}
