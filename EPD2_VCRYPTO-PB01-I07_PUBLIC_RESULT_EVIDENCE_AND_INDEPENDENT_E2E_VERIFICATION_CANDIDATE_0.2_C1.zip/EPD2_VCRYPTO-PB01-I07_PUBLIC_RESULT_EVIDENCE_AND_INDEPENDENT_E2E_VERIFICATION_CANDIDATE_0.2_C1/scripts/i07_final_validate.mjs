import { access, readFile, readdir, stat, writeFile, mkdir } from 'node:fs/promises';
import { join, relative } from 'node:path';
import { computeGateDigest, REQUIRED_NODE_VERSION, verifyCurrentInvocationAttestation } from './i07_postgres_attestation.mjs';
import { fileURLToPath } from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url));
const currentInvocationId=process.env.EPD2_I07_VALIDATION_INVOCATION_ID;
const currentInvocationStartedAt=process.env.EPD2_I07_VALIDATION_STARTED_AT_UTC;
const currentPgRunToken=process.env.EPD2_I07_VALIDATION_PG_RUN_TOKEN;
if(process.version!==REQUIRED_NODE_VERSION){console.error(`PB01-I07 final validation requires Node ${REQUIRED_NODE_VERSION}, got ${process.version}`);process.exit(2);}
if(!currentInvocationId||!currentInvocationStartedAt||!currentPgRunToken){console.error('PB01-I07 final validation refuses unbound/stale PostgreSQL evidence: current invocation identity is missing');process.exit(2);}
const read=async p=>JSON.parse(await readFile(join(root,p),'utf8'));
const exists=async p=>{try{await access(join(root,p));return true}catch{return false}};
async function walk(dir,out=[]){for(const e of await readdir(dir,{withFileTypes:true})){if(e.name==='node_modules'||e.name==='.git')continue;const p=join(dir,e.name);if(e.isDirectory())await walk(p,out);else out.push(p);}return out;}
const requiredDocs=['README_I07.md','I07_ACCEPTANCE_REPORT.md','I07_PUBLIC_RESULT_EVIDENCE.md','I07_INDEPENDENT_VERIFICATION.md','I07_POSTGRESQL_RUNTIME_EVIDENCE.md','I07_THREAT_MODEL.md','I07_RESIDUAL_RISKS.md','I07_DEPENDENCY_REPORT.md','I07_DEVELOPER_REPORT.md','I07_CHANGED_FILE_INVENTORY.csv'];
const [a,b,agree,mutA,pg,reg,dep]=await Promise.all([
  read('evidence/results/i07/verifier-a.json'),read('evidence/results/i07/verifier-b.json'),read('evidence/results/i07/cross-language-agreement.json'),read('evidence/results/i07/mutation-verifier-a.json'),read('evidence/results/i07/postgresql-acceptance.json'),read('evidence/results/i07/predecessor-regression-summary.json'),read('evidence/results/i07/dependency-audit.json')
]);
const index=await read('test-vectors/i07/index.json');const mutations=await read('test-vectors/i07/mutations/index.json');
const currentGateDigest=await computeGateDigest(root);
const pgInvocationVerification=verifyCurrentInvocationAttestation(pg,{invocationId:currentInvocationId,startedAtUtc:currentInvocationStartedAt,gateDigest:currentGateDigest,runToken:currentPgRunToken});
const files=await walk(root);const rels=files.map(p=>relative(root,p).replaceAll('\\','/'));
const privateFiles=rels.filter(p=>/\.(?:key|dkey|pem|p12|pfx)$/iu.test(p));
const i07RoleText=(await readFile(join(root,'migrations/postgresql/010_i07_roles.sql'),'utf8'))+(await readFile(join(root,'src/i07/postgres_publication_store.mjs'),'utf8'));
const forbiddenAuthority=['SUPER','GLOBAL'].map(x=>`${x}_ADMIN`);
const vectors=await Promise.all(index.vectors.map(v=>read(v.path)));
const scripts=JSON.parse(await readFile(join(root,'package.json'),'utf8')).scripts??{};
const checks={
  required_docs:(await Promise.all(requiredDocs.map(exists))).every(Boolean),
  positive_vectors:index.vectors.length===4&&vectors.every(v=>v.bundle?.pilot_status==='NON_BINDING_PILOT'),
  mutation_vectors:mutations.mutations.length===26&&mutA.status==='PASS'&&mutA.rejected===26&&String(b.mutations_rejected)==='26',
  verifier_a:a.status==='PASS'&&a.vector_count===4&&a.producer_imports===false,
  verifier_b:b.status==='PASS'&&String(b.vector_count)==='4'&&b.producer_imports===false&&b.wraps_verifier_a===false,
  cross_language:agree.status==='PASS'&&agree.byte_for_byte_agreement===true&&agree.vector_results.every(x=>x.byte_for_byte_agreement===true),
  postgres_16_node_24_19:pgInvocationVerification.ok,
  predecessor_regression:reg.status==='PASS'&&reg.semantic_regression_detected===false&&reg.i06_c1_election_ballot_binding_fix_preserved===true&&reg.foreign_election_ballot_guard_preserved===true,
  dependencies_unchanged:dep.status==='PASS'&&dep.package_lock_byte_identical===true&&dep.runtime_dependencies_changed===false&&dep.dev_dependencies_changed===false,
  offline_verification_commands:typeof scripts['verify:i07:a']==='string'&&typeof scripts['verify:i07:b']==='string'&&typeof scripts['test:i07']==='string'&&typeof scripts['test:i07:postgres']==='string'&&typeof scripts['validate:i07']==='string',
  no_guardian_private_material:privateFiles.length===0,
  no_universal_authority:!forbiddenAuthority.some(x=>i07RoleText.includes(x)),
  non_binding_pilot:vectors.every(v=>v.bundle?.pilot_status==='NON_BINDING_PILOT'&&v.bundle?.public_result?.pilot_status==='NON_BINDING_PILOT')
};
const status=Object.values(checks).every(Boolean)?'PASS':'FAIL';
const report={schema_version:'epd2.pb01.i07-final-validation/2',invocation_id:currentInvocationId,postgresql_attestation_errors:pgInvocationVerification.errors,checks,private_files:privateFiles,status,outcome:status==='PASS'?'PB01-I07 — ACCEPTED / Outcome A — I07 ESTABLISHED':'PB01-I07 — candidate defect'};
await mkdir(join(root,'evidence/results/i07'),{recursive:true});await writeFile(join(root,'evidence/results/i07/final-validation.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));if(status!=='PASS')process.exit(1);
