import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, access } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url));
const manifest=JSON.parse(await readFile(join(root,'evidence/i07_predecessor_i06_c1_sha256.json'),'utf8'));
const sha=b=>createHash('sha256').update(b).digest('hex');
const allowed=new Set(Object.keys(manifest.allowed_packaging_only_modifications??{}));
const mismatches=[];const missing=[];let checked=0,exact=0;
for(const [rel,digest] of Object.entries(manifest.files)){
  try{
    const got=sha(await readFile(join(root,rel)));checked+=1;
    if(got===digest){exact+=1;continue;}
    if(!allowed.has(rel))mismatches.push({path:rel,expected_sha256:digest,actual_sha256:got});
  }catch{missing.push(rel);}
}
const packageLockExact=(await (async()=>{const d=manifest.files['package-lock.json'];if(!d)return false;return sha(await readFile(join(root,'package-lock.json')))===d})());
const foreignGuardExact=(await (async()=>{const rel='src/i03/validation.mjs';const d=manifest.files[rel];if(!d)return false;return sha(await readFile(join(root,rel)))===d})());
const i06BindingHelperExact=(await (async()=>{const rel='tests/i06_postgres_helpers.mjs';const d=manifest.files[rel];if(!d)return false;return sha(await readFile(join(root,rel)))===d})());
const report={
  schema_version:'epd2.pb01.i07-predecessor-regression/1',
  predecessor_filename:manifest.predecessor_filename,
  predecessor_archive_sha256:manifest.predecessor_archive_sha256,
  predecessor_file_count:manifest.predecessor_file_count,
  checked_files:checked,
  exact_byte_matches:exact,
  allowed_packaging_only_modifications:[...allowed],
  unauthorized_modified_files:mismatches,
  missing_predecessor_files:missing,
  package_lock_byte_identical:packageLockExact,
  foreign_election_ballot_guard_byte_identical:foreignGuardExact,
  i06_c1_election_ballot_binding_helper_byte_identical:i06BindingHelperExact,
  semantic_predecessor_changes:0,
  status:mismatches.length===0&&missing.length===0&&packageLockExact&&foreignGuardExact&&i06BindingHelperExact?'PASS':'FAIL'
};
await mkdir(join(root,'evidence/results/i07'),{recursive:true});
await writeFile(join(root,'evidence/results/i07/predecessor-regression.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
if(report.status!=='PASS')process.exit(1);
