import { randomBytes } from 'node:crypto';
import { access, readFile, rename, rm } from 'node:fs/promises';
import { dirname, join, delimiter } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { computeGateDigest, computeRunTokenDigest, REQUIRED_NODE_VERSION, verifyCurrentInvocationAttestation } from './i07_postgres_attestation.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
if (process.version !== REQUIRED_NODE_VERSION) {
  console.error(`PB01-I07 validation requires Node ${REQUIRED_NODE_VERSION}, got ${process.version}`);
  process.exit(2);
}

let pgBin = process.env.EPD2_I07_PG_BIN;
if (!pgBin) {
  const probe = spawnSync('bash', ['-lc', 'command -v postgres'], { encoding: 'utf8' });
  if (probe.status === 0 && probe.stdout.trim()) pgBin = dirname(probe.stdout.trim());
}
if (!pgBin) {
  console.error('PB01-I07 environment blocker: PostgreSQL 16 bin directory not found. Set EPD2_I07_PG_BIN.');
  process.exit(2);
}
try { await access(join(pgBin, 'postgres')); } catch {
  console.error(`PB01-I07 environment blocker: postgres binary missing in ${pgBin}`);
  process.exit(2);
}
const pgVersion = spawnSync(join(pgBin, 'postgres'), ['--version'], { encoding: 'utf8' });
if (pgVersion.status !== 0 || !pgVersion.stdout.includes('PostgreSQL) 16.')) {
  console.error(`PB01-I07 environment blocker: PostgreSQL 16.x required, got ${(pgVersion.stdout || pgVersion.stderr).trim()}`);
  process.exit(2);
}

const gateDigest = await computeGateDigest(root);
const tokenPath = join(root, '.i07-current-pg-run-token.json');
const acceptancePath = join(root, 'evidence/results/i07/postgresql-acceptance.json');
let invocationId;
let startedAtUtc;
let runToken;
let reuseFreshPostgres = false;

try {
  const token = JSON.parse(await readFile(tokenPath, 'utf8'));
  const pg = JSON.parse(await readFile(acceptancePath, 'utf8'));
  const ageMs = Date.now() - Date.parse(token.completed_at_utc ?? '');
  const prelim = verifyCurrentInvocationAttestation(pg, {
    invocationId: token.invocation_id,
    startedAtUtc: pg.invocation_started_at_utc,
    gateDigest,
    runToken: token.run_token
  });
  const tokenMatches = token.schema_version === 'epd2.pb01.i07-pg-run-token/1' &&
    token.candidate_gate_digest === gateDigest &&
    token.acceptance_binding_digest === pg.invocation_binding_digest &&
    pg.run_token_digest === computeRunTokenDigest(token.run_token) &&
    Number.isFinite(ageMs) && ageMs >= 0 && ageMs <= 10 * 60 * 1000;
  if (prelim.ok && tokenMatches) {
    const claimed = `${tokenPath}.claimed-${process.pid}`;
    await rename(tokenPath, claimed);
    await rm(claimed, { force: true });
    invocationId = pg.invocation_id;
    startedAtUtc = pg.invocation_started_at_utc;
    runToken = token.run_token;
    reuseFreshPostgres = true;
    console.log(`[I07 current-run] consuming fresh one-time PostgreSQL 20/20 attestation ${invocationId}`);
  }
} catch {}

if (!reuseFreshPostgres) {
  invocationId = `i07-${randomBytes(32).toString('hex')}`;
  startedAtUtc = new Date().toISOString();
  runToken = randomBytes(32).toString('hex');
  await rm(acceptancePath, { force: true });
  await rm(tokenPath, { force: true });
}

const nodeDir = dirname(process.execPath);
const env = {
  ...process.env,
  PATH: `${nodeDir}${delimiter}${process.env.PATH ?? ''}`,
  EPD2_I07_NODE_BIN: process.execPath,
  EPD2_I07_PG_BIN: pgBin,
  EPD2_I07_VALIDATION_INVOCATION_ID: invocationId,
  EPD2_I07_VALIDATION_STARTED_AT_UTC: startedAtUtc,
  EPD2_I07_VALIDATION_GATE_DIGEST: gateDigest,
  EPD2_I07_VALIDATION_PG_RUN_TOKEN: runToken,
  EPD2_I07_VALIDATION_ORCHESTRATED: '1'
};

function run(command, args) {
  console.log(`\n[I07 current-run] ${command} ${args.join(' ')}`);
  const r = spawnSync(command, args, { cwd: root, env, stdio: 'inherit' });
  if (r.error) throw r.error;
  if (r.status !== 0) process.exit(r.status ?? 1);
}

run('npm', ['run', 'test:i07']);
run('npm', ['run', 'verify:i07:a']);
run('npm', ['run', 'verify:i07:b']);
run('npm', ['run', 'verify:i07:agreement']);
run(process.execPath, ['scripts/i07_check_predecessor.mjs']);
if (!reuseFreshPostgres) run('npm', ['run', 'test:i07:postgres']);
run(process.execPath, ['scripts/i07_final_validate.mjs']);
