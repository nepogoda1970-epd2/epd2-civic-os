#!/usr/bin/env bash
# PB01-I07 real PostgreSQL 16.x + exact Node 24.19.0 acceptance harness. No mocks.
set -euo pipefail
candidate_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
pg_bin="${EPD2_I07_PG_BIN:?set EPD2_I07_PG_BIN to PostgreSQL 16.x bin directory}"
node_bin="${EPD2_I07_NODE_BIN:-node}"
base_port="${EPD2_I07_PG_TEST_PORT:-$((56000 + RANDOM % 7000))}"
pg_user="$(id -un)"
if [ "$(id -u)" -eq 0 ]; then echo 'initdb refuses root; run under an unprivileged account' >&2; exit 77; fi
pg_version="$($pg_bin/postgres --version)"; node_version="$($node_bin --version)"
echo "$pg_version"; echo "Node.js $node_version"
case "$pg_version" in *"PostgreSQL) 16."*) ;; *) echo "I07 requires PostgreSQL 16.x" >&2; exit 2;; esac
if [ "$node_version" != "v24.19.0" ]; then echo "I07 acceptance requires Node v24.19.0, got $node_version" >&2; exit 2; fi
invocation_id="${EPD2_I07_VALIDATION_INVOCATION_ID:-i07-standalone-$($node_bin -e "process.stdout.write(require('node:crypto').randomBytes(32).toString('hex'))")}" 
invocation_started_at="${EPD2_I07_VALIDATION_STARTED_AT_UTC:-$(date -u +%Y-%m-%dT%H:%M:%S.000Z)}"
run_token="${EPD2_I07_VALIDATION_PG_RUN_TOKEN:-$($node_bin -e "process.stdout.write(require('node:crypto').randomBytes(32).toString('hex'))")}"
run_token_digest="$($node_bin -e "import('./scripts/i07_postgres_attestation.mjs').then(m=>process.stdout.write(m.computeRunTokenDigest(process.argv[1])))" "$run_token")"
gate_digest="$($node_bin -e "import('./scripts/i07_postgres_attestation.mjs').then(async m=>process.stdout.write(await m.computeGateDigest(process.cwd())))")"
if [ -n "${EPD2_I07_VALIDATION_GATE_DIGEST:-}" ] && [ "$gate_digest" != "$EPD2_I07_VALIDATION_GATE_DIGEST" ]; then echo "I07 candidate gate digest changed during validation" >&2; exit 4; fi

total=0; passed=0
run_class(){
 local name="$1" file="$2" expected="$3" offset="$4" work pgdata opts tap rc tests pass fail port
 port=$((base_port+offset))
 work="$(mktemp -d "${TMPDIR:-/tmp}/epd2-i07-pg-${name}.XXXXXX")"; pgdata="$work/data"; tap="$work/tap.log"
 opts="-c listen_addresses=127.0.0.1 -c port=$port -c unix_socket_directories='' -c fsync=on -c synchronous_commit=on -c full_page_writes=on"
 cleanup(){ "$pg_bin/pg_ctl" -D "$pgdata" -m immediate stop >/dev/null 2>&1 || true; rm -rf "$work"; }; trap cleanup RETURN
 "$pg_bin/initdb" -D "$pgdata" --no-locale --encoding=UTF8 --auth-local=trust --auth-host=trust >"$work/initdb.log"
 "$pg_bin/pg_ctl" -D "$pgdata" -o "$opts" -l "$work/postgres.log" -w start
 "$pg_bin/createdb" -h 127.0.0.1 -p "$port" -U "$pg_user" epd2_i07_test
 for m in 001_i03_submission_ledger 002_i03_roles 003_i04_finalization 004_i04_roles 005_i05_tally 006_i05_roles 007_i06_guardian_decryption 008_i06_roles 009_i07_public_result 010_i07_roles; do "$pg_bin/psql" -X -q -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i07_test -f "$candidate_root/migrations/postgresql/$m.sql" >/dev/null; done
 "$pg_bin/psql" -X -q -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i07_test >/dev/null <<'SQL'
CREATE ROLE epd2_i03_runtime_test LOGIN PASSWORD 'runtime-test-only' IN ROLE epd2_pb01_submission_runtime;
CREATE ROLE epd2_i03_evidence_test LOGIN PASSWORD 'evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
CREATE ROLE epd2_i04_finalizer_test LOGIN PASSWORD 'finalizer-test-only' IN ROLE epd2_pb01_finalization_runtime;
CREATE ROLE epd2_i04_evidence_test LOGIN PASSWORD 'i04-evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
CREATE ROLE epd2_i05_tally_test LOGIN PASSWORD 'tally-test-only' IN ROLE epd2_pb01_tally_runtime;
CREATE ROLE epd2_i05_evidence_test LOGIN PASSWORD 'i05-evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
CREATE ROLE epd2_i06_coordinator_test LOGIN PASSWORD 'coordinator-test-only' IN ROLE epd2_pb01_guardian_coordinator;
CREATE ROLE epd2_i06_ingester_test LOGIN PASSWORD 'ingester-test-only' IN ROLE epd2_pb01_guardian_ingester;
CREATE ROLE epd2_i06_finalizer_test LOGIN PASSWORD 'decrypt-finalizer-test-only' IN ROLE epd2_pb01_decryption_finalizer;
CREATE ROLE epd2_i06_reader_test LOGIN PASSWORD 'i06-reader-test-only' IN ROLE epd2_pb01_i06_runtime_reader;
CREATE ROLE epd2_i07_publisher_test LOGIN PASSWORD 'publisher-test-only' IN ROLE epd2_pb01_result_publisher;
CREATE ROLE epd2_i07_verifier_test LOGIN PASSWORD 'verifier-test-only' IN ROLE epd2_pb01_public_verifier;
SQL
 export EPD2_I03_PG_ADMIN_URL="postgresql://$pg_user@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I03_PG_RUNTIME_URL="postgresql://epd2_i03_runtime_test:runtime-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I03_PG_EVIDENCE_URL="postgresql://epd2_i03_evidence_test:evidence-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I04_PG_FINALIZER_URL="postgresql://epd2_i04_finalizer_test:finalizer-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I04_PG_EVIDENCE_URL="postgresql://epd2_i04_evidence_test:i04-evidence-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I05_PG_TALLY_URL="postgresql://epd2_i05_tally_test:tally-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I05_PG_EVIDENCE_URL="postgresql://epd2_i05_evidence_test:i05-evidence-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I06_PG_COORDINATOR_URL="postgresql://epd2_i06_coordinator_test:coordinator-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I06_PG_INGESTER_URL="postgresql://epd2_i06_ingester_test:ingester-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I06_PG_FINALIZER_URL="postgresql://epd2_i06_finalizer_test:decrypt-finalizer-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I06_PG_READER_URL="postgresql://epd2_i06_reader_test:i06-reader-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I07_PG_PUBLISHER_URL="postgresql://epd2_i07_publisher_test:publisher-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I07_PG_VERIFIER_URL="postgresql://epd2_i07_verifier_test:verifier-test-only@127.0.0.1:$port/epd2_i07_test"
 export EPD2_I03_PG_PORT="$port" EPD2_I03_PG_DUMP_PATH="$pg_bin/pg_dump" EPD2_I03_PG_RESTORE_PATH="$pg_bin/pg_restore" EPD2_I03_PG_CREATEDB_PATH="$pg_bin/createdb" EPD2_I03_PG_DROPDB_PATH="$pg_bin/dropdb"
 export EPD2_I05_PG_CTL_PATH="$pg_bin/pg_ctl" EPD2_I05_PG_DATA_DIR="$pgdata" EPD2_I05_PG_START_OPTIONS="$opts" EPD2_I06_PG_CTL_PATH="$pg_bin/pg_ctl" EPD2_I06_PG_DATA_DIR="$pgdata" EPD2_I06_PG_START_OPTIONS="$opts"
 echo "I07/PG class $name: fresh PostgreSQL 16 cluster; migrations 001-010"
 cd "$candidate_root"; set +e; "$node_bin" --test --test-force-exit --test-concurrency=1 "$file" 2>&1 | tee "$tap"; rc=${PIPESTATUS[0]}; set -e
 if [ "$rc" -ne 0 ]; then echo "I07/PG $name FAIL" >&2; return "$rc"; fi
 tests="$(awk '$2=="tests"{x=$3} END{print x+0}' "$tap")";pass="$(awk '$2=="pass"{x=$3} END{print x+0}' "$tap")";fail="$(awk '$2=="fail"{x=$3} END{print x+0}' "$tap")"
 if [ "$tests" -ne "$expected" ] || [ "$pass" -ne "$expected" ] || [ "$fail" -ne 0 ]; then echo "I07/PG $name expected $expected PASS, got tests=$tests pass=$pass fail=$fail" >&2; return 3; fi
 total=$((total+tests)); passed=$((passed+pass));
 mkdir -p "$candidate_root/evidence/results/i07"
 cat > "$candidate_root/evidence/results/i07/postgresql-${name}.json" <<JSON
{
  "schema_version": "epd2.pb01.i07-postgresql-class/1",
  "class": "$name",
  "postgresql_version": "$pg_version",
  "node_version": "$node_version",
  "fresh_cluster": true,
  "migrations": "001-010 from zero",
  "test_count": $tests,
  "pass_count": $pass,
  "fail_count": $fail,
  "status": "PASS"
}
JSON
 echo "I07/PG class $name: $pass/$tests PASS"
}
only_class="${EPD2_I07_PG_CLASS:-all}"
if [ "$only_class" = all ] || [ "$only_class" = publication-and-roles ]; then run_class publication-and-roles tests/i07-postgres-publication.test.mjs 4 0; fi
if [ "$only_class" = all ] || [ "$only_class" = crash-consistency ]; then run_class crash-consistency tests/i07-postgres-crash.test.mjs 4 1; fi
if [ "$only_class" = all ] || [ "$only_class" = privileged-tamper ]; then run_class privileged-tamper tests/i07-postgres-tamper.test.mjs 10 2; fi
if [ "$only_class" = all ] || [ "$only_class" = restart-and-backup ]; then run_class restart-and-backup tests/i07-postgres-restart-backup.test.mjs 2 3; fi
mkdir -p "$candidate_root/evidence/results/i07"
if [ "$only_class" = all ]; then
 completed_at="$(date -u +%Y-%m-%dT%H:%M:%S.000Z)"
 tmp_attestation="$candidate_root/evidence/results/i07/postgresql-acceptance.tmp.json"
 cat > "$tmp_attestation" <<JSON
{
  "schema_version": "epd2.pb01.i07-postgresql-acceptance/2",
  "invocation_id": "$invocation_id",
  "invocation_started_at_utc": "$invocation_started_at",
  "completed_at_utc": "$completed_at",
  "candidate_gate_digest": "$gate_digest",
  "run_token_digest": "$run_token_digest",
  "postgresql_version": "$pg_version",
  "node_version": "$node_version",
  "fresh_clusters": 4,
  "migrations": "001-010 from zero per class",
  "test_count": $total,
  "pass_count": $passed,
  "fail_count": 0,
  "status": "PASS"
}
JSON
 binding_digest="$($node_bin -e "import('./scripts/i07_postgres_attestation.mjs').then(async m=>{const fs=await import('node:fs/promises');const a=JSON.parse(await fs.readFile(process.argv[1],'utf8'));process.stdout.write(m.computeBindingDigest(a))})" "$tmp_attestation")"
 $node_bin -e "import('node:fs/promises').then(async fs=>{const p=process.argv[1],out=process.argv[2],digest=process.argv[3];const a=JSON.parse(await fs.readFile(p,'utf8'));a.invocation_binding_digest=digest;await fs.writeFile(out,JSON.stringify(a,null,2)+'\n');await fs.rm(p,{force:true})})" "$tmp_attestation" "$candidate_root/evidence/results/i07/postgresql-acceptance.json" "$binding_digest"
 if [ "${EPD2_I07_VALIDATION_ORCHESTRATED:-0}" != "1" ]; then
   umask 077
   cat > "$candidate_root/.i07-current-pg-run-token.json" <<TOKENJSON
{
  "schema_version": "epd2.pb01.i07-pg-run-token/1",
  "invocation_id": "$invocation_id",
  "run_token": "$run_token",
  "candidate_gate_digest": "$gate_digest",
  "acceptance_binding_digest": "$binding_digest",
  "completed_at_utc": "$completed_at"
}
TOKENJSON
 fi
fi
echo "PB01-I07 PostgreSQL acceptance: $passed/$total PASS"
