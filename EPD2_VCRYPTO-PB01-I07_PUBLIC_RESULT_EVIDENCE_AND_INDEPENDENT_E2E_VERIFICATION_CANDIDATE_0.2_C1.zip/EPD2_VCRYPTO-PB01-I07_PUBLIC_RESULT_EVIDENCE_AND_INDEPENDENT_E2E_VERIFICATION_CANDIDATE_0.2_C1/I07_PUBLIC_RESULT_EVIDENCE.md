# I07 Public Result Evidence

## Canonical result

`epd2.pb01.public-result/1` binds the human/API-visible result to the exact accepted chain. Its domain-separated digest uses `epd2.pb01.public-result.v1` over the accepted restricted canonical serialization. The result includes election identity, authoritative election-byte digest/fingerprint, I04 `F_final`, I05 tally and aggregate digests, I06 ceremony/decryption/plaintext digests, the plaintext result array, and `NON_BINDING_PILOT`.

## Public evidence bundle

`epd2.pb01.public-result-evidence-bundle/1` includes the exact public material required for offline verification: authoritative election public bytes; I04 public final evidence; I05 tally evidence and exact aggregate bytes; the I06 ceremony; accepted public partial-decryption shares/proofs; the threshold decryption record; the deterministic public result; and the Belenios decryption base archive required for upstream-compatible independent recomputation. Its domain-separated digest is `epd2.pb01.public-result-evidence.v1`.

No guardian secret key, voter identity, credential secret, lifecycle mapping, IP address, analytics identifier or administrator secret is included.

## Byte semantics

Predecessor byte semantics are reused exactly. Authoritative election bytes are the exact persisted Belenios election bytes accepted by I06 C1. No newline, whitespace, Unicode or JSON normalization is applied to predecessor byte commitments. I07 canonicalization is used only for the newly introduced I07 result and bundle objects. Exact upstream aggregate/archive/share byte fields are transported base64url and verified by byte digest before use.

## Cross-object binding

Verification checks election identity across I04/I05/I06/I07; `F_final` and final-set references across I04/I05/I06/result; aggregate bytes and digest across I05/I06/result; ceremony and guardian membership; threshold share digests and proofs; plaintext reconstruction and digest; decryption record; public result; and the final bundle digest. Missing or ambiguous evidence fails closed.
