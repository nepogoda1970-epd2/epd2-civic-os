# PB01-I07 — Public Result Evidence & Independent End-to-End Verification

Status target: **PB01-I07 — ACCEPTED / Outcome A — I07 ESTABLISHED**.

Accepted predecessor: `EPD2_VCRYPTO-PB01-I06_GUARDIAN_CEREMONY_AND_THRESHOLD_DECRYPTION_CANDIDATE_0.2_C1.zip`, SHA-256 `25114f10c95664e5145e4efc7c381aba4a2d9c3edc83760ee5e9bc72e55c532e`.

I07 adds a deterministic `PublicResult`, a canonical public evidence bundle, immutable PostgreSQL publication state, offline Verifier A, independent Go Verifier B, positive and mutation vectors, and production-style PostgreSQL publication/crash/tamper/restart/restore tests. I01–I06 cryptographic semantics are not reopened. The accepted I06 C1 election-byte binding and `FOREIGN_ELECTION_BALLOT` check are preserved byte-for-byte.

The public verification chain is:

`I04 F_final → I05 accepted aggregate → I06 frozen ceremony/shares/decryption → I07 PublicResult → PublicResultEvidenceBundle`.

The published status remains **`NON_BINDING_PILOT`**. I07 does not activate binding political voting.

Required commands:

```text
npm run test:i07
npm run verify:i07:a
npm run verify:i07:b
npm run test:i07:postgres
npm run validate:i07
```

`test:i07:postgres` requires an unprivileged process, PostgreSQL 16.x via `EPD2_I07_PG_BIN`, and Node v24.19.0 via `EPD2_I07_NODE_BIN` or PATH. The acceptance run recorded in this package used PostgreSQL 16.14, Node 24.19.0 and Go 1.23.2.

Offline auditors can verify downloaded frozen evidence without contacting a production API using `verifier/i07_offline_verify_a.mjs` or Go Verifier B `--bundle` mode.
