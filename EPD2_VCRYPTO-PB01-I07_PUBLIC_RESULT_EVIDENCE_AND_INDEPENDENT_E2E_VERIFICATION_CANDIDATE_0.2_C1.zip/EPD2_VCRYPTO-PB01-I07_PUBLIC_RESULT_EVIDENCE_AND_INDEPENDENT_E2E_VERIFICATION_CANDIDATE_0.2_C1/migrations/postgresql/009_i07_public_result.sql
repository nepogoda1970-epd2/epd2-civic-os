BEGIN;
CREATE SCHEMA IF NOT EXISTS pb01_i07;
CREATE TABLE pb01_i07.result_publications(
  election_instance_id text PRIMARY KEY REFERENCES pb01_i06.decryption_records(election_instance_id),
  decryption_record_digest char(64) NOT NULL CHECK(decryption_record_digest ~ '^[0-9a-f]{64}$'),
  public_result_digest char(64) NOT NULL UNIQUE CHECK(public_result_digest ~ '^[0-9a-f]{64}$'),
  public_evidence_bundle_digest char(64) NOT NULL UNIQUE CHECK(public_evidence_bundle_digest ~ '^[0-9a-f]{64}$'),
  public_result_canonical text NOT NULL CHECK(public_result_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  public_evidence_canonical text NOT NULL CHECK(public_evidence_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  publication_state text NOT NULL CHECK(publication_state IN ('DRAFT','EVIDENCE_PERSISTED','FINAL')),
  committed_at timestamptz NOT NULL,
  finalized_at timestamptz,
  CHECK((publication_state='FINAL')=(finalized_at IS NOT NULL))
);
CREATE OR REPLACE FUNCTION pb01_i07.reject_final_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN IF OLD.publication_state='FINAL' THEN RAISE EXCEPTION 'I07_FINAL_IMMUTABLE'; END IF; IF TG_OP='DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF; END $$;
CREATE TRIGGER i07_final_immutable BEFORE UPDATE OR DELETE ON pb01_i07.result_publications FOR EACH ROW EXECUTE FUNCTION pb01_i07.reject_final_mutation();
CREATE VIEW pb01_i07.public_results AS
SELECT election_instance_id,decryption_record_digest,public_result_digest,public_evidence_bundle_digest,public_result_canonical,public_evidence_canonical,finalized_at
FROM pb01_i07.result_publications WHERE publication_state='FINAL';
COMMIT;
