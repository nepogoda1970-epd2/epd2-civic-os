# C1 → C2 classified inventory

| C1 area | C2 classification | Resolution |
| --- | --- | --- |
| `.ruff_cache/` | excluded transient | Not copied; package validator rejects cache directories. |
| Rebased source changes | rebased functional delta | Applied only to canonical V25 checkout. |
| Public IA pages | retained and expanded | Eight indexes and six guarded detail fixtures. |
| Locale selector | corrected | URL-only state, direct EN, fallback and navigation preservation. |
| FRONT-00/01 snapshots | immutable inherited evidence | Not regenerated for C2. |
| C1 browser reporting | replaced | `front02.browser.spec.ts` is separately scoped. |
| C1 documents | superseded where stale | This C2 inventory and governed CSV are authoritative C2 references. |

Classification complete: `unclassified=0`.
