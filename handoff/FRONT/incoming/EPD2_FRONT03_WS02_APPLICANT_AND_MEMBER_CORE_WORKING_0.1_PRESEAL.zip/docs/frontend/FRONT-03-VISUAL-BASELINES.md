# FRONT-03 Visual Baselines

FRONT-03 reuses the accepted FRONT-00/01/02 tokens and shell geometry. No governed Design Change Decision is introduced. New WS-02 elements use existing `card`, `notice`, `button`, status-badge, spacing, radius and focus tokens.

High-value visual states to capture in governed browser verification:

- Applicant `/member/application` desktop and mobile;
- Member `/member/home` desktop and mobile;
- `/member/membership`;
- `/member/initiatives` and `/member/initiatives/new` draft/preview/blocked-terminal state;
- `/member/assurance/authentication-session-assurance` blocked state;
- `/member/membership/appeal` blocked state.

A baseline is not accepted merely by regenerating a screenshot. Any unexpected drift relative to accepted FRONT-00/01/02 geometry requires investigation; an intentional visual-language change requires a separate governed Design Change Decision.
