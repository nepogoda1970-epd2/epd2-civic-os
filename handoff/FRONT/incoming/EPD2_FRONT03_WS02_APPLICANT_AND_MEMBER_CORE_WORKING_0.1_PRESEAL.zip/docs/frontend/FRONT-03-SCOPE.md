# FRONT-03 Scope — WS-02 Applicant & Member Core

**Status:** `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`

FRONT-03 extends the exact accepted FRONT-02 C2.1 implementation baseline into a production-shaped WS-02 presentation layer. It does not close FRONT, does not self-accept, does not claim production readiness or legal activation, and does not create a competing API-02 authentication/session runtime.

## Included

- restricted Applicant account at `/member/application`;
- Member Core home, membership, initiatives, deliberation and delegation surfaces;
- session-assurance UI contract behind an API-02-owned typed port;
- Applicant membership-appeal state contract, kept `BLOCKED`;
- server-authorized organization-scope presentation and stale-context invalidation;
- one-time voting-handoff type with no persistent member/account/person identifier;
- DE/EN shell control without route/authority changes;
- fail-closed runtime adapter selection and governed test-only fixtures.

## Explicit exclusions

No ballot/cast/tally UI, no WS-07 Applicant credential, no universal user identifier, no browser-persisted bearer authority, no cross-workspace cookie/storage bridge, no member authority inferred from local state, no administrative membership approval, and no invented delegation/legal semantics.

## Entering authority

Current main at bootstrap: `9e86543c0c199cf1c56acb02f42fd348cf14200e`. Exact technical predecessor: `EPD2_FRONT02_IMPLEMENTATION_CANDIDATE_0.1_C2.1_2026-08-30.zip`, SHA-256 `aaf980a2cd3b3b06d48218adaa68d109c8770e6abfcbef230197b51a87006179`. Current Master V25 SHA-256: `895cf4186b88da74721f95d07ccdd6102a339a80d95ed19701e1695f5f7b4934`.
