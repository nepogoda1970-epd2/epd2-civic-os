# FRONT-03 API-02 Reconciliation Points

API-02 remains `ACTIVE / IN DEVELOPMENT` and solely owns human authentication, session, assurance and recovery runtime. FRONT-03 therefore leaves the final HTTP adapter fail-closed.

After exact independent API-02 acceptance, reconcile only against the accepted bytes and prove:

1. login/session bootstrap into WS-02;
2. Applicant principal cannot become Member through frontend/local state;
3. session expiry and revocation invalidate protected dynamic state;
4. exact step-up ceremony/result binding for consequential actions;
5. device/session inventory and revocation operations;
6. organization-scope reauthorization and stale-context clearing;
7. protected-route refusal with no record-existence leak;
8. one-time voting handoff without Member session or persistent member/account ID;
9. host-only Secure HttpOnly session cookies and no auth material in persistent browser storage.

Reference operations visible in inherited executable source (`identity-service/service_api.py`) are contract-level/reference evidence only and are **not** treated as the final accepted API-02 HTTP contract.
