# FRONT-02 C2 page catalogue

`FRONT-02-PAGE-CATALOGUE.csv` is the machine-readable source for the C2 public
information architecture. Every row names a path, owning workspace, visibility,
authority and scope boundary, dependency, locale behaviour and whether its
content is an illustrative fixture. It is deliberately a catalogue of
renditions, not an assertion that a protected record, login or workflow exists.

Known two-segment fixture slugs render a dated, categorised, issued,
version/correction-marked and provenance-marked public detail. Unknown slugs
return 404. Protected records have no public row and cannot be discovered by
the illustrative search fixture.

The ten workspace shells remain separately governed in
`foundation/workspaces.ts`; the FRONT-02 state-and-shell catalogue gives each a
separate read-only visual representation at `/foundation/front02`.
