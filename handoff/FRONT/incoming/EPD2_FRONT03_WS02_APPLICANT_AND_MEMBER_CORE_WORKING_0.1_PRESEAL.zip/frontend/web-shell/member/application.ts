import type { Front03Ports } from "./ports";
import { MEMBER_ONLY_PREFIXES } from "./policy";
import type { ActorRole, OrganizationScope, SafeError } from "./types";

export function authorizeFront03Route(route: string, actor: ActorRole): SafeError | null {
  if (actor === "Applicant" && MEMBER_ONLY_PREFIXES.some((prefix) => route === prefix || route.startsWith(`${prefix}/`))) {
    return {
      state: "forbidden",
      reason: "Diese Seite ist im aktuellen Kontotyp nicht verfügbar.",
      retryAllowed: false,
      leaksRecordExistence: false,
    };
  }
  return null;
}

export function mapFront03Error(error: unknown): SafeError {
  const code = error instanceof Error ? error.message : "UNKNOWN";
  const mapping: Record<string, SafeError> = {
    VALIDATION_ERROR: { state: "validation_error", reason: "Eingaben prüfen.", retryAllowed: true, leaksRecordExistence: false },
    STALE_VERSION: { state: "conflict", reason: "Die Ansicht ist veraltet. Neu laden und erneut prüfen.", retryAllowed: true, leaksRecordExistence: false },
    SCOPE_FORBIDDEN: { state: "forbidden", reason: "Organisationsbereich nicht verfügbar.", retryAllowed: false, leaksRecordExistence: false },
    FRONT03_DEPENDENCY_UNAVAILABLE_FAIL_CLOSED: { state: "dependency_unavailable", reason: "Die erforderliche Laufzeit-Schnittstelle ist noch nicht freigegeben.", retryAllowed: true, leaksRecordExistence: false },
  };
  return mapping[code] ?? { state: "dependency_unavailable", reason: "Vorgang kann derzeit nicht autoritativ bestätigt werden.", retryAllowed: true, leaksRecordExistence: false };
}

export class ScopeContextGuard {
  private generation = 0;
  private current: OrganizationScope | null = null;

  get activeScope() { return this.current; }

  async switchScope(port: Pick<Front03Ports, "reauthorizeScope">, scopeId: string) {
    const requestGeneration = ++this.generation;
    this.current = null; // clear incompatible/stale protected context immediately
    const scope = await port.reauthorizeScope(scopeId);
    if (requestGeneration !== this.generation) throw new Error("STALE_SCOPE_RESPONSE");
    this.current = scope;
    return scope;
  }

  invalidate() {
    this.generation += 1;
    this.current = null;
  }
}
