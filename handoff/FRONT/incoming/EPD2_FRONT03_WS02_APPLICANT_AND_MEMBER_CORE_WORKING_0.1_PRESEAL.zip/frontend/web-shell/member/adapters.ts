import type { Front03Ports } from "./ports";
import { FixtureFront03Adapter } from "./fixtures";
import { assertFront03GovernancePolicy } from "./policy";

export type Front03AdapterMode = "fixture-test" | "runtime-http" | "fail-closed";

export function resolveFront03AdapterMode(env: NodeJS.ProcessEnv): Front03AdapterMode {
  const requested = env.EPD2_FRONT03_ADAPTER;
  const governedTest = env.EPD2_FRONT03_GOVERNED_TEST_CONTEXT === "1";
  if (requested === "fixture-test") {
    if (!governedTest) throw new Error("FRONT03_FIXTURE_NOT_ALLOWED_OUTSIDE_GOVERNED_TEST");
    return "fixture-test";
  }
  if (requested === "runtime-http") {
    if (env.EPD2_API02_ACCEPTED_CONTRACT_IDENTITY !== "accepted-exact-bytes") {
      return "fail-closed";
    }
    return "runtime-http";
  }
  return "fail-closed";
}

class FailClosedFront03Adapter implements Front03Ports {
  private unavailable(): never {
    throw new Error("FRONT03_DEPENDENCY_UNAVAILABLE_FAIL_CLOSED");
  }
  readOwnApplication() { return Promise.reject(this.unavailable()); }
  readOwnAppeal() { return Promise.reject(this.unavailable()); }
  readHome() { return Promise.reject(this.unavailable()); }
  readMembership() { return Promise.reject(this.unavailable()); }
  listInitiatives() { return Promise.reject(this.unavailable()); }
  commitInitiative() { return Promise.reject(this.unavailable()); }
  listDeliberation() { return Promise.reject(this.unavailable()); }
  readDelegation() { return Promise.reject(this.unavailable()); }
  listAuthorizedScopes() { return Promise.reject(this.unavailable()); }
  reauthorizeScope() { return Promise.reject(this.unavailable()); }
  readSessionAssurance() { return Promise.reject(this.unavailable()); }
  createHandoff() { return Promise.reject(this.unavailable()); }
  supportEntry() { return Promise.reject(this.unavailable()); }
}

class UnreconciledHttpAdapter extends FailClosedFront03Adapter {
  // Intentionally contains no network request implementation. Exact API-02 bytes must be
  // accepted and reconciled before an HTTP runtime adapter can be authored.
}

export function createFront03Adapter(env: NodeJS.ProcessEnv): Front03Ports {
  assertFront03GovernancePolicy();
  const mode = resolveFront03AdapterMode(env);
  if (mode === "fixture-test") return new FixtureFront03Adapter();
  if (mode === "runtime-http") return new UnreconciledHttpAdapter();
  return new FailClosedFront03Adapter();
}
