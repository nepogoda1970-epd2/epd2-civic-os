"use client";

import Link from "next/link";
import { useMemo, useRef, useState } from "react";

import type { Front03PageData } from "../../member/view-model";
import { APPLICANT_NAVIGATION, MEMBER_NAVIGATION } from "../../member/policy";
import type { ActorRole, Locale, OrganizationScope } from "../../member/types";

type PageData<K extends Front03PageData["kind"]> = Extract<Front03PageData, { kind: K }>["data"];

const copy = {
  de: {
    fixture: "GOVERNED TEST FIXTURE · NICHT PRODUKTIV",
    applicant: "Antragstellerkonto",
    member: "Mitgliederbereich",
    status: "Status",
    provenance: "Herkunft",
    dependency: "Abhängigkeit",
    blocked: "Nicht aktiviert",
    unavailable: "Autoritative Laufzeit nicht verfügbar",
  },
  en: {
    fixture: "GOVERNED TEST FIXTURE · NON-PRODUCTION",
    applicant: "Applicant account",
    member: "Member workspace",
    status: "Status",
    provenance: "Provenance",
    dependency: "Dependency",
    blocked: "Not activated",
    unavailable: "Authoritative runtime unavailable",
  },
} as const;

function StatusPill({ status }: { status: string }) {
  return <span className="status-badge" data-front03-status={status}>{status}</span>;
}

function SafeErrorPanel({ data }: { data: PageData<"safe-error"> }) {
  return (
    <section className="member-state member-state--error" role="alert" aria-live="assertive">
      <p className="section-kicker">{data.state}</p>
      <h1>Seite nicht verfügbar</h1>
      <p>{data.reason}</p>
      <p>Es werden keine Angaben darüber offengelegt, ob ein geschützter Datensatz existiert.</p>
      {data.retryAllowed ? <button className="button button--secondary" type="button">Erneut prüfen</button> : null}
    </section>
  );
}

function ApplicantPage({ data }: { data: PageData<"application"> }) {
  return (
    <>
      <header className="member-page-header">
        <div><p className="section-kicker">Applicant · restricted account</p><h1>Mitgliedsantrag</h1></div>
        <StatusPill status={data.status} />
      </header>
      <section className="member-grid" aria-label="Antragsübersicht">
        <article className="card"><h2>Antrag</h2><dl className="metadata-list"><div><dt>ID</dt><dd>{data.applicationId}</dd></div><div><dt>Eingereicht</dt><dd>{data.submittedAt}</dd></div><div><dt>Zuständige Stelle</dt><dd>{data.competentUnit}</dd></div><div><dt>Verfahrensstufe</dt><dd>{data.proceduralStage}</dd></div></dl></article>
        <article className="card"><h2>Fristen & Nachforderungen</h2>{data.deadlines.map((item)=><p key={item.label}><strong>{item.label}:</strong> {item.dueAt}</p>)}{data.supplementaryRequests.map((item)=><p key={item}>{item}</p>)}</article>
        <article className="card"><h2>Sitzung & Sicherheit</h2><p>{data.securityState}</p><p className="member-muted">FRONT-03 mintet keine Credentials und übernimmt keine API-02 Autorität.</p></article>
      </section>
      <section className="member-section"><h2>Dokumente</h2><div className="member-list">{data.documents.map((doc)=><div className="member-list-row" key={doc.name}><strong>{doc.name}</strong><span>{doc.verification}</span></div>)}</div></section>
      <section className="member-section"><h2>Verlauf</h2><ol className="member-timeline">{data.timeline.map((entry)=><li key={`${entry.at}-${entry.title}`}><span>{entry.at}</span><strong>{entry.title}</strong><p>{entry.detail}</p><StatusPill status={entry.state} /></li>)}</ol></section>
      <section className="member-section"><h2>Mitteilungen</h2>{data.notices.map((notice)=><p key={notice.title}><strong>{notice.title}</strong> · {notice.date}</p>)}</section>
      <section className="notice notice--legal"><h2>Entscheidung / Abhilfe</h2><p>{data.finalDecision ?? "Noch keine abschließende Entscheidung."}</p><p>{data.reasonCode ? `Grund: ${data.reasonCode}` : "Ein belastender Bescheid wird nicht ohne Grund-/Remedy-Information dargestellt."}</p><p>{data.remedy}</p></section>
    </>
  );
}

function ScopeSelector({ scopes, active }: { scopes: readonly OrganizationScope[]; active: OrganizationScope }) {
  const [scopeId, setScopeId] = useState(active.id);
  const [contextVersion, setContextVersion] = useState(0);
  const change = (next: string) => {
    setScopeId(""); // old protected context cleared before applying the new scope
    queueMicrotask(() => {
      setScopeId(next);
      setContextVersion((value) => value + 1);
    });
  };
  return <div className="member-scope" data-context-version={contextVersion}><label htmlFor="member-scope">Organisationsbereich</label><select id="member-scope" value={scopeId || active.id} onChange={(event: { target: { value: string } })=>change(event.target.value)}>{scopes.map((scope)=><option key={scope.id} value={scope.id}>{scope.label}</option>)}</select><small>Nur server-autorisierte Bereiche; Auswahl erzeugt keine Berechtigung.</small></div>;
}

function MemberHomePage({ data }: { data: PageData<"home"> }) {
  return <>
    <header className="member-page-header"><div><p className="section-kicker">Member Core</p><h1>Meine Übersicht</h1><p>Mitgliedschaft: <strong>{data.membershipStatus}</strong></p></div><ScopeSelector scopes={data.authorizedScopes} active={data.activeScope}/></header>
    <section className="member-grid"><article className="card"><h2>Aufgaben & Fristen</h2>{data.tasks.map((task)=><p key={task.title}><strong>{task.title}</strong><br/><span>{task.dueAt} · {task.status}</span></p>)}</article><article className="card"><h2>Mitteilungen</h2>{data.notices.map((n)=><p key={n.title}>{n.title} · {n.date}</p>)}</article><article className="card"><h2>Dokumente</h2><p>{data.documentSummary}</p></article></section>
    <section className="member-section"><h2>Fähigkeiten</h2><div className="member-grid">{data.capabilities.map((cap)=><article className="card" key={cap.id}><div className="member-card-heading"><h3>{cap.title}</h3><StatusPill status={cap.status}/></div><p>{cap.reason}</p><p><strong>Owner:</strong> {cap.owner}</p><p><strong>Restriction:</strong> {cap.restriction}</p>{cap.href ? <Link className="button button--secondary" href={cap.href}>{cap.nextAction}</Link>:<p>{cap.nextAction}</p>}</article>)}</div></section>
    <section className="notice notice--warning"><h2>Voting boundary</h2><p><strong>{data.votingAvailability}</strong> — {data.votingReason}</p><p>WS-02 zeigt keinen Stimmzettel, keine Cast-Aktion und keine Zwischenauszählung; eine spätere Übergabe darf nur ein einmaliges zweckgebundenes Artefakt ohne dauerhafte Mitgliedskennung liefern.</p></section>
  </>;
}

function MembershipPage({ data }: { data: PageData<"membership"> }) {
  return <><header className="member-page-header"><div><p className="section-kicker">Member record</p><h1>Mitgliedschaft</h1></div><StatusPill status={data.status}/></header><section className="member-grid"><article className="card"><h2>Aktueller Stand</h2><p>{data.affiliation}</p><p>Version {data.version}</p><p>{data.provenance}</p></article><article className="card"><h2>Korrektur</h2><p>{data.correctionPath}</p><button className="button button--secondary" disabled type="button">Korrekturanfrage · Runtime blockiert</button></article></section><section className="member-section"><h2>Historie</h2><table className="member-table"><thead><tr><th>Version</th><th>Datum</th><th>Status</th><th>Quelle</th></tr></thead><tbody>{data.history.map((item)=><tr key={item.version}><td>{item.version}</td><td>{item.at}</td><td>{item.status}</td><td>{item.source}</td></tr>)}</tbody></table></section><section className="member-section"><h2>Renditions</h2>{data.renditions.map((item)=><p key={item.label}>{item.label} · Link nur bei erlaubter Runtime-Rendition</p>)}</section></>;
}

function InitiativesPage({ data }: { data: PageData<"initiatives"> }) {
  return <><header className="member-page-header"><div><p className="section-kicker">Initiative domain</p><h1>Initiativen</h1></div><Link className="button button--primary" href="/member/initiatives/new">Neue Initiative</Link></header><div className="member-grid">{data.map((item)=><article className="card" key={item.id}><p className="section-kicker">{item.id}</p><h2>{item.title}</h2><p>{item.state} · Version {item.version}</p><p>{item.provenance}</p></article>)}</div></>;
}

function NewInitiativePage() {
  const [phase, setPhase] = useState<"draft"|"preview"|"confirm"|"blocked">("draft");
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");
  const [error, setError] = useState("");
  const submitting = useRef(false);
  const preview = () => { if (!title.trim() || !summary.trim()) { setError("Titel und Zusammenfassung sind erforderlich."); return; } setError(""); setPhase("preview"); };
  const confirm = () => setPhase("confirm");
  const commit = () => { if (submitting.current) return; submitting.current = true; setPhase("blocked"); };
  return <><header className="member-page-header"><div><p className="section-kicker">Draft → Preview → Explicit confirmation → Authoritative commit → Receipt</p><h1>Neue Initiative</h1></div><StatusPill status="BLOCKED"/></header>{error ? <div role="alert" className="notice notice--danger"><strong>Fehlerübersicht</strong><p>{error}</p></div>:null}{phase === "draft" ? <section className="member-form" aria-labelledby="initiative-form"><h2 id="initiative-form">Entwurf</h2><div className="form-field"><label htmlFor="initiative-title">Titel</label><input id="initiative-title" value={title} onChange={(e: { target: { value: string } })=>setTitle(e.target.value)} /></div><div className="form-field"><label htmlFor="initiative-summary">Zusammenfassung</label><textarea id="initiative-summary" value={summary} onChange={(e: { target: { value: string } })=>setSummary(e.target.value)} /></div><button className="button button--primary" type="button" onClick={preview}>Vorschau</button></section>:null}{phase === "preview" ? <section className="member-form"><h2>Vorschau</h2><h3>{title}</h3><p>{summary}</p><button className="button button--primary" onClick={confirm} type="button">Explizit bestätigen</button> <button className="button button--secondary" onClick={()=>setPhase("draft")} type="button">Zurück</button></section>:null}{phase === "confirm" ? <section className="notice notice--warning"><h2>Bestätigung</h2><p>Noch wurde nichts autoritativ gespeichert oder übermittelt.</p><button className="button button--primary" onClick={commit} type="button">Autoritativen Commit anfordern</button></section>:null}{phase === "blocked" ? <section className="notice notice--legal" role="status" aria-live="polite"><h2>Nicht übermittelt</h2><p>Der authoritative commit endpoint ist vor akzeptiertem Runtime-Vertrag blockiert. Es wird kein Receipt und kein Erfolg vorgetäuscht.</p><button className="button button--secondary" onClick={()=>{submitting.current=false;setPhase("preview")}} type="button">Entwurf behalten</button></section>:null}</>;
}

function DeliberationPage({ data }: { data: PageData<"deliberation"> }) { return <><header className="member-page-header"><div><p className="section-kicker">Deliberation</p><h1>Beratung</h1></div></header><div className="member-grid">{data.map((item)=><article className="card" key={item.id}><h2>{item.title}</h2><p>Version {item.version}</p><StatusPill status={item.state}/><p>{item.provenance}</p></article>)}</div></>; }
function DelegationPage({ data }: { data: PageData<"delegation"> }) { return <><header className="member-page-header"><div><p className="section-kicker">Delegation</p><h1>Delegation</h1></div><StatusPill status={data.status}/></header><div className="notice notice--warning"><p>{data.explanation}</p><p><strong>Dependency:</strong> {data.dependency}</p></div></>; }
function AssurancePage({ data }: { data: PageData<"assurance"> }) { return <><header className="member-page-header"><div><p className="section-kicker">API-02-owned boundary</p><h1>Authentifizierung & Sitzungssicherheit</h1></div><StatusPill status={data.status}/></header><section className="member-grid"><article className="card"><h2>Assurance</h2><p>{data.assurance}</p><p>Session: {data.sessionState}</p><p>Step-up: {String(data.stepUpRequired)}</p></article><article className="card"><h2>Recovery</h2><p>{data.recoveryState}</p><p>{data.notification}</p></article></section><div className="notice notice--legal"><p>FRONT-03 implementiert keine Login-/Passkey-Ceremony, keine Credential-Minting-Logik, keine Session-Rotation und keine Recovery-Autorität.</p></div></>; }
function AppealPage({ data }: { data: PageData<"appeal"> }) { return <><header className="member-page-header"><div><p className="section-kicker">Applicant-facing case interface</p><h1>Membership Appeal</h1></div><StatusPill status={data.status}/></header><div className="notice notice--legal"><p><strong>Dependency:</strong> {data.dependency}</p><p>{data.remedy}</p><p>Keine WS-07 Credentials, kein direkter geschützter WS-07 Link.</p></div></>; }
function CapabilityPage({ data }: { data: PageData<"capability"> }) { return <><header className="member-page-header"><div><p className="section-kicker">Secondary Member Core capability</p><h1>Fähigkeit</h1></div><StatusPill status={data.status}/></header><div className="notice"><p><strong>Owner:</strong> {data.owner}</p><p><strong>Dependency:</strong> {data.dependency}</p><p>Vollständiger Domain-Workflow liegt außerhalb FRONT-03 und wird nicht als aktiv dargestellt.</p></div></>; }

export function MemberWorkspaceView({ route, actor, data, fixtureMode }: { route: string; actor: ActorRole; data: Front03PageData; fixtureMode: boolean }) {
  const [locale, setLocale] = useState<Locale>("de");
  const c = copy[locale];
  const nav = actor === "Applicant" ? APPLICANT_NAVIGATION : MEMBER_NAVIGATION;
  const page = useMemo(() => {
    if (data.kind === "safe-error") return <SafeErrorPanel data={data.data} />;
    if (data.kind === "application") return <ApplicantPage data={data.data}/>;
    if (data.kind === "home") return <MemberHomePage data={data.data}/>;
    if (data.kind === "membership") return <MembershipPage data={data.data}/>;
    if (data.kind === "initiatives") return <InitiativesPage data={data.data}/>;
    if (data.kind === "initiative-new") return <NewInitiativePage/>;
    if (data.kind === "deliberation") return <DeliberationPage data={data.data}/>;
    if (data.kind === "delegation") return <DelegationPage data={data.data}/>;
    if (data.kind === "assurance") return <AssurancePage data={data.data}/>;
    if (data.kind === "appeal") return <AppealPage data={data.data}/>;
    return <CapabilityPage data={data.data}/>;
  }, [data]);
  return <div className="member-shell" data-workspace="WS-02" data-actor={actor} data-route={route}><a className="skip-link" href="#member-main">Zum Inhalt springen</a>{fixtureMode ? <div className="member-fixture-banner" role="status">{c.fixture}</div>:null}<header className="member-header"><div className="workspace-heading"><Link className="logo" href="/member/home" aria-label="EPD² Member Application">EPD²</Link><span>{actor === "Applicant" ? c.applicant : c.member}</span></div><nav aria-label={actor === "Applicant" ? "Antragsteller-Navigation" : "Mitglieder-Navigation"}>{nav.map((item)=><Link aria-current={route === item.href ? "page" : undefined} href={item.href} key={item.href}>{item.label}</Link>)}</nav><div className="language-selector" role="group" aria-label="Sprache / language"><button aria-pressed={locale === "de"} onClick={()=>setLocale("de")} type="button">DE</button><span aria-hidden="true">|</span><button aria-pressed={locale === "en"} onClick={()=>setLocale("en")} type="button">EN</button></div></header><main id="member-main" className="member-main" tabIndex={-1}>{page}</main><footer className="member-footer"><p>WS-02 · host-only session boundary · no shared Voting Client authority</p><Link href="/hilfe">Hilfe</Link></footer></div>;
}
