import type { Metadata } from "next";

import { MemberWorkspaceView } from "../../../components/member/member-core";
import { createFront03Adapter, resolveFront03AdapterMode } from "../../../member/adapters";
import { loadFront03Page } from "../../../member/view-model";
import type { ActorRole } from "../../../member/types";

export const metadata: Metadata = {
  title: "Member Application · EPD²",
  robots: { index: false, follow: false },
};

type Props = {
  params: Promise<{ path?: string[] }>;
  searchParams: Promise<{ actor?: string; scope?: string; state?: string }>;
};

export default async function Front03MemberRoute({ params, searchParams }: Props) {
  const { path = [] } = await params;
  const query = await searchParams;
  const route = `/member/${path.join("/")}`.replace(/\/$/, "") || "/member/home";
  const defaultActor: ActorRole = route === "/member/application" || route === "/member/membership/appeal" ? "Applicant" : "Member";
  const testActor: ActorRole = query.actor === "applicant" ? "Applicant" : query.actor === "member" ? "Member" : defaultActor;
  const mode = resolveFront03AdapterMode(process.env);
  const fixtureMode = mode === "fixture-test";
  const actor = fixtureMode ? testActor : defaultActor;
  const ports = createFront03Adapter(process.env);
  const canonicalRoute = route === "/member" ? "/member/home" : route;
  let data = await loadFront03Page(ports, canonicalRoute, actor, query.scope);
  if (fixtureMode && query.state && ["session_expired", "step_up_required", "partial_outage", "stale"].includes(query.state)) {
    data = {
      kind: "safe-error",
      data: {
        state: query.state as "session_expired" | "step_up_required" | "partial_outage" | "stale",
        reason: query.state === "step_up_required"
          ? "Für diese Aktion ist eine höhere Sitzungsassurance erforderlich; die Aktion wurde nicht ausgeführt."
          : query.state === "session_expired"
            ? "Die Sitzung ist abgelaufen; geschützte dynamische Inhalte werden nicht weiter als autoritativ dargestellt."
            : query.state === "stale"
              ? "Die Ansicht ist veraltet und muss gegen den aktuellen Scope/Versionsstand neu geladen werden."
              : "Eine Abhängigkeit ist teilweise ausgefallen; es wurde nichts als gespeichert oder übermittelt markiert.",
        retryAllowed: true,
        leaksRecordExistence: false,
      },
    };
  }
  return <MemberWorkspaceView actor={actor} data={data} fixtureMode={fixtureMode} route={canonicalRoute} />;
}
