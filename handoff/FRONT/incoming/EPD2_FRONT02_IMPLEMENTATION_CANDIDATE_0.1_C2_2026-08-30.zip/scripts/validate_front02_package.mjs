import { readdirSync, statSync } from "node:fs";
import { join } from "node:path";

const forbidden = new Set([
  "node_modules",
  ".next",
  ".ruff_cache",
  "test-results",
  "playwright-report",
  "__pycache__",
]);
function walk(directory) {
  for (const name of readdirSync(directory)) {
    if (forbidden.has(name))
      throw new Error(`forbidden transient: ${join(directory, name)}`);
    const path = join(directory, name);
    if (statSync(path).isDirectory() && ![".git"].includes(name)) walk(path);
  }
}
walk(process.argv[2] ?? new URL("..", import.meta.url).pathname);
console.log("FRONT-02 package hygiene valid");
