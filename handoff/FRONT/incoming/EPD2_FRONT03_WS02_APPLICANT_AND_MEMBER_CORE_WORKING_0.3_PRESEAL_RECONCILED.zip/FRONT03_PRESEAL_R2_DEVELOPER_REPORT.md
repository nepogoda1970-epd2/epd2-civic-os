# FRONT-03 PRE-SEAL R2 developer report

Status: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED` — developer working verdict only; **not PASS, ACCEPTED, CLOSED, production-ready or legally activated**.

## R2 purpose

R2 continues the existing FRONT-03 WS-02 Applicant and Member Core implementation. It does not redesign the product from zero. The round adds two mandatory continuity gates:

1. complete reconciliation against the prior EPD² frontend prototype `EPD_Front(5).zip`;
2. reconciliation against the current live EPD² public website as reviewed on 2026-08-30.

Canonical repository governance, accepted workspace/security boundaries and accepted backend contracts remain authoritative for authority, legal effect and runtime activation. Public and legacy material is used for product, terminology and journey continuity where compatible.

## Bootstrap and entering baseline

- Permanent project bootstrap rule followed: Entrypoint → Program Control Register → Master Future Implementation Register → current FRONT stage material.
- FRONT-02 remains the accepted implementation predecessor.
- FRONT-02 C2.1 SHA-256: `aaf980a2cd3b3b06d48218adaa68d109c8770e6abfcbef230197b51a87006179`.
- API-02 remains an accepted-contract/runtime dependency that is not independently accepted for FRONT-03 binding in this candidate.
- R1 status remains the starting status: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`.

## Existing EPD² Frontend Reconciliation

### Reference archive identity

- Reference archive: `EPD_Front(5).zip`
- SHA-256: `a02ac40cf835814a51d21d3a0f1758d2a36581a3348a8977ba973ec051437e40`
- ZIP entries: 88
- HTML pages reviewed: 61
- Public/external HTML pages reviewed: 50
- Authenticated internal HTML pages reviewed: 11
- Machine inventory: `validation/front03/legacy-frontend-reference.json`

### Traceability artefacts

- Full legacy migration matrix: `docs/frontend/FRONT-03-EXISTING-FRONTEND-MIGRATION-MATRIX.csv`
- Public → internal continuity matrix: `docs/frontend/FRONT-03-PUBLIC-INTERNAL-CONTINUITY-MATRIX.csv`
- Gate-number collision reconciliation: `docs/frontend/FRONT-03-R2-GATE-NUMBERING-RECONCILIATION.md`

All 61 HTML pages have an explicit disposition. No relevant legacy page is silently omitted.

### Disposition summary

- `PRESERVE`: 27
- `MIGRATE`: 5
- `MODERNIZE_WITH_CONTINUITY`: 12
- `SPLIT_ACROSS_WORKSPACES`: 9
- `DEFER`: 3
- `SUPERSEDED_BY_GOVERNANCE`: 5
- `REMOVE_WITH_EXPLICIT_REASON`: 0

### Capabilities preserved or migrated

The R2 UI retains the established EPD² product language and journey concepts for:

- Bürgerbereich / personal member home;
- Profil & Mitgliedsstatus;
- Meine Vorschläge;
- Programmwerkstatt;
- Meine Stimmen & Delegation;
- Meine Organisation / regional scope;
- Anmeldung, Sitzungen & Vertrauensarchitektur;
- Applicant application status and remedy path.

### Capabilities split across workspaces

The old `intern/abstimmungen.html` concept is not copied as ballot authority into WS-02. FRONT-03 preserves availability, context and terminology, while actual voting remains an isolated WS-03 Voting Client capability when governably activated.

Public transparency, Offener Abgeordnetentisch and Digitale Bürgerbüros remain cross-workspace/public capabilities. FRONT-03 may link to them contextually but does not absorb their operational authority.

### Capabilities deferred / superseded by governance

- member communication with bodies: preserved as `PLANNED_LATER` rather than silently removed;
- assemblies: explicitly mapped outside the implemented R2 Member Core surface;
- legacy reputation semantics: superseded where newer governance no longer permits the old authority model;
- old authentication/login assumptions: replaced by API-02 governed session/assurance semantics;
- legacy security assumptions: modernized into the current assurance boundary rather than copied.

### Visual continuity decisions

R2 remains an evolution of the existing EPD² frontend rather than a generic SaaS dashboard. The existing shell, card hierarchy, navigation density, status presentation, typography direction and EPD² terminology remain the design reference. The R2 visual-baseline document records the comparison and the inherited mobile-baseline environmental limitation.

### Terminology continuity decisions

User-facing labels prefer established EPD² terms over architecture vocabulary. In particular, the visible shell uses `Bürgerbereich`, `Meine Vorschläge`, `Programmwerkstatt`, `Meine Stimmen & Delegation`, `Meine Organisation` and `Vertrauensarchitektur`. Workspace IDs remain implementation/documentation terms, not primary member-facing labels.

### Unresolved legacy gaps

No material legacy Member Core capability is silently lost. Capabilities that are not active are explicitly classified as planned, blocked, cross-workspace or superseded by governance in the migration and continuity matrices.

## Live Site Reconciliation

### Mandatory current public sources reviewed

- `https://epd-partei.de/`
- `https://epd-partei.de/mitmachen.html`
- `https://epd-partei.de/programm.html`
- `https://epd-partei.de/programmwerkstatt.html`
- `https://epd-partei.de/struktur.html`
- `https://epd-partei.de/transparenz.html`
- `https://epd-partei.de/faq`
- `https://epd-partei.de/satzung.html`

Supplemental source reviewed because it materially affects the Applicant/eID journey:

- `https://epd-partei.de/verifizierung.html`

Machine-readable reconciliation: `docs/frontend/FRONT-03-LIVE-SITE-CONTINUITY-MATRIX.csv` (31 rows).

### Bürgerbereich promises

Every current public Bürgerbereich promise is explicitly mapped:

- Profil und Mitgliedsstatus → implemented FRONT-03 member surface;
- Eigene Vorschläge → implemented FRONT-03 initiatives surface;
- Abstimmungen → availability/context only; real voting remains inactive and outside WS-02;
- Delegationen → represented but runtime-blocked pending accepted backend semantics;
- Kommunikation mit Gremien → `PLANNED_LATER` / separate governed communication capability;
- transparente Beteiligungshistorie → `PLANNED_LATER` / governed projection boundary;
- regionale Beteiligung → implemented scope-aware UX using only server-authorized scopes.

No public promise disappears silently.

### Applicant != Member

The live public verification journey contains language that can be read as identity verification directly enabling a membership account. Current governed semantics and the current Satzung draft require a separate admission decision. R2 therefore makes the boundary explicit:

`identity verification != membership admission`

`Applicant != Member`

Only an authoritative Aufnahmeentscheidung may activate member status. FRONT-03 does not infer membership from eID, login or account creation.

### Programmwerkstatt and current programme status

R2 preserves the public process chain:

`Problem → Strukturierung → Diskussion → Fach-/Rechtsprüfung → demokratische Entscheidung → Dokumentation`

The UI explicitly labels:

`Grundsatzprogramm – Gründungsfassung 1.2 · Entwurf / noch nicht beschlossen`

Initiative submission and deliberation do not imply program adoption. The live programme page also contains binding-language tension later in its content; R2 follows the explicit current draft/not-adopted status and records the tension in the continuity matrix instead of silently choosing a conflicting interpretation.

### Regional structure

The user-facing model is aligned with the live public organization terminology:

`Bund · Landesverbände · Regional-/Ortsverbände`

The selector does **not** hard-code an invented Bund/Berlin option list. Options are rendered exclusively from `OrganizationScopePort.listAuthorized()`; a stored preference is only a display preference and is re-authorized before protected context is shown.

### Voting and eID

R2 distinguishes three states:

- planned product capability;
- availability/context indication;
- actually activated runtime capability.

The public site currently states that real eID is not live and secure/secret online voting is not released. FRONT-03 therefore exposes no ballot-casting action, no live eID claim and no voting credential. Voting remains a separate WS-03 handoff boundary.

### Transparency, Abgeordnetentisch and Digitale Bürgerbüros

These concepts remain public/cross-workspace capabilities. R2 provides contextual links only and explicitly states that operational authority is not transferred into WS-02.

## R2 implementation changes

- `useScopeTransition()` now loads authorized scopes through `OrganizationScopePort.listAuthorized()` and re-authorizes the selected scope before protected context becomes ready.
- Scope options are generated from the port result; no UI hard-coded Bund/Berlin list remains.
- Scope terminology supports Bund, Land, Kreis and Ort while user-facing copy uses the current public Bund/Landesverbände/Regional-/Ortsverbände model.
- Member home now maps all current Bürgerbereich promises explicitly.
- Applicant screen makes `Applicant ≠ Member` and the Aufnahmeentscheidung boundary explicit.
- Programme/initiative/deliberation screens carry the current draft status and the public Programmwerkstatt process chain.
- Delegation/voting screen separates planned voting from active ballot capability.
- Assurance screen states that eID is planned and not live and that no real AusweisApp login is started by FRONT-03.
- Public transparency / Abgeordnetentisch / Bürgerbüro concepts are linked without authority duplication.
- Legacy and live-site continuity matrices plus fail-closed validator gates were added.

## Validator gates

The newest mandatory live-site gate keeps its requested identifier `G51`. The older prototype-reuse gate set also used `G51–G57`; the collision is documented rather than hidden. Its seven checks are shifted one position to `G52–G58`.

Current source/evidence validator result in adversarial mode:

- G51 — LIVE SITE CONTINUITY RECONCILIATION: PASS
- G52 — EXISTING FRONTEND INVENTORY PRESENT: PASS
- G53 — PUBLIC PAGE CONTINUITY MATRIX COMPLETE: PASS
- G54 — INTERNAL LEGACY MIGRATION MATRIX COMPLETE: PASS
- G55 — NO MATERIAL LEGACY MEMBER CAPABILITY SILENTLY LOST: PASS
- G56 — PUBLIC → MEMBER PROMISES MAPPED: PASS
- G57 — GOVERNANCE-OVERRIDDEN LEGACY BEHAVIOR EXPLICITLY DOCUMENTED: PASS
- G58 — VISUAL / TERMINOLOGY CONTINUITY CHECKED: PASS

Adversarial validator verification: **20/20 detected**.

Source mutation verification: **36/36 killed**.

## Verification performed in this R2 session

Performed successfully:

- Python syntax/compile check for the R2 validator/adversarial harness;
- R2 fail-closed source/evidence validator with G51–G58: PASS;
- validator adversarial cases: 20/20 detected;
- source mutation suite: 36/36 killed;
- TypeScript parser pass over changed member source: no TS1xxx syntax diagnostics.

Not re-executed in this environment:

- full Next/React TypeScript typecheck;
- ESLint / Prettier;
- Node/Vitest unit/render suite;
- Playwright browser/a11y/visual suite.

Reason: this extracted candidate contains no `node_modules`, and this container cannot resolve the npm registry. The TypeScript compiler is present globally and confirmed that the changed files have no parser-level errors, but dependency/type resolution fails because React/Next type packages are absent. R1 test evidence is retained as predecessor evidence and is **not** relabelled as an R2 rerun.

## Remaining blockers

R2 therefore does **not** receive `FRONT03_PRESEAL_READY_BLOCKED_ONLY_BY_ACCEPTED_API02` in this session.

Remaining blockers are:

1. exact independently accepted API-02 runtime/binding plus the governed reconciliation required by FRONT-03;
2. rerun of the inherited FRONT-01 mobile visual floor in a capable environment; the unchanged accepted FRONT-02 baseline reproduced the earlier local Chromium/font mismatch;
3. full R2 dependency-backed frontend verification (format/lint/typecheck/unit/browser/a11y/visual) in an environment with the locked Node dependencies available.

The R2 continuity requirements themselves are complete and fail-closed checked; the remaining blockers are runtime/verification blockers, not unmapped public or legacy product promises.
