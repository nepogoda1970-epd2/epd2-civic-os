# FRONT-03 PRE-SEAL R3 DEVELOPER REPORT

## Final developer status

`FRONT03_PRESEAL_READY_BLOCKED_ONLY_BY_ACCEPTED_API02`

This is a developer PRE-SEAL readiness status only. It is **not** `PASS`, `ACCEPTED`, `CLOSED`, `FINAL`, `PRODUCTION_READY`, `BSI_CERTIFIED`, or `BSI_COMPLIANT` authority.

## Candidate and lineage

- Final candidate name: `EPD2_FRONT03_WS02_APPLICANT_AND_MEMBER_CORE_WORKING_0.2_PRESEAL.zip`
- Embedded-copy note: the outer ZIP SHA-256 and byte size are self-referential metadata and are therefore recorded authoritatively in the detached standalone copy of this report returned beside the final ZIP. The archive contains this verification-complete embedded copy so the unpacked validator remains self-contained.
- Accepted technical predecessor: `EPD2_FRONT02_IMPLEMENTATION_CANDIDATE_0.1_C2.1_2026-08-30.zip`
- Accepted FRONT-02 SHA-256: `aaf980a2cd3b3b06d48218adaa68d109c8770e6abfcbef230197b51a87006179`
- Accepted FRONT-02 size: `15,504,858` bytes
- Entering R2 candidate: `EPD2_FRONT03_WS02_APPLICANT_AND_MEMBER_CORE_WORKING_0.1_PRESEAL_R2_LIVE_LEGACY_RECONCILED.zip`
- Entering R2 SHA-256: `f59c664c471cbc966c90dcc6c15f145eaa57642b3d63a3ab8764621186017241`
- Entering R2 size: `16,600,483` bytes

## Fresh bootstrap identities

- origin/main commit: `8ff32c3e9ed654768ae86ac569a9c498f78c5aa2`
- final dependency-backed verification commit: `a704a4fdc7aa38394ff2d48f271e5d65b64b0e55`
- Entrypoint SHA-256: `f6a93dec5e372c49c3f22d14e9cc7f5acea56c7ea355bd93b7e44ec940d8cbf2`
- PCR SHA-256: `36a7380f43835259390e65dc90b8398bdeba68ed26ed6e0de23f97a9887c7f97`
- Master SHA-256: `3cb40d8c46baa4126702a60cb3138b3776548eda4549fc4ec0dd6163c83c1a3d`
- BSI bootstrap SHA-256: `a72877ef643e239fad7fe167be138056289bc1ff4e7e077c2032fecec0275739`
- BSI matrix SHA-256: `8469dfa96a7e76ab513d6d37ce7960589b122b7de8f1315b6052996093b164d5`
- FIR-VOTE-BSI-001: confirmed in current governance bootstrap evidence.

## R3 code and runtime corrections

R3 preserved the correctly completed R2 live/legacy reconciliation and completed the application-layer runtime wiring. `MemberWorkspace` consumes typed application ports rather than selecting fixture/runtime authority inside page components. `MemberCorePort` drives Member Home; `MembershipPort` drives membership history/provenance/correction/decision state; `InitiativesPort` drives listing and the draft → preview → confirmation → `commit` → authoritative-shaped receipt flow; `DeliberationPort` and `DelegationPort` are used only for governed live/limited state and fail closed when runtime contracts are absent.

Applicant and Member identities remain distinct. Applicant routes do not acquire Member navigation, Member capability, WS-07 protected authority, or voting credentials. `VotingHandoff` contains no persistent member/account/person identifier and no WS-02 Member session is forwarded to WS-03. No ballot/cast/tally implementation exists inside WS-02.

## Fixture versus production-like profiles

Fixture testing requires both:

- `NEXT_PUBLIC_FRONT03_FIXTURE=1`
- `EPD2_FRONT03_GOVERNED_TEST_CONTEXT=1`

The independent production-like run used `NODE_ENV=production` with both fixture flags disabled. It proved that fixture data cannot activate, no silent fixture fallback occurs, protected actions stay blocked, and Member/Applicant/voting data are not fabricated.

## Organization-scope transition

The scope flow is:

`OrganizationScopePort.listAuthorized()` → user selection → protected context cleared immediately → `reauthorize(target)` → new context version → reload of affected port-backed projections.

The implementation clears old scope/context before reauthorization, aborts superseded work, suppresses stale responses by generation comparison, and reloads MemberCore, Membership, Initiatives, Deliberation and Delegation projections for the newly authorized scope. Selectable scopes are not hard-coded as an invented Bund/Berlin list.

## Live and legacy continuity

The R2 continuity artifacts are preserved and revalidated:

- `FRONT-03-LIVE-SITE-CONTINUITY-MATRIX.csv`
- `FRONT-03-EXISTING-FRONTEND-MIGRATION-MATRIX.csv`
- `FRONT-03-PUBLIC-INTERNAL-CONTINUITY-MATRIX.csv`

All 61 legacy HTML pages remain explicitly mapped. Current public promises such as Bürgerbereich, membership journey, Programmwerkstatt, regional organization terminology, eID/voting target capability, transparency, Abgeordnetentisch and Digitale Bürgerbüros remain represented without moving authority into WS-02. The current Grundsatzprogramm remains represented as an unadopted draft, not as adopted policy.

## Immutable visual baseline

R3 preserves the accepted FRONT-00/FRONT-01 visual language and the R2 live-reconciled Member Core presentation. The stale R2 screenshot contradiction was documented in `FRONT-03-R3-VISUAL-EVIDENCE-RECONCILIATION.md`; no ordinary redesign was authorized. The final 27 baseline PNGs are protected by SHA-256 manifest and Playwright pixel regression. Baseline SHA integrity is checked before and after the regression run. No Design Change Decision was required and no unapproved visual deviation remains.

## Dependency-backed execution

GitHub Actions run `33406850459` on commit `a704a4fdc7aa38394ff2d48f271e5d65b64b0e55` completed `SUCCESS`.

- `npm ci`: PASS
- format check: PASS
- typecheck: PASS
- lint: PASS
- Node TAP: `51/51` PASS
- Vitest: `30/30` PASS
- inherited FRONT-02 validation: PASS
- Next production build: PASS
- fixture/inherited browser + a11y + keyboard/focus + reflow: `213/213` PASS
- production-like fail-closed browser profile: `6/6` PASS
- immutable visual regression: `27/27` PASS
- accessibility serious/critical violations: `0`
- dependency audit: `0 critical`, `6 high`; new high/critical delta versus predecessor: `0`

All successful execution summaries carry the final R3 `source_tree_digest`, package-lock SHA, test/config digests, command/environment, timestamp, exit code, raw-report path and raw-report SHA.

## Mutation integrity — R3-C01

The final suite contains M01–M36 as independent violations. No universal poison marker, common `personId`, shared forbidden suffix, or unrelated second violation is injected.

- `common_poison_marker_used = false`
- mutations executed: `36`
- independently killed: `36/36`
- restoration verified: `36/36`
- every record contains target path, original/mutated/restored SHA-256, patch SHA-256, exact violation, expected gate, command, exit code, detected reason/rule and restoration result.

## Validator adversarial integrity — R3-C02

The validator was attacked with A01–A26 exactly across evidence corruption, inventory corruption, forbidden voting/session behavior, Applicant bypass, scope/port degradation, fixture-production fail-open, forged mutation evidence, missing R3 artifacts, stale governance/BSI evidence, forged READY state, post-evidence source changes and locked CSS changes.

- adversarial cases executed: `26`
- independently detected: `26/26`
- the intended gate is present in the RED result for every case.

The complete fail-closed gate set G01–G59 is implemented. Any non-API02 gate failure returns non-zero. The final unmutated validator result is `G01–G59 PASS`.

## BSI V26 readiness boundary

R3 revalidated the V26 frontend boundary without making a certification claim:

- no persistent member/person identifier inside the voting domain
- no WS-02 Member session accepted by WS-03
- no cross-workspace analytics correlation authority
- no ballot/cast/tally implementation inside WS-02
- VotingHandoff remains one-time/purpose-scoped and identity-minimized

## Exact inventory and package freeze

The final inventory is generated only after the verification-layer freeze. It independently stores every packaged file path, SHA-256 and byte size except the inventory file itself, and requires:

- missing = `0`
- unexpected = `0`
- hash mismatch = `0`
- duplicate = `0`
- traversal = `0`
- symlink escape = `0`
- CRC clean = `true`

The final archive is additionally checked with ZIP CRC verification, clean-path checks and a post-unpack full validator run.

## Remaining blocker

The only remaining blocker is the exact accepted API-02 authoritative runtime/activation gate. No remaining blocker is a FRONT-03 implementation, test, visual, validator, inventory, dependency, BSI-boundary, live/legacy-continuity or packaging failure.

## Final developer status

`FRONT03_PRESEAL_READY_BLOCKED_ONLY_BY_ACCEPTED_API02`
