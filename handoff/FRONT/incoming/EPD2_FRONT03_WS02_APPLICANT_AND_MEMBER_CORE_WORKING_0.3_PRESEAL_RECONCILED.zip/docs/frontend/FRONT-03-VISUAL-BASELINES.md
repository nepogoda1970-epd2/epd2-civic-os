# FRONT-03 visual baselines

Playwright owns baseline PNG files beneath `frontend/web-shell/tests/browser/front03.browser.spec.ts-snapshots/`. Mandatory mobile and desktop views cover Applicant, Member home, membership, initiatives, initiative preview, deliberation, blocked delegation, assurance, appeal, scope transition, session expiry and dependency unavailable. Baselines are evidence, not activation proof.

## R2 legacy/live continuity

The R2 Member Core keeps the accepted EPD² shell, cards, navigation density, typography and status treatment. User-facing navigation now follows established product terms: `Bürgerbereich`, `Profil & Mitgliedsstatus`, `Meine Vorschläge`, `Programmwerkstatt`, `Meine Stimmen & Delegation`, `Meine Organisation`, and `Vertrauensarchitektur` context. Architecture terms such as `workspace`, `resource`, `entity`, `record` and `WS-02 · Member Core` are not used as the primary user-facing labels.

The organization selector contains no hard-coded Bund/Berlin options. Labels and choices are rendered from `OrganizationScopePort.listAuthorized()`; fixture values exist only in the development adapter.
