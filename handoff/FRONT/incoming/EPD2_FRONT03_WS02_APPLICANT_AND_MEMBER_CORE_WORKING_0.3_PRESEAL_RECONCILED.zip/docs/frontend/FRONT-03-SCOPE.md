# FRONT-03 — WS-02 Applicant & Member Core

Status: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`.

This clean implementation derives from exact accepted FRONT-02 C2.1 (`aaf980a2cd3b3b06d48218adaa68d109c8770e6abfcbef230197b51a87006179`) and reconciles its technical tree with `main@8ff32c3e9ed654768ae86ac569a9c498f78c5aa2`. It implements the lowercase `/member` workspace, strict Applicant/Member separation, typed application ports, authoritative scope-transition mechanics, consequential initiative flow, session-assurance surface and a WS-03 handoff boundary. API-02-owned functions fail closed; development fixtures are excluded from production composition. No acceptance, certification, legal activation or FRONT closure is claimed.

## Hard boundaries

- Applicant is never locally promoted to Member.
- WS-02 contains no ballot, cast or tally surface.
- Voting continuation has no persistent person, member, account or session identifier.
- Scope display preference is not authority; every change reauthorizes and clears old protected context first.
- German is authoritative; English changes presentation only.
- API-02 runtime ceremonies remain `BLOCKED_BY_API02` until exact independent acceptance.


## R2 continuity reconciliation

FRONT-03 R2 additionally treats both the complete `EPD_Front(5).zip` prototype and the current live `epd-partei.de` website as mandatory product/content continuity inputs. Governance and accepted backend contracts still control authority and activation.

R2 therefore:

- preserves the public `Bürgerbereich` promise without pretending all promised functions are already active;
- preserves `Applicant != Member` and makes clear that identity verification alone does not activate membership;
- presents the current programme as `Grundsatzprogramm – Gründungsfassung 1.2 · Entwurf / noch nicht beschlossen`;
- uses the public Programmwerkstatt chain `Problem → Strukturierung → Diskussion → Fach-/Rechtsprüfung → demokratische Entscheidung → Dokumentation`;
- renders selectable organization scopes only from `OrganizationScopePort.listAuthorized()`; the component contains no invented Bund/Berlin option list;
- distinguishes planned voting/eID capability, availability indication and real activation;
- keeps Transparenz, Abgeordnetentisch and Digitale Bürgerbüros as public/cross-workspace capabilities rather than absorbing their authority into WS-02.

Traceability: `FRONT-03-LIVE-SITE-CONTINUITY-MATRIX.csv`, `FRONT-03-EXISTING-FRONTEND-MIGRATION-MATRIX.csv`, and `FRONT-03-PUBLIC-INTERNAL-CONTINUITY-MATRIX.csv`.
