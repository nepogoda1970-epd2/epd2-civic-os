# FRONT-03 PRE-SEAL R1 developer report

Status: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED` — developer internal verdict only; not PASS, ACCEPTED or CLOSED.

- Candidate: `EPD2_FRONT03_WS02_APPLICANT_AND_MEMBER_CORE_WORKING_0.1_PRESEAL.zip`
- Candidate size/SHA-256: populated in the standalone post-pack report; internal copy excluded from the self-referential count.
- Technical predecessor: FRONT-02 C2.1, SHA-256 `aaf980a2cd3b3b06d48218adaa68d109c8770e6abfcbef230197b51a87006179`, 15,504,858 bytes.
- Bootstrap main: `8ff32c3e9ed654768ae86ac569a9c498f78c5aa2`; working lineage: clean greenfield PRE-SEAL R1.
- Target Frontend Architecture: SHA-256 `492ef1f8eb9619d9d53cf7a4efe2c54fbdec9cd3670e4989ac92a3498dfbc3e4`.
- Governance: current V26 Entrypoint/PCR/Master reconciled; FRONT-02 remains accepted baseline; FRONT remains not closed.
- Routes: 9 mandatory lowercase `/member` routes.
- Ports: ApplicantCase, MemberCore, Membership, Initiatives, Deliberation, Delegation, OrganizationScope, SessionAssurance, VotingHandoff, SupportHelp.
- Tests: TypeScript, ESLint and formatting green; Node/TAP 48/48; Vitest 30/30; Playwright 120/120 across mobile/desktop/wide; axe serious/critical 0; 27 actual visual baselines.
- Accessibility: keyboard Applicant/Member flows, focus restoration, 320px/400% equivalent reflow green.
- Mutations: see machine evidence, required 36/36 killed.
- Validator adversarial: see machine evidence, required 13/13 detected.
- Dependency delta: no package-lock change and zero new high/critical findings; inherited predecessor debt is not represented as clean.
- BSI disposition: preparatory only, identity freeze preserved, no certification/conformance claim.
- Open gaps: exact independently accepted API-02 binding/C1 reconciliation; and a capable external environment must rerun the inherited FRONT-01 mobile visual floor. This local Chromium/font runtime produces the same +39 px mobile mismatch against the unchanged exact FRONT-02 C2.1 tree, while FRONT-03's own 27 baselines compare 27/27 green. Per the environmental-blocker rule this is not promoted to READY.
