#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
VALID=ROOT/'scripts/validate_front03.py'
AP=argparse.ArgumentParser(); AP.add_argument('--start',type=int,default=1); AP.add_argument('--end',type=int,default=26); AP.add_argument('--output'); ARGS=AP.parse_args()

def run_validator():
    cp=subprocess.run(['python3',str(VALID),str(ROOT),'--selftest'],capture_output=True,text=True,timeout=20)
    try:data=json.loads(cp.stdout)
    except Exception:data={'failed_gates':[],'status':'INVALID_OUTPUT'}
    return cp,data

def jmut(path,fn):
    p=ROOT/path; d=json.loads(p.read_text()); fn(d); p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')

def replace(path,old,new):
    p=ROOT/path; s=p.read_text();
    if old not in s: raise RuntimeError(f'target not found in {path}: {old!r}')
    p.write_text(s.replace(old,new,1))

def append(path,text):
    p=ROOT/path; p.write_text(p.read_text()+text)

def apply(cid):
    if cid=='A01': jmut('validation/front03/accessibility-summary.json',lambda d:d.update(status='FAIL'))
    elif cid=='A02': jmut('validation/front03/accessibility-summary.json',lambda d:d.update(violations=99))
    elif cid=='A03': jmut('validation/front03/browser-test-summary.json',lambda d:d.update(failed=7))
    elif cid=='A04': jmut('validation/front03/unit-test-summary.json',lambda d:d.update(failed=3))
    elif cid=='A05': jmut('validation/front03/visual-regression-summary.json',lambda d:d.update(failed=5))
    elif cid=='A06': (ROOT/'frontend/web-shell/tests/browser/front03.browser.spec.ts-snapshots/front03-home-mobile-linux.png').unlink()
    elif cid=='A07':
        p=ROOT/'validation/front03/exact-inventory.json'; d=json.loads(p.read_text()); d['files'][0]['sha256']='f'*64; p.write_text(json.dumps(d,indent=2)+'\n')
    elif cid=='A08': (ROOT/'frontend/web-shell/member/UNEXPECTED_AFTER_INVENTORY.txt').write_text('unexpected\n')
    elif cid=='A09': append('frontend/web-shell/member/runtime.ts','\nexport const adversarialBallot = "Cast ballot";\n')
    elif cid=='A10': append('frontend/web-shell/member/runtime.ts','\nlocalStorage.setItem("bearerToken","x");\n')
    elif cid=='A11': append('frontend/web-shell/member/runtime.ts','\ndocument.cookie = "auth=x; Domain=.epd.example";\n')
    elif cid=='A12':
        replace('frontend/web-shell/member/types.ts','purpose: "enter-voting-client";','memberId: string;\n  purpose: "enter-voting-client";')
    elif cid=='A13': append('frontend/web-shell/member/runtime.ts','\nexport const applicantMemberCapabilityBeforeTransition = true;\n')
    elif cid=='A14':
        replace('frontend/web-shell/member/useScopeTransition.ts','const result = await port.reauthorize(target, controller.current.signal);','const result = { ok: true as const, value: { scopeRef: target, contextVersion: "local-only" } };')
    elif cid=='A15': append('frontend/web-shell/member/runtime.ts','\nexport const hardcodedUnauthorizedScope = "secret-scope";\n')
    elif cid=='A16': replace('frontend/web-shell/member/useScopeTransition.ts','port.listAuthorized()','Promise.resolve({ ok: true as const, value: [] })')
    elif cid=='A17':
        replace('frontend/web-shell/app/member/[[...memberPath]]/page.tsx','process.env.NEXT_PUBLIC_FRONT03_FIXTURE === "1" &&\n    process.env.EPD2_FRONT03_GOVERNED_TEST_CONTEXT === "1"','true')
    elif cid=='A18':
        p=ROOT/'validation/front03/mutation-results.json'; fake={'common_poison_marker_used':False,'mutation_count':36,'killed_count':36,'mutations':[{'mutation_id':f'M{i:02d}','killed':True} for i in range(1,37)]}; p.write_text(json.dumps(fake,indent=2)+'\n')
    elif cid=='A19': (ROOT/'FRONT03_PRESEAL_R3_DEVELOPER_REPORT.md').unlink()
    elif cid=='A20': (ROOT/'FRONT03_PRESEAL_R3_DELTA_VS_FRONT02_C2.1.json').unlink()
    elif cid=='A21': append('docs/roadmap/EPD2_PROJECT_ENTRYPOINT.md','\n<!-- adversarial stale governance digest -->\n')
    elif cid=='A22': (ROOT/'validation/front03/bsi-voting-readiness-delta.json').unlink()
    elif cid=='A23':
        def f(d): d.update(status='FRONT03_PRESEAL_READY_BLOCKED_ONLY_BY_ACCEPTED_API02',non_api_failures=['G36'])
        jmut('validation/front03/final-preseal-verdict.json',f)
    elif cid=='A24': append('frontend/web-shell/member/MemberWorkspace.tsx','\n/* adversarial source change after browser evidence */\n')
    elif cid=='A25': append('frontend/web-shell/tests/browser/front03.browser.spec.ts','\n// adversarial source change after visual evidence\n')
    elif cid=='A26': append('frontend/web-shell/app/globals.css','\n/* unauthorized design change */\n.member-shell { border-radius: 37px; }\n')
    else: raise RuntimeError(cid)

CASES=[
 ('A01','accessibility status -> FAIL',['G36']),('A02','accessibility violations -> 99',['G36']),('A03','browser failures -> 7',['G35']),('A04','unit failures -> 3',['G34']),('A05','visual failures -> 5',['G40']),('A06','delete visual baseline',['G39','G58']),('A07','corrupt inventory hash',['G46']),('A08','add unexpected file after inventory',['G46']),('A09','insert Cast ballot UI under /member',['G20']),('A10','add bearer token localStorage write',['G16']),('A11','add Domain auth cookie',['G17']),('A12','add memberId/personId to VotingHandoff',['G21']),('A13','Applicant direct Member bypass',['G12']),('A14','downgrade scope switch to local setState only',['G28']),('A15','hard-code unauthorized scope',['G27']),('A16','remove OrganizationScopePort.listAuthorized use',['G27']),('A17','activate fixture backend in production profile',['G25']),('A18','forge mutation-results.json to 36/36',['G41']),('A19','remove R3 developer report',['G47']),('A20','remove R3 delta',['G48']),('A21','stale governance digest',['G02']),('A22','remove BSI delta',['G45']),('A23','forge READY status while any gate is red',['G50']),('A24','change R3 source after successful browser evidence',['G49']),('A25','change R3 source after successful visual evidence',['G49']),('A26','change existing locked design CSS without Design Change Decision',['G58'])]

# Clean validator must be green in self-test mode (G42 deliberately skipped only).
base_cp,base=run_validator()
if base_cp.returncode!=0 or base.get('status')!='PASS':
    raise SystemExit('clean validator selftest baseline is not GREEN')

results=[]
for cid,attack,expected in CASES[ARGS.start-1:ARGS.end]:
    # Preserve exact bytes for every path potentially touched by this case by snapshotting whole targeted set lazily.
    touched={
      'A01':['validation/front03/accessibility-summary.json'],'A02':['validation/front03/accessibility-summary.json'],'A03':['validation/front03/browser-test-summary.json'],'A04':['validation/front03/unit-test-summary.json'],'A05':['validation/front03/visual-regression-summary.json'],'A06':['frontend/web-shell/tests/browser/front03.browser.spec.ts-snapshots/front03-home-mobile-linux.png'],'A07':['validation/front03/exact-inventory.json'],'A08':['frontend/web-shell/member/UNEXPECTED_AFTER_INVENTORY.txt'],'A09':['frontend/web-shell/member/runtime.ts'],'A10':['frontend/web-shell/member/runtime.ts'],'A11':['frontend/web-shell/member/runtime.ts'],'A12':['frontend/web-shell/member/types.ts'],'A13':['frontend/web-shell/member/runtime.ts'],'A14':['frontend/web-shell/member/useScopeTransition.ts'],'A15':['frontend/web-shell/member/runtime.ts'],'A16':['frontend/web-shell/member/useScopeTransition.ts'],'A17':['frontend/web-shell/app/member/[[...memberPath]]/page.tsx'],'A18':['validation/front03/mutation-results.json'],'A19':['FRONT03_PRESEAL_R3_DEVELOPER_REPORT.md'],'A20':['FRONT03_PRESEAL_R3_DELTA_VS_FRONT02_C2.1.json'],'A21':['docs/roadmap/EPD2_PROJECT_ENTRYPOINT.md'],'A22':['validation/front03/bsi-voting-readiness-delta.json'],'A23':['validation/front03/final-preseal-verdict.json'],'A24':['frontend/web-shell/member/MemberWorkspace.tsx'],'A25':['frontend/web-shell/tests/browser/front03.browser.spec.ts'],'A26':['frontend/web-shell/app/globals.css']}[cid]
    snap={}
    for rel in touched:
        p=ROOT/rel; snap[rel]=(p.exists(),p.read_bytes() if p.exists() and p.is_file() else None)
    try:
        apply(cid)
        cp,data=run_validator(); failed=data.get('failed_gates',[])
        detected=cp.returncode!=0 and any(g in failed for g in expected)
        results.append({'case_id':cid,'exact_attack':attack,'expected_gates':expected,'executed_command':'python3 scripts/validate_front03.py . --selftest','exit_code':cp.returncode,'failed_gates':failed,'detected':detected,'detected_reason':'; '.join(failed)})
        print(cid,'DETECTED' if detected else 'MISSED',failed)
    finally:
        for rel,(existed,b) in snap.items():
            p=ROOT/rel
            if existed:
                p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b)
            else:
                if p.exists():
                    if p.is_dir():
                        import shutil; shutil.rmtree(p)
                    else:p.unlink()

out={'schema':'epd2.front03.validator-adversarial/3','case_count':len(results),'detected_count':sum(x['detected'] for x in results),'cases':results}
outpath=Path(ARGS.output) if ARGS.output else ROOT/'validation/front03/validator-adversarial-results.json'
outpath.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
expected_count=ARGS.end-ARGS.start+1
raise SystemExit(0 if len(results)==expected_count and all(x['detected'] for x in results) else 1)
