#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,subprocess,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
VALID=ROOT/'scripts/validate_front03.py'
RUNTIME=ROOT/'frontend/web-shell/member/runtime.ts'
CSS=ROOT/'frontend/web-shell/member/member.css'
PARSER=argparse.ArgumentParser()
PARSER.add_argument('--output', type=Path, default=Path(tempfile.gettempdir())/'front03-mutation-results.json')
ARGS=PARSER.parse_args()
CASES=[
('M01',RUNTIME,'export const applicantMemberNavigation = "/member/home";','Applicant receives Member navigation.','G13'),
('M02',RUNTIME,'export const applicantOtherCaseAccess = true;','Applicant can access another Applicant/case.','G12'),
('M03',RUNTIME,'export const applicantWs07Protected = "/ws-07/protected";','Applicant receives direct WS-07 protected authority/link.','G13'),
('M04',RUNTIME,'export const universalCrossDomainIdentifier = "stable-person";','universal cross-domain identifier introduced.','G15'),
('M05',RUNTIME,'export const ws02SessionForwardedToWs03 = "ambient-member-session";','WS-02 Member auth/session material forwarded to WS-03.','G19'),
('M06',RUNTIME,'document.cookie = "auth=x; Domain=.epd.example";','Domain auth cookie introduced.','G17'),
('M07',RUNTIME,'localStorage.setItem("bearerToken", "secret");','bearer/auth token stored in browser persistent storage.','G16'),
('M08',RUNTIME,'export const persistentMemberAnalyticsCorrelation = "stable-member";','persistent Member/person analytics correlation introduced.','G15'),
('M09',RUNTIME,'export const protectedRouteClientOnly = true;','protected route relies only on hidden navigation/client role.','G14'),
('M10',RUNTIME,'export const unauthorizedDeepLinkRevealsExistence = true;','unauthorized deep link leaks protected record existence.','G14'),
('M11',RUNTIME,'export const oldProtectedContextRetained = true;','old protected scope context remains during scope transition.','G29'),
('M12',RUNTIME,'export const unauthorizedScopeSelectable = "secret-scope";','unauthorized organization scope becomes selectable/active.','G27'),
('M13',RUNTIME,'export const frontendDeclaresEligibility = true;','frontend locally declares eligibility/authority.','G24'),
('M14',RUNTIME,'export const ballotCastControl = "Cast ballot";','ballot/cast/tally UI introduced into WS-02.','G20'),
('M15',RUNTIME,'export const applicantWs07Credential = "protected-authority";','Applicant receives WS-07 credential/authority.','G13'),
('M16',RUNTIME,'export const localApplicantPromotion = "member";','Applicant becomes Member through local/frontend state.','G12'),
('M17',RUNTIME,'export const blockedCapabilityProductionReady = true;','blocked capability presented as active/ready/production-ready.','G24'),
('M18',RUNTIME,'export const successBeforeAuthoritativeCommit = true;','success shown before authoritative commit.','G32'),
('M19',RUNTIME,'export const duplicateInitiativeSuccessSemantics = true;','duplicate initiative submit creates duplicate success semantics.','G32'),
('M20',RUNTIME,'export const bypassRequiredStepUp = true;','consequential action bypasses required step-up.','G32'),
('M21',RUNTIME,'export const expiredSessionRetainsProtectedUi = true;','expired/revoked session retains protected authoritative UI.','G32'),
('M22',RUNTIME,'export const outageShownAsSuccessfulSubmit = true;','partial outage shown as successful save/submit.','G32'),
('M23',RUNTIME,'export const staleResponseOverwritesNewerContext = true;','stale response overwrites newer scope/context.','G30'),
('M24',RUNTIME,'export const searchOutsideAuthorizedSubset = true;','search expands outside authorized/openable subset.','G32'),
('M25',RUNTIME,'export const privateIdentifierExposedByDefault = "private@example.test";','private contact/member identifier exposed by default.','G15'),
('M26',RUNTIME,'export const telemetrySerializesProtectedIdentifier = "stable-member";','telemetry serializes protected identifiers/secrets.','G16'),
('M27',RUNTIME,'export const localeChangesConsequentialSemantics = true;','EN translation changes consequential semantics/deadline.','G32'),
('M28',RUNTIME,'export const accessibleErrorSummaryRemoved = true;','accessible validation/error summary removed.','G32'),
('M29',CSS,'.critical-remedy { display: none !important; } /* criticalActionHiddenAt400 */','400%/narrow layout hides critical remedy/action.','G38'),
('M30',RUNTIME,'export const protectedOfflineCache: true = true;','protected dynamic data becomes offline cached by default.','G16'),
('M31',RUNTIME,'export const crossOriginStorageBridge = true;','SharedWorker/cross-origin storage/uncontrolled postMessage bridge introduced.','G18'),
('M32',RUNTIME,'export const adverseDecisionWithoutReasonRemedy = true;','adverse membership decision loses reason/remedy.','G32'),
('M33',RUNTIME,'export const applicantMemberCapabilityBeforeTransition = true;','Applicant receives Member capability before authoritative transition.','G12'),
('M34',RUNTIME,'export const staleRoleRemainsAuthoritative = true;','stale role/scope remains authoritative after server state change.','G29'),
('M35',RUNTIME,'export const localeChangesAuthority = true;','locale changes identity/scope/authorization/eligibility.','G12'),
('M36',RUNTIME,'export const votingHandoffPersistentIdentity = { memberId: "stable" };','VotingHandoff gains persistent member/account/person identifier.','G21'),
]
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def invoke(expected=None):
 cmd=['python3',str(VALID),str(ROOT)] + (['--causal-gate',expected] if expected else ['--source-only'])
 cp=subprocess.run(cmd,capture_output=True,text=True,timeout=15)
 try:data=json.loads(cp.stdout)
 except Exception:data={'failed_gates':[],'gates':{}}
 return cp,data
for expected in sorted({c[4] for c in CASES}):
 cp0,_=invoke(expected)
 if cp0.returncode!=0: raise RuntimeError(f'clean causal baseline for {expected} is not green')
results=[]
for mid,target,payload,violation,expected in CASES:
 original=target.read_bytes(); original_sha=sha_bytes(original); patch=("\n"+payload+"\n").encode(); start=time.time()
 try:
  target.write_bytes(original+patch)
  mutated_sha=sha_bytes(target.read_bytes()); cp,data=invoke(expected)
  failed=data.get('failed_gates',[]); g=data.get('gates',{}).get(expected,{})
  killed=cp.returncode!=0 and expected in failed and g.get('status')=='FAIL'
  reason='; '.join(g.get('errors',[])) or cp.stderr[-300:]
 finally:
  target.write_bytes(original)
 restored_sha=sha_bytes(target.read_bytes()); restored=(restored_sha==original_sha)
 results.append({'mutation_id':mid,'target_path':target.relative_to(ROOT).as_posix(),'original_sha256':original_sha,'mutated_sha256':mutated_sha,'patch_sha256':sha_bytes(patch),'exact_violation':violation,'expected_gate':expected,'executed_command':f'python3 scripts/validate_front03.py . --causal-gate {expected}','exit_code':cp.returncode,'detected_reason':reason,'detected_rule':expected,'restored_sha256':restored_sha,'restoration_verified':restored,'killed':bool(killed and restored),'elapsed_seconds':round(time.time()-start,3)})
 print(mid,'KILLED' if results[-1]['killed'] else 'SURVIVED',expected,failed)
source_digest=json.loads((ROOT/'validation/front03/front03-r3-dependency-backed-evidence.json').read_text())['source_tree_digest']
out={'schema':'epd2.front03.mutation-results/3','common_poison_marker_used':False,'source_tree_digest':source_digest,'mutation_count':len(results),'killed_count':sum(x['killed'] for x in results),'mutations':results}
ARGS.output.parent.mkdir(parents=True,exist_ok=True)
ARGS.output.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
raise SystemExit(0 if len(results)==36 and all(x['killed'] for x in results) else 1)
