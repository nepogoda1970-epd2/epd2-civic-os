#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib,json,re,sys
from pathlib import Path

EXPECTED={
'front02_sha':'aaf980a2cd3b3b06d48218adaa68d109c8770e6abfcbef230197b51a87006179','front02_size':15504858,
'main':'8ff32c3e9ed654768ae86ac569a9c498f78c5aa2',
'entry':'f6a93dec5e372c49c3f22d14e9cc7f5acea56c7ea355bd93b7e44ec940d8cbf2','pcr':'36a7380f43835259390e65dc90b8398bdeba68ed26ed6e0de23f97a9887c7f97','master':'3cb40d8c46baa4126702a60cb3138b3776548eda4549fc4ec0dd6163c83c1a3d','bsi_boot':'a72877ef643e239fad7fe167be138056289bc1ff4e7e077c2032fecec0275739','bsi_matrix':'8469dfa96a7e76ab513d6d37ce7960589b122b7de8f1315b6052996093b164d5'}
parser=argparse.ArgumentParser(); parser.add_argument('root',nargs='?',default='.'); parser.add_argument('--source-only',action='store_true'); parser.add_argument('--selftest',action='store_true'); parser.add_argument('--causal-gate'); args=parser.parse_args()
R=Path(args.root).resolve(); V=R/'validation/front03'; gates={}; failures=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def txt(rel):
 p=R/rel
 return p.read_text(encoding='utf-8',errors='ignore') if p.is_file() else ''
def js(rel):
 p=R/rel
 try: return json.loads(p.read_text(encoding='utf-8'))
 except Exception: return None
def rows(rel):
 p=R/rel
 if not p.is_file(): return []
 try:
  with p.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
 except Exception:return []
def gate(n,errs):
 errs=[str(x) for x in errs if x]
 gates[n]={'status':'PASS' if not errs else 'FAIL','errors':errs}
 if errs: failures.extend(f'{n}:{e}' for e in errs)
def prod_files():
 roots=[R/'frontend/web-shell/member',R/'frontend/web-shell/app/member']
 out=[]
 for root in roots:
  if root.exists(): out += [p for p in root.rglob('*') if p.is_file() and p.suffix in {'.ts','.tsx','.js','.mjs','.css'}]
 return out
def prodsrc(): return '\n'.join(p.read_text(errors='ignore') for p in prod_files())
def evidence(name): return js('validation/front03/'+name) or {}
def evidence_pass(d, extras=()):
 e=[]
 if d.get('executed') is not True:e.append('executed-not-true')
 if d.get('status')!='PASS':e.append('status-not-PASS')
 if d.get('exit_code',0)!=0:e.append('exit-code-nonzero')
 for k,v in extras:
  if d.get(k)!=v:e.append(f'{k}!={v!r}')
 return e
S=prodsrc(); route=txt('docs/frontend/FRONT-03-WS02-ROUTE-DECISIONS.csv'); runtime=txt('frontend/web-shell/member/runtime.ts'); types=txt('frontend/web-shell/member/types.ts'); workspace=txt('frontend/web-shell/member/MemberWorkspace.tsx'); scopehook=txt('frontend/web-shell/member/useScopeTransition.ts'); entry=txt('frontend/web-shell/app/member/[[...memberPath]]/page.tsx')
# Fast causal mode is part of the real validator and evaluates exactly one source rule.
if args.causal_gate:
 def m(p): return bool(re.search(p,S,re.I))
 g=args.causal_gate; er=[]
 if g=='G12':
  if m(r'applicantOtherCaseAccess|otherApplicantCase|localApplicantPromotion|applicantBecomesMemberLocally|applicantMemberCapabilityBeforeTransition|applicantMemberCapability|localeChangesAuthority'): er=['applicant-member-boundary-violation']
 elif g=='G13':
  if m(r'applicantMemberNavigation|applicantMemberNav|applicantWs07Protected|applicantWs07Credential|ws07Protected|ws07Credential'): er=['applicant-shell-or-WS07-authority-exposed']
 elif g=='G14':
  if m(r'protectedRouteClientOnly|hiddenNavigationIsAuthorization|unauthorizedDeepLinkRevealsExistence|recordExistsForUnauthorized'): er=['protected-route-refusal-fail-open']
 elif g=='G15':
  if m(r'universalCrossDomainIdentifier|universalIdentifier|persistentMemberAnalyticsCorrelation|analyticsPersistentMemberIdentifier|privateIdentifierExposedByDefault|defaultPrivateContactExposure'): er=['persistent-universal-or-private-identifier']
 elif g=='G16':
  if m(r'(localStorage|sessionStorage)\.setItem\([^)]*(bearer|authToken|accessToken)|telemetrySerializesProtectedIdentifier|telemetrySecretSerialization|protectedDynamicDataOfflineCached\s*=\s*true|protectedOfflineCache\s*:\s*true'): er=['browser-persistence-or-secret-serialization']
 elif g=='G17':
  if m(r'document\.cookie\s*=.*Domain='): er=['domain-auth-cookie']
 elif g=='G18':
  if m(r'new\s+SharedWorker|crossOriginStorageBridge|uncontrolledPostMessage|postMessage\s*\('): er=['cross-origin-auth-session-bridge']
 elif g=='G19':
  if m(r'ws02SessionForwardedToWs03|forwardMemberSessionToVoting|ws03MemberSession'): er=['ws02-session-forwarded-to-ws03']
 elif g=='G20':
  if m(r'Cast ballot|Stimme abgeben|Zwischenergebnis|ballotCastControl'): er=['ballot-cast-tally-implementation-in-ws02']
 elif g=='G21':
  if m(r'votingHandoffPersistentIdentity|VotingHandoff[\s\S]{0,180}(memberId|accountId|personId)'): er=['VotingHandoff-persistent-identity']
 elif g=='G24':
  if m(r'frontendDeclaresEligibility|localEligibilityAuthority|blockedCapabilityProductionReady|capabilityPresentedAsProductionReady'): er=['frontend-overstates-authority-or-runtime']
 elif g=='G27':
  if m(r'unauthorizedScopeSelectable|hardcodedUnauthorizedScope'): er=['unauthorized-or-hardcoded-scope']
 elif g=='G29':
  if m(r'oldProtectedContextRetained|staleProtectedContextAuthoritative|staleRoleRemainsAuthoritative|oldRoleAuthoritative'): er=['old-protected-context-not-invalidated']
 elif g=='G30':
  if m(r'staleResponseOverwritesNewerContext|staleOverwrite'): er=['stale-response-suppression-missing']
 elif g=='G32':
  badpat=r'successBeforeAuthoritativeCommit|earlySuccessReceipt|duplicateInitiativeSuccessSemantics|duplicateSuccessReceipt|bypassRequiredStepUp|consequentialActionWithoutStepUp|expiredSessionRetainsProtectedUi|revokedSessionStillAuthoritative|outageShownAsSuccessfulSubmit|partialOutageSuccess|searchOutsideAuthorizedSubset|searchAllProtected|localeChangesConsequentialSemantics|accessibleErrorSummaryRemoved|accessibleValidationSummaryFalse|adverseDecisionWithoutReasonRemedy|adverseDecisionNoRemedy'
  if m(badpat): er=['screen-action-semantics-violation']
 elif g=='G38':
  if m(r'criticalActionHiddenAt400|criticalActionHiddenAt320'): er=['critical-action-hidden-at-narrow-layout']
 else: er=['unknown-causal-gate']
 res={'schema':'epd2.front03.validator/3','mode':'causal','gates':{g:{'status':'FAIL' if er else 'PASS','errors':er}},'failed_gates':[g] if er else [],'status':'FAIL' if er else 'PASS'}
 print(json.dumps(res,indent=2)); raise SystemExit(1 if er else 0)
# G01 predecessor identity
p=evidence('predecessor-identity.json'); gate('G01',[] if p.get('sha256')==EXPECTED['front02_sha'] and p.get('size')==EXPECTED['front02_size'] and p.get('crc_clean') is True else ['accepted-FRONT02-identity-mismatch'])
# G02-05 governance identities
checks=[('G02','docs/roadmap/EPD2_PROJECT_ENTRYPOINT.md','entry'),('G03','docs/roadmap/EPD2_PROGRAM_CONTROL_REGISTER.md','pcr'),('G04','docs/roadmap/EPD2_MASTER_FUTURE_IMPLEMENTATION_REGISTER.md','master'),('G05','docs/roadmap/EPD2_BSI_VOTING_BOOTSTRAP_RULE.md','bsi_boot'),('G05','docs/security/bsi/EPD2_BSI_CC_PP_0121_CERTIFICATION_READINESS_GAP_MATRIX_0.1.md','bsi_matrix')]
g5=[]
for g,path,key in checks:
 pp=R/path; er=[] if pp.is_file() and sha(pp)==EXPECTED[key] else [f'{path}-digest-mismatch']
 if g=='G05':g5+=er
 else:gate(g,er)
gate('G05',g5)
# G06 exactly one canonical basename for each governance file
ge=[]
if not args.source_only:
 for name in ['EPD2_PROJECT_ENTRYPOINT.md','EPD2_PROGRAM_CONTROL_REGISTER.md','EPD2_MASTER_FUTURE_IMPLEMENTATION_REGISTER.md','EPD2_BSI_VOTING_BOOTSTRAP_RULE.md','EPD2_BSI_CC_PP_0121_CERTIFICATION_READINESS_GAP_MATRIX_0.1.md']:
  found=[p for p in R.rglob(name) if not any(x in p.parts for x in {'node_modules','.next'})]
  if len(found)!=1: ge.append(f'{name}-copies={len(found)}')
gate('G06',ge)
gov=evidence('governance-reconciliation.json'); gate('G07',[] if gov.get('status')=='PASS' and gov.get('target_main')==EXPECTED['main'] and gov.get('canonical_register_copies')==1 else ['governance-reconciliation-not-current'])
gate('G08',[] if 'PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED' in txt('docs/frontend/FRONT-03-SCOPE.md') and not re.search(r'\b(ACCEPTED|CLOSED|PRODUCTION_READY|BSI_CERTIFIED)\b',txt('docs/frontend/FRONT-03-SCOPE.md')) else ['preseal-status-invalid'])
# routing
required=['/member/application','/member/home','/member/membership','/member/initiatives','/member/initiatives/new','/member/deliberation','/member/delegation','/member/assurance/authentication-session-assurance','/member/membership/appeal']
gate('G09',[] if all(x in route for x in required) and '/Member/' not in route else ['lowercase-member-routing-invalid'])
gate('G10',[] if '/Member/' not in S and 'memberPath' in entry else ['uppercase-compatibility-not-safe'])
gate('G11',[f'missing-route:{x}' for x in required if x not in route])
# semantic source mutation detectors and real invariants
sem={
 'applicant_member_nav':r'applicantMemberNavigation|applicantMemberNav',
 'other_case':r'applicantOtherCaseAccess|otherApplicantCase',
 'ws07':r'applicantWs07Protected|applicantWs07Credential|ws07Protected|ws07Credential',
 'universal':r'universalCrossDomainIdentifier|universalIdentifier',
 'session_to_ws03':r'ws02SessionForwardedToWs03|forwardMemberSessionToVoting|ws03MemberSession',
 'domain_cookie':r'document\.cookie\s*=.*Domain=',
 'bearer_store':r'(localStorage|sessionStorage)\.setItem\([^)]*(bearer|authToken|accessToken)|indexedDB[\s\S]{0,80}(bearer|authToken|accessToken)',
 'persistent_analytics':r'persistentMemberAnalyticsCorrelation|analyticsPersistentMemberIdentifier',
 'client_only_guard':r'protectedRouteClientOnly|hiddenNavigationIsAuthorization',
 'deep_leak':r'unauthorizedDeepLinkRevealsExistence|recordExistsForUnauthorized',
 'old_context':r'oldProtectedContextRetained|staleProtectedContextAuthoritative',
 'unauth_scope':r'unauthorizedScopeSelectable|hardcodedUnauthorizedScope',
 'local_authority':r'frontendDeclaresEligibility|localEligibilityAuthority',
 'ballot_ui':r'(Cast ballot|Stimme abgeben|Zwischenergebnis|ballotCastControl)',
 'local_promotion':r'localApplicantPromotion|applicantBecomesMemberLocally',
 'overstate':r'blockedCapabilityProductionReady|capabilityPresentedAsProductionReady',
 'early_success':r'successBeforeAuthoritativeCommit|earlySuccessReceipt',
 'duplicate_success':r'duplicateInitiativeSuccessSemantics|duplicateSuccessReceipt',
 'bypass_stepup':r'bypassRequiredStepUp|consequentialActionWithoutStepUp',
 'expired_ui':r'expiredSessionRetainsProtectedUi|revokedSessionStillAuthoritative',
 'outage_success':r'outageShownAsSuccessfulSubmit|partialOutageSuccess',
 'stale_overwrite':r'staleResponseOverwritesNewerContext|staleOverwrite',
 'search_expands':r'searchOutsideAuthorizedSubset|searchAllProtected',
 'private_default':r'privateIdentifierExposedByDefault|defaultPrivateContactExposure',
 'telemetry_secret':r'telemetrySerializesProtectedIdentifier|telemetrySecretSerialization',
 'locale_semantics':r'localeChangesConsequentialSemantics|localeChangesAuthority',
 'a11y_summary_removed':r'accessibleErrorSummaryRemoved|accessibleValidationSummaryFalse',
 'critical_hidden':r'criticalActionHiddenAt400|criticalActionHiddenAt320',
 'offline_cache':r'protectedDynamicDataOfflineCached\s*=\s*true|protectedOfflineCache\s*:\s*true',
 'bridge':r'new\s+SharedWorker|crossOriginStorageBridge|uncontrolledPostMessage|postMessage\s*\(',
 'adverse_no_remedy':r'adverseDecisionWithoutReasonRemedy|adverseDecisionNoRemedy',
 'applicant_early_cap':r'applicantMemberCapabilityBeforeTransition|applicantMemberCapability',
 'stale_role':r'staleRoleRemainsAuthoritative|oldRoleAuthoritative',
 'voting_id':r'VotingHandoff[\s\S]{0,180}(memberId|accountId|personId)|votingHandoffPersistentIdentity',
}
def has(k): return bool(re.search(sem[k],S,re.I))
# G12 Applicant/Member separation
ge=[]
if has('other_case') or has('local_promotion') or has('applicant_early_cap') or has('locale_semantics'):ge.append('applicant-member-boundary-violation')
if 'actor !== "applicant"' not in runtime and "actor !== 'applicant'" not in runtime:ge.append('applicant-own-case-guard-missing')
gate('G12',ge)
gate('G13',[] if not has('applicant_member_nav') and not has('ws07') else ['applicant-shell-or-WS07-authority-exposed'])
gate('G14',[] if not has('client_only_guard') and not has('deep_leak') and 'nicht freigegeben' in workspace else ['protected-route-refusal-fail-open'])
gate('G15',[] if not has('universal') and not has('persistent_analytics') and not has('private_default') else ['persistent-universal-or-private-identifier'])
gate('G16',[] if not has('bearer_store') and not has('telemetry_secret') and not has('offline_cache') else ['browser-persistence-or-secret-serialization'])
gate('G17',[] if not has('domain_cookie') else ['domain-auth-cookie'])
gate('G18',[] if not has('bridge') else ['cross-origin-auth-session-bridge'])
vc=re.search(r'export type VotingContinuation = \{([\s\S]*?)\};',types); vbody=vc.group(1) if vc else ''
gate('G19',[] if (not has('session_to_ws03') and vc is not None and 'session' not in vbody.lower()) else ['ws02-session-forwarded-to-ws03'])
gate('G20',[] if not has('ballot_ui') else ['ballot-cast-tally-implementation-in-ws02'])
gate('G21',[] if vc and not re.search(r'\b(memberId|accountId|personId)\b',vbody,re.I) and not has('voting_id') else ['VotingHandoff-persistent-identity'])
# matrices/API status
rt=rows('docs/frontend/FRONT-03-WS02-RUNTIME-CONTRACT-MATRIX.csv'); gate('G22',[] if rt and all(r.get('runtime_state') for r in rt) else ['runtime-contract-matrix-incomplete'])
cap=rows('docs/frontend/FRONT-03-CAPABILITY-STATUS-MATRIX.csv'); gate('G23',[] if cap and all(r.get('status') in {'AVAILABLE','LIMITED','PLANNED','BLOCKED','UNAVAILABLE','OTHER_WORKSPACE'} for r in cap) else ['capability-matrix-incomplete'])
ge=[]
if has('local_authority') or has('overstate'):ge.append('frontend-overstates-authority-or-runtime')
if any(r.get('runtime_state') in {'LIVE','PRODUCTION_READY'} and not r.get('executable_API_route') for r in rt):ge.append('unaccepted-api-presented-live')
gate('G24',ge)
# G25 production fixture exclusion evidence and source selector
fp=evidence('fixture-production-exclusion.json'); ge=evidence_pass(fp,[('fixture_data_present',False),('silent_fixture_fallback',False)])
fixture_expr=re.search(r'const\s+fixtureEnabled\s*=\s*([\s\S]*?);',entry)
expr=fixture_expr.group(1) if fixture_expr else ''
if not ('NEXT_PUBLIC_FRONT03_FIXTURE === "1"' in expr and 'EPD2_FRONT03_GOVERNED_TEST_CONTEXT === "1"' in expr and '&&' in expr):ge.append('dual-fixture-gate-missing')
if re.search(r'\|\|\s*true|fixtureEnabled\s*=\s*true|runtimeProfile=\{?\s*["\']fixture["\']',entry):ge.append('fixture-production-activation-fail-open')
gate('G25',ge)
# scope wiring
ge=[]
if 'OrganizationScopePort' not in types:ge.append('port-type-missing')
if 'organizationScope' not in runtime:ge.append('runtime-port-missing')
gate('G26',ge)
ge=[]
if 'listAuthorized()' not in scopehook:ge.append('listAuthorized-not-called')
if has('unauth_scope') or '<option value=' in workspace:ge.append('unauthorized-or-hardcoded-scope')
gate('G27',ge)
ge=[]
for t in ['reauthorize(target','setContextReady(false)','setContextVersion("")','setScope("")']:
 if t not in scopehook:ge.append('missing:'+t)
gate('G28',ge)
gate('G29',[] if 'setContextReady(false)' in scopehook and 'setScope("")' in scopehook and not has('old_context') and not has('stale_role') else ['old-protected-context-not-invalidated'])
gate('G30',[] if 'current !== generation.current' in scopehook and not has('stale_overwrite') else ['stale-response-suppression-missing'])
ge=[]
for p in ['memberCore.read','membership.read','initiatives.list','deliberation.list','delegation.status']:
 if p not in workspace:ge.append('reload-missing:'+p)
gate('G31',ge)
# G32 state/action semantics + independent mutation checks
ge=[]
for k in ['early_success','duplicate_success','bypass_stepup','expired_ui','outage_success','search_expands','locale_semantics','a11y_summary_removed','adverse_no_remedy']:
 if has(k):ge.append(k)
sm=rows('docs/frontend/FRONT-03-SCREEN-STATE-MATRIX.csv'); am=rows('docs/frontend/FRONT-03-ACTION-SEMANTICS-MATRIX.csv')
if not sm or not am:ge.append('screen-or-action-matrix-incomplete')
gate('G32',ge)
# Causal mutation mode stops here: only implementation/source gates are evaluated.
if args.source_only:
 for n in range(33,38): gates[f'G{n:02d}']={'status':'SKIP','errors':['source-only-causal-mode']}
 gate('G38',[] if not has('critical_hidden') else ['critical-action-hidden-at-narrow-layout'])
 for n in range(39,60): gates[f'G{n:02d}']={'status':'SKIP','errors':['source-only-causal-mode']}
 bad=[n for n,v in gates.items() if v['status']=='FAIL']
 result={'schema':'epd2.front03.validator/3','mode':'source-only','gates':gates,'failed_gates':bad,'status':'PASS' if not bad else 'FAIL'}
 print(json.dumps(result,indent=2,ensure_ascii=False)); raise SystemExit(0 if not bad else 1)
# execution/evidence gates
else:
 fr=evidence('front02-regression-summary.json'); gate('G33',evidence_pass(fr)+([] if fr.get('failed')==0 else ['front02-regression-failed']))
 un=evidence('unit-test-summary.json'); gate('G34',evidence_pass(un)+([] if un.get('failed')==0 and un.get('tap_passed')==51 and un.get('vitest_passed')==30 else ['unit-counts-invalid']))
 br=evidence('browser-test-summary.json'); gate('G35',evidence_pass(br)+([] if br.get('failed')==0 and br.get('fixture_passed')==213 and br.get('production_like_passed')==6 else ['browser-counts-invalid']))
 ac=evidence('accessibility-summary.json'); gate('G36',evidence_pass(ac)+([] if ac.get('serious')==0 and ac.get('critical')==0 and ac.get('violations',0)==0 else ['accessibility-violations']))
 kb=evidence('keyboard-focus-summary.json'); gate('G37',evidence_pass(kb)+([] if kb.get('failed')==0 else ['keyboard-focus-failed']))
 rr=evidence('responsive-reflow-summary.json'); ge=evidence_pass(rr)+([] if rr.get('failed')==0 and rr.get('critical_action_reachable') is True else ['responsive-reflow-failed']);
 if has('critical_hidden'):ge.append('critical-action-hidden-at-narrow-layout')
 gate('G38',ge)
 bdir=R/'frontend/web-shell/tests/browser/front03.browser.spec.ts-snapshots'; manifest=R/'frontend/web-shell/tests/browser/front03-r3-visual-baseline.sha256'; gate('G39',[] if bdir.is_dir() and len(list(bdir.glob('*.png')))==27 and manifest.is_file() else ['visual-baselines-not-27'])
 vr=evidence('visual-regression-summary.json'); gate('G40',evidence_pass(vr)+([] if vr.get('failed')==0 and vr.get('missing_baselines')==0 and vr.get('unexpected_baselines')==0 and vr.get('baseline_files_generated') is False and vr.get('comparison_passed')==27 else ['visual-regression-invalid']))
 mr=evidence('mutation-results.json'); muts=mr.get('mutations',[]); gate('G41',[] if len(muts)==36 and mr.get('common_poison_marker_used') is False and all(x.get('killed') and x.get('restoration_verified') and x.get('detected_rule') for x in muts) else ['mutations-not-genuine-36-of-36'])
 if args.selftest: gates['G42']={'status':'SKIP','errors':['validator-selftest-mode']}
 else:
  ar=evidence('validator-adversarial-results.json'); cs=ar.get('cases',[]); gate('G42',[] if len(cs)>=26 and all(x.get('detected') for x in cs[:26]) else ['validator-adversarial-not-26-of-26'])
 dd=evidence('dependency-delta.json'); gate('G43',evidence_pass(dd))
 gate('G44',[] if dd.get('critical')==0 and dd.get('new_high_or_critical_dependency_findings')==0 else ['new-high-critical-dependency-findings'])
 bd=evidence('bsi-voting-readiness-delta.json'); gate('G45',evidence_pass(bd)+([] if bd.get('v26_current') and not bd.get('persistent_member_person_id_in_voting_domain') and not bd.get('ws02_session_forwarded_to_ws03') and not bd.get('ballot_cast_tally_in_ws02') else ['bsi-v26-boundary-failed']))
 # inventory independently recomputed; inventory excludes itself only
 inv=evidence('exact-inventory.json'); ge=[]
 if not inv:ge.append('inventory-missing')
 else:
  raw_files=inv.get('files',[])
  if isinstance(raw_files,dict):
   listed={str(k):str(v) for k,v in raw_files.items()}
  elif isinstance(raw_files,list):
   listed={x.get('path'):x.get('sha256') for x in raw_files if isinstance(x,dict) and x.get('path')}
  else:
   listed={}
   ge.append('inventory-files-invalid')
  current={}
  for q in R.rglob('*'):
   if not q.is_file():continue
   rel=q.relative_to(R).as_posix()
   if rel in {'validation/front03/exact-inventory.json'} or any(part in {'.git','node_modules','.next','test-results','playwright-report','__pycache__'} for part in q.parts):continue
   current[rel]=sha(q)
  missing=sorted(set(listed)-set(current)); unexpected=sorted(set(current)-set(listed)); mism=sorted(k for k in set(current)&set(listed) if current[k]!=listed[k])
  if missing:ge.append('inventory-missing:'+','.join(missing[:3]))
  if unexpected:ge.append('inventory-unexpected:'+','.join(unexpected[:3]))
  if mism:ge.append('inventory-hash-mismatch:'+','.join(mism[:3]))
  if inv.get('duplicate',0)!=0 or inv.get('traversal',0)!=0 or inv.get('symlink_escape',0)!=0 or inv.get('crc_clean') is not True:ge.append('inventory-hygiene-invalid')
 gate('G46',ge)
 gate('G47',[] if (R/'FRONT03_PRESEAL_R3_DEVELOPER_REPORT.md').is_file() else ['R3-developer-report-missing'])
 d=js('FRONT03_PRESEAL_R3_DELTA_VS_FRONT02_C2.1.json') or {}; req=['accepted_front02_predecessor','accepted_front02_sha256','accepted_front02_size','r2_entering_candidate','r2_entering_sha256','r2_entering_size','r3_candidate','r3_candidate_sha256','r3_candidate_size','added_files','modified_files','removed_files','fixed_findings','validator_changes','mutation_changes','runtime_port_wiring_changes','fixture_production_separation_changes','visual_baseline_changes','design_change_decisions','live_legacy_reconciliation_changes','bsi_readiness_changes','api02_only_deferrals']
 ge=[f'delta-missing:{k}' for k in req if k not in d]
 serialized=json.dumps(d,sort_keys=True)
 if re.search(r'\b(TBD|TODO|POPULATED_POST_PACK)\b',serialized,re.I):ge.append('delta-placeholder-present')
 if d.get('r3_candidate')!='EPD2_FRONT03_WS02_APPLICANT_AND_MEMBER_CORE_WORKING_0.2_PRESEAL.zip':ge.append('r3-candidate-name-invalid')
 gate('G48',ge)
 # freshness: final CI evidence hashes each listed implementation/test file + raw report
 de=evidence('front03-r3-dependency-backed-evidence.json'); ge=[]
 if de.get('executed') is not True or de.get('status')!='PASS' or de.get('exit_code')!=0:ge.append('dependency-evidence-not-pass')
 calc=hashlib.sha256()
 for ent in de.get('entries',[]):
  q=R/ent['path']; rel=ent['path']; expected_hash=ent['sha256']
  if not q.is_file():
   ge.append('stale-source:'+rel); continue
  if sha(q)!=expected_hash:ge.append('stale-source:'+rel); continue
  calc.update(rel.encode()+b'\0'+bytes.fromhex(expected_hash))
 if calc.hexdigest()!=de.get('source_tree_digest'):ge.append('source-tree-digest-mismatch')
 rawp=R/'validation/front03'/Path(str(de.get('raw_report_path',''))).name
 if not rawp.is_file() or sha(rawp)!=de.get('raw_report_sha256'):ge.append('raw-report-stale')
 for name in ['unit-test-summary.json','browser-test-summary.json','accessibility-summary.json','keyboard-focus-summary.json','responsive-reflow-summary.json','visual-regression-summary.json','fixture-production-exclusion.json','dependency-delta.json','bsi-voting-readiness-delta.json']:
  e=evidence(name)
  if e.get('source_tree_digest')!=de.get('source_tree_digest'):ge.append('evidence-source-digest-stale:'+name)
 gate('G49',ge)
 verdict=evidence('final-preseal-verdict.json'); ge=[]
 if verdict.get('status')=='FRONT03_PRESEAL_READY_BLOCKED_ONLY_BY_ACCEPTED_API02' and verdict.get('non_api_failures'):ge.append('forged-ready-with-non-api-failures')
 api=[r for r in rt if r.get('runtime_state') in {'BLOCKED_BY_API02','FIXTURE_ONLY'}]
 if not api:ge.append('api02-deferrals-not-recorded')
 gate('G50',ge)
# G51-57 continuity
legacy=rows('docs/frontend/FRONT-03-EXISTING-FRONTEND-MIGRATION-MATRIX.csv'); pub=rows('docs/frontend/FRONT-03-PUBLIC-INTERNAL-CONTINUITY-MATRIX.csv'); live=rows('docs/frontend/FRONT-03-LIVE-SITE-CONTINUITY-MATRIX.csv')
gate('G51',[] if len(legacy)==61 else [f'legacy-inventory-count={len(legacy)}'])
gate('G52',[] if pub and all(r.get('public_promise_or_entry_point') and r.get('continuity_status') and r.get('resolution') for r in pub) else ['public-continuity-incomplete'])
internal=[r for r in legacy if r.get('public_or_internal')=='internal']; gate('G53',[] if len(internal)==11 and all(r.get('migration_disposition') for r in internal) else [f'internal-migration-count={len(internal)}'])
gate('G54',[] if all(r.get('migration_disposition') not in {'','DROP','REMOVED'} for r in internal) else ['material-legacy-capability-silently-lost'])
promises=['Profil und Mitgliedsstatus','Eigene Vorschläge','Abstimmungen','Delegationen','Kommunikation mit Gremien','transparente Beteiligungshistorie','regionale Beteiligung']; blob='\n'.join((r.get('live_section','')+' '+r.get('live_user_promise','')) for r in live); gate('G55',[p for p in promises if p.lower() not in blob.lower()])
over=[r for r in legacy if r.get('migration_disposition')=='SUPERSEDED_BY_GOVERNANCE']; gate('G56',[] if over and all(r.get('governance_reason') and r.get('security_architecture_change') for r in over) else ['governance-overrides-not-documented'])
ge=[]
for term in ['Bürgerbereich','Gründungsfassung 1.2','Bund','Landesverbände','Regional-/Ortsverbände']:
 if term.lower() not in (txt('docs/frontend/FRONT-03-LIVE-SITE-CONTINUITY-MATRIX.csv')+' '+workspace).lower():ge.append('terminology:'+term)
if 'nicht live' not in workspace or has('ballot_ui'):ge.append('eid-voting-terminology-overstated')
gate('G57',ge)
# G58 immutable visual matrix + baseline integrity + locked frontend CSS as CI-tested
vm=rows('docs/frontend/FRONT-03-IMMUTABLE-VISUAL-BASELINE-MATRIX.csv'); ge=[]
allowed={'EXACT_REUSE','NEW_COMPONENT_FROM_EXISTING_PRIMITIVES','SECURITY_DRIVEN_BEHAVIOR_CHANGE_NO_RESTYLE','GOVERNED_DESIGN_CHANGE_DECISION'}
if len(vm)<11:ge.append('visual-traceability-incomplete')
for r in vm:
 if r.get('baseline_status') not in allowed:ge.append('invalid-baseline-status')
 if r.get('visual_deviation','').lower() in {'true','yes','1'} and not r.get('design_change_decision'):ge.append('unapproved-visual-deviation')
# manifest SHA verifies baseline bytes independently
mp=R/'frontend/web-shell/tests/browser/front03-r3-visual-baseline.sha256'
if mp.is_file():
 for line in mp.read_text().splitlines():
  if not line.strip():continue
  h,path=line.split(None,1); q=R/'frontend/web-shell'/path.strip().lstrip('*')
  if not q.is_file() or sha(q)!=h:ge.append('baseline-hash-mismatch:'+path.strip())
else: ge.append('visual-manifest-missing')
de=evidence('front03-r3-dependency-backed-evidence.json')
css=R/'frontend/web-shell/app/globals.css'; cent=next((x for x in de.get('entries',[]) if x.get('path')=='frontend/web-shell/app/globals.css'),None)
if not cent or not css.is_file() or sha(css)!=cent.get('sha256'):ge.append('locked-css-changed-after-evidence')
gate('G58',ge)
# G59 DCD enforcement
ge=[]
for r in vm:
 if r.get('visual_deviation','').lower() in {'true','yes','1'}:
  dcd=r.get('design_change_decision',''); p=R/'docs/frontend/design-decisions'/dcd
  if not dcd or not p.is_file() or 'APPROVED' not in p.read_text(errors='ignore'):ge.append('missing-approved-DCD:'+dcd)
gate('G59',ge)
# overall: source-only ignores SKIPs, selftest ignores only G42 skip; full requires all PASS
bad=[n for n,v in gates.items() if v['status']=='FAIL']
result={'schema':'epd2.front03.validator/3','mode':'source-only' if args.source_only else ('selftest' if args.selftest else 'full'),'gates':gates,'failed_gates':bad,'status':'PASS' if not bad else 'FAIL'}
print(json.dumps(result,indent=2,ensure_ascii=False))
raise SystemExit(0 if not bad else 1)
