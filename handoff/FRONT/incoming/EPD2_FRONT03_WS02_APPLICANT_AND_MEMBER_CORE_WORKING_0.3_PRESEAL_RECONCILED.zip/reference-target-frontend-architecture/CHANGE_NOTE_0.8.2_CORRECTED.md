# CHANGE NOTE 0.8.2 CORRECTED

- Voting handoff isolation clarified.
- Origin-local browser runtime rules added.
- `membership_appeal_pending` added.
- Applicant/legal workspace separation corrected.
- AI provenance and stale analysis contract added.
- Role names and permissions synchronized; canonical aliases separated.
- Migration map revalidated against all 61 HTML pages as HTML/CSS/JS prototypes.
- Readiness claims removed and status vocabulary constrained.
- AGR-01 through AGR-38 traceability added without claiming frontend closure for backend/legal/infrastructure gaps.
- Production readiness is not claimed.
- Workspace/origin count remains 10/10.
- No product code was written and no repository was changed.
