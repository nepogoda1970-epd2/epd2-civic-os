# EPD² Target Frontend Architecture 0.8.2 CORRECTED

**Status:** authoritative frontend target baseline for independent audit and later implementation planning.  
**Not an implementation or activation record.**

## 1. Baseline and non-claims

- Repository baseline: `0.8.0`; Canon: `0.7.0`.
- PACK-01—08: PASS.
- PACK-09: `IMPLEMENTATION CANDIDATE-2 / NOT PASS`.
- Framework 0.8.2 CORRECTED is authoritative: 58 domains, 50 trust boundaries, 103 hard invariants, AGR-01—38, roadmap PACK-09—35.
- PACK-29—35 remain proposed.
- This blueprint writes no production code, changes no repository, and activates no legal, security, voting, cryptographic or production capability.

## 2. Architecture outcome

The target consists of **10 workspaces on 10 distinct origins**, **81 concrete target pages/routes**, **36 reusable components** and **22 domain-specific components**. Every Framework domain has a concrete workspace, page, route, role, source of truth, PACK and activation gate. Generic placeholder assignments are prohibited and absent.

## 3. Non-negotiable trust rules

Every origin registers only its own Service Worker. Shared workers between workspaces, cross-origin storage bridges, uncontrolled `postMessage`, shared tokens, and shared Voting Client analytics/runtime bundles are prohibited. Privileged workspaces do not persist sensitive records in browser storage without an approved security profile. Sensitive dynamic responses use `Cache-Control: no-store`.

WS-02 never transfers its session to WS-03. It supplies only a one-time purpose-scoped handoff artifact with no persistent member identifier. WS-03 has no shared cookies, localStorage, IndexedDB, identity session, analytics, fingerprinting, shared telemetry, admin functions, intermediate tally or cross-origin profiling. On completion/cancellation WS-03 may clear only its own origin storage; gateway/log correlation metadata is minimized. `Clear-Site-Data` is not a mechanism for WS-03 to clear WS-02.

1. No global user ID in frontend contracts; only purpose-scoped subject references.
2. No cross-workspace analytics, political profiling or public/private identity leakage.
3. Voting has a separate origin, session, cookies and storage; no direct identity, admin functions or intermediate tally.
4. Public surfaces read only approved renditions, never authoritative registries, protected correspondence or internal drafts.
5. Administration is role-specific; no universal admin. Break-glass is isolated, alerted out-of-band and independently reviewed.
6. No broad admin search or cross-regional visibility without explicit organization scope.
7. Reputation is explainable and contestable; no hidden score.
8. Planned capability is labelled planned and cannot be presented as active, binding, secure, anonymous, certified or legally effective.

## 4. Workspace architecture

### WS-01 — Public Website

- Origin / prefix: `https://www.epd.example` · `/`
- Purpose: Public explanation, approved news and non-authoritative participation handoffs.
- Roles: visitor; citizen (secondary: publication officer (preview only))
- Authentication/session: none; explicit handoff to another origin; no privileged session
- Cookies/storage/analytics: essential consent cookie only; SameSite=Lax; no shared auth cookie; theme/language only; no identity or political-interest data; optional aggregate first-party metrics; no cross-workspace correlation
- Data: PUBLIC_APPROVED
- Allowed: read approved rendition; consented analytics choice; start authenticated handoff
- Forbidden: read authoritative registry; view drafts; casework; voting; approvals
- PACK/gate: 18;28; available now only as explanatory prototype; approved renditions gated
- Degraded mode: static approved pages; authenticated handoffs disabled with status notice

### WS-02 — Member Application

- Origin / prefix: `https://app.epd.example` · `/member`
- Purpose: Membership, initiatives, deliberation, delegation, program and internal participation.
- Roles: applicant; member; initiative author; delegate; moderator (secondary: candidate; assembly participant)
- Authentication/session: member IAM; step-up for high-impact actions; member-only session; never accepted by voting origin
- Cookies/storage/analytics: host-only secure HttpOnly cookies; no Domain cookie; non-sensitive UI preferences only; no political profiling; workspace-local operational telemetry
- Data: INTERNAL; CONFIDENTIAL_CASE_SCOPED
- Allowed: manage own membership data; submit initiative; deliberate; delegate; join activated assembly
- Forbidden: cast ballot on member origin; tally; universal search; institutional approval
- PACK/gate: 01-09;18;21-22;32;34; Wave 1 only for PACK-01-08 PASS; later routes planned/gated
- Degraded mode: read-only snapshot; save draft locally only when non-sensitive and consented

### WS-03 — Voting Client

- Origin / prefix: `https://vote.epd.example` · `/vote`
- Purpose: Isolated credential redemption, ballot casting and receipt verification.
- Roles: eligible voter (secondary: accessibility support operator without ballot access)
- Authentication/session: one-time scoped credential handoff; no member session; separate origin and cryptographic voting session
- Cookies/storage/analytics: host-only essential session; no shared cookies; no shared localStorage; ballot persistence prohibited by default; none; strictly non-identifying availability metrics outside ballot flow
- Data: VOTING_SCOPED; NO_DIRECT_IDENTITY
- Allowed: redeem scoped credential; mark/review/cast ballot; verify receipt
- Forbidden: identity lookup; member profile; tally; admin; analytics; intermediate result
- PACK/gate: 15;16;18; planned; legal, security, cryptographic and infrastructure review required
- Degraded mode: fail closed; preserve no partial vote; direct voter to governed fallback

### WS-04 — Representative Workspace

- Origin / prefix: `https://represent.epd.example` · `/representative`
- Purpose: Mandate work, public desk intake triage, deviations, declarations and governed summaries.
- Roles: representative; mandate staff (secondary: publication reviewer; conflict officer)
- Authentication/session: mandate-scoped IAM and step-up; representative/mandate scope session
- Cookies/storage/analytics: host-only secure cookies; UI preferences only; no case content; workspace-local operational telemetry; no citizen profiling
- Data: MANDATE_INTERNAL; CASE_CONFIDENTIAL; PUBLIC_APPROVED
- Allowed: triage mandate cases; record position/deviation; submit meeting/declaration; propose rendition
- Forbidden: system administration; final publication approval; registry custody; eligibility decisions
- PACK/gate: 20;27-29;35; PACK-29 proposed; full desk integration requires stable PACK-35 interface
- Degraded mode: case intake paused; public approved positions remain available

### WS-05 — Citizen Office Portal

- Origin / prefix: `https://office.epd.example` · `/office`
- Purpose: No-wrong-door intake, consented routing, status and response exchange.
- Roles: citizen; caseworker (secondary: routing reviewer; ombuds officer)
- Authentication/session: case-scoped account or secure case token; staff IAM; citizen-case and staff-role sessions separated
- Cookies/storage/analytics: host-only secure cookies; no correspondence; draft only with explicit device warning; no content analytics or political profiling
- Data: CASE_CONFIDENTIAL; SPECIAL_CATEGORY_POSSIBLE
- Allowed: submit; consent to routing; view own case; respond; contest automated assistance
- Forbidden: publish correspondence; broad search; infer membership; legal-effect decision by AI
- PACK/gate: 22;23;33; PACK-33 proposed; public intake wording may be explanatory only
- Degraded mode: issue reference and governed offline channel; no silent loss

### WS-06 — Institutional Administration

- Origin / prefix: `https://admin.epd.example` · `/admin`
- Purpose: Role-specific institutional consoles; never a universal admin.
- Roles: authority admin; security admin; records officer; incident commander (secondary: schema steward; recovery verifier; audit reviewer)
- Authentication/session: privileged IAM; phishing-resistant MFA; step-up; console and duty specific; break-glass isolated
- Cookies/storage/analytics: host-only secure short-lived cookies; none for protected data; security telemetry only; no product analytics
- Data: RESTRICTED_ADMIN; SECURITY_SENSITIVE
- Allowed: role-specific administration; dual-control approvals; scoped incident/recovery actions
- Forbidden: universal access; ballot access; self-approval; unlogged break-glass; content browsing without purpose
- PACK/gate: 08;12;13;17;20;26; planned; security and production infrastructure required
- Degraded mode: fail closed; documented manual operations and out-of-band alert

### WS-07 — Compliance & Legal Workspace

- Origin / prefix: `https://legal.epd.example` · `/legal`
- Purpose: Compliance workflows, cases, deadlines, records, appeals and protected reporting.
- Roles: legal officer; compliance officer; records officer (secondary: arbitrator; DPO; investigation officer)
- Authentication/session: role and case-scope IAM; MFA; legal purpose and case scoped
- Cookies/storage/analytics: host-only secure cookies; none for evidence/case payload; no content analytics; compliance metrics disclosure-controlled
- Data: LEGAL_PRIVILEGED; CASE_CONFIDENTIAL; EVIDENCE_RESTRICTED
- Allowed: case handling; issue decision within authority; hold/retention; evidence custody
- Forbidden: technical notification confers legal effect; self-appeal review; public raw-case access
- PACK/gate: 09;11;23-24;27;31; PACK-09 candidate not PASS; later legal PACKs planned
- Degraded mode: manual governed docket; deadlines preserved and visible

### WS-08 — Finance Workspace

- Origin / prefix: `https://finance.epd.example` · `/finance`
- Purpose: Party finance, donations, procurement and independent audit handoff.
- Roles: finance officer; procurement officer (secondary: finance auditor; vendor reviewer)
- Authentication/session: finance/procurement IAM; MFA; finance and independent-audit duties separated
- Cookies/storage/analytics: host-only secure cookies; none for financial data; operational metrics only
- Data: FINANCIAL_CONFIDENTIAL; PUBLIC_APPROVED
- Allowed: record/reconcile; review donation; procurement workflow; prepare report
- Forbidden: auditor edits source ledger; publish raw financial data; self-approve vendor
- PACK/gate: 10;25;28; planned; legal and provider gateway review required
- Degraded mode: controlled manual ledger/import queue; no duplicate posting

### WS-09 — Independent Oversight & Verification

- Origin / prefix: `https://verify.epd.example` · `/verify`
- Purpose: Independent verification, certification review, objections, ethics and constitutional oversight.
- Roles: independent verifier; election board; oversight reviewer (secondary: appeals reviewer; ethics council; constitutional reviewer)
- Authentication/session: independent-role IAM; MFA; verifier keys where applicable; independent from operational workspaces
- Cookies/storage/analytics: host-only secure cookies; verification preferences only; no protected evidence; no cross-workspace tracking
- Data: OVERSIGHT_RESTRICTED; PUBLIC_VERIFICATION
- Allowed: verify evidence; certify within authority; record objection/review; publish signed verification statement
- Forbidden: operate election; edit source records; own methodology and decide its appeal
- PACK/gate: 16;17;31;34; planned/proposed; certification requires legal and security activation
- Degraded mode: verification unavailable notice; source artifacts remain immutable

### WS-10 — Transparency Publication Portal

- Origin / prefix: `https://transparency.epd.example` · `/transparency`
- Purpose: Approved, redacted, versioned and correctable public renditions.
- Roles: public reader; publication officer (secondary: redaction reviewer; registry custodian (source only))
- Authentication/session: public read; separate publication-role IAM; public and publication preview sessions separated
- Cookies/storage/analytics: public essential cookies only; publication host-only session; language/filter preferences only; aggregate first-party only; no cross-workspace identifiers
- Data: PUBLIC_APPROVED; AGGREGATED_DISCLOSURE_CONTROLLED
- Allowed: read/download approved rendition; propose/review/publish/correct by separated roles
- Forbidden: direct registry reads; raw correspondence; protected drafts; publication officer as custodian
- PACK/gate: 10;17;28;29;35; planned; each rendition requires publication gate
- Degraded mode: last valid rendition marked stale; correction channel remains available

## 5. Navigation and authority

Each workspace has a persistent origin/scope/classification header, role-filtered primary navigation, page-level secondary navigation and deterministic breadcrumbs. Cross-workspace links are explicit handoffs: the target origin re-authenticates and re-authorizes. Deep links never confer authority and must not reveal the existence of protected records. Organization-scope switching exposes only authorized Bund/Land/Kreis/body scopes and clears incompatible page context.

No role gains powers from navigation visibility. Server authority is evaluated by purpose, role, organization scope, record scope, state and version. Prohibited combinations include representative/system administrator, mandate holder/verifier, publication officer/registry custodian, crisis authority/oversight body, reputation methodology owner/appeals reviewer and legal-effect authority/technical sender.

## 6. Corrected domain mappings

### Tally and certification

Tally is not backend-only. The target includes restricted election-board oversight, certification, verifier evidence review, objection/appeal tracking and a separately approved public certified-result rendition. The voting client never exposes tally progress.

### Membership appeal lifecycle

`membership_appeal_pending` blocks a duplicate ordinary membership application while exposing appeal status, evidence upload, protected correspondence, receipt, deadlines, decision and further remedies. The applicant remains in WS-02. Only authorized Legal/Compliance Officers enter WS-07; WS-02 exchanges case-scoped data with WS-07 through a governed interface/API. The applicant never receives direct legal-workspace access. The complete lifecycle is auditable and corrections never overwrite prior records.

### AI governance

One-click analysis displays analysis version, model version, prompt-template version, immutable digest, DiscussionSnapshot ID/version, snapshot timestamp, source coverage, stale status and contest/correction action. STALE is mandatory after newer comments, arguments, amendments or sources. Git commit hash remains audit metadata and need not be shown to ordinary users. AI is advisory only and cannot change initiative text, eligibility, ballot or tally, certify a result, or consequentially auto-moderate content.

AI UI is distributed by purpose: use-case registry, model/version record, reviewer decision, contest/correction and public AI log, plus snapshot-bound initiative analysis, moderation assistance, representative summaries and citizen-routing assistance. AI never creates legal effect or silently routes a citizen case.

### Regional organization

PACK-08 PASS supports current organization and regional scope visibility. Creation, restructuring, office lifecycle and cross-scope workflows remain gated by later domain PACKs; PASS is not extrapolated to those workflows.

### Privileged administration

Institutional Administration contains distinct consoles for authority, access review, break-glass, export/DLP, feature flags, schema registry, incidents, recovery and audit. Console routes share an origin but not a universal privilege set; every action is purpose-authorized and auditable.

### PACK-35

PACK-35 spans party-office and representative declarations, organization/interest-representative registry, disclosure and exception review, and approved public rendition. It stores a generic typed subject reference including `representative_mandate`. PACK-29 consumes its stable interface; PACK-35 does not depend on full PACK-29 implementation.

## 7. Page and component contract

Every target page specifies source of truth, API dependency, page sections, primary/secondary actions, approvals, domain states, empty/loading/error/unauthorized/stale states, correction path, audit visibility, public/internal distinction, accessibility, PACK, implementation wave, activation gate and data classification. Every component inherits page authority and may never grant authority itself.

The complete executable planning catalog is in `EPD2_Frontend_Page_Catalog_0.8.2.csv`; route, navigation, component and traceability CSVs are normative machine-readable appendices.

## 8. State architecture

Seventeen domain state machines are defined separately: initiative, amendment, AI analysis, voting, certification, candidacy, assembly, legal case, citizen case, representative disclosure, lobbying disclosure, emergency governance, constitutional review, program adoption, reputation contest publication and membership appeal. Each state records entry conditions, visible/prohibited actions, transition authority, audit event, failure and terminal semantics.

## 9. Activation and public wording

PACK-01—08-backed reference UI may be available only to the extent actually verified. PACK-09 is candidate/not PASS. PACK-10—28 are required/planned and PACK-29—35 proposed. Pages remain blocked until the owning PACK is PASS and applicable legal, security, infrastructure, external-gateway and publication gates are evidenced. A disabled button alone is not an activation control; the UI must state status and omit misleading claims.

## 10. Accessibility Definition of Done

Every page and component requires keyboard operation, logical focus order and restoration, programmatic labels and screen-reader names, error summaries, plain language, accessible tables, text alternatives for charts, reduced motion, 400% zoom, AA contrast, multilingual readiness and a governed fallback process. Voting additionally requires end-to-end assistive-technology testing without weakening secrecy or eligibility separation.

## 11. Migration

All **61** current HTML pages have an explicit decision. Counts: `KEEP` 11, `MERGE` 7, `MOVE` 24, `PUBLIC_EXPLANATION_ONLY` 3, `REPLACE` 3, `REWRITE` 11, `SPLIT` 2. Existing neutral explanatory content and visual identity may be retained; unsupported readiness claims are removed. Static mock actions become either governed workspace actions or clearly labelled public explanations.

## 12. Implementation waves

1. **Wave 0:** design system, accessibility, workspace shells, origin/session patterns, role navigation, provenance and state/error foundation. No product activation.
2. **Wave 1:** UI only for PACK-01—08 PASS reference core.
3. **Wave 2:** PACK-09—18 after individual PASS and activation gates.
4. **Wave 3:** PACK-19—28 after individual PASS and activation gates.
5. **Wave 4:** proposed PACK-29—35 after specification, implementation, PASS and activation.

## 13. Acceptance result

- 58/58 domains have concrete mappings.
- 81/81 pages have concrete routes, roles, states, components/PACK ownership and gates.
- 61/61 current pages have migration decisions.
- Voting isolation and public/private/admin boundaries are explicit.
- Critical hard invariants have visible UI enforcement or negative-action requirements.
- Generic placeholder mappings: **0**.
- Activation-blocked target pages/capabilities: **76**.

## 14. Normative appendices

The corrected CSV catalogs, including the canonical role alias map, AGR traceability and invariant enforcement matrix,, `AUDITOR_README.md` and `SHA256SUMS.txt` distributed with this document form the auditable baseline. If narrative and CSV differ, the more restrictive trust-boundary, authority or activation rule governs until a reviewed amendment resolves the conflict.


## 15. Role alignment

Canonical role names are normative in both role matrices and all catalogs; aliases are isolated in `EPD2_Frontend_Role_Alias_Map_0.8.2.csv`. There is no Universal Administrator. Auditor and verifier roles are read-only by default and may append only separately authorized findings. Publication Officer is not Registry Custodian; Mandate Holder is not Parliamentary Data Verifier; Security Administrator is not System Administrator; Crisis Authority is not Oversight Body; Reputation Methodology Owner is not Appeals Reviewer.

## 16. Trust-boundary and AGR traceability

Frontend enforcement is never presented as sufficient by itself. `EPD2_Frontend_Invariant_Enforcement_0.8.2.csv` names UI, backend, gateway, infrastructure, audit and PACK responsibility for the critical frontend-relevant invariants. `EPD2_Architecture_Frontend_Traceability_0.8.2.csv` covers AGR-01 through AGR-38 and explicitly distinguishes covered, intentionally deferred and not-frontend-relevant gaps. Target Frontend Architecture is a design baseline, not production readiness.
