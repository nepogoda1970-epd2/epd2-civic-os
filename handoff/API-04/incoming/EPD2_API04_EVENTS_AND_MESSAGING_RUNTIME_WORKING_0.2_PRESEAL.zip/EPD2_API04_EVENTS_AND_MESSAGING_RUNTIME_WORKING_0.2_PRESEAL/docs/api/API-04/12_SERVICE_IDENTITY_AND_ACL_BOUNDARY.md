# Service identity and the ACL boundary

## Two layers, both must hold

**The broker's own ACL.** A per-service credential with `configure=^$` — declare
nothing — and `write`/`read` regexes bounded to that principal's own exchanges
and queues. This is what makes an unauthorized *connection* fail. A live test
asserts the broker closes the channel with 403 when a service principal attempts
to declare a queue.

**The ACL matrix.** A verified API-03 principal, an exact topic or subscription,
the event type, the event version, the organization scope and the data
classification. This is what makes an unauthorized *publish* fail even from a
peer whose broker credential happens to work.

Neither layer is domain authorization. A publish that passes both says nothing
about whether the resulting domain effect is permitted; that is the owning
service's question, and for a consequential effect it is asked again at the
commit point.

## Identity is a type decision, not a check

```python
def verify(self, credential, *, purpose):
    if isinstance(credential, MessageAssertedIdentity): raise ...
    if isinstance(credential, HumanCredential):        raise ...
    if not isinstance(credential, TransportCredential): raise ...
    return self._verify_transport_credential(credential, purpose=purpose)
```

`verify` accepts a `TransportCredential` and nothing else. A `TransportCredential`
can only be produced by a transport that authenticated its peer. A message body,
an AMQP header and an envelope field cannot produce one, because the two types
that model those — `MessageAssertedIdentity` and `HumanCredential` — are separate
classes with no conversion, and `verify` refuses them **by type** before it reads
any value.

That is why "trust a message-supplied producer" is not a defect this runtime can
acquire by forgetting an `if`: there is no code path that turns a message field
into a principal. Mutations M20 and M21 remove those gates and unit tests catch
both.

Credential state is checked on every use, not at connection time:
`SERVICE_CREDENTIAL_REVOKED`, `SERVICE_CREDENTIAL_EXPIRED`,
`HUMAN_CREDENTIAL_AS_SERVICE_IDENTITY`, `SERVICE_IDENTITY_NOT_VERIFIED`. Fixture
F-15 revokes a credential while work is in flight and asserts the effect does not
happen.

## Unavailable means NOT READY, never open

`SERVICE_IDENTITY_UNAVAILABLE` is a *retryable* refusal and a *blocking*
readiness signal. Fixture F-14 takes the directory down, asserts the consumer
retries rather than applying, and asserts the readiness snapshot reports the
runtime not ready with that exact code.

The default binding is `RefusingServiceIdentityPort`, whose `binding_state` is
`REFUSING_UNBOUND` and whose `is_available()` is `False`. An unbound identity
port refuses; it never allows.

## No wildcards

```python
WILDCARDS = frozenset({"*", "*:*", "**", ".*", "all", "any", ""})
```

A wildcard row cannot be *loaded*: `AclMatrix.__init__` raises
`MESSAGING_ACL_WILDCARD_PROHIBITED` while reading the matrix, so a matrix with a
wildcard in it does not produce a permissive runtime — it produces a runtime that
will not start. G7 scans the JSON independently.

## What a binding grants

```text
service_id  +  topic_id / subscription_id
            +  event_type          (produce only)
            +  event_versions      the versions the topic carries
            +  organization_scopes
            +  data_classification
```

Every check is against **both** the binding and the verified principal.
Organization scope must be in the binding *and* in the principal's own scopes;
the data classification must match the binding *and* be one the principal may
handle. Mutations M32 and M33 drop the principal half of each and unit tests
catch both.

The eight service principals and their grants are in
`API04_PRODUCER_CONSUMER_ACL_MATRIX.json`. G7 checks the matrix against the topic
register in both directions: a registered producer with no binding, and a
subscription with no binding, both fail.

## The API-03 boundary

One module: `identity/api03_r13_adapter.py`. The consumed surface is written down
in `reconciliation.CONSUMED_SURFACE` and is four directory methods, nine
credential-record fields and two enumerations. The adapter implements no
authorization rule — it answers "who is this peer, and is its credential
currently good?" — and it refuses to be constructed with a predecessor label
containing "ACCEPTED" or "CLOSED".
