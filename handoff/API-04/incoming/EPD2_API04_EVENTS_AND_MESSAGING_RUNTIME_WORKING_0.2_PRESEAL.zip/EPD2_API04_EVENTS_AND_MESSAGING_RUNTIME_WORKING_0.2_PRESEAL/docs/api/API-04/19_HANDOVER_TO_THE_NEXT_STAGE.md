# Handover

## Status of this handover

```text
PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED
```

Nothing in this document authorises a subsequent stage to begin, and nothing here
records this one as complete. A stage that consumes API-04 consumes it as a
working parallel predecessor, under exactly the constraint this stage applies to
API-03 R13.

## What a consumer of this stage may rely on

**The delivery contract.** At-least-once delivery with an effectively-once
consumer effect. Duplicates arrive; the effect happens once. A consumer author
who assumes no duplicates has written a bug.

**The canonical envelope.** `epd2_core.event_envelope.EventEnvelope`, unchanged,
with transport metadata in AMQP headers and never in the envelope.

**The registers.** `API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json` is the authority
on which topics exist, who may produce and consume them, what ordering each
declares, and what retry and quarantine policy each carries.
`API04_PRODUCER_CONSUMER_ACL_MATRIX.json` is the authority on grants. Neither is
generated; both are governance decisions.

**The reason codes.** Forty codes redeclared from existing registries and
forty-three registered in `contracts/reason-codes/api-04.yml`. A code's meaning
is fixed once (`P13-RSN-004`); a later stage that needs a new fact registers a new
code rather than widening one of these.

**The ports.** PACK-13's, unchanged. A stage that wants a different broker
implements `delivery.BrokerPort`; a stage that wants different storage implements
the `storage.*Store` protocols. Nothing here needs to change for either.

## What a consumer of this stage may not rely on

- that API-04 is accepted or closed — it is neither;
- that these topic names, partition counts or retry budgets are final — they are
  governed, and governance may move them;
- that the API-03 identity surface bound here matches the accepted API-03 — that
  is exactly what the reconciliation exists to determine;
- any throughput or capacity figure — none is measured (OG-API04-08);
- that the envelope is signed — it is not (OG-API04-03).

## The order of operations before any candidate exists

1. API-03 receives independent `ACCEPTED / CLOSED`.
2. Its exact archive and SHA-256 are obtained and verified against the governed
   acceptance record — not against R13.
3. `compare_surfaces(CONSUMED_SURFACE, accepted_surface)` is run and every row is
   recorded and classified.
4. `identity/api03_r13_adapter.py` is updated for every `NAME` and `SHAPE` row.
   No other module changes; if another module needs to change, the adapter
   boundary leaked and that is the finding.
5. The ACL matrix's scopes are re-derived from the accepted directory.
6. The whole suite is re-run: unit, live fixtures, mutations, validator.
7. G22 and G23 are run in an environment that has the accepted archives, so
   neither remains blocked.
8. Only then is the exact accepted SHA-256 bound into `API04_LINEAGE.json`, the
   reconciliation state set, the inventory and manifest regenerated, and a
   candidate assembled — with its own internal status of
   `CANDIDATE_NOT_ACCEPTED`.

Steps 1 through 8 are `CHECKLIST` rows R-01 … R-14 in
`identity/reconciliation.py`, and `assert_may_freeze_lineage` refuses step 8
until step 2 has produced a SHA-256.

## What the next stage inherits as work

The nine entries in `18_OPEN_GAPS.md`, of which three need a decision rather than
code:

- **OG-API04-01** — the canon and PACK-13 disagree about seven event payloads;
- **OG-API04-02** — the `organizational_authority.*` payloads carry no object
  version;
- **OG-API04-03** — envelope signing needs an owner for the key material.

The remaining six are bounded engineering: jittered retry tiers, a scale
qualification, moving the effects into their owning services, and running the two
environment-blocked gates where their inputs exist.

## Interfaces a later stage would extend, not replace

```text
ConsumerTransportPort   pull-side transport; add an adapter, keep the port
ServiceIdentityPort     one implementation today; the type gate is the contract
EffectFn                (connection, record, basis) -> (reference, result)
AUTHORITY_SOURCES       a consequential topic without an entry cannot commit
EFFECTS                 subscription id -> effect function
```

Adding a topic means: a canonical schema in `contracts/events` (owned by the
canon, not by this stage), a row in the topic register, a row in the ACL matrix,
an effect function, and — if it is consequential — an authority source. The
validator fails if any of those five is missing, which is the point.
