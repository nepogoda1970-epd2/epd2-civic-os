# Ordering and versioning

## No global ordering

There is no global order and none is assumed. Ordering is declared per topic,
using PACK-13's own vocabulary — `OrderingScopeKind` — and nothing else:

| kind | meaning | used by |
|---|---|---|
| `per_aggregate` | in order within one aggregate | membership and authority topics |
| `per_organization_and_aggregate` | in order within one aggregate in one organization | legal hold, retention |
| `per_stream` | in order within a named stream | available, unused in this register |

`assess_ordering` is PACK-13's and is called, not re-implemented. A gap and a
replay are different facts with different codes:
`EVENT_ORDERING_GAP_DETECTED` (a position ahead of the checkpoint, retryable —
the missing message may still arrive) and `EVENT_OUT_OF_ORDER` (a position at or
behind the checkpoint).

## The checkpoint

`ConsumerCheckpoint` is per consumer, per ordering scope key. `advance_to`
refuses a position that is not an advance. Moving it **backwards** is a distinct,
authorized operation — `rewind_to` demands a `PrivilegedGrantReference` whose
operation is `consumer_checkpoint_rewind` — because a rewind replays
already-processed events and is safe only because consumers are idempotent.
Two different acts, two different risk profiles, two different methods.

The checkpoint is durable and is saved inside the effect transaction. An earlier
revision kept ordering state in memory per consumer instance, which meant a
restart reset the ordering guarantee; fixture F-06 is what makes the durable
version testable.

## `occurred_at` is not an order

`occurred_at` is a producer wall-clock assertion, carried as evidence of what the
producer believed. Ordering is `sequence_number` plus `assess_ordering`. There is
no code path that sorts by `occurred_at`, and a unit test asserts that by
scanning every module's **executable tokens** — comments and docstrings skipped,
so the sentence saying this never happens does not itself count as it happening.

## Versions

An event version is `major.minor`. The compatibility rules are the canon's:
a minor version adds optional fields; a major version is a new event type as far
as a consumer is concerned.

Two registers say two different things about versions, and keeping them apart
was a correction this revision made:

- the **topic register**'s `event_versions` — what the topic legitimately
  carries;
- each **subscription**'s `supported_event_versions` — what that consumer can
  interpret;
- the **ACL matrix**'s `event_versions` — what this layer authorises, which is
  the topic's set.

So a version the topic carries but this consumer cannot interpret reaches the
compatibility layer and is dead-lettered as `EVENT_VERSION_UNSUPPORTED` — it is
not turned into `CONSUMER_NOT_AUTHORIZED_FOR_SUBSCRIPTION`, which would tell an
operator to fix a grant rather than a consumer. Two facts an operator acts on
differently are two codes (`P13-RSN-002`).

## The mixed-version window

`membership.membership_decision_recorded` carries 1.0 and 1.1. The projection
consumer accepts both; the notification consumer accepts only 1.0. That is not an
accident of the register — it is the window a real rollout produces, and fixture
F-11 publishes a 1.1 event and asserts that the projection applies it while the
notification consumer quarantines it with `EVENT_VERSION_UNSUPPORTED`, and that
the producer's outbox record is `acknowledged` either way.

## Fail closed on a consequential consumer

A consequential consumer that receives a version it does not support raises
rather than dead-lettering: it does not guess, does not skip, and does not apply
a partial interpretation (`P13-DEL-013`). A non-consequential one dead-letters.
Both behaviours are inherited from `ReferenceConsumer` and both are covered by
the parity test.
