# Entering baseline and parallel status

## The mode

```text
PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED
```

This stage was begun and completed in parallel with an API-03 that has not been
independently accepted. That is a deliberate mode, not an oversight, and it has
consequences that are enforced mechanically rather than remembered.

## What was read before anything was written

The bootstrap reading for this stage, all of it carried into this archive and
digest-verified by G1:

- `docs/roadmap/EPD2_PROJECT_ENTRYPOINT.md`
- `docs/roadmap/EPD2_PROGRAM_CONTROL_REGISTER.md`
- `docs/roadmap/EPD2_MASTER_FUTURE_IMPLEMENTATION_REGISTER.md`
- `docs/canonical/TZ-00-domain-event-canon.md` (canon 0.8.0) and
  `docs/canonical/canon-version.json`
- `contracts/events/*.schema.json`, `contracts/schemas/`,
  `contracts/reason-codes/pack-02.yml … pack-15.yml`
- `services/data-plane-service` (PACK-13, the production data plane) in full
- `packages/python/epd2-core` (the canonical envelope, canonical JSON,
  identifiers, reason codes)
- `services/audit-core`
- the V26 governance surface: `CANONICAL_SHA256SUMS.txt`,
  `V26_AUTHORITY_METADATA.txt`, `docs/security/bsi/*`

The requirement identifiers this stage answers to: FIR-ID-001, FIR-AUTH-001,
FIR-TEST-002, FIR-REL-001, FIR-READY-001, FIR-DATA-004, FIR-TIME-001,
FIR-OPS-001, FIR-SEC-SECRET-001, FIR-VOTE-NET-001, FIR-API-001.

## API-03 R13: a working integration predecessor

R13 is externally reviewed. The evidence is carried verbatim in
`identity/api03_r13_adapter.py` and in `API04_LINEAGE.json`:

```text
run id      33280355709
workflow    API-03 R13 external governed review
branch      review/api03-r13-external
head sha    5904ef7212b368f3e734f8be54f5c63f374ea503
conclusion  SUCCESS
artifact    api03-r13-external-review-33280355709  (id 9722794132)
sha-256     1f10da8aff6d4966ba018c7105d5dcabdd75430644a4fe6d281b323633cb6e40
archive     API 03_R13.zip, 40,735,799 bytes
```

**What that review proves:** that a fresh extraction of API-03 R13 passes its
own validator in a clean external environment.

**What it does not prove**, and what nothing in this archive may be read as
saying:

- that API-03 is accepted;
- that API-03 is closed;
- that R13 may be recorded as an accepted predecessor;
- that R13 has been reconciled against the exact accepted API-02;
- that the R13 service-to-service identity surface is final;
- that any API-04 lineage may be frozen.

That list is not only prose. It is `REVIEW_DOES_NOT_PROVE` in
`identity/reconciliation.py`, and the adapter's constructor raises
`ACCEPTED_PREDECESSOR_CLAIM_PROHIBITED` if it is handed a label containing
"ACCEPTED" or "CLOSED".

## The isolated adapter boundary

Everything API-04 consumes from API-03 goes through
`identity/api03_r13_adapter.py`, and the exact surface is written down in
`reconciliation.CONSUMED_SURFACE`: four directory methods, nine credential
record fields, two enumerations. No other module in this service imports
anything API-03-shaped.

The exact R13 archive is not present in this authoring environment. What the
adapter binds is therefore the R13 *interface contract* as the handoff documents
it, through a directory port that the real R13 runtime satisfies;
`binding_state` records that as
`API03_R13_WORKING_INTEGRATION_PREDECESSOR` rather than implying more. The
stand-in directory implements the credential lifecycle the reconciliation will
have to re-verify against the real thing: active, suspended, revoked, expired,
unknown.

## What is forbidden until the exact accepted API-03 exists

- freezing a predecessor SHA-256 (`assert_may_freeze_lineage` raises
  `PREDECESSOR_NOT_ACCEPTED`);
- sealing a C1 inventory;
- assembling a candidate;
- any statement that this stage or its predecessor is accepted, closed, final or
  production ready.

The readiness snapshot carries this in a **third** list —
`lineage_blocking_reason_codes` — separate from `blocking_reason_codes` and
`consequential_blocking_reason_codes`, because an un-reconciled predecessor is
not an outage. The working runtime is ready; the lineage is not.

## The reconciliation, when it becomes possible

`identity/reconciliation.py` carries a fourteen-row checklist (R-01 … R-14) and,
more usefully, a **mechanical** step: `compare_surfaces(CONSUMED_SURFACE,
accepted_surface)` returns every difference in both directions as a typed row —
`SURFACE_ABSENT`, `MEMBER_ABSENT`, `MEMBER_ADDED`, `SURFACE_ADDED`. The
comparison is executed, not read.
