# Privacy, retention and voting isolation

## The payload gate is PACK-13's

`epd2_data_plane_service.domain.reject_prohibited_payload_keys` already decides
which payload keys may exist, with a distinct reason code for each class:

```text
SECRET_PAYLOAD_KEYS    → PAYLOAD_NOT_MINIMAL
GLOBAL_IDENTITY_KEYS   → DATAPLANE_GLOBAL_USER_IDENTIFIER_PROHIBITED
VOTING_MATERIAL_KEYS   → DATAPLANE_VOTING_MATERIAL_PROHIBITED
BULK_CONTENT_KEYS      → PAYLOAD_NOT_MINIMAL
```

API-04 **calls it** rather than keeping a second list, and G17 fails if a second
prohibited-key list is defined in this package. A second list is a list that
disagrees with the first one eventually.

### The `account_id` correction

An earlier revision kept a local list that blanket-prohibited `account_id`. The
canonical `GLOBAL_IDENTITY_KEYS` deliberately does not: FIR-ID-001 prohibits the
*universal* person identifier and names the IAM account identifier as a
legitimate **domain-local** class. Three canonical event families declare
`account_id`, and the blanket ban would have refused all three.

The correction was to delete the local list, not to loosen the canonical one.
`member_id` remains prohibited, because PACK-13 puts it in
`GLOBAL_IDENTITY_KEYS`, and a unit test asserts both facts side by side so the
distinction cannot quietly collapse in either direction. Mutation M16 restores
the over-prohibition and that test catches it.

## What is genuinely new: the wire

PACK-13 models no transport, so it has no reason to model **infrastructure
correlation metadata**. API-04 does:

```text
ip · ip_address · client_ip · remote_addr · x_forwarded_for · forwarded_for
asn · source_asn · user_agent · tls_session_id · tls_fingerprint · ja3 · ja4
cdn_request_id · waf_request_id · edge_request_id · proxy_id
load_balancer_id · device_fingerprint · browser_fingerprint
client_port · source_port
```

FIR-VOTE-NET-001 exists because application-layer unlinkability is not
infrastructure-layer unlinkability, and a broker header is exactly where that
metadata would otherwise ride along. `NETWORK_CORRELATION_METADATA_PROHIBITED`
is raised for any of them, at any depth, in an envelope, in headers or in durable
evidence. Key spellings are normalised, so `X-Forwarded-For`, `x_forwarded_for`
and `X Forwarded For` are the same key. A live test pulls a real message off the
wire and asserts both envelope and headers are clean; another publishes one with
a `client_ip` header and asserts it quarantines.

## Secret-shaped values

Some things are credentials whatever key they sit under: a bearer token, a basic
credential, a JWT, a PEM private key, a DSN with a password in it. Those shapes
are refused by value, not by key name.

## An unsafe refusal cannot be constructed

`assert_evidence_safe` runs in `MessagingRefusal.__init__`. So a refusal carrying
a secret, a global person key or network metadata **fails to exist** — the unsafe
value never reaches a log line, because the object that would carry it there
cannot be built. It raises; it never redacts, because a silent redaction hides
the defect that produced it. Mutation M18 removes the call and a unit test
catches it.

The same gate runs over dead-letter evidence and over the re-drive and replay
recorders.

## Voting isolation, structurally

**There is no voting plane.** Not a second virtual host, not a separate
exchange, not a "restricted" queue.

`P13-VOTE-002` and `P13-VOTE-006`: PACK-13 defines no type that can carry voting
material and refuses it at every payload boundary. `P13-VOTE-008`: the voting
data plane's topology is deferred to PACK-15/16. So voting material cannot enter
this runtime's outbox at all — which is a stronger isolation than a second plane,
because there is nothing to keep off a plane that does not exist.

Three checks hold it in place:

- the register declares `voting_plane: {"exists": false}` with the reasoning, and
  G18 fails if that flips or if any topic id contains `vote`, `ballot` or
  `tally`;
- G18 lists the live broker's virtual hosts and fails on any whose name suggests
  voting;
- a live test tries to publish a payload carrying `ballot_id` and asserts
  `DATAPLANE_VOTING_MATERIAL_PROHIBITED` — the write never happens.

## Retention and legal hold

Every topic carries a retention schedule, and so does its dead-letter policy:

```text
domain-event-p365d   membership events
domain-event-p730d   procedural deadlines
governance-p3650d    organizational authority
audit-p3650d         legal hold, retention
```

`api04_gov.legal_hold` and `api04_gov.disposition_record` hold the governance
state. A record under legal hold cannot be replayed
(`RECORD_UNDER_LEGAL_HOLD`), and a purged or tombstoned subject does not come
back through a replay (`GOVERNED_RECORD_DELETION_FORBIDDEN`). Both are live
tests.

`GOVERNED_RECORD_DELETION_FORBIDDEN` also protects the derived copies this stage
creates — outbox rows, deduplication markers, dead letters, broker queues,
projections, replay evidence — each of which is a `derived_copy_kind` in the
disposition record, so a disposition names what it acted on.
