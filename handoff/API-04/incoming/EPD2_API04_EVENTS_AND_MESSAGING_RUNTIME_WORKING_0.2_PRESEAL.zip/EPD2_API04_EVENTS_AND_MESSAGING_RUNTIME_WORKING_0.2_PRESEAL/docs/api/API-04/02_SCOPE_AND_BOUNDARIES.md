# Scope and boundaries

## What API-04 owns

1. **The transactional outbox on PostgreSQL.** Per domain, never central
   (ADR-070). The transaction that writes domain state writes the event, or
   neither commits.
2. **A real broker runtime.** A pinned RabbitMQ 3.12.1, a governed topology
   declared from a register, publisher confirms, quorum queues, per-principal
   permissions.
3. **The delivery semantics.** At-least-once delivery with an effectively-once
   consumer effect, durable deduplication, ordering within a declared scope,
   bounded retry, quarantine with evidence.
4. **A governed topic and subscription topology.** PACK-13 prescribes none
   (`P13-VOTE-008`); this is the gap API-04 fills, machine-readably.
5. **A service-identity boundary.** Who is the peer on this connection, and is
   its credential currently good.
6. **Governed re-drive**, and the transport half of governed replay.
7. **Readiness, lag and backpressure** for the messaging plane.

## What API-04 does not own, and refuses to

**No messaging-domain ownership.** There is no "messaging domain" here that owns
business state. Every effect writes a table owned by the domain that consumes
the event, inside the transaction this runtime opens; the runtime owns the
*boundary*, not the write. `runtime/boundaries.assert_no_domain_decision` scans
this package for domain verbs and returns an empty list, as a test.

**No identity of its own.** Service identity is derived from API-03 through one
adapter. The runtime answers no question about *whether a peer may do a thing*
beyond the ACL matrix, and it never decides a domain authorization question.

**No global person identity.** There is no cross-domain person key anywhere in
this stage. The payload gate is PACK-13's `reject_prohibited_payload_keys`,
called and not re-implemented, so the canonical `GLOBAL_IDENTITY_KEYS` set is
the single answer to what is prohibited.

**No voting plane.** Not a second virtual host, not a separate exchange, not a
"restricted" queue. PACK-13 defines no type that can carry voting material and
refuses it at every payload boundary (`P13-VOTE-002`, `P13-VOTE-006`), and
`P13-VOTE-008` leaves the voting data plane's topology to PACK-15/16. API-04
therefore provides no voting plane at all, which is a stronger isolation than a
second plane would be: voting material cannot enter this runtime's outbox, so
there is nothing to keep off a plane.

**No API-05 or later scope.** No provider gateway, no vendor callback, no
outbound integration. `assert_no_forward_scope` scans for the markers and G27
scans the tree.

**No new envelope.** There is exactly one event envelope in EPD² and it is
`epd2_core.event_envelope.EventEnvelope`. `assert_no_second_envelope` refuses
any class in this package whose name contains "Envelope".

**No parallel port.** A class named `BrokerPort`, `OutboxStore`,
`IdempotencyStore`, `ConsumerCheckpointStore`, `DeadLetterStore` — or any of the
other names PACK-13 already defines — *defined* in this package is a
re-implementation wearing the port's name.
`assert_no_parallel_port` walks the AST of every module and permits exactly two
new port names: `ConsumerTransportPort`, because PACK-13 models no wire and so
has no pull side, and `ServiceIdentityPort`, because PACK-13 has no transport
and so never needs to know who is on the other end of one.

## Fail closed

Every refusal in this runtime is a refusal, not a downgrade:

- identity unavailable → NOT READY, never open;
- an unsupported event version on a consequential consumer → fail closed, not a
  partial interpretation;
- an unclassified failure → quarantine, not a retry loop;
- trusted time lost → consequential decisions refuse rather than use the local
  clock;
- a consequential commit with no revalidated authority basis → refused, because
  absence is a wiring defect and not a default.

## The one-way boundaries

```text
domain state  ──writes──▶  its own outbox        (never another domain's)
outbox        ──read by──▶ its own dispatcher     (never the domain's connection)
wire          ──carries──▶ the canonical envelope (never transport metadata)
transport     ──proves───▶ a peer identity        (never a message-asserted one)
consumer      ──writes───▶ its own domain's table (never another domain's)
```
