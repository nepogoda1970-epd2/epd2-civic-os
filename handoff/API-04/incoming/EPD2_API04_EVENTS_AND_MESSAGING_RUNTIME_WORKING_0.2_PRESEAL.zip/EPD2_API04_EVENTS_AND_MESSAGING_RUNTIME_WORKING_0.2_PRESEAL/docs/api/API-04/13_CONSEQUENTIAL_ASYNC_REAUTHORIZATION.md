# Consequential asynchronous work — FIR-AUTH-001

```text
authorization at request  !=  authorization at consequential commit
queued authority          !=  permanent authority
```

## The problem

A message sits in a queue. Between the moment its producer was authorized and
the moment its effect commits, the world can move: the authority can be revoked,
the object can be changed by someone else, the governing policy can be replaced,
the work item's own deadline can pass. Applying the effect anyway would exercise
power that was withdrawn.

## Which subscriptions this applies to

The consequential ones, declared in the register and cross-checked by G15
against `API04_CONSEQUENTIAL_ASYNC_REGISTER.json`:

```text
organizational_authority.assigned::governance-service
organizational_authority.revoked::governance-service
```

Both change *who may act*. A subscription that is consequential and does not
require commit reauthorisation fails G15; there is no way to declare one without
the other.

## The check

`revalidate_for_commit` runs **inside the transaction that will write the
effect**, and reads the authority row under lock:

```sql
SELECT * FROM dom_governance.authority_state WHERE authority_id = %s FOR UPDATE
```

`FOR UPDATE` is the difference between a re-check and a fix. A concurrent
revocation either lands before the read, in which case this commit sees it, or
waits behind the commit. There is no window between check and commit for it to
land in.

Five conditions refuse, each with its own code:

| condition | code | fixture |
|---|---|---|
| no current authority row, or it is inactive | `CONCURRENCY_AUTHORITY_LAPSED` | F-16 |
| the object version moved while the work was queued | `CONCURRENCY_STALE_AGGREGATE_VERSION` | F-17 |
| the organization scope changed, or the principal no longer holds it | `ORGANIZATION_SCOPE_MISMATCH` | — |
| the governing policy version changed | `COMMIT_POLICY_VERSION_CHANGED` | F-18 |
| the work item's own deadline passed while it waited | `COMMIT_DEADLINE_EXPIRED` | F-19 |

The first three are PACK-13's codes, used because PACK-13 already names those
facts. The last two are additive: PACK-13 has no queue, so it has no notion of a
policy that moved *while something waited* or a deadline that passed *in a
queue*.

`ConcurrencyPolicy.require_authority_effective_at_execution` is PACK-13's and is
called for the expiry check rather than re-implemented.

## The basis is recorded with the effect

A successful revalidation produces a `CommitAuthorityBasis` — authority id,
organization, scope kind, object version, policy version, the acting service
principal, its credential id, and the moment of revalidation — and the effect
writes it into the row it creates:

```sql
INSERT INTO dom_governance.authority_assignment
    (..., object_version, authority_basis, organization_id) VALUES (...)
```

So the audit answers "on what authority did this commit?" from the row itself,
rather than by reconstruction. The reason code
`COMMIT_AUTHORITY_BASIS_RECORDED` appears both in the deduplication marker and
in the consume outcome.

## Absence is a defect, not a default

```python
def _require_basis(basis, topic_id):
    if basis is None:
        raise ConcurrencyAuthorityLapsedError(
            f"a consequential effect on {topic_id!r} requires a revalidated "
            f"authority basis; absence is a wiring defect, not a default")
    return basis
```

Defence in depth: `revalidate_for_commit` normally refuses first, so this guard
is the second line — a wiring change that stopped calling the revalidation would
otherwise reach the effect with no basis at all. Because it is a second line, the
fixtures do not reach it, so it has its **own** unit test. Mutation M55 disables
it, and that unit test is what catches it. Depth is only depth if it is tested on
its own.

## No authority source, no commit

```python
AUTHORITY_SOURCES = {
    "organizational_authority.assigned": ("dom_governance.authority_state", ...),
    "organizational_authority.revoked":  ("dom_governance.authority_state", ...),
}
```

A topic that is consequential and absent from this map cannot commit. There is
no default authority source and inventing one would be the defect.

## Load shedding is unavailable here

A consequential message is never shed to reduce lag. `OverloadPolicy.shed`
raises `CONSEQUENTIAL_MESSAGE_SHED_PROHIBITED` for any consequential
subscription, because the cheapest way to reduce lag is exactly the one that must
stay unavailable.

## An honest limitation

The canonical `organizational_authority.*` payloads carry no object version, so
the version this commit was requested against is taken from
`OutboxRecord.sequence_number` — which is that version by construction, since the
producer wrote both in one transaction. It works, and it is one indirection more
than it should be. Recorded as OG-API04-02 in `18_OPEN_GAPS.md`: an event that
carried its own object version would let the check stand on the payload alone.
