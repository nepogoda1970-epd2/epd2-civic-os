# The event and message envelope

## There is one envelope, and API-04 did not write it

`epd2_core.event_envelope.EventEnvelope`:

```text
event_id        event_type       event_version
occurred_at     producer         actor(ActorRef)      subject(SubjectRef)
correlation_id  causation_id     payload
integrity(EventIntegrity{payload_hash, signature})
```

API-04 constructs it with the canonical builder, `build_event_envelope`, and
serialises it with `persistence/codec.py`. It adds no field, removes no field,
and defines no second envelope type. `assert_no_second_envelope` walks the AST
of every module in this package and reports any class whose name contains
"Envelope"; the list is empty, and a mutation that adds one is caught.

An earlier revision of this runtime defined its own envelope with transport
fields on it. That was the largest single divergence the canonical cross-check
found, and correcting it is the reason this revision exists.

## Where transport metadata lives instead

ADR-071: transport metadata stays off the envelope, so the envelope remains
canon-neutral. It lives in two places, both of which already existed:

**On the outbox record** — PACK-13's `OutboxRecord` carries `status`,
`attempts`, `publication_evidence`, `sequence_number`, `retention_schedule`,
`under_legal_hold`. None of that is on the event.

**In AMQP headers** — the wire carries the canonical envelope as its body and
the transport facts as headers:

```text
x-epd2-event-version     x-epd2-sequence-number
x-epd2-partition         x-epd2-destination
x-epd2-attempt           x-epd2-reason-code      (retry and quarantine only)
```

The consumer refuses the reverse direction: an envelope arriving with
`attempt`, `delivery_count`, `redelivered`, `queue`, `routing_key`, `partition`,
`offset`, `delivery_tag` or `lease_id` as a **field** is refused with
`ENVELOPE_TRANSPORT_METADATA_PROHIBITED`. A live test pulls a real message off a
real queue and asserts the body's key set is exactly the canonical one.

## Integrity

`compute_payload_hash` is canonical-JSON based and is computed by the builder.
The consumer recomputes it from the payload it received and compares; a mismatch
is `SCHEMA_DIGEST_MISMATCH` — PACK-13's code for that fact, not a new one — and
the message is quarantined without reaching a domain table. Fixture F-09
exercises it by publishing a peer message whose hash does not match its payload.

The `signature` slot exists in the canonical envelope and is not populated by
this stage. That is recorded as an open gap rather than filled with something
that would look like a signature: signing authority belongs to the stage that
owns the key material, and inventing one here would create a second trust root.

## Identity of an event

`OutboxRecord` refuses to be constructed with an `event_id` that differs from
its envelope's, or an `event_type` that differs from its envelope's
(`P13-OBX-005`). A republication therefore cannot mint a new logical event: there
is no second identifier for it to mint.

In the database the same rule is a trigger, not a convention:

```sql
IF NEW.event_id IS DISTINCT FROM OLD.event_id
   OR NEW.envelope IS DISTINCT FROM OLD.envelope
   OR NEW.payload_hash IS DISTINCT FROM OLD.payload_hash
   OR NEW.event_type ... OR NEW.sequence_number ... THEN
    RAISE EXCEPTION 'SCHEMA_VERSION_IDENTITY_IMMUTABLE';
```

so the refusal survives a caller that forgets. Two live tests update those
columns directly and assert the exception.

## Correlation and causation

`correlation_id` and `causation_id` are canonical envelope fields and are UUIDs.
Separately, a *transport header* correlation reference must be request-scoped —
`^req-[0-9a-f]{32}$` — because a stable correlation reference on the wire is a
person-tracking key by another name. `assert_correlation_header_request_scoped`
refuses anything else with `CORRELATION_REFERENCE_NOT_REQUEST_SCOPED`.
