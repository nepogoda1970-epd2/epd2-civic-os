# API-04 — Events & Messaging Runtime / Delivery Semantics

```text
STATUS   PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED
VERSION  0.2.0-preseal
ENGINE   PostgreSQL 16.15 (live)   ·   RabbitMQ 3.12.1 (live)
```

## What this archive is

A working, running events-and-messaging runtime for EPD², built as a set of
**production adapters behind PACK-13's unchanged ports**, plus the two things
PACK-13 deliberately left out because it modelled no transport: a service-identity
boundary and a governed topic topology.

Nothing in `services/data-plane-service`, `packages/python/epd2-core`,
`contracts/` or `docs/canonical/` is modified by this stage. Those files are
carried into the archive verbatim so the adapters can be compiled, run and
reviewed, and every one of their digests is verified by validator gate G1.

## What this archive is not

It is **not** an acceptance, a closure, or a candidate.

- No lineage is frozen. `API04_LINEAGE.json` records
  `accepted_predecessor_sha256: null` and
  `predecessor_binding_state: PENDING_EXACT_ACCEPTED_API03`.
- API-03 R13 is used only as a `WORKING_INTEGRATION_PREDECESSOR`, behind one
  adapter module, for the service-identity surface and nothing else. It is not
  recorded as an accepted predecessor anywhere, and the adapter refuses to be
  constructed with a label that says otherwise.
- Authoritative acceptance is independent of the developer. It is not performed
  here, not claimed here, and not implied by any figure in this archive.

## The delivery contract

```text
AT-LEAST-ONCE DELIVERY  +  EFFECTIVELY-ONCE CONSUMER EFFECT
```

Duplicates are **delivered and absorbed**, not prevented. The absorption is a
primary key in PostgreSQL, not a process dictionary, so two workers racing on a
redelivery lose the race in the storage engine rather than each believing they
were first. The stronger unqualified phrase appears nowhere in this repository
except in the sentences forbidding it, and a structural guard
(`runtime/boundaries.assert_no_stronger_delivery_claim`) asserts that as a test.

## What runs

| | |
|---|---|
| Producer path | one domain transaction writes the domain row and the canonical event into the domain's own outbox, or neither |
| Dispatcher | leases with `FOR UPDATE SKIP LOCKED`, applies PACK-13's `decide_dispatch`, publishes to a real broker with publisher confirms |
| Consumer | verifies transport identity → authorizes against the ACL matrix → validates the payload against its canonical schema → deduplicates, checks version, assesses ordering → revalidates authority for a consequential effect → commits effect, marker and checkpoint in **one** transaction → acknowledges |
| Failure | bounded retry through tiered TTL queues, then quarantine with evidence. There is no fourth outcome and no path that discards a message |

## Measured, not asserted

Every figure below comes from a run recorded in
`validation/api04/validator_result.json` and `17_TEST_EVIDENCE.md`.

- 28 validator gates, G0–G27. Two report `NOT_RUN_ENVIRONMENT_BLOCKED` with the
  exact missing input: G22 (the inherited API-chain non-regression phase needs
  the exact accepted API-01/02/03 archives) and G23 (the DATA no-new-regression
  phase needs the accepted DATA baseline). A blocked gate is never counted as a
  pass.
- 22 mandated cross-service failure fixtures, every one against the live
  PostgreSQL and the live RabbitMQ. A broker outage is `rabbitmqctl stop_app`.
- 70 adversarial mutations, each one applied to a full copy of the tree and run
  against that copy's **own** tests. Each must end in a test failure — not in a
  collection error and not in an empty selection.

## Corrections carried in this revision

This is R2. Five divergences found by cross-checking the previous revision
against the canonical closure were corrected, and each is now held in place by
a test and a mutation:

1. the canonical `epd2_core` envelope is used unchanged; transport metadata
   lives on the outbox record and in AMQP headers (ADR-071);
2. the adapters implement PACK-13's `BrokerPort` and `storage.*Store` protocols
   instead of parallel ones;
3. the topic register is bound to the canonical event catalogue, indexed from
   each schema's own title;
4. existing reason codes are **redeclared**, not re-minted; only genuinely new
   codes are registered, with no pack prefix;
5. the `account_id` over-prohibition was removed — FIR-ID-001 prohibits the
   *universal* identifier, and three canonical event families legitimately
   declare `account_id`.

Three further findings came out of this round's own tests and are recorded in
`18_OPEN_GAPS.md` rather than quietly fixed or quietly ignored.

## Where to start reading

`02_SCOPE_AND_BOUNDARIES.md` for what this stage owns and refuses to own, then
`07_DELIVERY_AND_IDEMPOTENCY.md` for the contract, then `18_OPEN_GAPS.md` for
what is honestly not finished.
