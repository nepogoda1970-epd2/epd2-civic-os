# The transactional outbox

## The invariant, both directions

```text
no committed domain state without its event
no event without committed domain state
```

Both, because only one of them is the obvious one. `domain_unit_of_work` refuses
each direction with `OUTBOX_PUBLICATION_PENDING`:

- an outbox event staged with no authoritative domain write behind it;
- a domain write that declares an event, committing without one.

Two live tests exercise the two directions, and a third rolls the transaction
back mid-flight and asserts that neither the write nor the event survived.

## Per domain, never central

ADR-070. Each domain has its own outbox table in its own schema:

```text
dom_membership.outbox_record
dom_organization.outbox_record
dom_compliance.outbox_record
```

A central `public.outbox` would be a shared mutable table that every domain
writes and every dispatcher scans — a cross-domain coupling with no owner. G8
scans the migrations for one and fails if it appears.

`PostgresOutboxStore` extends PACK-13's `DomainOwnedStore`, so
`_require_owner` refuses a write from another domain with
`DATAPLANE_CROSS_DOMAIN_DIRECT_ACCESS_DENIED`. A live test attempts exactly
that.

## No publish before commit — structurally

The dispatcher runs on a **different connection** and refuses the domain's:

```python
def assert_not_domain_connection(self, domain_connection):
    if domain_connection is self.connection:
        raise PublishBeforeCommitRefused(...)
```

An uncommitted outbox row is therefore not "not published yet" — it is invisible
to the only code that can publish it. A live test writes a row without
committing, runs the dispatcher, and asserts `leased == 0`; then commits and
asserts `leased == 1`.

## Leases

Several dispatchers may run. A lease is a durable claim:

```sql
WITH candidate AS (
    SELECT outbox_record_id FROM dom_<domain>.outbox_record
    WHERE (lease_expires_at IS NULL OR lease_expires_at < now())
      AND ((status IN ('pending','failed') AND next_attempt_at <= now())
        OR (lease_expires_at IS NOT NULL AND lease_expires_at < now()))
      AND status NOT IN ('acknowledged','dead_lettered','superseded_by_replay')
    ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT %s
)
UPDATE ... SET lease_id, lease_holder, lease_expires_at = now() + interval
RETURNING *
```

`FOR UPDATE SKIP LOCKED` keeps two dispatchers from racing *inside this one
statement*; the `lease_expires_at` predicate is what keeps a second dispatcher
from taking work a first one already claimed, because the lease is committed and
its row lock is long gone by then. The first version of this query had only the
`SKIP LOCKED` half, and fixture F-21 caught it: two dispatchers leased the same
record. Mutation M48 reverts the fix and must fail F-21.

A dispatcher that dies holding a lease loses it: `reclaim_expired_leases`
returns expired leases to the pool and records
`DISPATCH_LEASE_RECLAIMED_RECORDED`.

## Status transitions

PACK-13 declares them; this runtime uses `with_status`, which refuses an
undeclared transition, so the transitions are proved rather than assumed:

```text
pending      → dispatching, superseded_by_replay
dispatching  → published, failed, dead_lettered
published    → acknowledged, failed, dead_lettered
failed       → dispatching, dead_lettered
acknowledged → (terminal)
dead_lettered→ dispatching        (only through a governed re-drive)
```

`pending → acknowledged` is absent, deliberately: nothing may skip the middle.

## Published is not acknowledged

`DeliveryOutcome.ACKNOWLEDGEMENT_UNKNOWN` is a first-class outcome
(`P13-DEL-007`), and the adapter produces it rather than guessing: the broker
adapter returns `None` when a publisher confirm did not arrive, and `None` is
neither an error nor a success.

A record in that state is **not finished**. The dispatcher moves it along the
declared `published → failed` transition and schedules another attempt, keeping
the publication evidence (published_at present, acknowledgement absent) on the
record. The possible duplicate that produces is absorbed by the consumer's
deduplication rather than by an assumption. Fixture F-03 suppresses a real
publisher confirm, asserts the outcome, re-dispatches, and asserts the consumer
applies once and suppresses once.

## Backlog

`unacknowledged_age` and `count_by_status` feed the readiness signal, and
`OUTBOX_BACKLOG_THRESHOLD_EXCEEDED` exists for the case where the backlog itself
is the fact an operator needs. A committed command with the broker down is
*pending publication*, not lost — fixture F-01 stops the broker with
`rabbitmqctl stop_app`, dispatches, and asserts the row is still there,
unpublished, with `BROKER_UNAVAILABLE` and `RETRY_SCHEDULED_RECORDED` recorded.
