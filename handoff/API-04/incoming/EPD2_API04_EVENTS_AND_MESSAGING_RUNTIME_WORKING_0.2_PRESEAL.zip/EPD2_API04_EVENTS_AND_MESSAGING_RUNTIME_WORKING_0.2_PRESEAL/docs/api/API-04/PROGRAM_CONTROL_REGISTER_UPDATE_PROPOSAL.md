# Program Control Register — update proposal

**This is a proposal. It is not an applied change.**
`docs/roadmap/EPD2_PROGRAM_CONTROL_REGISTER.md` is carried into this archive
verbatim and is byte-identical to the V26 governance copy; gate G1 verifies its
digest. Applying any of the changes below is a governance act and is not
performed by the developer.

---

## P-01 · Record API-04 as parallel working, not as a completed stage

**Proposed entry**

```text
API-04  Events & Messaging Runtime / Delivery Semantics
        state       PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED
        archive     EPD2_API04_EVENTS_AND_MESSAGING_RUNTIME_WORKING_0.2_PRESEAL
        predecessor API-03 R13, WORKING_INTEGRATION_PREDECESSOR
        lineage     NOT FROZEN — accepted_predecessor_sha256 is null
        acceptance  NOT PERFORMED, NOT CLAIMED
```

**Why.** The register currently has no entry for this stage. An absent entry and
a completed entry are both wrong; the state above is the one the archive's own
status file, lineage record and validator all report.

---

## P-02 · Record the two environment-blocked gates as outstanding, not as passed

**Proposed entry**

```text
API-04 validator   28 gates, G0–G27
        G22  inherited API-chain non-regression   NOT_RUN_ENVIRONMENT_BLOCKED
        G23  DATA no-new-regression               NOT_RUN_ENVIRONMENT_BLOCKED
        blocking input: the exact accepted API-01/02/03 archives; the accepted
        DATA baseline archive and its validator
```

**Why.** Both gates are executable; neither has its inputs here. Recording them
as outstanding keeps the acceptance path honest: they must run before a
candidate, and the register is where that obligation belongs.

---

## P-03 · Register the API-04 additive reason codes

**Proposed entry**

```text
contracts/reason-codes/api-04.yml
        additive codes    43
        redeclared codes  40  (listed in reason_codes.REDECLARED, not re-minted)
        prefix            none — the series has never used one
        owner             events-messaging-runtime (API-04)
```

**Why.** The additive codes are new facts with no precedent in PACK-02 … PACK-15:
a transport layer, a service-identity boundary and a topic ACL. The forty
redeclared ones are deliberately *not* registered again, because `P13-RSN-004`
fixes a code's meaning once and a parallel `API04_SCHEMA_INCOMPATIBLE` beside
`SCHEMA_INCOMPATIBLE` would hand an auditor two codes for one fact.

---

## P-04 · Record the canon / PACK-13 disagreement as a governance item

**Proposed entry**

```text
OPEN  seven canonical event types declare payload keys that PACK-13's
      reject_prohibited_payload_keys refuses:
        membership.membership_activated      membership.membership_suspended
        contribution.flagged                 delegation.snapshot_created
        result.published                     vote.rejected
        vote.superseded
      resolution required: amend the canonical schemas, or amend PACK-13's
      prohibited-key sets. Both are canon-level decisions.
      For vote.* and result.published, see P13-VOTE-008 (PACK-15/16).
```

**Why.** Two governed artefacts disagree, and neither API-04 nor any other
consuming stage can resolve it. Leaving it in a stage's gap list makes it
invisible to the programme; the register is where a cross-artefact conflict
belongs.

---

## P-05 · Record the object-version gap on the organizational authority events

**Proposed entry**

```text
OPEN  organizational_authority.assigned / .revoked carry no object version in
      their canonical payloads. The FIR-AUTH-001 commit-time check therefore
      binds to OutboxRecord.sequence_number, which is the aggregate version by
      construction. An explicit payload field would let the check stand on the
      event alone.
```

**Why.** It works today because of a producer-path invariant. Writing the
dependency down means a later change to the producer path cannot silently break
a consequential authorization check.

---

## P-06 · Record the reference infrastructure as a demonstration, not a decision

**Proposed entry**

```text
API-04 reference runtime
        broker    RabbitMQ 3.12.1  (REFERENCE ADAPTER)
        engine    PostgreSQL 16.15 (governed engine for this stage)
        note      the broker choice is what this stage can demonstrate against,
                  not an EPD2 infrastructure or procurement decision
```

**Why.** A pinned version in a validated archive reads like a decision unless it
is explicitly recorded as not being one. The adapter class constant says so in
code; the register is where it needs to say so to the programme.

---

## What this proposal does not ask for

- No acceptance of API-04.
- No closure of API-04.
- No change to the recorded state of API-03, which remains as its own governance
  records describe it.
- No lineage entry binding API-04 to any predecessor SHA-256; that entry becomes
  possible only after the exact accepted API-03 exists.
