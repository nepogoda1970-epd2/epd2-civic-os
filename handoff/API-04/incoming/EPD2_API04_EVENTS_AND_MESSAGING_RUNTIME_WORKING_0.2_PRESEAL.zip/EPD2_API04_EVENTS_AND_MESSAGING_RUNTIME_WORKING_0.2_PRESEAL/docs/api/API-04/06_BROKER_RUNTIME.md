# The broker runtime

```text
product : RabbitMQ
version : 3.12.1   (Ubuntu 24.04 package 3.12.1-1ubuntu1.2, Erlang/OTP 25)
class   : REFERENCE ADAPTER — not an EPD2 infrastructure or procurement decision
node    : epd2api04@localhost      vhost: epd2-api04
```

## Exactly pinned

`BROKER_VERSION = "3.12.1"`. Not a range, not a floating tag, and never
`latest`: evidence produced against an unknown broker version is not evidence.
`assert_pinned_version` reads the version the server itself reports in its
connection properties and refuses anything else with
`BROKER_VERSION_NOT_PINNED`. Gate G20 connects to the live broker and asserts
the reported version; mutation M39 sets it to `latest` and must be caught.

The adapter class is recorded explicitly:
`REFERENCE_ADAPTER_NOT_A_PROCUREMENT_DECISION`. Choosing RabbitMQ here is a
choice about what this stage can *demonstrate*, not a recommendation about what
EPD² should run.

## The port

`RabbitMqBroker` implements `epd2_data_plane_service.delivery.BrokerPort`
unchanged — one method, `publish(record, destination)`, returning a
`BrokerAcknowledgementReference` or `None`. A unit test compares the adapter's
signature parameter-by-parameter against the Protocol's, including the return
annotation, because a method that merely has the right name is how an adapter
drifts from the port it claims to satisfy.

The same class also implements `ConsumerTransportPort`, which is *additive*:
PACK-13 has no consumer transport because it models no wire, so this is a new
seam rather than a re-implementation. It is deliberately small — `pull`,
`acknowledge`, `abandon_without_acknowledgement`, `republish`, `queue_depth` —
and `pull` holds **one** unacknowledged delivery at a time, so consumer memory
is bounded by one message rather than by queue depth.

## Topology, declared from the register and nowhere else

`declare_from_registry` declares exactly what
`API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json` says exists:

```text
per topic         one durable topic exchange
per subscription  one quorum queue per partition, bound by  <event_type>.p<N>
                  one quarantine queue per partition
                  three retry queues per partition (tiered TTL)
plane-wide        dlx.retry.<vhost>       direct
                  dlx.quarantine.<vhost>  direct
                  dlx.return.<vhost>      direct
```

`dlx.return` deserves its sentence. An expired retry must come back to the queue
it left and to no other. Returning it through the topic exchange would re-fan it
out to every other subscription on that topic — harmless to correctness, because
those consumers deduplicate, and wrong anyway: one subscription's retry is not
another subscription's delivery. Each main queue is therefore also bound to
`dlx.return` by its own name, and each retry queue dead-letters to that exchange
with that name as its routing key.

## Auto-creation is impossible, twice

**In the register:** a topic that is not in it cannot be published to, consumed
from or declared, and `refuse_auto_creation` raises
`TOPIC_AUTO_CREATION_PROHIBITED`.

**At the broker:** every service principal holds `configure=^$` — permission to
declare nothing at all. A live test connects as a service principal, attempts
`queue_declare`, and asserts the broker closes the channel with 403. Only the
provisioner credential may declare, and it declares only the register.

## Partitioning

```python
def partition_for(key, partitions):
    digest = 0
    for byte in str(key).encode("utf-8"):
        digest = (digest * 131 + byte) & 0xFFFFFFFF
    return digest % partitions
```

Deterministic across processes, deliberately: Python's `hash()` is salted per
process, so a `hash()`-based partitioner would send the same aggregate to
different partitions in different workers and silently break per-aggregate
ordering. Unit tests assert stability, boundedness and spread; mutation M40
collapses it to a single partition and must be caught.

## Durability

Quorum queues (`x-queue-type: quorum`), persistent messages
(`delivery_mode=2`), publisher confirms (`confirm_delivery`), and
`mandatory=True` so an unroutable publish raises `BROKER_UNAVAILABLE` rather
than vanishing. Fixture F-02 stops and restarts the broker between publish and
consume and asserts the message survived.

## Credentials

Broker credentials live **outside** the archive, at mode 0600, and the default
location is a per-operator path. A sealed archive that carries a credential is a
sealed archive that leaks one; G25 scans for secret-shaped values and the
allowlist contains exactly one file — the negative fixtures for the scanner
itself, asserted by a test to still contain them.
