# Readiness, lag and stale state — FIR-READY-001

```text
process alive  !=  service ready
service ready  !=  authoritatively ready
port open      !=  safe for consequential traffic
```

## Two levels and a third list

`ready` — the runtime may carry ordinary traffic. Blocked by:

| signal | code |
|---|---|
| broker not connected | `BROKER_UNAVAILABLE` |
| broker version not the pinned one | `BROKER_VERSION_NOT_PINNED` |
| live topology does not match the register | `TOPIC_REGISTRY_RUNTIME_DRIFT` |
| API-03 boundary unreachable | `SERVICE_IDENTITY_UNAVAILABLE` |
| canonical catalogue not loaded | `EVENT_TYPE_NOT_IN_CANONICAL_CATALOGUE` |
| migrations incomplete or drifted | `DATAPLANE_DATABASE_UNAVAILABLE` |
| a dispatcher is unhealthy | `CONSUMER_NOT_READY` |
| open dead letters at or above the threshold | `EVENT_DEAD_LETTER_REQUIRED` |

`authoritatively_ready` — the runtime may carry **consequential** traffic. It
requires everything above *and*:

| signal | code |
|---|---|
| a consumer's lag band exceeds its declared ceiling | `CONSUMER_NOT_READY` |
| a projection watermark is behind its required position | `PROJECTION_STALE` |

`lineage_blocking_reason_codes` — a **third** list, and separate on purpose. An
un-reconciled predecessor is not an outage: the working runtime is ready and the
lineage is not. While no exact accepted API-03 is bound this list contains
`PREDECESSOR_NOT_ACCEPTED` and the other two lists are unaffected. Mutation M57
merges it into the blocking list and a unit test catches it.

Blocking codes are PACK-13's wherever PACK-13 has one, so an operator sees the
same code here as elsewhere for the same fact.

## Lag is a band, never a figure

`P13-EVT-009`: an exact lag figure across organizations is itself information.
`read_lag` uses PACK-13's `lag_band_for` and `ConsumerLag` unchanged and never
exposes the raw count outside the band it maps to:

```text
none · low · moderate · high · severe
```

This is a correction to an earlier revision of this runtime, which reported exact
per-subscription counts. Mutation M58 restores that and a live test catches it;
G16 additionally asserts that no value in the readiness payload's `lag_bands` is
numeric.

A queue that is not declared is **not** zero lag. It is a topology problem, and
readiness reports it as one rather than folding it into a lag reading.

## Backpressure that never drops

```text
degraded mode  !=  weakened invariant
```

The consumer pulls one unacknowledged delivery at a time, so memory is bounded by
one message rather than by queue depth; `prefetch` bounds how many a single poll
will process. When an observed band exceeds a subscription's declared ceiling,
`OverloadPolicy` may:

- **pause** the subscription;
- **throttle** its producer;
- **shed** — but only non-consequential work. `shed` raises
  `CONSEQUENTIAL_MESSAGE_SHED_PROHIBITED` otherwise.

`fair_partition_order` rotates the partition cursor so one hot partition cannot
starve the others.

## Stale reads

`PostgresProjectionStore.require_fresh` refuses to serve a projection whose
applied position is behind its required position: a consequential read never uses
a projection that is behind. `PROJECTION_STALE` and
`PROJECTION_NOT_AUTHORITATIVE` are two different facts and have two codes — "this
is behind" and "this was never the authority" are different problems.

## Every evaluation is recorded

`api04_gov.readiness_snapshot` receives every readiness evaluation with its
signals, so "was it ready at the time?" is answerable afterwards. A live test
asserts the row exists, carries `broker_version_pinned`, and records the
reconciliation state.
