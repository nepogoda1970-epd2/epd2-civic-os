# Replay and re-drive

Two different operations, deliberately separated.

**Re-drive** moves *one dead letter* back to *its own subscription*. PACK-13 has
no re-drive because it has no transport to re-drive onto, so this is additive.

**Replay** re-emits historical events into a bounded range. PACK-13 governs it
(`P13-DEL-010`) and this stage uses that vocabulary rather than inventing one.

## What does not exist

```text
requeue all
replay all
an unbounded replay range
a re-drive to a subscription other than the dead letter's own
a second re-drive of an already re-driven dead letter
a replay that mints a new logical event id for an event that already existed
```

`redrive_bulk` exists **only** to raise
`REDRIVE_BULK_UNBOUNDED_PROHIBITED`. There is no unbounded requeue path to find.
Mutation M60 turns it into a no-op and a unit test catches it.

`ReplayReference` is bounded by construction: it carries `from_sequence`,
`to_sequence`, a `PrivilegedGrantReference`, an `EvidenceReference` and a reason
code, and its `__post_init__` refuses an empty or inverted range and a grant
whose operation is not `event_replay`. An unbounded replay is not something the
type can express.

## Governed re-drive

```text
operator principal + authority reference + reason   (all three, or refused)
    ↓
the dead letter is loaded FOR UPDATE and must name this subscription
    ↓
it must not already be re-driven
    ↓
schema compatibility · authorization NOW · current object state
    ↓
the evaluation is recorded — whether it proceeded or not
    ↓
only then does the message move, and only then is it marked re-driven
```

A refused re-drive still writes its evaluation row with
`REDRIVE_AUTHORITY_MISSING` and the individual check results. A live test refuses
one on a revoked authorization and asserts the row exists, the outcome code is
right, and the dead letter is still not marked re-driven.

## Governed replay

Six checks before a single message moves:

1. **schema compatibility** of the historical version against what the consumer
   accepts now;
2. **the retention horizon** — outside it the replay is refused, not truncated;
3. **legal hold**;
4. **disposition history** — a purged or tombstoned subject does not come back;
5. **current authorization**, not the authorization that existed at origin;
6. **current object state and policy version**, with an explicit
   re-interpretation refusal when the policy has moved and the topic does not
   permit re-evaluation.

Each has its own reason code and each is exercised by a live test:
`EVENT_REPLAY_NOT_AUTHORIZED`, `RECORD_UNDER_LEGAL_HOLD`,
`GOVERNED_RECORD_DELETION_FORBIDDEN`, `SCHEMA_INCOMPATIBLE`,
`REPLAY_REINTERPRETATION_PROHIBITED`, `CONCURRENCY_AUTHORITY_LAPSED`,
`CONCURRENCY_STALE_AGGREGATE_VERSION`.

Check 6 is the one worth dwelling on. Re-judging a historical event under a
policy that did not exist when it happened is not a replay — it is a
retrospective decision wearing a replay's clothes. The refusal is explicit and
has its own code.

## Replay repeats history; it does not rewrite it

`replay_preserves_history` is PACK-13's and is what makes that checkable rather
than asserted. A replay never mints a new logical event id for an event that
already existed — `SUPERSEDED_BY_REPLAY` exists as an outbox status so a replay
can *mark* a record without deleting it.

## Evidence, always

Every replay writes a row: kind, topic, target subscription, ordering scope,
range, operator, authority, grant, reason code, evidence digest, all six check
results, the policy version, whether history was preserved, the outcome code and
the message count. **A refused replay records `message_count = 0` and the emit
callback is never reached** — a live test passes an `emit` that fails the test if
it is called.

## Kinds

```text
exact_message       exactly one sequence position, asserted equal at both ends
bounded_range       from_sequence … to_sequence
projection_rebuild  the projection's own ordering scope and range
selected_consumer   one subscription, one bounded range
```
