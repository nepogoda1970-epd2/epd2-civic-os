# Test evidence

Everything below is measured by a run, not asserted by a document. The
authoritative record is `validation/api04/validator_result.json`, written by
`scripts/validate_api04.py`, which runs the suite itself and parses its JUnit
output rather than trusting a summary.

## The suite

```text
628 tests   0 failures   0 errors   0 skipped

  350  tests/unit        properties that hold without a broker or a database
   24  tests/fixtures    the mandated cross-service failure fixtures
   43  tests/live        governed operations and structural invariants, live
  211  tests/mutation    70 mutations × (target match, detector selects, detected)
                         + the catalogue's own coverage assertion
```

Zero skipped is deliberate. A skipped test in a preseal is a property nobody
checked, and there is no environment in which this suite degrades gracefully:
without the live PostgreSQL and the live RabbitMQ it fails, loudly.

## The infrastructure the evidence was produced on

```text
PostgreSQL  16.15      asserted from SHOW server_version, refused otherwise
RabbitMQ    3.12.1     asserted from the server's own connection properties
node        epd2api04@localhost      vhost  epd2-api04
Python      3.11
```

Nothing on the failure path is mocked. A broker outage is
`rabbitmqctl stop_app`. A lost acknowledgement is a publisher confirm that never
arrives. A consumer crash closes a real channel and leaves a real unacknowledged
delivery on a real quorum queue. A revoked authority is a row that changes under
`SELECT … FOR UPDATE` while the work is in flight.

## The twenty-two mandated failure fixtures

| | scenario | asserted outcome |
|---|---|---|
| F-01 | broker down when the domain commits | deferred, `BROKER_UNAVAILABLE`, the row survives unpublished, publishes on recovery |
| F-02 | broker restarts between publish and consume | the quorum queue survives; the message applies once |
| F-03 | publisher confirm never arrives | `published` + `acknowledgement_unknown`, `DELIVERY_ACKNOWLEDGEMENT_MISSING`, re-attempted, duplicate suppressed downstream |
| F-04 | consumer dies after the effect, before the acknowledgement | one effect, redelivery suppressed |
| F-05 | the same event delivered twice | one effect, one `EVENT_DUPLICATE_SUPPRESSED` |
| F-06 | a message arrives out of order | refused and retried, `EVENT_ORDERING_GAP_DETECTED`, no effect |
| F-07 | a poison message | quarantined on the first attempt, `SCHEMA_INCOMPATIBLE`, main queue empty |
| F-08 | a payload missing a required field | quarantined, no domain write |
| F-09 | the payload hash does not match the payload | quarantined, `SCHEMA_DIGEST_MISMATCH` |
| F-10 | an event type not in the canonical catalogue | quarantined, `EVENT_TYPE_NOT_IN_CANONICAL_CATALOGUE` |
| F-11 | the mixed-version window (1.0 / 1.1) | applied where understood, `EVENT_VERSION_UNSUPPORTED` where not |
| F-12 | a producer not bound to the topic | never reaches the wire; the outbox row is dead-lettered |
| F-13 | a consumer not bound to the subscription | quarantined, no effect |
| F-14 | the API-03 identity boundary unreachable | retried, and the readiness snapshot reports NOT READY |
| F-15 | the acting credential revoked in flight | `SERVICE_CREDENTIAL_REVOKED`, no effect |
| F-16 | authority revoked while queued | `CONCURRENCY_AUTHORITY_LAPSED`, no assignment row |
| F-17 | object version moved while queued | `CONCURRENCY_STALE_AGGREGATE_VERSION` |
| F-18 | policy version changed while queued | `COMMIT_POLICY_VERSION_CHANGED` |
| F-19 | the work item's own deadline expired | `COMMIT_DEADLINE_EXPIRED` |
| F-20 | the database unreachable at commit | nothing acknowledged, no partial effect, applies once on recovery |
| F-21 | a dispatcher dies holding a lease | the lease is respected, then reclaimed; the record still goes out |
| F-22 | the retry budget runs out | exactly `max_attempts − 1` retries, then quarantine with `RETRY_BUDGET_EXHAUSTED_RECORDED` |

Two controls sit alongside them: **F-16b** applies the same consequential path
with nothing changed and asserts the authority basis is recorded on the row, and
**F-21b** asserts two dispatchers never lease the same record.

## The adversarial mutation suite

Seventy mutations, across nineteen governed areas:

```text
delivery 8 · privacy 6 · identity 6 · reauthorization 6 · boundaries 5
topology 5 · envelope 4 · reason codes 4 · lineage 4 · acl 4 · replay 4
transport 3 · readiness 2 · redrive 2 · outbox 2 · engine 2
lag 1 · backpressure 1 · clock 1
```

The procedure, per mutation, with no shortcut in it:

1. copy the whole tree to a scratch directory — sources, contracts, registers;
2. apply exactly one substitution, asserted beforehand to match **exactly once**
   in its file;
3. run the **mutated copy's own** tests, from inside the mutated copy, against
   the same live PostgreSQL and RabbitMQ;
4. require the run to end in *test failures* — exit code 1.

Step 4 is what makes this an assertion rather than a ritual. A `-k` expression
that selected nothing would exit 5; a mutation that crashed on import would exit
2 or 3. Both are rejected, so "detected" always means a test asserted the
property and the property was gone. The green half is separate: the same
selection on the unmutated tree must collect at least one test.

Three mutations were **not** detected on the first run, and each exposed a real
hole rather than a bad mutation:

- **M02** — the mutation itself was too weak; rewritten to actually put transport
  metadata into the envelope.
- **M07** — nothing asserted that every reason code the module defines is
  published in one of its two lists. Two tests were added: one over the module's
  constants, one over every `rc.NAME` the package actually raises.
- **M55** — `_require_basis` is defence in depth, so the fixtures never reach it;
  `revalidate_for_commit` refuses first. It now has its own unit test, because
  depth is only depth if it is tested on its own.

## Defects this round's tests found in this round's code

Recorded because a test that found nothing is a test that proved nothing:

1. **The deduplication marker and the effect were in two different
   transactions.** The consumer's stores were held on a long-lived connection
   while the effect ran on a per-message one. A hanging fixture exposed it;
   `_ConsumerStores` now binds all three stores to the transaction's own
   connection.
2. **Leases were not respected.** `lease_batch` relied on `FOR UPDATE SKIP
   LOCKED` alone, and since the lease commits, its row lock is gone — a second
   dispatcher took the same record. F-21 and F-21b caught it; the query now
   excludes live leases explicitly. M48 reverts the fix.
3. **An unknown acknowledgement was treated as finished.** A record published
   without a confirm was never re-attempted. F-03 caught it; the dispatcher now
   moves it along the declared `published → failed` transition and schedules
   another attempt.
4. **A retry re-fanned out to every subscription on the topic.** Retry queues
   dead-lettered back through the topic exchange. A dedicated `dlx.return`
   exchange now routes each retry back to the queue it left.
5. **The consume ACL conflated authorisation with compatibility.** A version the
   topic legitimately carries but a consumer cannot interpret was refused as an
   authorisation failure. The two are now two layers and two codes.
6. **Retention schedules on written records were unasserted.** G19 measured its
   own coverage and found only the replay-side legal-hold tests; live tests were
   added asserting that the outbox row and the quarantine row each carry the
   schedule their topic declares.
7. **An applied effect recorded no reason code**, and the non-consequential
   marker borrowed `READINESS_EVALUATED_RECORDED`. F-16b caught it;
   `CONSUMER_EFFECT_APPLIED_RECORDED` was registered for the fact.

## The validator

Twenty-eight gates, G0–G27. Two report `NOT_RUN_ENVIRONMENT_BLOCKED` with the
exact missing input and are listed under `environment_blocked_gates`:

```text
G22  inherited API-chain non-regression
     needs the exact independently accepted API-01, API-02 and API-03 archives.
     API-03 R13 is a working integration predecessor and is not a substitute.
G23  DATA no-new-regression
     needs the accepted DATA baseline archive and its validator.
```

A blocked gate is never counted as a pass. The run's result is computed from
failures only, and the blocked list is reported separately so the two can never
be confused.

Terminal line:

```text
API04_PRESEAL_RESULT:PASS:validation/api04/validator_result.json
```

## What the evidence does not show

- No throughput, latency or capacity figure. None is measured (OG-API04-08), and
  nothing here should be read as one.
- No evidence about the exact accepted API-01, API-02 or API-03, because none is
  present in this environment.
- No acceptance. The validator's own output records
  `"authoritative_verification": "NOT PERFORMED"` and
  `"self_acceptance_claim": "NONE"`.
