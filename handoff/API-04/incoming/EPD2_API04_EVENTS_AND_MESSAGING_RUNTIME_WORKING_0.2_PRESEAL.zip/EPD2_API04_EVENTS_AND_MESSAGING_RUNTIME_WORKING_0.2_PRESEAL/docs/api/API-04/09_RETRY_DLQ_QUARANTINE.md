# Retry, dead-letter and quarantine

## Three outcomes, and no fourth

A delivered message ends in exactly one of:

```text
APPLIED     the effect committed, the marker completed, the message acknowledged
RETRIED     republished into a retry tier with an incremented attempt count
QUARANTINED a dead-letter record was written, then the message moved to the
            quarantine queue, then acknowledged
```

There is no path that discards a message. `MESSAGE_SILENT_DROP_PROHIBITED`
exists as a code, and mutation M45 inserts a silent drop into `_dispose`;
fixture F-07 catches it.

## Which failures retry

A declared set, not a default:

```text
BROKER_UNAVAILABLE              the transport is down
DATAPLANE_DATABASE_UNAVAILABLE  the database is down
SCHEMA_REGISTRY_UNAVAILABLE     the registry is unreachable
SERVICE_IDENTITY_UNAVAILABLE    the API-03 boundary is unreachable
CONSUMER_NOT_READY              this consumer is not ready yet
EVENT_ORDERING_GAP_DETECTED     the missing message may still arrive
RETRY_SCHEDULED_RECORDED
```

Everything else quarantines, **including anything unclassified**. An
unclassified exception becomes `FAILURE_CLASS_UNKNOWN` and quarantines rather
than looping: a failure nobody has classified is not a failure anybody has shown
to be transient. Mutation M44 makes `SCHEMA_INCOMPATIBLE` retryable — a payload
that can never become valid would then occupy the queue until its budget ran out
— and fixture F-07 catches it.

## Bounded, tiered backoff

Retry tiers are queues with a fixed message TTL that dead-letter back to the
subscription's own queue:

```text
tier 0    200 ms
tier 1    800 ms
tier 2  3 200 ms   (and every attempt beyond)
```

Fixed at declaration time, so the consumer-side backoff is bounded and
exponential but not jittered; the dispatcher's own backoff, which it computes
through PACK-13's `RetryPolicy`, is. Attempt *n* uses tier `min(n-1, 2)`.

## The budget

Per subscription, from the register: 5 attempts for ordinary topics, 3 for the
consequential authority topics. When `attempt >= max_attempts` the disposition
is `RETRY_BUDGET_EXHAUSTED_RECORDED` and the message quarantines. Fixture F-22
holds a retryable failure open — the identity directory stays unavailable —
drives the loop until the budget runs out, and asserts: exactly
`max_attempts - 1` retries, one quarantine, the dead-letter row carrying
`RETRY_BUDGET_EXHAUSTED_RECORDED` and `attempt_count == max_attempts`, the main
queue empty and the quarantine queue holding one.

## Quarantine evidence

A dead-letter record carries who, what, why, how many attempts, when, its
classification and its retention schedule — and a **minimised** envelope
reference:

```text
event_id  event_type  event_version  producer  occurred_at
correlation_id  payload_hash
```

No payload. The topic's own dead-letter policy decides whether a minimised copy
is retained, and every `restricted` topic says `REFERENCE_ONLY`. A live test
quarantines a restricted-topic message and asserts the record has no `payload`
key, `payload_retained` is false, and the whole reference passes
`assert_evidence_safe` — the same gate every refusal passes.

The evidence is written **before** the message moves to the quarantine queue,
inside a transaction. A quarantined message with no record of why would be worse
than a lost one.

## Poison messages

A message that will never succeed is detected as such rather than retried
forever (`P13-DEL-012`). On the dispatch side `decide_dispatch` returns
`DEAD_LETTER` with `EVENT_POISON_MESSAGE` when a deterministic failure has been
observed. On the consume side a schema-invalid payload is not retryable and
quarantines on the first attempt: fixture F-07 publishes a payload whose
`status` is outside the canonical enumeration and asserts one dead letter,
`SCHEMA_INCOMPATIBLE`, an empty main queue and one quarantined message.

## Review

`awaiting_review` lists dead letters that are neither reviewed nor re-driven, and
`open_count` feeds readiness: at 25 open dead letters the runtime reports
`EVENT_DEAD_LETTER_REQUIRED` as a blocking condition. A quarantine queue nobody
looks at is a slower form of dropping messages.
