# Threat model

Each entry is a way this runtime could be made to do the wrong thing, what stops
it, and what proves the stop is real. "Proved by" names a test or a mutation; a
control with no proof is listed as a gap in `18_OPEN_GAPS.md` instead.

## T-01 A message asserts its own producer identity

**Attack.** A peer publishes an envelope claiming `producer: membership-service`
and the runtime treats that as identity.

**Control.** Identity comes only from a `TransportCredential`, which only a
transport that authenticated its peer can produce. `MessageAssertedIdentity` is a
separate type with no conversion, refused by type before any value is read.

**Proved by.** Unit tests on the type gate; mutations M20, M21.

## T-02 An unauthorized service publishes to a topic

**Attack.** A service with a valid broker credential publishes to a topic it does
not own.

**Control.** Two layers. The broker's `write` regex is bounded to that
principal's own exchanges; the ACL matrix requires an exact produce binding for
`(service, topic, event_type, version, scope, classification)`, evaluated
**before** the publish.

**Proved by.** Fixture F-12 asserts the message never reaches the wire and the
outbox row is dead-lettered; mutation M49 moves the check after the publish.

## T-03 A protected topic is created by being used

**Attack.** A publish to an undeclared topic auto-creates it, bypassing the
register.

**Control.** Service principals hold `configure=^$` — they may declare nothing —
and the register refuses an unregistered topic before the broker is reached.

**Proved by.** A live test asserting a 403 channel close; G7 checks the live
permissions; mutations M36, M37.

## T-04 A duplicate delivery causes a second effect

**Attack.** A redelivery after a crash, a broker restart or an unconfirmed
publish applies the effect twice.

**Control.** Durable deduplication on a primary key, in the same transaction as
the effect.

**Proved by.** Fixtures F-03, F-04, F-05; the parity test; mutation M43 restores
per-process deduplication.

## T-05 A message is silently dropped

**Attack.** A refusal path acknowledges and returns without writing evidence.

**Control.** Three outcomes and no fourth; quarantine evidence is written before
the message moves.

**Proved by.** Fixture F-07; mutation M45 inserts exactly this drop.

## T-06 A permanently failing message occupies the queue forever

**Attack.** A poison message is classified as retryable and consumes capacity
indefinitely.

**Control.** A declared retryable set, a bounded budget per subscription, tiered
TTL retry queues, then quarantine.

**Proved by.** Fixtures F-07, F-22; mutations M44, M47.

## T-07 Queued work commits on an authority that has lapsed

**Attack.** An authority is revoked while a consequential message waits, and the
effect applies anyway.

**Control.** `revalidate_for_commit` reads the authority `FOR UPDATE` inside the
effect transaction; five conditions refuse.

**Proved by.** Fixtures F-16 … F-19; mutations M50 … M55.

## T-08 An event is published before its domain state commits

**Attack.** The dispatcher sees an uncommitted row and publishes it; the
transaction then rolls back.

**Control.** The dispatcher runs on a different connection and refuses the
domain's, so an uncommitted row is invisible to it.

**Proved by.** Live tests on both halves; mutation M67.

## T-09 Domain state commits without its event, or the reverse

**Attack.** One of the two writes is lost, leaving state and events disagreeing.

**Control.** `domain_unit_of_work` refuses both directions before committing.

**Proved by.** Three live tests; mutation M66.

## T-10 A tampered payload is applied

**Attack.** A peer changes the payload and leaves the integrity hash alone, or
sends a payload the schema forbids.

**Control.** Schema validation and payload-hash recomputation at the boundary,
before any effect.

**Proved by.** Fixtures F-08, F-09; mutations M04, M46.

## T-11 Infrastructure metadata correlates people across events

**Attack.** A client address, TLS fingerprint or CDN request id rides in a broker
header and links otherwise unlinkable events.

**Control.** `NETWORK_CORRELATION_KEYS` refused at any depth, in envelopes,
headers and durable evidence; header correlation references must be
request-scoped.

**Proved by.** Live tests both directions; mutations M14, M17.

## T-12 A secret reaches a durable record or a log line

**Attack.** A refusal detail or a quarantine record carries a token or a DSN with
a password.

**Control.** `assert_evidence_safe` runs in the refusal constructor, so the
unsafe refusal cannot be constructed; the same gate runs over quarantine, re-drive
and replay evidence. G25 scans the archive.

**Proved by.** Unit tests; mutation M18.

## T-13 Voting material enters the general plane

**Attack.** A payload carries a ballot, a vote or a tally.

**Control.** PACK-13's payload gate refuses it at write time. There is no voting
plane at all.

**Proved by.** Live test on the producer path; G18 on the register and the live
virtual hosts; mutation M19.

## T-14 A person is identified across domains

**Attack.** A universal person key is carried in a payload, a register or
quarantine evidence.

**Control.** PACK-13's `GLOBAL_IDENTITY_KEYS`, called and not duplicated; G17
scans the registers.

**Proved by.** Unit tests; mutation M16 (which fails in the *over*-prohibiting
direction, the failure this revision corrected).

## T-15 An operator re-drives or replays their way around a control

**Attack.** "Requeue all" moves a thousand quarantined messages past the checks
that quarantined them; a replay re-judges history under a newer policy.

**Control.** No unbounded requeue path exists; a re-drive is one item to its own
subscription, once, with operator, authority and reason; a replay is bounded by
its type and passes six checks, with an explicit re-interpretation refusal.

**Proved by.** Live tests on each check; mutations M60 … M65.

## T-16 Evidence is produced against the wrong infrastructure

**Attack.** A run against a different broker or engine version is presented as
evidence.

**Control.** The broker version is exactly pinned and asserted from the server's
own report; the engine version is asserted from `SHOW server_version`; migrations
are checksummed with no repair path.

**Proved by.** G20, G21, live tests; mutations M39, M68, M69.

## T-17 A working predecessor is recorded as an accepted one

**Attack.** API-03 R13 is written into a lineage record as an accepted
predecessor, and a candidate is assembled on it.

**Control.** The adapter refuses an "ACCEPTED"/"CLOSED" label at construction;
`assert_may_freeze_lineage` refuses without an exact accepted SHA-256; the
lineage record carries `null`; G2 scans the whole archive for the claim and G3
checks the lineage record.

**Proved by.** Unit tests; mutations M26, M27, M28.

## T-18 A guard is disabled and nobody notices

**Attack.** A refusal is commented out, a check is inverted, an allowlist is
widened.

**Control.** Seventy adversarial mutations, each applied to a full copy of the
tree and run against that copy's own tests, each required to end in a **test
failure** rather than a collection error or an empty selection.

**Proved by.** `tests/mutation/`, and G26.
