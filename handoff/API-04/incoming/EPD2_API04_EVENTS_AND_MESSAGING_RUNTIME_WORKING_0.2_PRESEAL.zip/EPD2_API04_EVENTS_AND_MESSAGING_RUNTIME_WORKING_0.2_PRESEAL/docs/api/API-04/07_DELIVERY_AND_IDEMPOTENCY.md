# Delivery and idempotency

## The contract

```text
AT-LEAST-ONCE DELIVERY  +  EFFECTIVELY-ONCE CONSUMER EFFECT
```

Written that way everywhere, and never shortened. The stronger unqualified
phrase is not a stronger claim this runtime is being modest about — it is a
claim a distributed system with a network cannot make, and writing it would
misrepresent what the code does. `assert_no_stronger_delivery_claim` scans every
module for it and permits it only inside a sentence that forbids it.

The two halves are different promises:

- **at-least-once delivery** — a committed command's event will be published, and
  may be published more than once. A publisher confirm that never arrives, a
  broker restart, a consumer that dies before acknowledging: each can produce a
  second delivery, and each does in the fixtures.
- **effectively-once consumer effect** — the *effect* happens once. The second
  delivery is absorbed.

## Where the absorption happens

`ReferenceConsumer` deduplicates in a process dictionary. That is right for a
reference implementation and wrong for a runtime: a guarantee that lasts as long
as a process is not a guarantee, and two workers racing on a redelivery would
each believe they were first.

`DurableConsumer` subclasses it and changes **exactly one thing** — where the
deduplication record lives:

```sql
INSERT INTO dom_<domain>.deduplication_record
    (consumer_domain, consumer_name, event_id, first_seen_at,
     observation_count, payload_hash, expires_at)
VALUES (...)
ON CONFLICT (consumer_domain, consumer_name, event_id) DO UPDATE
    SET observation_count = deduplication_record.observation_count + 1
RETURNING first_seen_at, observation_count, payload_hash,
          effect_reference, effect_result, reason_code, (xmax = 0) AS inserted
```

Uniqueness is a primary key. The race is lost in the storage engine. A live test
runs two `DurableConsumer` instances on two connections and asserts one applies
and one suppresses.

Everything else is inherited: the order of the checks, the fail-closed on an
unsupported version for a consequential consumer, the ordering assessment, the
result shape. A **parity test** asserts the two produce the same `ConsumerResult`
for the same inputs, so a decision changed upstream reaches this runtime instead
of quietly diverging from it. The one intended difference is asserted too: a
fresh `ReferenceConsumer` forgets, a fresh `DurableConsumer` does not.

## Scope of a deduplication key

`consumer_domain : consumer_name : event_id` (`P13-IDEM-009`). The same event
consumed by two consumers is two independent effects — a projection update and a
notification are not the same thing, and suppressing the second because the first
happened would be a bug, not idempotency.

## The order of the checks, and why

```text
1. deduplication
2. version support
3. ordering
```

Deduplication first, because a redelivery of an event this consumer already
applied must be absorbed **even if the consumer's supported-version set has since
changed**. If the version check came first, narrowing a consumer's supported
versions would turn old, already-applied events into dead letters. That is
PACK-13's ordering, inherited rather than restated, and mutation M42 reverses it;
the parity test catches it.

## One transaction

```text
BEGIN
  read or start the checkpoint for this ordering scope
  observe the event (deduplication)
  if consequential: revalidate the authority under SELECT ... FOR UPDATE
  write the domain effect
  complete the deduplication marker with the effect reference and result
  save the advanced checkpoint
COMMIT
acknowledge
```

Effect, marker and checkpoint commit together or not at all. The stores are
built **per message, on that transaction's own connection** — an earlier
arrangement held them on a long-lived connection, which put the marker and the
effect in two different transactions; a hanging fixture found it, and
`_ConsumerStores` now makes "one transaction" a fact rather than an intention.

The acknowledgement is the last step and is outside the transaction, which is
exactly why at-least-once is the honest description: a process that dies between
the commit and the acknowledgement produces a redelivery, and fixture F-04 does
precisely that, with a real channel close, and asserts one effect.

## Idempotency keys

`IdempotencyPolicy` and `IdempotencyKey` are PACK-13's and are used unchanged.
The reused-key-with-a-different-payload case is a **conflict, not a duplicate**,
and it has its own code: `IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD`. The
deduplication store detects it by comparing the stored payload hash with the
presented one.

## Horizons

The deduplication horizon must cover the replay horizon: a replay that reaches
back further than deduplication remembers would re-apply effects.
`horizon_covers` refuses that with
`DEDUPLICATION_HORIZON_BELOW_REPLAY_HORIZON`. Default horizon: 90 days.
