# Open gaps

Everything here is known, unresolved, and written down instead of worked around.
Each entry says what is missing, what the current behaviour is, and what would
close it. None of them is a defect that a test is hiding; several were found *by*
the tests in this round.

---

## OG-API04-01 · Seven canonical event types cannot be carried on this plane

**What.** Seven of the thirty-four canonical event types in `contracts/events`
declare payload keys that PACK-13's own `reject_prohibited_payload_keys`
refuses:

```text
membership.membership_activated
membership.membership_suspended
contribution.flagged
delegation.snapshot_created
result.published
vote.rejected
vote.superseded
```

**Current behaviour.** They are absent from the topic register, so nothing tries
to publish them. If something did, the write would be refused at the payload
boundary with the canonical prohibition code.

**Why this is not for API-04 to fix.** Two governed artefacts disagree: the canon
declares an event whose payload the data plane refuses. Resolving it means either
amending the canonical schema or amending PACK-13's prohibited-key sets, and both
are canon-level decisions with their own change process. Silently carrying the
event by relaxing the gate here would be the wrong fix, and quietly dropping the
event type would hide the disagreement.

**What closes it.** A governance decision recording which of the two moves, and
for the `vote.*` and `result.published` cases, the PACK-15/16 voting plane that
`P13-VOTE-008` defers those topics to.

---

## OG-API04-02 · The consequential commit binds to the outbox sequence number

**What.** The canonical `organizational_authority.*` payloads carry no object
version, so `revalidate_for_commit` compares the stored `object_version` against
`OutboxRecord.sequence_number` rather than against a version the event itself
carries.

**Current behaviour.** Correct, and one indirection more than it should be. The
sequence number *is* the aggregate version by construction, because the producer
writes the domain row and the outbox record in one transaction — but that is an
invariant of the producer path rather than something the event states.

**What closes it.** An `object_version` (or equivalent) field on the canonical
`organizational_authority.*` payloads, so the commit-time check stands on the
payload alone and does not depend on how the event was written.

---

## OG-API04-03 · The envelope signature slot is not populated

**What.** `EventIntegrity` has a `signature` field. This stage computes and
verifies `payload_hash` and leaves `signature` empty.

**Current behaviour.** Integrity is protected against corruption and against a
payload edited without its hash. It is not protected against a peer that can
write to the broker and compute a hash.

**Why not filled here.** Signing authority belongs to the stage that owns the key
material. Minting a signing key in the messaging runtime would create a second
trust root and a key-rotation problem with no owner.

**What closes it.** A key-management decision and the stage that owns it, after
which this runtime signs on publish and verifies on consume at the same boundary
where it checks the hash today.

---

## OG-API04-04 · Two gates cannot execute in this environment

**What.** G22 (inherited API-chain non-regression) and G23 (DATA
no-new-regression) report `NOT_RUN_ENVIRONMENT_BLOCKED`.

**Why.** G22 runs against the exact independently accepted API-01, API-02 and
API-03 archives, none of which is present here; API-03 R13 is a working
integration predecessor and is not a substitute. G23 needs the accepted DATA
baseline archive and its validator.

**Current behaviour.** Both report the exact missing input and are listed in
`environment_blocked_gates`. Neither is counted as a pass, and the run's overall
result is computed from failures only, so a blocked gate can never be mistaken
for a passing one.

**What closes it.** Running the validator in an environment that has those
archives — which is part of the reconciliation checklist (R-08, R-09).

---

## OG-API04-05 · The API-03 surface is bound to a documented contract, not to R13's bytes

**What.** The exact R13 archive is not present in this authoring environment. The
adapter binds the R13 *interface contract* as the handoff documents it, through a
directory port the real R13 runtime satisfies, and `binding_state` records that.

**Current behaviour.** The stand-in directory implements the credential lifecycle
the reconciliation will re-verify: active, suspended, revoked, expired, unknown.
The consumed surface is written down in `CONSUMED_SURFACE` so the comparison is
mechanical rather than a reading exercise.

**What closes it.** R-03 and R-04 of the reconciliation checklist: enumerate the
accepted API-03's S2S identity surface and run
`compare_surfaces(CONSUMED_SURFACE, accepted_surface)`, then update the adapter —
and only the adapter — for every `NAME` and `SHAPE` row.

---

## OG-API04-06 · Ordering across partitions of one topic is not ordered

**What.** Ordering holds within an ordering scope. A topic with two partitions
gives no ordering *between* them.

**Current behaviour.** Correct and declared: `per_aggregate` means what it says,
and the partition function is deterministic so one aggregate always lands on one
partition. Nothing in the register declares an ordering guarantee wider than a
scope.

**Why it is listed.** Because it is the invariant most likely to be misread by a
future consumer author who wants "the events in order". The register is the
answer, and `assess_ordering` refuses anything that assumes more.

**What closes it.** Nothing needs to; this is a documented boundary rather than a
defect. It is here so that adding a topic that *does* need cross-aggregate
ordering forces the `per_stream` scope kind to be chosen deliberately.

---

## OG-API04-07 · Retry tier backoff is not jittered

**What.** Consumer-side retry uses queues with fixed TTLs (200 ms, 800 ms,
3 200 ms), so a large batch of simultaneous failures retries in a synchronised
wave.

**Current behaviour.** Bounded and exponential, and adequate at the volumes this
stage demonstrates. The dispatcher's own backoff, which it computes rather than
reading from a queue TTL, is jittered through PACK-13's `RetryPolicy`.

**What closes it.** Either per-message TTL on republish, or a small set of
staggered tiers chosen per message. Both are straightforward; neither is done
here, and pretending the current behaviour is jittered would be worse than saying
it is not.

---

## OG-API04-08 · No throughput or scale qualification

**What.** This stage demonstrates correctness under failure, not performance
under load. There is no sustained-throughput measurement, no queue-depth-under-load
figure and no concurrency qualification.

**Current behaviour.** Concurrency is *bounded* — one unacknowledged delivery per
consumer, a declared prefetch, leased dispatch batches — and the bounds are
tested. How fast it goes is not measured, and no figure in this archive should be
read as a throughput claim.

**What closes it.** A separate qualification stage with its own harness, load
profile and acceptance criteria.

---

## OG-API04-09 · Effects live in this service rather than in their owning services

**What.** `runtime/effects.py` contains the eleven consumer effects. In the
assembled repository each belongs to the service that owns the table it writes.

**Current behaviour.** What API-04 actually owns is the transaction boundary, the
deduplication marker and the authority revalidation — not the business write.
Keeping the effects here makes the boundary demonstrable in one archive; it is a
packaging convenience, not an ownership claim, and `_require_basis` refusing a
missing basis is what keeps the boundary honest.

**What closes it.** Moving each effect into its owning service when the services
are assembled, leaving the transaction boundary here. No interface change is
needed: the effect signature is already `(connection, record, basis)`.
