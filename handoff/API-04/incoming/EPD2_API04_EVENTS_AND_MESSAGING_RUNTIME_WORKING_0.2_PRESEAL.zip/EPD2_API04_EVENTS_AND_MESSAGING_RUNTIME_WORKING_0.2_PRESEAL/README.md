# EPD² API-04 — Events & Messaging Runtime / Delivery Semantics

```text
STATUS   PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED
VERSION  0.2.0-preseal
```

This archive is a **working parallel preseal**. It is not an acceptance, not a
closure and not a candidate. Authoritative acceptance is independent of the
developer and is not performed, claimed or implied here.

## Where to look

| | |
|---|---|
| `docs/api/API-04/01_EXECUTIVE_RESULT.md` | what this is, in one page |
| `docs/api/API-04/` | nineteen documents and ten machine-readable registers |
| `services/events-messaging-runtime/` | the runtime, its tests and its migrations |
| `scripts/validate_api04.py` | twenty-eight gates, G0–G27 |
| `CARRIED_CANONICAL_SHA256SUMS.txt` | the canonical closure, carried verbatim and unmodified |

## Running it

Requires a live PostgreSQL **16.15** and a live RabbitMQ **3.12.1**. Both
versions are asserted from the servers' own reports; evidence produced against
anything else is refused.

```sh
# provision the broker topology and the per-service credentials
python3 scripts/provision_broker.py --secrets-out "$HOME/.epd2/api04-broker.json"

# environment
export API04_POSTGRES_DSN='postgresql://api04@127.0.0.1:5432/epd2_api04'
export API04_BROKER_SECRETS="$HOME/.epd2/api04-broker.json"
export PGPASSWORD=...          # never stored in this archive

# the suite
cd services/events-messaging-runtime && python3 -m pytest tests -q

# the validator (runs the suite itself and writes its evidence)
python3 scripts/validate_api04.py
```

The validator's terminal line is:

```text
API04_PRESEAL_RESULT:PASS:validation/api04/validator_result.json
```

## The delivery contract

```text
AT-LEAST-ONCE DELIVERY  +  EFFECTIVELY-ONCE CONSUMER EFFECT
```

Duplicates are delivered and absorbed, not prevented.

## What is carried and what is authored

Everything under `packages/`, `contracts/` (except
`contracts/reason-codes/api-04.yml`), `docs/canonical/`, `docs/roadmap/`,
`docs/security/`, `services/audit-core/` and `services/data-plane-service/` is
**carried verbatim** from the canonical repository and modified by nothing in
this stage. Gate G1 verifies every digest.

Everything under `services/events-messaging-runtime/`, `docs/api/API-04/`,
`scripts/` and `contracts/reason-codes/api-04.yml` is authored by this stage.
