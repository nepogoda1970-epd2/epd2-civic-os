"""Degraded mode is not a weakened invariant."""

from __future__ import annotations

import pathlib

import pytest

from epd2_events_messaging_runtime.exceptions import ConsequentialMessageShedProhibitedError
from epd2_events_messaging_runtime.runtime.backpressure import OverloadPolicy
from epd2_events_messaging_runtime.topology.catalogue import load_canonical_catalogue
from epd2_events_messaging_runtime.topology.registry import load_topic_registry

REPO_ROOT = pathlib.Path(__file__).resolve().parents[4]


@pytest.fixture(scope="module")
def registry():
    return load_topic_registry(
        REPO_ROOT / "docs/api/API-04/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json",
        catalogue=load_canonical_catalogue(REPO_ROOT),
    )


def test_a_consequential_subscription_is_never_shed(registry):
    consequential = [s for s in registry.subscriptions if s.consequential_effect]
    assert consequential, "the register must contain at least one consequential subscription"
    for sub in consequential:
        with pytest.raises(ConsequentialMessageShedProhibitedError) as excinfo:
            OverloadPolicy.shed(sub)
        assert excinfo.value.reason_code == "CONSEQUENTIAL_MESSAGE_SHED_PROHIBITED"


def test_a_non_consequential_subscription_may_be_shed(registry):
    sub = next(s for s in registry.subscriptions if not s.consequential_effect)
    assert OverloadPolicy.shed(sub) == "BACKPRESSURE_APPLIED_RECORDED"


def test_pause_and_resume_are_driven_by_the_declared_ceiling(registry):
    policy = OverloadPolicy()
    sub = next(s for s in registry.subscriptions if s.lag_band_ceiling == "low")
    assert policy.apply(sub, "none") is None
    assert policy.is_paused(sub.subscription_id) is False
    assert policy.apply(sub, "high") == "BACKPRESSURE_APPLIED_RECORDED"
    assert policy.is_paused(sub.subscription_id) is True
    assert policy.apply(sub, "low") is None
    assert policy.is_paused(sub.subscription_id) is False


def test_producer_throttling_is_recorded_and_never_negative():
    policy = OverloadPolicy()
    policy.throttle_producer("membership-service", -5)
    assert policy.producer_throttle_ms["membership-service"] == 0


def test_partition_order_is_round_robin_so_one_partition_cannot_starve_the_rest():
    assert OverloadPolicy.fair_partition_order(1, 7) == [0]
    assert OverloadPolicy.fair_partition_order(4, 0) == [0, 1, 2, 3]
    assert OverloadPolicy.fair_partition_order(4, 2) == [2, 3, 0, 1]
    for cursor in range(8):
        assert sorted(OverloadPolicy.fair_partition_order(4, cursor)) == [0, 1, 2, 3]
