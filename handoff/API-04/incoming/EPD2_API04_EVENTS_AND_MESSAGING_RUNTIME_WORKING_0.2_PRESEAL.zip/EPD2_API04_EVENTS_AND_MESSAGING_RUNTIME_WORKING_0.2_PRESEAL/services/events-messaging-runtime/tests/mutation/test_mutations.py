"""Every mutation in the catalogue must be caught by this repository's own tests.

The procedure is the same for each row and there is no shortcut in it:

1. copy the whole tree to a scratch directory — sources, contracts, registers;
2. apply exactly one substitution, asserted to match exactly once beforehand;
3. run the **mutated copy's own** tests, from inside the mutated copy, against
   the same live PostgreSQL and RabbitMQ;
4. require the run to end in *test failures* — exit code 1 — and not in a
   collection error, an import error or an empty selection.

Step 4 is the part that makes this an assertion rather than a ritual. A `-k`
expression that selects nothing would end in exit code 5, and a mutation that
crashed on import would end in 2 or 3; both are rejected, so "detected" always
means a test asserted the property and the property was gone.

The green half is `test_the_detector_selects_tests_in_the_unmutated_tree`: the
same selection, on the unmutated tree, must collect at least one test.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path

import pytest

from mutation.mutations import MUTATIONS, Mutation
from support import harness

pytestmark = pytest.mark.mutation

SERVICE = "services/events-messaging-runtime"
SCRATCH = Path(os.environ.get("API04_MUTATION_SCRATCH", "/tmp/api04-mutants"))


@pytest.fixture(scope="session")
def pristine() -> Path:
    return Path(harness.REPO_ROOT).resolve()


def _environment(root: Path) -> dict[str, str]:
    env = dict(os.environ)
    env["API04_REPOSITORY_ROOT"] = str(root)
    env["API04_POSTGRES_DSN"] = harness.POSTGRES_DSN
    env["API04_BROKER_SECRETS"] = str(harness.BROKER_SECRETS)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env.setdefault("PGPASSWORD", os.environ.get("PGPASSWORD", ""))
    return env


def _run_pytest(root: Path, mutation: Mutation, *, collect_only: bool) -> subprocess.CompletedProcess:
    command = [
        sys.executable, "-m", "pytest", *mutation.targets,
        "-k", mutation.selector, "-q", "-p", "no:cacheprovider",
    ]
    command += ["--collect-only"] if collect_only else ["-x"]
    return subprocess.run(
        command,
        cwd=root / SERVICE,
        env=_environment(root),
        capture_output=True,
        text=True,
        timeout=300,
    )


@pytest.mark.parametrize("mutation", MUTATIONS, ids=lambda m: m.id)
def test_the_find_string_matches_exactly_once(pristine: Path, mutation: Mutation):
    """A mutation whose target text moved would otherwise be applied nowhere and
    still look detected, because the unmutated tests would run unchanged."""
    text = (pristine / mutation.path).read_text(encoding="utf-8")
    assert text.count(mutation.find) == 1, (
        f"{mutation.id}: the mutation target appears {text.count(mutation.find)} times "
        f"in {mutation.path}"
    )


@pytest.mark.parametrize("mutation", MUTATIONS, ids=lambda m: m.id)
def test_the_detector_selects_tests_in_the_unmutated_tree(pristine: Path, mutation: Mutation):
    """The green half: the selection is real, and it is not empty."""
    result = _run_pytest(pristine, mutation, collect_only=True)
    assert result.returncode == 0, (
        f"{mutation.id}: the detector does not collect cleanly\n{result.stdout[-2000:]}"
    )
    assert "no tests ran" not in result.stdout, f"{mutation.id}: the detector selects nothing"


@pytest.mark.parametrize("mutation", MUTATIONS, ids=lambda m: m.id)
def test_the_mutation_is_detected(pristine: Path, mutation: Mutation):
    SCRATCH.mkdir(parents=True, exist_ok=True)
    mutant = SCRATCH / f"{mutation.id}-{uuid.uuid4().hex[:8]}"
    shutil.copytree(pristine, mutant, symlinks=True)
    try:
        target = mutant / mutation.path
        source = target.read_text(encoding="utf-8")
        assert source.count(mutation.find) == 1
        target.write_text(source.replace(mutation.find, mutation.replace), encoding="utf-8")

        result = _run_pytest(mutant, mutation, collect_only=False)
        assert result.returncode == 1, (
            f"{mutation.id} ({mutation.area}) was NOT detected as a test failure.\n"
            f"why it matters: {mutation.why}\n"
            f"exit code {result.returncode} (1 = detected; 5 = selected nothing; "
            f"2/3 = collection or internal error)\n"
            f"{result.stdout[-3000:]}\n{result.stderr[-2000:]}"
        )
    finally:
        shutil.rmtree(mutant, ignore_errors=True)


def test_the_catalogue_covers_every_governed_area():
    areas = {m.area for m in MUTATIONS}
    required = {
        "envelope", "reason codes", "boundaries", "privacy", "identity", "lineage",
        "acl", "topology", "transport", "delivery", "reauthorization", "readiness",
        "lag", "backpressure", "redrive", "replay", "outbox", "engine", "clock",
    }
    assert required <= areas, f"no mutation covers {sorted(required - areas)}"
    assert len(MUTATIONS) >= 42, "the mandate is at least 42 adversarial mutations"
    assert len({m.id for m in MUTATIONS}) == len(MUTATIONS)
