"""`DurableConsumer` is `ReferenceConsumer` with its deduplication moved.

Parity is asserted rather than assumed: for the same inputs the two produce the
same `ConsumerResult` shape, so a decision changed upstream reaches this runtime
instead of quietly diverging from it. The one difference is deliberate and is
asserted too — the reference forgets across processes, the adapter does not.
"""

from __future__ import annotations

import uuid
from datetime import timedelta

import pytest

from epd2_data_plane_service.delivery import ConsumerEffect, ReferenceConsumer
from epd2_data_plane_service.exceptions import EventVersionUnsupportedError

from epd2_events_messaging_runtime.persistence import db
from epd2_events_messaging_runtime.persistence.postgres_stores import PostgresDeduplicationStore
from epd2_events_messaging_runtime.runtime.consumer import DurableConsumer
from support import factories, harness

pytestmark = [pytest.mark.live, pytest.mark.parity]


def _pair(connection, *, versions=frozenset({"1.0"}), consequential=True, name="parity"):
    reference = ReferenceConsumer(
        consumer_name=name,
        consumer_domain="projection",
        supported_event_versions=versions,
        consequential=consequential,
    )
    durable = DurableConsumer(
        consumer_name=name,
        consumer_domain="projection",
        supported_event_versions=versions,
        deduplication=PostgresDeduplicationStore("projection", connection),
        connection=connection,
        deduplication_horizon=timedelta(days=90),
        consequential=consequential,
    )
    return reference, durable


@pytest.fixture()
def connection(runtime):
    """Autocommit: these tests exercise the deduplication table itself, and a
    marker held open in an uncommitted transaction is not a durable marker."""
    conn = db.connect(harness.POSTGRES_DSN)
    conn.autocommit = True
    yield conn
    conn.close()


def test_a_first_delivery_is_applied_by_both(connection):
    reference, durable = _pair(connection)
    record = factories.outbox_record(sequence_number=1)
    now = factories.now()
    left = reference.consume(record, checkpoint=factories.checkpoint(0), now=now)
    right = durable.consume(record, checkpoint=factories.checkpoint(0), now=now)
    assert left.effect is right.effect is ConsumerEffect.APPLIED
    assert left.checkpoint.position == right.checkpoint.position == 1
    assert left.reason_code == right.reason_code


def test_a_redelivery_is_suppressed_by_both(connection):
    reference, durable = _pair(connection)
    record = factories.outbox_record(sequence_number=1)
    now = factories.now()
    reference.consume(record, checkpoint=factories.checkpoint(0), now=now)
    durable.consume(record, checkpoint=factories.checkpoint(0), now=now)
    durable.record_effect(record, effect_reference="e", effect_result={}, reason_code="X")

    left = reference.consume(record, checkpoint=factories.checkpoint(1), now=now)
    right = durable.consume(record, checkpoint=factories.checkpoint(1), now=now)
    assert left.effect is right.effect is ConsumerEffect.SUPPRESSED_DUPLICATE
    assert left.reason_code == right.reason_code == "EVENT_DUPLICATE_SUPPRESSED"


def test_out_of_order_is_refused_by_both_with_the_same_code(connection):
    reference, durable = _pair(connection)
    record = factories.outbox_record(sequence_number=5)
    now = factories.now()
    left = reference.consume(record, checkpoint=factories.checkpoint(1), now=now)
    right = durable.consume(record, checkpoint=factories.checkpoint(1), now=now)
    assert left.effect is right.effect is ConsumerEffect.REFUSED
    assert left.reason_code == right.reason_code


def test_a_consequential_consumer_fails_closed_on_an_unsupported_version(connection):
    reference, durable = _pair(connection, consequential=True)
    record = factories.outbox_record(event_version="9.9")
    now = factories.now()
    with pytest.raises(EventVersionUnsupportedError):
        reference.consume(record, checkpoint=factories.checkpoint(0), now=now)
    with pytest.raises(EventVersionUnsupportedError):
        durable.consume(record, checkpoint=factories.checkpoint(0), now=now)


def test_a_non_consequential_consumer_dead_letters_the_same_way(connection):
    reference, durable = _pair(connection, consequential=False, name="parity-nc")
    record = factories.outbox_record(event_version="9.9")
    now = factories.now()
    left = reference.consume(record, checkpoint=factories.checkpoint(0), now=now)
    right = durable.consume(record, checkpoint=factories.checkpoint(0), now=now)
    assert left.effect is right.effect is ConsumerEffect.DEAD_LETTERED
    assert left.reason_code == right.reason_code == "EVENT_VERSION_UNSUPPORTED"


def test_deduplication_comes_before_the_version_check_in_both(connection):
    """A version narrowing must not turn already-applied events into dead
    letters — PACK-13's ordering of the checks, inherited rather than restated."""
    record = factories.outbox_record(event_version="1.0", sequence_number=1)
    now = factories.now()
    reference, durable = _pair(connection, versions=frozenset({"1.0"}), name="narrowing")
    reference.consume(record, checkpoint=factories.checkpoint(0), now=now)
    durable.consume(record, checkpoint=factories.checkpoint(0), now=now)
    durable.record_effect(record, effect_reference="e", effect_result={}, reason_code="X")

    narrowed_reference, narrowed_durable = _pair(
        connection, versions=frozenset({"2.0"}), name="narrowing"
    )
    narrowed_reference._seen = reference._seen
    left = narrowed_reference.consume(record, checkpoint=factories.checkpoint(1), now=now)
    right = narrowed_durable.consume(record, checkpoint=factories.checkpoint(1), now=now)
    assert left.effect is right.effect is ConsumerEffect.SUPPRESSED_DUPLICATE


def test_the_durable_deduplication_survives_a_new_process(connection):
    """The one intended difference. A second `DurableConsumer` — the model of a
    second worker — sees the first one's marker; a second `ReferenceConsumer`
    does not, which is exactly why the override exists."""
    record = factories.outbox_record(sequence_number=1)
    now = factories.now()
    _, first = _pair(connection, name="worker")
    first.consume(record, checkpoint=factories.checkpoint(0), now=now)
    first.record_effect(record, effect_reference="e", effect_result={}, reason_code="X")

    fresh_reference, second_worker = _pair(connection, name="worker")
    assert (
        fresh_reference.consume(record, checkpoint=factories.checkpoint(0), now=now).effect
        is ConsumerEffect.APPLIED
    )
    assert (
        second_worker.consume(record, checkpoint=factories.checkpoint(0), now=now).effect
        is ConsumerEffect.SUPPRESSED_DUPLICATE
    )


def test_two_workers_racing_on_the_same_event_produce_one_effect(connection):
    """The uniqueness is a primary key; the race is lost in the storage engine."""
    record = factories.outbox_record(event_id=uuid.uuid4(), sequence_number=1)
    now = factories.now()
    _, worker_a = _pair(connection, name="racing")
    other = db.connect(harness.POSTGRES_DSN)
    other.autocommit = True
    try:
        _, worker_b = _pair(other, name="racing")
        first = worker_a.consume(record, checkpoint=factories.checkpoint(0), now=now)
        worker_a.record_effect(record, effect_reference="e", effect_result={}, reason_code="X")
        second = worker_b.consume(record, checkpoint=factories.checkpoint(0), now=now)
        assert first.effect is ConsumerEffect.APPLIED
        assert second.effect is ConsumerEffect.SUPPRESSED_DUPLICATE
    finally:
        other.close()
