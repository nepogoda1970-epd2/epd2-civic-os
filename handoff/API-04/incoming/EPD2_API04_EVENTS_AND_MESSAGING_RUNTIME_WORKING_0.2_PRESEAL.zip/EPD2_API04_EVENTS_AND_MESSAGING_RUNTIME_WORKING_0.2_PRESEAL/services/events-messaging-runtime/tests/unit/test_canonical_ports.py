"""Every PACK-13 seam this service claims to use still resolves.

A port renamed upstream fails here as a test rather than as a silent
divergence, which is the whole reason `CANONICAL_PORTS` is a list and not prose.
"""

from __future__ import annotations

import importlib

import pytest

from epd2_events_messaging_runtime import CANONICAL_PORTS, STATUS, VERSION


@pytest.mark.parametrize("reference", CANONICAL_PORTS)
def test_canonical_port_resolves(reference: str):
    module_name, _, attribute = reference.partition(":")
    module = importlib.import_module(module_name)
    assert hasattr(module, attribute), f"{reference} no longer resolves"


def test_status_is_the_declared_working_preseal_status():
    assert STATUS == "PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED"
    assert VERSION.endswith("-preseal")


def test_the_service_declares_no_acceptance():
    forbidden = ("API-04 ACCEPTED", "API-04 CLOSED", "FINAL PASS", "PRODUCTION READY")
    import epd2_events_messaging_runtime as pkg

    text = (pkg.__doc__ or "") + STATUS + VERSION
    for phrase in forbidden:
        assert phrase not in text.upper()
