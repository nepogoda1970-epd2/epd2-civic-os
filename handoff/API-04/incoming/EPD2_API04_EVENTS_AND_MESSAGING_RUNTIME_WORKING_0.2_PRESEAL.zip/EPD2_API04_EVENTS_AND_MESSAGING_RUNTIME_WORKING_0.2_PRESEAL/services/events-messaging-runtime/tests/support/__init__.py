"""Test support: the live harness and the pure builders."""
