"""Transport privacy: PACK-13's payload gate, plus the wire layer it has no reason to model."""

from __future__ import annotations

import pytest

from epd2_data_plane_service.domain import GLOBAL_IDENTITY_KEYS, VOTING_MATERIAL_KEYS

from epd2_events_messaging_runtime.exceptions import (
    CorrelationReferenceNotRequestScopedError,
    GlobalUserIdentifierProhibitedError,
    MessagingRefusal,
    NetworkCorrelationMetadataProhibitedError,
    PayloadNotMinimalError,
    VotingMaterialProhibitedError,
)
from epd2_events_messaging_runtime.runtime import privacy


@pytest.mark.parametrize("key", sorted(privacy.NETWORK_CORRELATION_KEYS))
def test_every_network_correlation_key_is_refused_in_a_header(key: str):
    with pytest.raises(NetworkCorrelationMetadataProhibitedError):
        privacy.assert_no_network_correlation({key: "value"}, context="headers")


def test_network_correlation_is_found_at_any_depth():
    nested = {"a": {"b": [{"c": {"client_ip": "203.0.113.7"}}]}}
    assert privacy.find_network_correlation_keys(nested)
    with pytest.raises(NetworkCorrelationMetadataProhibitedError):
        privacy.assert_no_network_correlation(nested, context="envelope")


def test_key_spelling_variants_are_normalised():
    for spelling in ("X-Forwarded-For", "x_forwarded_for", "X Forwarded For"):
        with pytest.raises(NetworkCorrelationMetadataProhibitedError):
            privacy.assert_no_network_correlation({spelling: "1.2.3.4"}, context="headers")


@pytest.mark.parametrize(
    "value",
    [
        "Bearer abcdefghijklmnopqrstuvwxyz012345",
        "Basic YWxhZGRpbjpvcGVuc2VzYW1lMTIzNDU2",
        "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dBjftJeZ4CVPmB92K27uhbUJU1p1r_wW1gFWFOEjXk",
        "-----BEGIN RSA PRIVATE KEY-----",
        "amqp://user:hunter2@broker:5672/vhost",
    ],
)
def test_secret_shaped_values_are_refused_whatever_key_they_sit_under(value: str):
    with pytest.raises(PayloadNotMinimalError):
        privacy.assert_evidence_safe({"harmless_name": value}, context="evidence")


def test_evidence_carrying_a_global_person_key_is_refused():
    key = sorted(GLOBAL_IDENTITY_KEYS)[0]
    with pytest.raises(GlobalUserIdentifierProhibitedError):
        privacy.assert_evidence_safe({key: "x"}, context="evidence")


def test_account_id_is_not_blanket_prohibited():
    """FIR-ID-001 prohibits the *universal* identifier, not the domain-local IAM
    account identifier. Three canonical event families declare `account_id`; a
    blanket ban would refuse all three."""
    assert "account_id" not in GLOBAL_IDENTITY_KEYS
    privacy.assert_evidence_safe({"account_id": "acc-1"}, context="evidence")
    privacy.assert_payload_admissible({"account_id": "acc-1"}, context="payload")


def test_member_id_remains_prohibited_because_pack13_says_so():
    """The correction was to stop over-prohibiting `account_id`, not to loosen
    the canonical set: `member_id` is in `GLOBAL_IDENTITY_KEYS` and stays
    refused. API-04 keeps no second list, so this is PACK-13's answer verbatim."""
    assert "member_id" in GLOBAL_IDENTITY_KEYS
    with pytest.raises(GlobalUserIdentifierProhibitedError):
        privacy.assert_payload_admissible({"member_id": "m-1"}, context="payload")


@pytest.mark.parametrize("key", sorted(VOTING_MATERIAL_KEYS))
def test_voting_material_cannot_enter_the_plane(key: str):
    with pytest.raises(VotingMaterialProhibitedError):
        privacy.assert_no_voting_material({key: "x"}, context="payload")
    with pytest.raises(Exception):
        privacy.assert_payload_admissible({key: "x"}, context="payload")


def test_a_clean_payload_passes_every_gate():
    payload = {"membership_application_id": "a1", "status": "application_pending"}
    privacy.assert_payload_admissible(payload, context="payload")
    privacy.assert_evidence_safe(payload, context="evidence")
    privacy.assert_no_voting_material(payload, context="payload")
    privacy.assert_no_network_correlation(payload, context="payload")


def test_a_correlation_header_must_be_request_scoped():
    privacy.assert_correlation_header_request_scoped(None, context="headers")
    privacy.assert_correlation_header_request_scoped("req-" + "0" * 32, context="headers")
    for bad in ("member-42", "session-forever", "req-short", "REQ-" + "0" * 32):
        with pytest.raises(CorrelationReferenceNotRequestScopedError):
            privacy.assert_correlation_header_request_scoped(bad, context="headers")


def test_an_unsafe_refusal_cannot_be_constructed():
    """The gate runs in `MessagingRefusal.__init__`, so the unsafe detail never
    reaches a log line — the refusal itself fails to exist."""
    with pytest.raises(NetworkCorrelationMetadataProhibitedError):
        MessagingRefusal("boom", detail={"client_ip": "203.0.113.7"})


def test_a_safe_refusal_keeps_its_detail():
    refusal = MessagingRefusal("boom", detail={"topic_id": "membership.x"})
    assert refusal.detail == {"topic_id": "membership.x"}
    assert refusal.reason_code in str(refusal)


def test_the_prohibited_key_list_is_pack13s_and_not_a_second_one():
    from epd2_data_plane_service.domain import PROHIBITED_PAYLOAD_KEYS as canonical

    assert privacy.PROHIBITED_PAYLOAD_KEYS is canonical
