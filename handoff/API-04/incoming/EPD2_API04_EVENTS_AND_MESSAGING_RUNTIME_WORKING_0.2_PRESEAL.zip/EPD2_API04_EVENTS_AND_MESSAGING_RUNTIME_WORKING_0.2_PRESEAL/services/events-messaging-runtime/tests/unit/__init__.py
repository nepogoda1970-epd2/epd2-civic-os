"""Unit tests: everything that holds without a broker or a database."""
