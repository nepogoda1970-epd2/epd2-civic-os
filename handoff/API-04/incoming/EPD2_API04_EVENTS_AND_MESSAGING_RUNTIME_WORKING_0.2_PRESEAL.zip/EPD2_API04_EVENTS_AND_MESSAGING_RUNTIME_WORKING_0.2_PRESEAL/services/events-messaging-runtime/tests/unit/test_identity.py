"""Service identity: a type decision, not a remembered check."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from epd2_events_messaging_runtime.exceptions import (
    AcceptedPredecessorClaimProhibitedError,
    HumanCredentialAsServiceIdentityError,
    PredecessorNotAcceptedError,
    ServiceCredentialExpiredError,
    ServiceCredentialRevokedError,
    ServiceIdentityAssertedByMessageError,
    ServiceIdentityNotVerifiedError,
    ServiceIdentityUnavailableError,
)
from epd2_events_messaging_runtime.identity.api03_r13_adapter import (
    API03_R13_REVIEW_EVIDENCE,
    Api03R13ServiceIdentityAdapter,
    Api03ServiceCredentialRecord,
    StandInApi03CredentialDirectory,
)
from epd2_events_messaging_runtime.identity.port import (
    CredentialState,
    HumanCredential,
    MessageAssertedIdentity,
    PrincipalClass,
    RefusingServiceIdentityPort,
    TransportCredential,
)
from epd2_events_messaging_runtime.runtime.clock import TimeAuthority

NOW = datetime(2026, 8, 31, tzinfo=timezone.utc)


class FrozenClock:
    def __init__(self, moment: datetime = NOW) -> None:
        self.moment = moment

    def now_utc(self) -> datetime:
        return self.moment


def record(state: CredentialState = CredentialState.ACTIVE, **kw) -> Api03ServiceCredentialRecord:
    return Api03ServiceCredentialRecord(
        service_id=kw.get("service_id", "membership-service"),
        credential_id="cred-membership-service",
        state=state,
        organization_scopes=frozenset({"org:bund"}),
        data_classifications=frozenset({"internal"}),
        trust_anchor="api03:workload-mtls-intermediate",
        not_before=kw.get("not_before", NOW - timedelta(days=1)),
        not_after=kw.get("not_after", NOW + timedelta(days=30)),
        principal_class=kw.get("principal_class", PrincipalClass.SERVICE),
    )


def adapter(directory=None, clock=None) -> Api03R13ServiceIdentityAdapter:
    directory = directory or StandInApi03CredentialDirectory({"svc-membership-service": record()})
    return Api03R13ServiceIdentityAdapter(directory, clock=clock or FrozenClock())


def credential(peer: str = "svc-membership-service") -> TransportCredential:
    return TransportCredential(
        authenticated_by="amqp-plain-over-authenticated-connection",
        peer_identity=peer,
        connection_reference="conn-1",
        presented_at=NOW,
    )


def test_a_transport_credential_verifies():
    principal = adapter().verify(credential(), purpose="publish")
    assert principal.service_id == "membership-service"
    assert principal.credential_state is CredentialState.ACTIVE
    assert principal.attributes["predecessor_label"] == "WORKING_INTEGRATION_PREDECESSOR"


def test_a_message_may_not_assert_its_own_producer_identity():
    with pytest.raises(ServiceIdentityAssertedByMessageError):
        adapter().verify(MessageAssertedIdentity(claimed_service="membership-service"), purpose="p")


def test_a_human_credential_is_not_a_service_identity():
    with pytest.raises(HumanCredentialAsServiceIdentityError):
        adapter().verify(HumanCredential(credential_reference="session-1"), purpose="p")


def test_a_raw_string_is_not_evidence():
    with pytest.raises(ServiceIdentityNotVerifiedError):
        adapter().verify("membership-service", purpose="p")


def test_a_dict_that_looks_like_a_credential_is_not_one():
    with pytest.raises(ServiceIdentityNotVerifiedError):
        adapter().verify({"peer_identity": "svc-membership-service"}, purpose="p")


def test_an_unknown_peer_is_refused():
    with pytest.raises(ServiceIdentityNotVerifiedError):
        adapter().verify(credential("svc-nobody"), purpose="p")


def test_a_revoked_credential_is_refused():
    directory = StandInApi03CredentialDirectory({"svc-membership-service": record()})
    directory.revoke("cred-membership-service")
    with pytest.raises(ServiceCredentialRevokedError):
        adapter(directory).verify(credential(), purpose="p")


def test_a_credential_outside_its_window_is_expired():
    directory = StandInApi03CredentialDirectory(
        {"svc-membership-service": record(not_after=NOW - timedelta(days=1))}
    )
    with pytest.raises(ServiceCredentialExpiredError):
        adapter(directory).verify(credential(), purpose="p")


def test_a_human_principal_class_is_refused_even_with_a_transport_credential():
    directory = StandInApi03CredentialDirectory(
        {"svc-membership-service": record(principal_class=PrincipalClass.HUMAN)}
    )
    with pytest.raises(HumanCredentialAsServiceIdentityError):
        adapter(directory).verify(credential(), purpose="p")


def test_an_unavailable_directory_refuses_rather_than_opens():
    directory = StandInApi03CredentialDirectory({"svc-membership-service": record()})
    directory.set_available(False)
    with pytest.raises(ServiceIdentityUnavailableError):
        adapter(directory).verify(credential(), purpose="p")
    assert adapter(directory).is_available() is False


def test_the_unbound_port_refuses():
    port = RefusingServiceIdentityPort()
    assert port.binding_state == "REFUSING_UNBOUND"
    assert port.is_available() is False
    with pytest.raises(ServiceIdentityUnavailableError):
        port.verify(credential(), purpose="p")


def test_a_transport_credential_names_its_mechanism_and_peer():
    with pytest.raises(ServiceIdentityNotVerifiedError):
        TransportCredential(
            authenticated_by="", peer_identity="svc-x", connection_reference="c", presented_at=NOW
        )


@pytest.mark.parametrize("label", ["ACCEPTED_PREDECESSOR", "API-03 ACCEPTED", "CLOSED"])
def test_r13_may_not_be_labelled_accepted_or_closed(label: str):
    with pytest.raises(AcceptedPredecessorClaimProhibitedError):
        Api03R13ServiceIdentityAdapter(
            StandInApi03CredentialDirectory(), clock=FrozenClock(), predecessor_label=label
        )


def test_an_unknown_predecessor_label_is_refused():
    with pytest.raises(PredecessorNotAcceptedError):
        Api03R13ServiceIdentityAdapter(
            StandInApi03CredentialDirectory(), clock=FrozenClock(), predecessor_label="SOMETHING"
        )


def test_the_review_evidence_is_carried_verbatim():
    assert API03_R13_REVIEW_EVIDENCE["run_id"] == "33280355709"
    assert API03_R13_REVIEW_EVIDENCE["head_sha"] == (
        "5904ef7212b368f3e734f8be54f5c63f374ea503"
    )
    assert API03_R13_REVIEW_EVIDENCE["conclusion"] == "SUCCESS"
    assert API03_R13_REVIEW_EVIDENCE["artifact_sha256"] == (
        "1f10da8aff6d4966ba018c7105d5dcabdd75430644a4fe6d281b323633cb6e40"
    )
    assert API03_R13_REVIEW_EVIDENCE["archive_size_bytes"] == "40735799"


def test_the_time_authority_fails_closed_when_trust_is_lost():
    from epd2_events_messaging_runtime.exceptions import MessagingRuntimeNotReadyError

    clock = TimeAuthority()
    assert clock.require_trusted("commit") is not None
    clock.lose_trust()
    with pytest.raises(MessagingRuntimeNotReadyError):
        clock.require_trusted("commit")
    clock.restore_trust()
    assert clock.trusted is True
