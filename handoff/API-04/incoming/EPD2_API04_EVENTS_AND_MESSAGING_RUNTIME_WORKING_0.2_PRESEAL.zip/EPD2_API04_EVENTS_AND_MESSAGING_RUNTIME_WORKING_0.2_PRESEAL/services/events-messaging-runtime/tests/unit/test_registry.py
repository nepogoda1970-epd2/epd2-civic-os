"""The governed topic register: bound to the catalogue, refusing what is absent."""

from __future__ import annotations

import pathlib
import uuid

import pytest

from epd2_data_plane_service.delivery import OrderingScopeKind

from epd2_events_messaging_runtime.exceptions import (
    SubscriptionNotRegisteredError,
    TopicAutoCreationProhibitedError,
    TopicNotRegisteredError,
)
from epd2_events_messaging_runtime.topology.catalogue import load_canonical_catalogue
from epd2_events_messaging_runtime.topology.registry import load_topic_registry
from support import factories

REPO_ROOT = pathlib.Path(__file__).resolve().parents[4]
REGISTER = REPO_ROOT / "docs/api/API-04/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json"


@pytest.fixture(scope="module")
def registry():
    return load_topic_registry(REGISTER, catalogue=load_canonical_catalogue(REPO_ROOT))


def test_every_topic_id_is_a_canonical_event_type(registry):
    catalogue = load_canonical_catalogue(REPO_ROOT)
    for topic in registry.topics:
        assert topic.event_type in catalogue
        assert topic.topic_id == topic.event_type


def test_every_subscription_points_at_a_registered_topic(registry):
    for sub in registry.subscriptions:
        assert registry.topic(sub.topic_id) is not None


def test_an_unregistered_topic_is_refused(registry):
    with pytest.raises(TopicNotRegisteredError) as excinfo:
        registry.topic("membership.not_registered")
    assert excinfo.value.reason_code == "TOPIC_NOT_REGISTERED"


def test_an_unregistered_subscription_is_refused(registry):
    with pytest.raises(SubscriptionNotRegisteredError):
        registry.subscription("nope::nobody")


def test_auto_creation_is_refused(registry):
    with pytest.raises(TopicAutoCreationProhibitedError):
        registry.refuse_auto_creation(registry.topics[0].topic_id)


def test_there_is_no_voting_plane(registry):
    assert registry.voting_plane_exists is False
    assert set(registry.planes) == {"epd2-api04"}


def test_ordering_vocabulary_is_pack13s(registry):
    for topic in registry.topics:
        assert isinstance(topic.ordering_scope_kind, OrderingScopeKind)


def test_ordering_scope_shape_follows_its_kind(registry):
    aggregate_id = uuid.uuid4()
    scope = factories.scope()
    for topic in registry.topics:
        computed = topic.ordering_scope(aggregate_id=aggregate_id, organization=scope)
        assert computed.kind is topic.ordering_scope_kind
        if topic.ordering_scope_kind is OrderingScopeKind.PER_ORGANIZATION_AND_AGGREGATE:
            assert computed.organization_scope == scope
            assert computed.aggregate_id == aggregate_id
        elif topic.ordering_scope_kind is OrderingScopeKind.PER_AGGREGATE:
            assert computed.aggregate_id == aggregate_id
            assert computed.organization_scope is None


def test_declared_queues_cover_main_and_dead_letter_for_every_partition(registry):
    expected = 0
    for sub in registry.subscriptions:
        expected += registry.topic(sub.topic_id).partitions * 2
    assert len(registry.declared_queues()) == expected


def test_drift_is_reported_in_both_directions(registry):
    live = {"exchanges": set(registry.declared_exchanges()), "queues": set(registry.declared_queues())}
    assert registry.drift_against(live) == []

    missing = dict(live)
    missing["queues"] = set(list(live["queues"])[1:])
    assert any("absent from runtime" in row for row in registry.drift_against(missing))

    extra = dict(live)
    extra["queues"] = live["queues"] | {"queue.not.in.register.p0"}
    assert any("absent from register" in row for row in registry.drift_against(extra))


def test_consequential_topics_require_commit_reauthorisation(registry):
    for topic in registry.topics:
        if topic.consequential_effect:
            assert topic.commit_reauthorisation_required


def test_restricted_topics_keep_reference_only_dead_letters(registry):
    for topic in registry.topics:
        if topic.data_classification == "restricted":
            assert topic.dead_letter_policy["payload"] == "REFERENCE_ONLY"


def test_retry_budgets_are_bounded(registry):
    for topic in registry.topics:
        assert 1 <= int(topic.retry_policy["max_attempts"]) <= 10
    for sub in registry.subscriptions:
        assert 1 <= sub.max_attempts <= 10
