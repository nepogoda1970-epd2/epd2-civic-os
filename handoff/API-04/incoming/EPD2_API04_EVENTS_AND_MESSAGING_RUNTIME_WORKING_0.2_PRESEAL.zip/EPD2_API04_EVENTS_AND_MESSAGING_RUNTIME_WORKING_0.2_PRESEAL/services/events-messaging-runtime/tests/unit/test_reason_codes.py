"""Reason codes: redeclared codes exist upstream, additive codes are registered.

Both directions, because either alone would let the registry and the module
drift: a redeclaration that quietly becomes an invention, or an additive code
that is raised but never registered.
"""

from __future__ import annotations

import pathlib
import re

import pytest
import yaml

from epd2_events_messaging_runtime import reason_codes as rc

REPO_ROOT = pathlib.Path(__file__).resolve().parents[4]
REGISTRY_DIR = REPO_ROOT / "contracts/reason-codes"
API04_REGISTRY = REGISTRY_DIR / "api-04.yml"


def _codes(path: pathlib.Path) -> dict[str, dict]:
    document = yaml.safe_load(path.read_text(encoding="utf-8")) or []
    entries = document if isinstance(document, list) else document.get("codes", [])
    out: dict[str, dict] = {}
    for entry in entries:
        if isinstance(entry, dict) and "code" in entry:
            out[entry["code"]] = entry
    return out


def carried_registries() -> dict[str, dict]:
    known: dict[str, dict] = {}
    for path in sorted(REGISTRY_DIR.glob("*.yml")):
        if path.name == "api-04.yml":
            continue
        known.update(_codes(path))
    return known


def test_every_redeclared_code_exists_in_a_carried_registry():
    known = carried_registries()
    missing = [code for code in rc.REDECLARED if code not in known]
    assert missing == [], f"redeclared codes with no upstream registration: {missing}"


def test_every_additive_code_is_registered_in_api04_yml():
    registered = _codes(API04_REGISTRY)
    missing = [code for code in rc.ADDITIVE if code not in registered]
    assert missing == [], f"additive codes raised but not registered: {missing}"


def test_the_api04_registry_registers_nothing_the_module_does_not_raise():
    registered = _codes(API04_REGISTRY)
    extra = sorted(set(registered) - set(rc.ADDITIVE))
    assert extra == [], f"registered but never raised: {extra}"


def test_no_additive_code_shadows_an_existing_one():
    """P13-RSN-004: a code's meaning is fixed once. Re-minting an existing
    meaning under a new name is the failure this prevents."""
    known = carried_registries()
    shadowed = [code for code in rc.ADDITIVE if code in known]
    assert shadowed == [], f"additive codes that already exist upstream: {shadowed}"


def test_no_pack_prefix_is_used():
    prefixed = [code for code in rc.ADDITIVE if re.match(r"^(API04|API_04|P13|PACK)", code)]
    assert prefixed == [], f"the registry series uses no pack prefix: {prefixed}"


def test_no_generic_catch_all_code():
    """P13-RSN-002. `FAILURE_CLASS_UNKNOWN` is not a generic error: it names one
    specific fact — the failure could not be classified — and quarantines."""
    generic = {"MESSAGING_ERROR", "EVENT_ERROR", "GENERIC_ERROR", "CONFLICT", "UNKNOWN_ERROR"}
    assert generic.isdisjoint(set(rc.ALL))


def test_registry_entries_carry_the_governed_shape():
    registered = _codes(API04_REGISTRY)
    required = {"code", "meaning", "severity", "description", "retryable", "owner",
                "introduced_in_version"}
    for code, entry in sorted(registered.items()):
        missing = required - set(entry)
        assert not missing, f"{code} is missing {sorted(missing)}"
        assert entry["owner"] == "events-messaging-runtime (API-04)"


def test_all_is_the_two_lists_and_has_no_duplicates():
    assert rc.ALL == rc.REDECLARED + rc.ADDITIVE
    assert len(set(rc.ALL)) == len(rc.ALL)


@pytest.mark.parametrize("code", rc.ALL)
def test_every_code_is_screaming_snake_case(code: str):
    assert re.fullmatch(r"[A-Z][A-Z0-9_]*[A-Z0-9]", code), code


def test_every_constant_the_module_defines_is_in_all():
    """`REDECLARED` and `ADDITIVE` are the two published lists, and every code
    the module defines must be in one of them. A constant that is raised but
    listed nowhere is exactly how a code escapes the registry checks above."""
    defined = {
        name: value
        for name, value in vars(rc).items()
        if name.isupper() and isinstance(value, str) and name not in {"REDECLARED", "ADDITIVE", "ALL"}
    }
    missing = sorted(name for name, value in defined.items() if value not in rc.ALL)
    assert missing == [], f"reason codes defined but published in neither list: {missing}"


def test_every_reason_code_the_package_raises_is_published():
    """The same check from the other side: every `rc.NAME` the runtime actually
    uses resolves to a published code."""
    import ast

    from epd2_events_messaging_runtime.runtime import boundaries

    used: set[str] = set()
    for path in sorted(pathlib.Path(boundaries.PACKAGE_ROOT).rglob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Attribute)
                and isinstance(node.value, ast.Name)
                and node.value.id == "rc"
                and node.attr.isupper()
            ):
                used.add(node.attr)
    assert used, "the runtime raises reason codes through the `rc` module"
    unpublished = sorted(
        name for name in used if getattr(rc, name, None) not in rc.ALL
    )
    assert unpublished == [], f"raised but not published: {unpublished}"
