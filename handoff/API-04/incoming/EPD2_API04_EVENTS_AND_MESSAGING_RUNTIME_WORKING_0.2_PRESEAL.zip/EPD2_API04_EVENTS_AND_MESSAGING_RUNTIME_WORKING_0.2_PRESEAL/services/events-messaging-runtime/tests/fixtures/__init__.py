"""The mandatory cross-service failure fixtures (FIR-TEST-002)."""
