"""Governed replay and re-drive: bounded by construction, refused otherwise."""

from __future__ import annotations

import uuid

import pytest

from epd2_data_plane_service.delivery import replay_preserves_history
from epd2_data_plane_service.exceptions import EventReplayNotAuthorizedError

from epd2_events_messaging_runtime.exceptions import (
    RedriveAuthorityMissingError,
    RedriveBulkUnboundedProhibitedError,
    ReplayRangeUnboundedProhibitedError,
)
from epd2_events_messaging_runtime.runtime import redrive as redrive_module
from epd2_events_messaging_runtime.runtime import replay as replay_module
from support import factories


# -- replay -----------------------------------------------------------------


def test_a_bounded_range_validates():
    request = replay_module.ReplayRequest(
        kind="bounded_range",
        topic_id="membership.membership_application_submitted",
        reference=factories.replay_reference(from_sequence=1, to_sequence=10),
    )
    request.validate()


def test_the_replay_reference_cannot_express_an_unbounded_range():
    with pytest.raises(ValueError):
        factories.replay_reference(from_sequence=1, to_sequence=0)
    with pytest.raises(ValueError):
        factories.replay_reference(from_sequence=0, to_sequence=5)


def test_an_exact_message_replay_names_exactly_one_position():
    request = replay_module.ReplayRequest(
        kind="exact_message",
        topic_id="membership.membership_application_submitted",
        reference=factories.replay_reference(from_sequence=4, to_sequence=9),
    )
    with pytest.raises(ReplayRangeUnboundedProhibitedError):
        request.validate()


def test_an_unknown_replay_kind_is_refused():
    request = replay_module.ReplayRequest(
        kind="everything",
        topic_id="membership.membership_application_submitted",
        reference=factories.replay_reference(),
    )
    with pytest.raises(EventReplayNotAuthorizedError):
        request.validate()


def test_the_declared_kinds_are_the_only_ones():
    assert replay_module.REPLAY_KINDS == (
        "exact_message", "bounded_range", "projection_rebuild", "selected_consumer"
    )


def test_a_grant_for_another_operation_does_not_authorize_a_replay():
    from epd2_data_plane_service.delivery import ReplayReference

    with pytest.raises(EventReplayNotAuthorizedError):
        ReplayReference(
            replay_id=uuid.uuid4(),
            requested_by=factories.actor_reference(),
            grant=factories.privileged_grant("consumer_checkpoint_rewind"),
            ordering_scope_key="scope",
            from_sequence=1,
            to_sequence=1,
            requested_at=factories.now(),
            evidence=factories.evidence_reference(),
            reason_code="EVENT_REPLAY_NOT_AUTHORIZED",
        )


def test_replay_repeats_history_rather_than_rewriting_it():
    original = [factories.outbox_record(sequence_number=n) for n in (1, 2, 3)]
    assert replay_preserves_history(original, list(original)) is True
    rewritten = list(original[:2]) + [factories.outbox_record(sequence_number=3)]
    assert replay_preserves_history(original, rewritten) is False


# -- re-drive ---------------------------------------------------------------


def test_there_is_no_unbounded_requeue_path():
    with pytest.raises(RedriveBulkUnboundedProhibitedError) as excinfo:
        redrive_module.redrive_bulk(subscription_id="anything")
    assert excinfo.value.reason_code == "REDRIVE_BULK_UNBOUNDED_PROHIBITED"


@pytest.mark.parametrize(
    "operator, authority, reason",
    [("", "auth-1", "because"), ("op-1", "", "because"), ("op-1", "auth-1", "   ")],
)
def test_a_redrive_requires_operator_authority_and_reason(operator, authority, reason):
    with pytest.raises(RedriveAuthorityMissingError):
        redrive_module.RedriveAuthority(
            operator_principal=operator, authority_reference=authority, reason=reason
        ).validate()


def test_a_complete_redrive_authority_validates():
    redrive_module.RedriveAuthority(
        operator_principal="op-1",
        authority_reference="grant-1",
        reason="schema was fixed under change record CR-14",
    ).validate()
