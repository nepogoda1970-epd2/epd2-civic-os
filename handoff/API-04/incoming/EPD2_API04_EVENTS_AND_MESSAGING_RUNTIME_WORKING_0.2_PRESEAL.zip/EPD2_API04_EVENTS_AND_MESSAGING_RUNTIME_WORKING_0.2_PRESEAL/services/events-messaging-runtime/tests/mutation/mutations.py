"""The adversarial mutation catalogue.

Each entry breaks one property this runtime claims to hold, and names the test
that must fail when it is broken. A mutation nobody notices is a property nobody
is actually testing — that is the whole purpose of the catalogue, and it is why
each row carries `why` in prose: the row is the argument, the run is the proof.

`find` must appear **exactly once** in `path`; the suite asserts that before it
applies anything, so a mutation that silently stopped matching fails loudly
instead of passing as "detected".
"""

from __future__ import annotations

from dataclasses import dataclass

SERVICE = "services/events-messaging-runtime"
SRC = f"{SERVICE}/src/epd2_events_messaging_runtime"

UNIT = "tests/unit"
FIXTURES = "tests/fixtures"
LIVE = "tests/live"


@dataclass(frozen=True, slots=True)
class Mutation:
    id: str
    area: str
    why: str
    path: str
    find: str
    replace: str
    targets: tuple[str, ...]
    selector: str


M = Mutation

MUTATIONS: tuple[Mutation, ...] = (
    # -- the canonical envelope ---------------------------------------------
    M("M01", "envelope",
      "The envelope loses its integrity block, so a tampered payload would ride "
      "undetected.",
      f"{SRC}/persistence/codec.py",
      '        "integrity": {',
      '        "integrity_removed_by_mutation": {',
      (UNIT + "/test_codec.py",), "test_codec"),

    M("M02", "envelope",
      "Transport metadata is written into the canonical envelope, which is the "
      "exact coupling ADR-071 exists to prevent.",
      f"{SRC}/persistence/codec.py",
      '        "payload": dict(envelope.payload),',
      '        "payload": dict(envelope.payload),\n'
      '        "delivery_count": 0,\n'
      '        "routing_key": envelope.event_type,',
      (UNIT + "/test_codec.py",), "transport_metadata"),

    M("M03", "envelope",
      "A second envelope type is defined here, so the canon stops being the "
      "single definition of what an event is.",
      f"{SRC}/persistence/codec.py",
      "def envelope_to_json(",
      "class Api04EventEnvelope:\n    pass\n\n\ndef envelope_to_json(",
      (UNIT + "/test_boundaries.py",), "second_envelope"),

    M("M04", "envelope",
      "The payload hash is recomputed on read instead of carried, so a mismatch "
      "between payload and hash becomes invisible.",
      f"{SRC}/runtime/consumer.py",
      "        expected = compute_payload_hash(record.envelope.payload)",
      "        expected = record.envelope.integrity.payload_hash",
      (FIXTURES + "/test_failure_fixtures.py",), "f09"),

    # -- reason codes --------------------------------------------------------
    M("M05", "reason codes",
      "An additive code takes a pack prefix, which this registry series has "
      "never used.",
      f"{SRC}/reason_codes.py",
      'TOPIC_NOT_REGISTERED: Final = "TOPIC_NOT_REGISTERED"',
      'TOPIC_NOT_REGISTERED: Final = "API04_TOPIC_NOT_REGISTERED"',
      (UNIT + "/test_reason_codes.py",), "test_reason_codes"),

    M("M06", "reason codes",
      "A generic catch-all code appears, and P13-RSN-002 exists precisely to "
      "keep two different operator actions from sharing one code.",
      f"{SRC}/reason_codes.py",
      "ADDITIVE: Final[tuple[str, ...]] = (",
      'MESSAGING_ERROR: Final = "MESSAGING_ERROR"\n\n'
      "ADDITIVE: Final[tuple[str, ...]] = (\n    MESSAGING_ERROR,",
      (UNIT + "/test_reason_codes.py",), "test_reason_codes"),

    M("M07", "reason codes",
      "An existing code is re-minted as an API-04 code, giving an auditor two "
      "codes for one fact.",
      f"{SRC}/reason_codes.py",
      "    SCHEMA_INCOMPATIBLE,\n    SCHEMA_COMPATIBILITY_UNKNOWN,",
      "    SCHEMA_COMPATIBILITY_UNKNOWN,",
      (UNIT + "/test_reason_codes.py",), "test_reason_codes"),

    M("M08", "reason codes",
      "A code is raised that no registry registers.",
      f"{SRC}/reason_codes.py",
      'FAILURE_CLASS_UNKNOWN: Final = "FAILURE_CLASS_UNKNOWN"',
      'FAILURE_CLASS_UNKNOWN: Final = "FAILURE_CLASS_UNREGISTERED"',
      (UNIT + "/test_reason_codes.py",), "test_reason_codes"),

    # -- structural boundaries ----------------------------------------------
    M("M09", "boundaries",
      "A PACK-13 port name is defined here, which is a re-implementation "
      "wearing the port's name.",
      f"{SRC}/transport/ports.py",
      "class ConsumerTransportPort(ABC):",
      "class OutboxStore:\n    pass\n\n\nclass ConsumerTransportPort(ABC):",
      (UNIT + "/test_boundaries.py",), "parallel_port"),

    M("M10", "boundaries",
      "The permitted-new-port allowlist is widened to cover a canonical port, "
      "which turns the guard into a rubber stamp.",
      f"{SRC}/runtime/boundaries.py",
      'PERMITTED_NEW_PORTS = frozenset({"ConsumerTransportPort", "ServiceIdentityPort"})',
      'PERMITTED_NEW_PORTS = frozenset({"ConsumerTransportPort", "ServiceIdentityPort", '
      '"BrokerPort", "OutboxStore"})',
      (UNIT + "/test_boundaries.py",), "permitted_new_ports"),

    M("M11", "boundaries",
      "The delivery contract is strengthened to the unqualified claim the "
      "runtime cannot make.",
      f"{SRC}/runtime/dispatcher.py",
      "    def _policy(self, topic: Topic) -> RetryPolicy:",
      "    DELIVERY = 'this dispatcher delivers each message exactly once'\n\n"
      "    def _policy(self, topic: Topic) -> RetryPolicy:",
      (UNIT + "/test_boundaries.py", UNIT + "/test_delivery_semantics.py"), "stronger or claim"),

    M("M12", "boundaries",
      "A domain decision is taken in the messaging layer, which owns none.",
      f"{SRC}/runtime/effects.py",
      "def projection_upsert(",
      "def decide_eligibility(applicant):\n    return True\n\n\ndef projection_upsert(",
      (UNIT + "/test_boundaries.py",), "domain_decision"),

    M("M13", "boundaries",
      "API-05 scope leaks into this stage.",
      f"{SRC}/runtime/composition.py",
      "STATUS = \"PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED\"",
      "STATUS = \"PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED\"\nPROVIDER_GATEWAY = \"api-05\"",
      (UNIT + "/test_boundaries.py",), "forward_scope"),

    # -- privacy and voting isolation ---------------------------------------
    M("M14", "privacy",
      "An infrastructure correlation key stops being refused, so a client "
      "address can ride along on a broker header.",
      f"{SRC}/runtime/privacy.py",
      '        "client_ip",\n',
      "",
      (UNIT + "/test_privacy.py",), "network_correlation"),

    M("M15", "privacy",
      "The evidence gate becomes a no-op, so a secret can reach a durable "
      "quarantine record.",
      f"{SRC}/runtime/privacy.py",
      "    secrets = find_secret_material(obj)",
      "    return\n    secrets = find_secret_material(obj)",
      (UNIT + "/test_privacy.py",), "test_privacy"),

    M("M16", "privacy",
      "`account_id` is blanket-prohibited again — the exact over-prohibition "
      "this round corrected, which would refuse three canonical event families.",
      f"{SRC}/runtime/privacy.py",
      "def find_global_identity_keys(obj: Any) -> list[str]:\n"
      "    return [path for path, key, _ in _walk(obj) if key in GLOBAL_IDENTITY_KEYS]",
      "def find_global_identity_keys(obj: Any) -> list[str]:\n"
      "    keys = GLOBAL_IDENTITY_KEYS | {'account_id'}\n"
      "    return [path for path, key, _ in _walk(obj) if key in keys]",
      (UNIT + "/test_privacy.py",), "account_id"),

    M("M17", "privacy",
      "A correlation header stops having to be request-scoped, so a stable "
      "reference could follow a person across requests.",
      f"{SRC}/runtime/privacy.py",
      '_REQUEST_SCOPED = re.compile(r"^req-[0-9a-f]{32}$")',
      '_REQUEST_SCOPED = re.compile(r".*")',
      (UNIT + "/test_privacy.py",), "request_scoped"),

    M("M18", "privacy",
      "A refusal can be constructed carrying unsafe detail, which is how the "
      "unsafe value reaches a log line.",
      f"{SRC}/exceptions.py",
      "        privacy.assert_evidence_safe(self.detail, context=f\"refusal:{self.reason_code}\")",
      "        pass",
      (UNIT + "/test_privacy.py",), "unsafe_refusal"),

    M("M19", "privacy",
      "Voting material stops being refused at the payload boundary, which is "
      "the whole of API-04's voting isolation.",
      f"{SRC}/runtime/privacy.py",
      "def assert_payload_admissible(payload: Any, *, context: str) -> None:\n"
      '    """PACK-13\'s own payload gate, unchanged, called before anything is written."""\n'
      "    reject_prohibited_payload_keys(payload, context=context)",
      "def assert_payload_admissible(payload: Any, *, context: str) -> None:\n"
      "    return",
      (LIVE + "/test_boundaries_live.py", UNIT + "/test_privacy.py"), "voting"),

    # -- service identity ----------------------------------------------------
    M("M20", "identity",
      "A message may assert its own producer identity, which is the classic "
      "way a transport layer becomes an authorization bypass.",
      f"{SRC}/identity/port.py",
      "        if isinstance(credential, MessageAssertedIdentity):",
      "        if False and isinstance(credential, MessageAssertedIdentity):",
      (UNIT + "/test_identity.py",), "assert_its_own_producer"),

    M("M21", "identity",
      "Anything at all is accepted as transport-authenticated evidence.",
      f"{SRC}/identity/port.py",
      "        if not isinstance(credential, TransportCredential):",
      "        if False:",
      (UNIT + "/test_identity.py",), "test_identity"),

    M("M22", "identity",
      "A revoked credential still acts.",
      f"{SRC}/identity/port.py",
      "        if self.credential_state is CredentialState.REVOKED:",
      "        if False:",
      (UNIT + "/test_identity.py", UNIT + "/test_acl.py"), "revoked"),

    M("M23", "identity",
      "A human credential passes as a service identity.",
      f"{SRC}/identity/port.py",
      "        if self.principal_class is not PrincipalClass.SERVICE:",
      "        if False:",
      (UNIT + "/test_identity.py",), "human_principal_class"),

    M("M24", "identity",
      "An unavailable identity boundary fails open instead of closed.",
      f"{SRC}/identity/api03_r13_adapter.py",
      "        if not self._directory.is_available():",
      "        if False:",
      (UNIT + "/test_identity.py",), "unavailable_directory"),

    M("M25", "identity",
      "The unbound identity port allows instead of refusing.",
      f"{SRC}/identity/port.py",
      "        raise ServiceIdentityUnavailableError(\n"
      '            "no API-03 service-identity adapter is bound", detail={"purpose": purpose}\n'
      "        )",
      "        raise NotImplementedError",
      (UNIT + "/test_identity.py",), "unbound_port"),

    # -- lineage governance --------------------------------------------------
    M("M26", "lineage",
      "API-03 R13 can be labelled an accepted predecessor, which is the single "
      "claim this stage may not make.",
      f"{SRC}/identity/api03_r13_adapter.py",
      '        if "ACCEPTED" in predecessor_label.upper() or "CLOSED" in predecessor_label.upper():',
      "        if False:",
      (UNIT + "/test_identity.py",), "labelled_accepted"),

    M("M27", "lineage",
      "The reconciliation state reports RECONCILED without an exact accepted "
      "API-03, which would unblock a lineage freeze that is not earned.",
      f"{SRC}/identity/reconciliation.py",
      "    return RECONCILED if accepted_api03_sha256 else PENDING",
      "    return RECONCILED",
      (UNIT + "/test_reconciliation.py",), "test_reconciliation"),

    M("M28", "lineage",
      "Lineage may be frozen with no accepted predecessor bound.",
      f"{SRC}/identity/reconciliation.py",
      "    if not accepted_api03_sha256:",
      "    if False:",
      (UNIT + "/test_reconciliation.py",), "frozen"),

    M("M29", "lineage",
      "The surface comparison stops reporting members the accepted API-03 no "
      "longer offers, so the reconciliation would silently pass.",
      f"{SRC}/identity/reconciliation.py",
      '                rows.append(SurfaceDifference("MEMBER_ABSENT", surface, member, '
      '"consumed member is not offered"))',
      "                pass",
      (UNIT + "/test_reconciliation.py",), "missing_member"),

    # -- topology and ACL ----------------------------------------------------
    M("M30", "acl",
      "Wildcard ACL rows load, which is how `*:*` gets into a governed matrix.",
      f"{SRC}/topology/acl.py",
      'WILDCARDS = frozenset({"*", "*:*", "**", ".*", "all", "any", ""})',
      "WILDCARDS = frozenset()",
      (UNIT + "/test_acl.py",), "wildcard"),

    M("M31", "acl",
      "A producer may publish any version of its topic, including one no "
      "consumer was told to expect.",
      f"{SRC}/topology/acl.py",
      "        if event_version not in binding.event_versions:\n"
      "            raise ProducerNotAuthorizedForTopicError(\n"
      '                "producer is not bound to this event version",',
      "        if False:\n"
      "            raise ProducerNotAuthorizedForTopicError(\n"
      '                "producer is not bound to this event version",',
      (UNIT + "/test_acl.py",), "unbound_event_version"),

    M("M32", "acl",
      "Organization scope is checked against the binding but not against the "
      "verified principal, so a principal acts outside its own scope.",
      f"{SRC}/topology/acl.py",
      "        if organization_scope not in granted or organization_scope not in "
      "principal.organization_scopes:",
      "        if organization_scope not in granted:",
      (UNIT + "/test_acl.py",), "scope_outside"),

    M("M33", "acl",
      "A principal may handle a data classification it was never granted.",
      f"{SRC}/topology/acl.py",
      "        if presented not in principal.data_classifications:",
      "        if False:",
      (UNIT + "/test_acl.py",), "may_not_handle"),

    M("M34", "topology",
      "An event type absent from the canonical catalogue is synthesised rather "
      "than refused — API-04 minting an event type.",
      f"{SRC}/topology/catalogue.py",
      "            raise EventTypeNotInCanonicalCatalogueError(",
      "            return None  # type: ignore[return-value]\n"
      "            raise EventTypeNotInCanonicalCatalogueError(",
      (UNIT + "/test_catalogue.py", FIXTURES + "/test_failure_fixtures.py"),
      "unknown_event_type or f10"),

    M("M35", "topology",
      "A payload schema whose bytes do not match the register's digest is "
      "accepted.",
      f"{SRC}/topology/catalogue.py",
      "        if entry.payload_schema_sha256 != expected_sha256:",
      "        if False:",
      (UNIT + "/test_catalogue.py",), "digest_mismatch"),

    M("M36", "topology",
      "A topic that is not in the governed register can still be used.",
      f"{SRC}/topology/registry.py",
      "            raise TopicNotRegisteredError(",
      "            return None  # type: ignore[return-value]\n"
      "            raise TopicNotRegisteredError(",
      (UNIT + "/test_registry.py",), "unregistered_topic"),

    M("M37", "topology",
      "A protected topic can come into existence by being used.",
      f"{SRC}/topology/registry.py",
      "        raise TopicAutoCreationProhibitedError(",
      "        return\n        raise TopicAutoCreationProhibitedError(",
      (UNIT + "/test_registry.py",), "auto_creation"),

    M("M38", "topology",
      "Runtime drift against the register is reported in one direction only, so "
      "an undeclared queue on the live broker goes unnoticed.",
      f"{SRC}/topology/registry.py",
      '            for extra in sorted(live - declared):\n'
      '                problems.append(f"runtime {label} absent from register: {extra}")',
      "            pass",
      (UNIT + "/test_registry.py",), "drift"),

    # -- transport -----------------------------------------------------------
    M("M39", "transport",
      "The broker version stops being pinned, so evidence could be produced "
      "against a different broker.",
      f"{SRC}/transport/rabbitmq.py",
      'BROKER_VERSION = "3.12.1"',
      'BROKER_VERSION = "latest"',
      (UNIT + "/test_transport_addressing.py",), "pinned"),

    M("M40", "transport",
      "Partitioning collapses to one partition, so ordering scopes silently "
      "share a queue.",
      f"{SRC}/transport/rabbitmq.py",
      "    digest = 0\n"
      "    for byte in str(key).encode(\"utf-8\"):\n"
      "        digest = (digest * 131 + byte) & 0xFFFFFFFF\n"
      "    return digest % partitions",
      "    return 0",
      (UNIT + "/test_transport_addressing.py",), "spreads"),

    M("M41", "transport",
      "An unknown acknowledgement is reported as an acknowledgement, which is "
      "exactly the guess P13-DEL-007 forbids.",
      f"{SRC}/transport/rabbitmq.py",
      "        if self._acknowledgements_suppressed:\n            return None",
      "        if False:\n            return None",
      (FIXTURES + "/test_failure_fixtures.py",), "f03"),

    # -- delivery semantics --------------------------------------------------
    M("M42", "delivery",
      "Deduplication moves after the version check, so narrowing a consumer's "
      "supported versions turns already-applied events into dead letters.",
      f"{SRC}/runtime/consumer.py",
      "        if record.event_version not in self.supported_event_versions:",
      "        if True or record.event_version not in self.supported_event_versions:",
      (UNIT + "/test_consumer_parity.py",), "test_consumer_parity"),

    M("M43", "delivery",
      "Deduplication becomes per-process again, so two workers each believe "
      "they are first and a redelivery after a crash applies a second effect.",
      f"{SRC}/runtime/consumer.py",
      "        self._deduplication = deduplication",
      "        class _InProcess:\n"
      "            _seen: dict = {}\n\n"
      "            def observe(self, *, consumer_name, consumer_domain, event_id,\n"
      "                        payload_hash, now, expires_at):\n"
      "                from epd2_data_plane_service.idempotency import DeduplicationRecord\n\n"
      "                from ..persistence.postgres_stores import DeduplicationOutcome\n\n"
      "                key = (consumer_domain, consumer_name, event_id)\n"
      "                seen = key in self._seen\n"
      "                marker = DeduplicationRecord(\n"
      "                    consumer_name=consumer_name, consumer_domain=consumer_domain,\n"
      "                    event_id=event_id, first_seen_at=now,\n"
      "                )\n"
      "                self._seen[key] = marker\n"
      "                return DeduplicationOutcome(\n"
      "                    record=marker, first_observation=not seen, completed=seen,\n"
      "                    effect_reference=None, effect_result=None,\n"
      "                )\n\n"
      "            def complete(self, **kw):\n"
      "                return None\n\n"
      "        self._deduplication = _InProcess()",
      (UNIT + "/test_consumer_parity.py",),
      "durable or racing"),

    M("M44", "delivery",
      "A schema-incompatible payload becomes retryable, so a message that can "
      "never succeed occupies the queue until its budget runs out.",
      f"{SRC}/runtime/consumer.py",
      "        rc.CONSUMER_NOT_READY,\n        rc.EVENT_ORDERING_GAP_DETECTED,",
      "        rc.CONSUMER_NOT_READY,\n        rc.SCHEMA_INCOMPATIBLE,\n"
      "        rc.EVENT_ORDERING_GAP_DETECTED,",
      (FIXTURES + "/test_failure_fixtures.py",), "f07"),

    M("M45", "delivery",
      "A refused message is dropped instead of quarantined — the silent drop "
      "this runtime has no path for.",
      f"{SRC}/runtime/consumer.py",
      "        reason_code = getattr(refusal, \"reason_code\", rc.FAILURE_CLASS_UNKNOWN)",
      "        self.transport.acknowledge(message)\n        return\n"
      "        reason_code = getattr(refusal, \"reason_code\", rc.FAILURE_CLASS_UNKNOWN)",
      (FIXTURES + "/test_failure_fixtures.py",), "f07"),

    M("M46", "delivery",
      "The payload is no longer validated against its canonical schema before "
      "the effect.",
      f"{SRC}/runtime/consumer.py",
      "                self._validate_payload(record)",
      "                pass",
      (FIXTURES + "/test_failure_fixtures.py",), "f08"),

    M("M47", "delivery",
      "The retry budget stops being bounded, so a permanently failing message "
      "retries forever instead of quarantining.",
      f"{SRC}/runtime/consumer.py",
      "        exhausted = attempt >= self.subscription.max_attempts",
      "        exhausted = False",
      (FIXTURES + "/test_failure_fixtures.py",), "f22"),

    M("M48", "delivery",
      "A lease is no longer respected, so two dispatchers do the same work.",
      f"{SRC}/persistence/postgres_stores.py",
      "                    WHERE (lease_expires_at IS NULL OR lease_expires_at < now())\n"
      "                      AND ((status IN ('pending','failed') AND next_attempt_at <= now())",
      "                    WHERE ((status IN ('pending','failed') AND next_attempt_at <= now())",
      (FIXTURES + "/test_failure_fixtures.py",), "f21"),

    M("M49", "delivery",
      "The ACL is evaluated after the publish, so an unauthorized message is "
      "already on the wire when it is refused.",
      f"{SRC}/runtime/dispatcher.py",
      "                self.acl.authorize_publish(",
      "                _ = lambda: self.acl.authorize_publish(",
      (FIXTURES + "/test_failure_fixtures.py",), "f12"),

    # -- FIR-AUTH-001 --------------------------------------------------------
    M("M50", "reauthorization",
      "A consequential commit no longer revalidates authority at the commit "
      "point, so queued work inherits an authority that has since lapsed.",
      f"{SRC}/runtime/consumer.py",
      "                    if self.subscription.commit_reauthorisation_required:",
      "                    if False:",
      (FIXTURES + "/test_failure_fixtures.py",), "f16"),

    M("M51", "reauthorization",
      "A revoked authority no longer stops the commit.",
      f"{SRC}/runtime/reauthorization.py",
      '    if not row["authority_active"]:',
      "    if False:",
      (FIXTURES + "/test_failure_fixtures.py",), "f16 and not f16b"),

    M("M52", "reauthorization",
      "An object version that moved while the work was queued is overwritten.",
      f"{SRC}/runtime/reauthorization.py",
      '    if int(row["object_version"]) != int(requested_object_version):',
      "    if False:",
      (FIXTURES + "/test_failure_fixtures.py",), "f17"),

    M("M53", "reauthorization",
      "A governing policy version that changed between request and commit is "
      "ignored.",
      f"{SRC}/runtime/reauthorization.py",
      '    if row["policy_version"] != requested_policy:',
      "    if False:",
      (FIXTURES + "/test_failure_fixtures.py",), "f18"),

    M("M54", "reauthorization",
      "The work item's own deadline may pass while it waits, and the commit "
      "still happens.",
      f"{SRC}/runtime/reauthorization.py",
      '    if row["deadline_at"] is not None and now > row["deadline_at"]:',
      "    if False:",
      (FIXTURES + "/test_failure_fixtures.py",), "f19"),

    M("M55", "reauthorization",
      "A consequential effect proceeds on an absent authority basis, which "
      "turns a wiring defect into a silent commit.",
      f"{SRC}/runtime/effects.py",
      "    if basis is None:\n        raise ConcurrencyAuthorityLapsedError(",
      "    if False:\n        raise ConcurrencyAuthorityLapsedError(",
      (UNIT + "/test_effect_guards.py",), "absent_authority_basis or not_a_default"),

    # -- readiness, lag, backpressure ---------------------------------------
    M("M56", "readiness",
      "Consequential readiness collapses into ordinary readiness, so "
      "consequential traffic flows while a projection is behind.",
      f"{SRC}/runtime/readiness.py",
      "        authoritatively_ready=ready and not consequential,",
      "        authoritatively_ready=ready,",
      (UNIT + "/test_readiness_and_lag.py",), "test_readiness_and_lag"),

    M("M57", "readiness",
      "The lineage block is merged into the readiness block, which would make "
      "an un-reconciled predecessor look like an outage.",
      f"{SRC}/runtime/readiness.py",
      "    lineage: list[str] = []",
      "    lineage: list[str] = []\n    blocking.append(rc.PREDECESSOR_NOT_ACCEPTED)",
      (UNIT + "/test_readiness_and_lag.py",), "test_readiness_and_lag"),

    M("M58", "lag",
      "Lag is reported as an exact figure rather than a band, which P13-EVT-009 "
      "refuses because the figure is itself information.",
      f"{SRC}/runtime/lag.py",
      "            lag_band=lag_band_for(behind),",
      "            lag_band=str(behind),",
      (LIVE + "/test_governance_live.py",), "lag"),

    M("M59", "backpressure",
      "Consequential work becomes sheddable, which is the cheapest way to "
      "reduce lag and the one that must stay unavailable.",
      f"{SRC}/runtime/backpressure.py",
      "        if subscription.consequential_effect:",
      "        if False:",
      (UNIT + "/test_backpressure.py",), "shed"),

    # -- governed re-drive and replay ---------------------------------------
    M("M60", "redrive",
      "An unbounded requeue-all path appears.",
      f"{SRC}/runtime/redrive.py",
      'def redrive_bulk(*_: Any, **__: Any) -> None:\n'
      '    raise RedriveBulkUnboundedProhibitedError("there is no unbounded requeue-all path")',
      "def redrive_bulk(*_: Any, **__: Any) -> None:\n    return None",
      (UNIT + "/test_replay_redrive_policy.py",), "requeue"),

    M("M61", "redrive",
      "A dead letter can be re-driven to a subscription that is not its own.",
      f"{SRC}/runtime/redrive.py",
      '    if item["subscription_id"] != request.target_subscription:',
      "    if False:",
      (LIVE + "/test_governance_live.py",), "another_subscription"),

    M("M62", "replay",
      "An exact-message replay stops naming exactly one position, so a "
      "single-message replay can quietly become a range.",
      f"{SRC}/runtime/replay.py",
      '        if self.kind == "exact_message" and self.reference.to_sequence != '
      "self.reference.from_sequence:",
      "        if False:",
      (UNIT + "/test_replay_redrive_policy.py",), "exact_message"),

    M("M63", "replay",
      "A legal hold no longer blocks a replay.",
      f"{SRC}/runtime/replay.py",
      "    if held and blocking is None:",
      "    if False:",
      (LIVE + "/test_governance_live.py",), "legal_hold"),

    M("M64", "replay",
      "A purged or tombstoned subject comes back through a replay.",
      f"{SRC}/runtime/replay.py",
      '    if row and int(row["n"]) and blocking is None:',
      "    if False:",
      (LIVE + "/test_governance_live.py",), "purged"),

    M("M65", "replay",
      "A historical event is re-judged under a policy that did not exist when "
      "it happened.",
      f"{SRC}/runtime/replay.py",
      "    if origin_policy_version != current_policy_version and not reinterpretation_permitted:",
      "    if False:",
      (LIVE + "/test_governance_live.py",), "each_replay_check"),

    # -- the transactional boundary and the engine --------------------------
    M("M66", "outbox",
      "A domain write may commit without its event, or an event without its "
      "write.",
      f"{SRC}/runtime/unit_of_work.py",
      "        if self.staged and not self.domain_writes:",
      "        if False:",
      (LIVE + "/test_boundaries_live.py",), "without_a_domain_write"),

    M("M67", "outbox",
      "The dispatcher accepts the domain transaction's own connection, so an "
      "uncommitted row becomes publishable.",
      f"{SRC}/runtime/dispatcher.py",
      "        if domain_connection is self.connection:",
      "        if False:",
      (LIVE + "/test_boundaries_live.py",), "domain_transactions_own_connection"),

    M("M68", "engine",
      "The governed engine version stops being enforced.",
      f"{SRC}/persistence/db.py",
      'REQUIRED_ENGINE_VERSION = "16.15"',
      'REQUIRED_ENGINE_VERSION = "16"',
      (LIVE + "/test_governance_live.py",), "governed_version"),

    M("M69", "engine",
      "A migration that changed after it was applied is accepted, which is a "
      "repair path where there must be none.",
      f"{SRC}/persistence/db.py",
      "            if known[migration.name] != migration.checksum:",
      "            if False:",
      (LIVE + "/test_governance_live.py",), "repair_path"),

    M("M70", "clock",
      "Consequential work proceeds on an untrusted clock instead of failing "
      "closed.",
      f"{SRC}/runtime/clock.py",
      "        if not self._trusted:",
      "        if False:",
      (UNIT + "/test_identity.py",), "time_authority"),
)
