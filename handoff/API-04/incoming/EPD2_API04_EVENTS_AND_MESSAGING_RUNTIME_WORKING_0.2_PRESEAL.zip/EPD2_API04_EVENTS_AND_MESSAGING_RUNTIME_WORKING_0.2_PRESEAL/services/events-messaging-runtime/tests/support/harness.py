"""Live test harness: real PostgreSQL 16.15, real RabbitMQ 3.12.1.

Every fixture runs against both. Nothing on that path is mocked: a broker restart
is `rabbitmqctl stop_app`, a lost acknowledgement is a real unacked delivery on a
real quorum queue, and a "consumer crash" tears down a real connection.

The payload builders below construct payloads that satisfy the **canonical**
schemas in `contracts/events/`, not shapes invented for the tests. If a canonical
schema changes, these fail — which is the point.
"""

from __future__ import annotations

import os
import pathlib
import subprocess
import sys
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Mapping

REPO_ROOT = pathlib.Path(
    os.environ.get("API04_REPOSITORY_ROOT", pathlib.Path(__file__).resolve().parents[4])
)
for extra in (
    "packages/python/epd2-core/src",
    "services/audit-core/src",
    "services/data-plane-service/src",
    "services/events-messaging-runtime/src",
):
    path = str(REPO_ROOT / extra)
    if path not in sys.path:
        sys.path.insert(0, path)

from epd2_events_messaging_runtime.persistence import db  # noqa: E402
from epd2_events_messaging_runtime.runtime.composition import (  # noqa: E402
    Api04Runtime,
    RuntimeConfig,
)
from epd2_events_messaging_runtime.transport.rabbitmq import (  # noqa: E402
    RETRY_TIER_TTL_MS,
    partition_queue,
    retry_queue,
)

POSTGRES_DSN = os.environ.get(
    "API04_POSTGRES_DSN", "postgresql://api04@127.0.0.1:5432/epd2_api04_r2"
)
#: Broker credentials live **outside** the tree, at mode 0600. The default is a
#: per-operator location and never a path inside the archive: a sealed archive
#: that carries a credential is a sealed archive that leaks one.
BROKER_SECRETS = pathlib.Path(
    os.environ.get(
        "API04_BROKER_SECRETS", str(pathlib.Path.home() / ".epd2" / "api04-broker.json")
    )
)

TRUNCATE = (
    "dom_membership.outbox_record", "dom_organization.outbox_record", "dom_compliance.outbox_record",
    "dom_projection.deduplication_record", "dom_notification.deduplication_record",
    "dom_governance.deduplication_record", "dom_casework.deduplication_record",
    "dom_audit.deduplication_record",
    "dom_projection.consumer_checkpoint", "dom_notification.consumer_checkpoint",
    "dom_governance.consumer_checkpoint", "dom_casework.consumer_checkpoint",
    "dom_audit.consumer_checkpoint",
    "dom_projection.projection_row", "dom_projection.projection_definition",
    "dom_notification.notification_delivery", "dom_casework.deadline_state",
    "dom_audit.ingested_record",
    "dom_governance.authority_assignment", "dom_governance.authority_state",
    "api04_gov.redrive_record", "api04_gov.replay_record", "api04_gov.dead_letter_record",
    "api04_gov.readiness_snapshot", "api04_gov.disposition_record", "api04_gov.legal_hold",
)


def make_runtime(**overrides: Any) -> Api04Runtime:
    return Api04Runtime(
        RuntimeConfig(
            repository_root=REPO_ROOT,
            postgres_dsn=POSTGRES_DSN,
            broker_secrets_path=BROKER_SECRETS,
            **overrides,
        )
    )


def clean(runtime: Api04Runtime) -> None:
    conn = db.connect(POSTGRES_DSN)
    with conn.cursor() as cur:
        cur.execute("TRUNCATE " + ", ".join(TRUNCATE) + " RESTART IDENTITY CASCADE")
    conn.commit()
    conn.close()
    purge_queues(runtime)


def purge_queues(runtime: Api04Runtime) -> int:
    purged = 0
    broker = runtime.broker_for()
    for sub in runtime.topics.subscriptions:
        topic = runtime.topics.topic(sub.topic_id)
        for partition in range(topic.partitions):
            names = [partition_queue(sub.queue, partition),
                     partition_queue(sub.dead_letter_queue, partition)]
            names += [retry_queue(sub.queue, partition, t) for t in range(len(RETRY_TIER_TTL_MS))]
            for name in names:
                try:
                    broker.purge(name)
                    purged += 1
                except Exception:
                    broker.close()
                    broker = runtime.broker_for()
    return purged


# --- SQL helpers -----------------------------------------------------------

def query(sql: str, params: Iterable[Any] = ()) -> list[dict[str, Any]]:
    conn = db.connect(POSTGRES_DSN)
    rows = db.fetch_all(conn, sql, tuple(params))
    conn.close()
    return rows


def execute(sql: str, params: Iterable[Any] = ()) -> int:
    conn = db.connect(POSTGRES_DSN)
    affected = db.execute(conn, sql, tuple(params))
    conn.commit()
    conn.close()
    return affected


def scalar(sql: str, params: Iterable[Any] = ()) -> Any:
    rows = query(sql, params)
    return next(iter(rows[0].values())) if rows else None


def outbox_row(domain: str, event_id: uuid.UUID) -> dict[str, Any] | None:
    rows = query(f"SELECT * FROM dom_{domain}.outbox_record WHERE event_id = %s", (event_id,))
    return rows[0] if rows else None


def dead_letters(subscription_id: str | None = None) -> list[dict[str, Any]]:
    if subscription_id:
        return query(
            "SELECT * FROM api04_gov.dead_letter_record WHERE subscription_id = %s ORDER BY failed_at",
            (subscription_id,),
        )
    return query("SELECT * FROM api04_gov.dead_letter_record ORDER BY failed_at")


def broker_ctl(*args: str) -> str:
    env = dict(os.environ)
    env["HOME"] = "/var/lib/rabbitmq"
    node = env.get("RABBITMQ_NODENAME", "epd2api04@localhost")
    result = subprocess.run(["rabbitmqctl", "-n", node, *args], capture_output=True, text=True, env=env)
    return result.stdout + result.stderr


# --- canonical payload builders -------------------------------------------

def iso(moment: datetime | None = None) -> str:
    return (moment or datetime.now(timezone.utc)).isoformat()


def application_submitted(application_id: uuid.UUID | None = None) -> dict[str, Any]:
    return {
        "membership_application_id": str(application_id or uuid.uuid4()),
        "status": "application_pending",
    }


def decision_recorded(
    application_id: uuid.UUID, *, status: str = "approved", reason_code: str | None = "MEMBERSHIP_APPROVED"
) -> dict[str, Any]:
    return {
        "membership_application_id": str(application_id),
        "status": status,
        "decision_authority_reference": str(uuid.uuid5(uuid.NAMESPACE_URL, "authority/membership-board")),
        "reason_code": reason_code,
    }


def eligibility_evaluated(application_id: uuid.UUID, *, approve: bool = True) -> dict[str, Any]:
    return {"membership_application_id": str(application_id), "recommended_approval": approve}


def authority_assigned(
    authority_id: uuid.UUID, *, policy_version: str = "policy-2026-08", status: str = "active"
) -> dict[str, Any]:
    return {
        "authority_id": str(authority_id),
        "status": status,
        "policy_version": policy_version,
        "decision_reference": str(uuid.uuid5(uuid.NAMESPACE_URL, f"decision/{authority_id}")),
        "effective_time": iso(),
        "recorded_at": iso(),
    }


def authority_revoked(authority_id: uuid.UUID, *, policy_version: str = "policy-2026-08") -> dict[str, Any]:
    return {
        "authority_id": str(authority_id),
        "status": "revoked",
        "revocation_reason_reference": "REVOKED_BY_DECISION",
        "policy_version": policy_version,
        "effective_time": iso(),
        "recorded_at": iso(),
    }


def deadline_state_changed(case_id: uuid.UUID, *, organization_id: uuid.UUID) -> dict[str, Any]:
    return {
        "deadline_id": str(uuid.uuid4()),
        "case_id": str(case_id),
        "organization_id": str(organization_id),
        "deadline_code": "OBJECTION_WINDOW",
        "timezone": "Europe/Berlin",
        "status": "running",
        "sequence": 1,
        "event_type": "started",
        "due_at_before": iso(datetime.now(timezone.utc) + timedelta(days=14)),
        "due_at_after": None,
        "remaining_seconds": 1209600,
        "reason_code": "DEADLINE_STARTED",
        "superseded_by_deadline_id": None,
        "recorded_at": iso(),
    }


def legal_hold_changed(hold_id: uuid.UUID, *, organization_id: uuid.UUID,
                       action: str = "issued", status: str = "active") -> dict[str, Any]:
    return {
        "hold_id": str(hold_id),
        "organization_id": str(organization_id),
        "matter_reference": "MATTER-2026-014",
        "action": action,
        "status": status,
        "reason_code": "LEGAL_HOLD_ISSUED",
        "scope_record_count": 12,
        "scope_record_classes": ["membership_application"],
        "recorded_at": iso(),
    }


def retention_started(record_id: uuid.UUID, *, organization_id: uuid.UUID) -> dict[str, Any]:
    return {
        "record_id": str(record_id),
        "organization_id": str(organization_id),
        "record_class": "membership_application",
        "trigger": "created_at",
        "retention_started_at": iso(),
        "retention_policy_id": str(uuid.uuid5(uuid.NAMESPACE_URL, "retention/membership")),
        "retention_policy_version": 3,
        "recorded_at": iso(),
    }


def seed_authority(
    authority_id: uuid.UUID,
    *,
    organization_id: uuid.UUID,
    policy_version: str = "policy-2026-08",
    object_version: int = 1,
    active: bool = True,
    scope_kind: str = "bund",
    authority_expires_at: datetime | None = None,
    deadline_at: datetime | None = None,
) -> None:
    execute(
        """
        INSERT INTO dom_governance.authority_state
            (authority_id, authority_active, organization_id, scope_kind, object_version,
             policy_version, authority_expires_at, deadline_at)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
        ON CONFLICT (authority_id) DO UPDATE SET
            authority_active = EXCLUDED.authority_active,
            organization_id = EXCLUDED.organization_id,
            scope_kind = EXCLUDED.scope_kind,
            object_version = EXCLUDED.object_version,
            policy_version = EXCLUDED.policy_version,
            authority_expires_at = EXCLUDED.authority_expires_at,
            deadline_at = EXCLUDED.deadline_at
        """,
        (authority_id, active, organization_id, scope_kind, object_version,
         policy_version, authority_expires_at, deadline_at),
    )


def mutate_authority(authority_id: uuid.UUID, **columns: Any) -> None:
    assignments = ", ".join(f"{k} = %s" for k in columns)
    execute(
        f"UPDATE dom_governance.authority_state SET {assignments} WHERE authority_id = %s",
        (*columns.values(), authority_id),
    )


# --- pipeline helpers ------------------------------------------------------

def emit(runtime: Api04Runtime, service_id: str, topic_id: str, payload: Mapping[str, Any],
         **kw: Any) -> uuid.UUID:
    return runtime.publish_from_domain(
        service_id=service_id, topic_id=topic_id, payload=dict(payload),
        sequence_number=kw.pop("sequence_number", 1), **kw
    )


def dispatch(runtime: Api04Runtime, service_id: str, **kw: Any):
    return runtime.dispatcher_for(service_id).run_once(**kw)


def consume(runtime: Api04Runtime, subscription_id: str, **kw: Any):
    return runtime.consumer_for(subscription_id).poll_all_partitions(**kw)


# --- live infrastructure control ------------------------------------------

def stop_broker() -> str:
    """A real broker outage: `rabbitmqctl stop_app` stops the AMQP listener and
    drops every connection. Nothing here is mocked."""
    return broker_ctl("stop_app")


def start_broker() -> str:
    out = broker_ctl("start_app")
    broker_ctl("await_startup", "--timeout", "60")
    return out


def reset_transport(runtime: Api04Runtime) -> None:
    """Drop cached connections and dispatchers after an outage, the way a
    supervised process would come back."""
    for broker in list(runtime.brokers.values()):
        try:
            broker.close()
        except Exception:
            pass
    runtime.brokers.clear()
    runtime._dispatchers.clear()


def queue_depth(runtime: Api04Runtime, subscription_id: str, *, dead_letter: bool = False) -> int:
    subscription = runtime.topics.subscription(subscription_id)
    topic = runtime.topics.topic(subscription.topic_id)
    queue = subscription.dead_letter_queue if dead_letter else subscription.queue
    broker = runtime.broker_for()
    total = 0
    for partition in range(topic.partitions):
        total += broker.queue_depth(partition_queue(queue, partition))
    return total


def drain(runtime: Api04Runtime, subscription_id: str, *, dead_letter: bool = False) -> list:
    subscription = runtime.topics.subscription(subscription_id)
    topic = runtime.topics.topic(subscription.topic_id)
    queue = subscription.dead_letter_queue if dead_letter else subscription.queue
    broker = runtime.broker_for()
    out: list = []
    for partition in range(topic.partitions):
        out.extend(broker.drain(partition_queue(queue, partition)))
    return out


def publish_raw(runtime: Api04Runtime, topic_id: str, envelope: dict, *,
                headers: dict | None = None, partition: int | None = None) -> str:
    """Put a message on the wire directly, bypassing the producer path.

    Used by the fixtures that model a *malformed* or *hostile* message: a
    producer that this runtime governs cannot emit one, so the only honest way
    to test the consumer's refusal is to publish it as a peer would."""
    from epd2_events_messaging_runtime.transport.rabbitmq import partition_for, routing_key

    topic = runtime.topics.topic(topic_id)
    key_value = envelope.get("payload", {}).get(topic.partition_key)
    resolved = partition if partition is not None else partition_for(str(key_value), topic.partitions)
    broker = runtime.broker_for()
    return broker.republish(
        exchange=topic.destination_name,
        routing_key=routing_key(topic.event_type, resolved),
        envelope=envelope,
        headers={"x-epd2-sequence-number": 1, **(headers or {})},
    )


def envelope_on_the_wire(runtime: Api04Runtime, domain: str, event_id) -> dict:
    """The canonical envelope exactly as the dispatcher published it."""
    row = outbox_row(domain, event_id)
    assert row is not None
    return dict(row["envelope"])
