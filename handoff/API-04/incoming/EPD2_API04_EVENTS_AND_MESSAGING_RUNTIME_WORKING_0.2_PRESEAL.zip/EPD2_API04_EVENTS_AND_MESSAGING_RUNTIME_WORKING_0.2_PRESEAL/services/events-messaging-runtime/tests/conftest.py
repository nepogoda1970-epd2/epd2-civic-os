"""Pytest wiring.

`live_runtime` is session-scoped: bootstrapping applies migrations and declares
the broker topology, and neither should happen per test. `runtime` cleans first,
so every test owns its evidence.
"""

from __future__ import annotations

import pytest

from support import harness


@pytest.fixture(scope="session")
def live_runtime():
    runtime = harness.make_runtime()
    runtime.bootstrap()
    yield runtime
    runtime.close()


@pytest.fixture()
def runtime(live_runtime):
    harness.clean(live_runtime)
    live_runtime._dispatchers.clear()
    live_runtime.register_service_credentials()
    live_runtime.clock.restore_trust()
    live_runtime.identity_directory.set_available(True)
    live_runtime.dispatcher_healthy = True
    yield live_runtime
