"""Readiness has two levels and a third list; lag is a band, never a figure."""

from __future__ import annotations

import pytest

from epd2_data_plane_service.delivery import LAG_BANDS, lag_band_for

from epd2_events_messaging_runtime import reason_codes as rc
from epd2_events_messaging_runtime.runtime import lag as lag_module
from epd2_events_messaging_runtime.runtime import readiness


def healthy(**overrides) -> readiness.ReadinessSignals:
    base = dict(
        broker_connected=True,
        broker_version_pinned=True,
        topology_matches_register=True,
        identity_available=True,
        canonical_catalogue_loaded=True,
        migrations_complete=True,
        dispatcher_healthy=True,
        lag_bands={"s": "none"},
        lag_ceilings={"s": "low"},
        lag_breached=(),
        projection_watermarks={"p": (5, 5)},
        open_dead_letters=0,
        reconciliation_state="PENDING_EXACT_ACCEPTED_API03",
    )
    base.update(overrides)
    return readiness.ReadinessSignals(**base)


def test_a_healthy_runtime_is_ready_and_authoritatively_ready():
    snapshot = readiness.evaluate(healthy())
    assert snapshot.ready and snapshot.authoritatively_ready
    assert snapshot.blocking_reason_codes == ()


def test_lineage_blocking_is_separate_from_readiness():
    snapshot = readiness.evaluate(healthy())
    assert snapshot.lineage_blocking_reason_codes == (rc.PREDECESSOR_NOT_ACCEPTED,)
    assert rc.PREDECESSOR_NOT_ACCEPTED not in snapshot.blocking_reason_codes
    assert rc.PREDECESSOR_NOT_ACCEPTED not in snapshot.consequential_blocking_reason_codes


def test_lineage_clears_only_with_the_reconciled_state():
    snapshot = readiness.evaluate(
        healthy(reconciliation_state="RECONCILED_AGAINST_EXACT_ACCEPTED_API03")
    )
    assert snapshot.lineage_blocking_reason_codes == ()


@pytest.mark.parametrize(
    "signal, code",
    [
        ({"broker_connected": False}, rc.BROKER_UNAVAILABLE),
        ({"broker_version_pinned": False}, rc.BROKER_VERSION_NOT_PINNED),
        ({"topology_matches_register": False}, rc.TOPIC_REGISTRY_RUNTIME_DRIFT),
        ({"identity_available": False}, rc.SERVICE_IDENTITY_UNAVAILABLE),
        ({"canonical_catalogue_loaded": False}, rc.EVENT_TYPE_NOT_IN_CANONICAL_CATALOGUE),
        ({"migrations_complete": False}, rc.DATAPLANE_DATABASE_UNAVAILABLE),
        ({"dispatcher_healthy": False}, rc.CONSUMER_NOT_READY),
        ({"open_dead_letters": 25}, rc.EVENT_DEAD_LETTER_REQUIRED),
    ],
)
def test_each_failed_signal_blocks_with_its_own_code(signal, code):
    snapshot = readiness.evaluate(healthy(**signal))
    assert code in snapshot.blocking_reason_codes
    assert snapshot.ready is False
    assert snapshot.authoritatively_ready is False


def test_a_breached_lag_ceiling_blocks_only_consequential_traffic():
    snapshot = readiness.evaluate(healthy(lag_breached=("s",)))
    assert snapshot.ready is True
    assert snapshot.authoritatively_ready is False
    assert rc.CONSUMER_NOT_READY in snapshot.consequential_blocking_reason_codes


def test_a_stale_projection_blocks_only_consequential_traffic():
    snapshot = readiness.evaluate(healthy(projection_watermarks={"p": (3, 5)}))
    assert snapshot.ready is True
    assert snapshot.authoritatively_ready is False
    assert rc.PROJECTION_STALE in snapshot.consequential_blocking_reason_codes


def test_a_disconnected_broker_does_not_also_claim_a_version_mismatch():
    snapshot = readiness.evaluate(healthy(broker_connected=False, broker_version_pinned=False))
    assert rc.BROKER_VERSION_NOT_PINNED not in snapshot.blocking_reason_codes


def test_the_snapshot_serialises_all_three_lists():
    body = readiness.evaluate(healthy(broker_connected=False)).as_json()
    assert set(body) == {
        "ready", "authoritatively_ready", "blocking_reason_codes",
        "consequential_blocking_reason_codes", "lineage_blocking_reason_codes", "signals",
    }


def test_band_order_is_pack13s():
    assert lag_module.BAND_ORDER == tuple(LAG_BANDS)


def test_band_exceeds_uses_that_order():
    assert lag_module.band_exceeds("high", "low") is True
    assert lag_module.band_exceeds("none", "low") is False
    assert lag_module.band_exceeds("low", "low") is False


def test_lag_is_reported_as_a_band_and_never_as_a_figure():
    reading = lag_module.LagReading(
        per_subscription={
            "s": __import__("epd2_data_plane_service.delivery", fromlist=["ConsumerLag"]).ConsumerLag(
                consumer_name="s",
                ordering_scope_key="s",
                lag_band=lag_band_for(4321),
                observed_at=__import__("datetime").datetime.now(
                    __import__("datetime").timezone.utc
                ),
            )
        },
        ceilings={"s": "low"},
        breached=("s",),
    )
    body = reading.as_json()
    assert body == {"s": lag_band_for(4321)}
    assert all(not str(v).isdigit() for v in body.values())
