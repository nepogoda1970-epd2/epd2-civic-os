"""The validator's exemption lists must keep earning their place.

Three scans in `scripts/validate_api04.py` exempt a handful of files, because a
detector has to contain the thing it detects. Each exemption is a hole in a
scan, so each is asserted here: the file still exists, and it still contains
what it was exempted for. An exemption that stops being needed is an exemption
that could be reused to hide something.
"""

from __future__ import annotations

import importlib.util
import pathlib

import pytest

REPO_ROOT = pathlib.Path(__file__).resolve().parents[4]
VALIDATOR = REPO_ROOT / "scripts/validate_api04.py"


@pytest.fixture(scope="module")
def validator():
    import sys

    spec = importlib.util.spec_from_file_location("api04_validator", VALIDATOR)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    # Registered before execution: the module defines dataclasses, and
    # `dataclasses` resolves their annotations through `sys.modules`.
    sys.modules["api04_validator"] = module
    try:
        spec.loader.exec_module(module)
    finally:
        sys.modules.pop("api04_validator", None)
    return module


def _text(relative: str) -> str:
    path = REPO_ROOT / relative
    assert path.exists(), f"exempted file no longer exists: {relative}"
    return path.read_text(encoding="utf-8")


def test_every_claim_exemption_still_contains_a_forbidden_phrase(validator):
    for relative in validator.CLAIM_SCAN_EXEMPT:
        lowered = _text(relative).lower()
        assert any(claim in lowered for claim in validator.FORBIDDEN_CLAIMS), (
            f"{relative} is exempted from the claim scan but contains no forbidden "
            f"phrase; the exemption is now an unearned hole in the scan"
        )


def test_every_forward_scope_exemption_still_contains_a_marker(validator):
    markers = ("api-05", "api05", "provider_gateway", "vendor_callback")
    for relative in validator.FORWARD_SCOPE_EXEMPT:
        lowered = _text(relative).lower()
        assert any(marker in lowered for marker in markers), (
            f"{relative} is exempted from the forward-scope scan but names no marker"
        )


def test_every_secret_allowlist_entry_still_contains_a_secret_shaped_value(validator):
    assert validator.SECRET_SCAN_ALLOWLIST, "an empty allowlist would be silently permissive"
    for relative, reason in validator.SECRET_SCAN_ALLOWLIST.items():
        text = _text(relative)
        assert any(p.search(text) for p in validator.SECRET_PATTERNS), (
            f"{relative} is allowlisted for {reason!r} but no longer contains a "
            f"secret-shaped value"
        )


def test_the_host_path_exemption_still_contains_a_host_path_pattern(validator):
    """The needles are composed rather than written, so this test does not itself
    become an absolute authoring path for the scan to find."""
    home = "/" + "home" + "/"
    users = "/" + "Users" + "/"
    for relative in validator.HOST_PATH_EXEMPT:
        text = _text(relative)
        assert home in text or users in text


def test_the_exemption_lists_are_small_and_named(validator):
    """A scan whose exemption list grows without bound is not a scan."""
    assert len(validator.CLAIM_SCAN_EXEMPT) <= 12
    assert len(validator.FORWARD_SCOPE_EXEMPT) <= 6
    assert len(validator.SECRET_SCAN_ALLOWLIST) <= 4
    assert len(validator.HOST_PATH_EXEMPT) <= 2
    everything = (
        list(validator.CLAIM_SCAN_EXEMPT)
        + list(validator.FORWARD_SCOPE_EXEMPT)
        + list(validator.SECRET_SCAN_ALLOWLIST)
        + list(validator.HOST_PATH_EXEMPT)
    )
    for relative in everything:
        assert not relative.endswith("/"), "an exemption names a file, never a directory"


def test_the_validator_declares_twenty_eight_gates(validator):
    numbers = [g[0] for g in validator.Validator.GATES]
    assert numbers == list(range(28))
    assert len({g[1] for g in validator.Validator.GATES}) == 28


def test_a_blocked_gate_is_never_counted_as_a_pass(validator):
    """`NOT_RUN_ENVIRONMENT_BLOCKED` is a third outcome, and the run result is
    computed from failures only — so a blocked gate must be visible somewhere
    else, and it is: `environment_blocked_gates`."""
    source = VALIDATOR.read_text(encoding="utf-8")
    assert '"environment_blocked_gates": blocked' in source
    assert "BLOCKED = " in source
    assert validator.BLOCKED != validator.PASS
