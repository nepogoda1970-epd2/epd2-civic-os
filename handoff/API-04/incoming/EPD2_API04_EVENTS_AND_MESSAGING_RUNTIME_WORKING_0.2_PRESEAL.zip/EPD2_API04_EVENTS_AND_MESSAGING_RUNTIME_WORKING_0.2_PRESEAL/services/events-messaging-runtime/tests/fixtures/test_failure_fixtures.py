"""The mandatory cross-service failure fixtures (FIR-TEST-002).

Twenty-two scenarios, every one of them against the live PostgreSQL 16.15 and
the live RabbitMQ 3.12.1. Nothing on the failure path is simulated: a broker
outage is `rabbitmqctl stop_app`, a lost acknowledgement is a real publisher
confirm that never arrives, a consumer crash closes a real channel and leaves a
real unacknowledged delivery on a real quorum queue, and a revoked authority is
a row that changes under `SELECT … FOR UPDATE` while the work is in flight.

Each fixture asserts three things where they apply: the **observable outcome**,
the **exact reason code**, and that nothing was silently dropped — a message is
applied, retried, or quarantined with evidence, and there is no fourth outcome.
"""

from __future__ import annotations

import time
import uuid

import pytest

from epd2_data_plane_service.outbox import OutboxStatus

from epd2_events_messaging_runtime import reason_codes as rc
from support import harness

pytestmark = [pytest.mark.live, pytest.mark.fixture]

MEMBERSHIP = "membership.membership_application_submitted"
PROJECTION = "membership.membership_application_submitted::projection-service"
NOTIFICATION = "membership.membership_application_submitted::notification-service"
DECISION = "membership.membership_decision_recorded"
DECISION_PROJECTION = "membership.membership_decision_recorded::projection-service"
AUTHORITY = "organizational_authority.assigned"
AUTHORITY_SUB = "organizational_authority.assigned::governance-service"


def _submit(runtime, *, sequence_number: int = 1):
    application_id = uuid.uuid4()
    event_id = harness.emit(
        runtime,
        "membership-service",
        MEMBERSHIP,
        harness.application_submitted(application_id),
        sequence_number=sequence_number,
    )
    return application_id, event_id


def _dispatch_until(runtime, service_id: str, *, published: int = 1, seconds: float = 6.0):
    """Drive the dispatcher until the governed backoff lets the record through.

    The wait is the runtime's own `RetryPolicy`, not a guessed sleep: the loop
    ends when the work is done or the deadline passes, so a backoff that grew
    fails the fixture instead of silently making it flaky."""
    deadline = time.monotonic() + seconds
    total = None
    while time.monotonic() < deadline:
        outcome = harness.dispatch(runtime, service_id)
        if total is None:
            total = outcome
        else:
            total.published += outcome.published
            total.acknowledged += outcome.acknowledged
            total.leased += outcome.leased
            total.reason_codes.extend(outcome.reason_codes)
        if total.published >= published:
            return total
        time.sleep(0.1)
    return total


def _projection_rows() -> int:
    return int(harness.scalar("SELECT count(*) AS n FROM dom_projection.projection_row") or 0)


# ---------------------------------------------------------------------------
# F-01  the broker is down when the domain commits
# ---------------------------------------------------------------------------
def test_f01_broker_unavailable_at_dispatch_defers_and_never_loses(runtime):
    _, event_id = _submit(runtime)
    harness.stop_broker()
    try:
        harness.reset_transport(runtime)
        outcome = harness.dispatch(runtime, "membership-service")
        assert outcome.published == 0
        assert rc.BROKER_UNAVAILABLE in outcome.reason_codes
        assert rc.RETRY_SCHEDULED_RECORDED in outcome.reason_codes

        row = harness.outbox_row("membership", event_id)
        assert row is not None, "a committed command is pending publication, never lost"
        assert row["status"] in (OutboxStatus.PENDING.value, OutboxStatus.FAILED.value)
        assert row["publication_evidence"] is None
    finally:
        harness.start_broker()
        harness.reset_transport(runtime)

    recovered = _dispatch_until(runtime, "membership-service")
    assert recovered.published == 1
    assert harness.outbox_row("membership", event_id)["status"] == OutboxStatus.ACKNOWLEDGED.value


# ---------------------------------------------------------------------------
# F-02  the broker restarts between publish and consume
# ---------------------------------------------------------------------------
def test_f02_broker_restart_preserves_the_durable_message(runtime):
    _, event_id = _submit(runtime)
    assert harness.dispatch(runtime, "membership-service").published == 1

    harness.stop_broker()
    harness.start_broker()
    harness.reset_transport(runtime)

    outcome = harness.consume(runtime, PROJECTION)
    assert outcome.applied == 1, "a quorum queue survives a broker restart"
    assert _projection_rows() == 1


# ---------------------------------------------------------------------------
# F-03  the publisher confirm never arrives
# ---------------------------------------------------------------------------
def test_f03_unknown_acknowledgement_is_neither_success_nor_failure(runtime):
    _, event_id = _submit(runtime)
    dispatcher = runtime.dispatcher_for("membership-service")
    dispatcher.broker.suppress_acknowledgements(True)
    try:
        outcome = dispatcher.run_once()
        assert outcome.published == 1
        assert outcome.acknowledgement_unknown == 1
        assert outcome.acknowledged == 0
        assert rc.DELIVERY_ACKNOWLEDGEMENT_MISSING in outcome.reason_codes

        row = harness.outbox_row("membership", event_id)
        # The publish happened; the confirmation did not. The record carries
        # both facts: the publication evidence without an acknowledgement, and
        # the declared `published -> failed` transition that schedules another
        # attempt instead of assuming the message arrived.
        assert row["publication_evidence"]["published_at"] is not None
        assert row["publication_evidence"]["acknowledgement"] is None
        assert row["status"] == OutboxStatus.FAILED.value
    finally:
        dispatcher.broker.suppress_acknowledgements(False)

    # It is re-attempted rather than assumed delivered, and the duplicate that
    # produces is absorbed by the consumer rather than by an assumption.
    again = _dispatch_until(runtime, "membership-service")
    assert again.published == 1
    assert again.acknowledged == 1

    consumed = harness.consume(runtime, PROJECTION)
    assert consumed.applied == 1
    assert consumed.duplicates == 1
    assert rc.EVENT_DUPLICATE_SUPPRESSED in consumed.reason_codes
    assert _projection_rows() == 1


# ---------------------------------------------------------------------------
# F-04  the consumer dies after the effect and before the acknowledgement
# ---------------------------------------------------------------------------
def test_f04_consumer_crash_after_effect_produces_one_effect_not_two(runtime):
    _submit(runtime)
    harness.dispatch(runtime, "membership-service")

    crashing = runtime.consumer_for(PROJECTION, abandon_after_effect=True)
    first = crashing.poll_all_partitions()
    assert first.applied == 1
    assert _projection_rows() == 1

    harness.reset_transport(runtime)
    redelivered = harness.consume(runtime, PROJECTION)
    assert redelivered.duplicates == 1
    assert redelivered.applied == 0
    assert _projection_rows() == 1, "effectively-once consumer effect"


# ---------------------------------------------------------------------------
# F-05  the same event is delivered twice
# ---------------------------------------------------------------------------
def test_f05_a_duplicate_delivery_is_suppressed_with_its_own_code(runtime):
    _, event_id = _submit(runtime)
    harness.dispatch(runtime, "membership-service")
    envelope = harness.envelope_on_the_wire(runtime, "membership", event_id)
    harness.publish_raw(runtime, MEMBERSHIP, envelope)

    outcome = harness.consume(runtime, PROJECTION)
    assert outcome.applied == 1
    assert outcome.duplicates == 1
    assert outcome.reason_codes.count(rc.EVENT_DUPLICATE_SUPPRESSED) == 1
    assert _projection_rows() == 1


# ---------------------------------------------------------------------------
# F-06  a message arrives out of order
# ---------------------------------------------------------------------------
def test_f06_out_of_order_is_refused_and_retried_not_applied(runtime):
    application_id = uuid.uuid4()
    harness.emit(
        runtime, "membership-service", MEMBERSHIP,
        harness.application_submitted(application_id), sequence_number=1,
    )
    harness.dispatch(runtime, "membership-service")
    assert harness.consume(runtime, PROJECTION).applied == 1

    # A gap: sequence 5 with the checkpoint at 1.
    gap_id = uuid.uuid4()
    harness.emit(
        runtime, "membership-service", MEMBERSHIP,
        harness.application_submitted(application_id), sequence_number=5,
        event_id=gap_id,
    )
    harness.dispatch(runtime, "membership-service")
    outcome = harness.consume(runtime, PROJECTION)
    assert outcome.applied == 0
    assert outcome.retried == 1
    assert rc.EVENT_ORDERING_GAP_DETECTED in outcome.reason_codes
    assert _projection_rows() == 1


# ---------------------------------------------------------------------------
# F-07  a poison message loops nowhere
# ---------------------------------------------------------------------------
def test_f07_a_poison_message_is_quarantined_within_its_attempt_budget(runtime):
    """A payload that will never become valid. It must not consume the queue
    forever: bounded attempts, then quarantine with evidence."""
    envelope = {
        "event_id": str(uuid.uuid4()),
        "event_type": MEMBERSHIP,
        "event_version": "1.0",
        "occurred_at": harness.iso(),
        "producer": "membership-service",
        "actor": {"actor_id": str(uuid.uuid4()), "actor_type": "service"},
        "subject": {"subject_type": "membership_application_id", "subject_id": str(uuid.uuid4())},
        "correlation_id": str(uuid.uuid4()),
        "causation_id": None,
        "payload": {"membership_application_id": str(uuid.uuid4()), "status": "not_a_status"},
        "integrity": {"payload_hash": "sha256:" + "0" * 64, "signature": None},
    }
    harness.publish_raw(runtime, MEMBERSHIP, envelope)

    outcome = harness.consume(runtime, PROJECTION)
    assert outcome.applied == 0
    assert outcome.dead_lettered == 1
    assert rc.SCHEMA_INCOMPATIBLE in outcome.reason_codes

    letters = harness.dead_letters(PROJECTION)
    assert len(letters) == 1
    assert letters[0]["reason_code"] == rc.SCHEMA_INCOMPATIBLE
    assert harness.queue_depth(runtime, PROJECTION) == 0
    assert harness.queue_depth(runtime, PROJECTION, dead_letter=True) == 1


# ---------------------------------------------------------------------------
# F-08  the payload does not satisfy its canonical schema
# ---------------------------------------------------------------------------
def test_f08_a_schema_incompatible_payload_never_reaches_the_domain(runtime):
    envelope = {
        "event_id": str(uuid.uuid4()),
        "event_type": MEMBERSHIP,
        "event_version": "1.0",
        "occurred_at": harness.iso(),
        "producer": "membership-service",
        "actor": {"actor_id": str(uuid.uuid4()), "actor_type": "service"},
        "subject": {"subject_type": "membership_application_id", "subject_id": str(uuid.uuid4())},
        "correlation_id": str(uuid.uuid4()),
        "causation_id": None,
        "payload": {"membership_application_id": str(uuid.uuid4())},  # `status` missing
        "integrity": {"payload_hash": "sha256:" + "0" * 64, "signature": None},
    }
    harness.publish_raw(runtime, MEMBERSHIP, envelope)
    outcome = harness.consume(runtime, PROJECTION)
    assert outcome.dead_lettered == 1
    assert rc.SCHEMA_INCOMPATIBLE in outcome.reason_codes
    assert _projection_rows() == 0


def _wire_envelope(event_type: str, payload: dict, *, version: str = "1.0",
                   event_id: uuid.UUID | None = None, subject_key: str,
                   payload_hash: str | None = None) -> dict:
    """An envelope as a *peer* would put it on the wire.

    Built through the canonical builder wherever the fixture is not deliberately
    corrupting a field, so a fixture tests the consumer's refusal rather than a
    hand-written shape the producer path would never emit.
    """
    from epd2_core.event_envelope import ActorRef, SubjectRef, build_event_envelope

    from epd2_events_messaging_runtime.persistence import codec

    envelope = build_event_envelope(
        event_id=event_id or uuid.uuid4(),
        event_type=event_type,
        event_version=version,
        occurred_at=__import__("datetime").datetime.now(__import__("datetime").timezone.utc),
        producer="membership-service",
        actor=ActorRef(actor_id=uuid.uuid4(), actor_type="service"),
        subject=SubjectRef(subject_type=subject_key, subject_id=uuid.UUID(str(payload[subject_key]))),
        correlation_id=uuid.uuid4(),
        causation_id=None,
        payload=payload,
    )
    body = codec.envelope_to_json(envelope)
    if payload_hash is not None:
        body["integrity"]["payload_hash"] = payload_hash
    return body


# ---------------------------------------------------------------------------
# F-09  the payload hash does not match the payload
# ---------------------------------------------------------------------------
def test_f09_a_payload_hash_mismatch_is_refused_with_the_canonical_code(runtime):
    application_id = uuid.uuid4()
    envelope = _wire_envelope(
        MEMBERSHIP,
        harness.application_submitted(application_id),
        subject_key="membership_application_id",
        payload_hash="sha256:" + "e" * 64,
    )
    harness.publish_raw(runtime, MEMBERSHIP, envelope)

    outcome = harness.consume(runtime, PROJECTION)
    assert outcome.applied == 0
    assert outcome.dead_lettered == 1
    assert rc.SCHEMA_DIGEST_MISMATCH in outcome.reason_codes
    assert _projection_rows() == 0


# ---------------------------------------------------------------------------
# F-10  an event type that is not in the canonical catalogue
# ---------------------------------------------------------------------------
def test_f10_an_uncatalogued_event_type_never_becomes_an_effect(runtime):
    envelope = _wire_envelope(
        "membership.invented_by_a_peer",
        harness.application_submitted(uuid.uuid4()),
        subject_key="membership_application_id",
    )
    harness.publish_raw(runtime, MEMBERSHIP, envelope)

    outcome = harness.consume(runtime, PROJECTION)
    assert outcome.dead_lettered == 1
    assert rc.EVENT_TYPE_NOT_IN_CANONICAL_CATALOGUE in outcome.reason_codes
    assert _projection_rows() == 0


# ---------------------------------------------------------------------------
# F-11  the mixed-version window: one consumer understands 1.1, the other does not
# ---------------------------------------------------------------------------
def test_f11_an_unsupported_version_dead_letters_where_it_is_not_understood(runtime):
    application_id = uuid.uuid4()
    event_id = harness.emit(
        runtime, "membership-service", DECISION,
        harness.decision_recorded(application_id), event_version="1.1",
    )
    assert harness.dispatch(runtime, "membership-service").published == 1

    understood = harness.consume(runtime, DECISION_PROJECTION)
    assert understood.applied == 1, "projection-service accepts 1.0 and 1.1"

    not_understood = harness.consume(
        runtime, "membership.membership_decision_recorded::notification-service"
    )
    assert not_understood.applied == 0
    assert not_understood.dead_lettered == 1
    assert rc.EVENT_VERSION_UNSUPPORTED in not_understood.reason_codes
    assert harness.outbox_row("membership", event_id)["status"] == "acknowledged"


# ---------------------------------------------------------------------------
# F-12  a producer that is not bound to the topic
# ---------------------------------------------------------------------------
def test_f12_an_unauthorised_producer_never_reaches_the_wire(runtime):
    """The domain wrote and the outbox row exists — and the message still does
    not go out, because the ACL is evaluated at dispatch, before the publish."""
    case_id = uuid.uuid4()
    event_id = harness.emit(
        runtime, "compliance-service", "procedural_deadline.state_changed",
        harness.deadline_state_changed(case_id, organization_id=runtime.organization.organization_id),
    )
    # Revoke the binding by presenting a principal that holds no produce grant
    # for this topic: the compliance principal is re-registered as membership's.
    dispatcher = runtime.dispatcher_for("compliance-service")
    dispatcher.producer_credential = runtime.transport_credential("projection-service")

    outcome = dispatcher.run_once()
    assert outcome.published == 0
    assert outcome.refused == 1
    assert rc.PRODUCER_NOT_AUTHORIZED_FOR_TOPIC in outcome.reason_codes
    assert harness.outbox_row("compliance", event_id)["status"] == "dead_lettered"
    assert harness.queue_depth(runtime, "procedural_deadline.state_changed::casework-service") == 0

    letters = harness.dead_letters()
    assert len(letters) == 1
    assert letters[0]["reason_code"] == rc.PRODUCER_NOT_AUTHORIZED_FOR_TOPIC


# ---------------------------------------------------------------------------
# F-13  a consumer that is not bound to the subscription
# ---------------------------------------------------------------------------
def test_f13_an_unauthorised_consumer_quarantines_rather_than_applies(runtime):
    _submit(runtime)
    harness.dispatch(runtime, "membership-service")

    consumer = runtime.consumer_for(PROJECTION)
    consumer.consumer_credential = runtime.transport_credential("casework-service")
    outcome = consumer.poll_all_partitions()

    assert outcome.applied == 0
    assert outcome.dead_lettered == 1
    assert rc.CONSUMER_NOT_AUTHORIZED_FOR_SUBSCRIPTION in outcome.reason_codes
    assert _projection_rows() == 0


# ---------------------------------------------------------------------------
# F-14  the API-03 identity boundary is unreachable
# ---------------------------------------------------------------------------
def test_f14_identity_unavailable_retries_and_reports_not_ready(runtime):
    _submit(runtime)
    harness.dispatch(runtime, "membership-service")

    runtime.identity_directory.set_available(False)
    try:
        outcome = harness.consume(runtime, PROJECTION)
        assert outcome.applied == 0
        assert outcome.retried == 1, "identity being down is transient, so it retries"
        assert rc.SERVICE_IDENTITY_UNAVAILABLE in outcome.reason_codes

        snapshot = runtime.readiness()
        assert snapshot.ready is False
        assert rc.SERVICE_IDENTITY_UNAVAILABLE in snapshot.blocking_reason_codes
    finally:
        runtime.identity_directory.set_available(True)

    assert _projection_rows() == 0


# ---------------------------------------------------------------------------
# F-15  the acting credential is revoked while the work is in flight
# ---------------------------------------------------------------------------
def test_f15_a_revoked_credential_stops_the_effect(runtime):
    _submit(runtime)
    harness.dispatch(runtime, "membership-service")

    runtime.identity_directory.revoke("cred-projection-service")
    outcome = harness.consume(runtime, PROJECTION)

    assert outcome.applied == 0
    assert outcome.dead_lettered == 1
    assert rc.SERVICE_CREDENTIAL_REVOKED in outcome.reason_codes
    assert _projection_rows() == 0


# ---------------------------------------------------------------------------
# F-16 … F-19  FIR-AUTH-001: the authority that existed at request time
#              must still exist at the consequential commit
# ---------------------------------------------------------------------------
def _queue_authority(runtime, **seed):
    authority_id = uuid.uuid4()
    harness.seed_authority(
        authority_id,
        organization_id=runtime.organization.organization_id,
        object_version=1,
        **seed,
    )
    event_id = harness.emit(
        runtime, "organization-service", AUTHORITY,
        harness.authority_assigned(authority_id), sequence_number=1,
    )
    assert harness.dispatch(runtime, "organization-service").published == 1
    return authority_id, event_id


def _assignments() -> int:
    return int(
        harness.scalar("SELECT count(*) AS n FROM dom_governance.authority_assignment") or 0
    )


def test_f16_authority_revoked_while_queued_stops_the_commit(runtime):
    authority_id, _ = _queue_authority(runtime)
    harness.mutate_authority(authority_id, authority_active=False)

    outcome = harness.consume(runtime, AUTHORITY_SUB)
    assert outcome.applied == 0
    assert outcome.dead_lettered == 1
    assert rc.CONCURRENCY_AUTHORITY_LAPSED in outcome.reason_codes
    assert _assignments() == 0


def test_f17_object_version_moved_while_queued_stops_the_commit(runtime):
    authority_id, _ = _queue_authority(runtime)
    harness.mutate_authority(authority_id, object_version=2)

    outcome = harness.consume(runtime, AUTHORITY_SUB)
    assert outcome.applied == 0
    assert rc.CONCURRENCY_STALE_AGGREGATE_VERSION in outcome.reason_codes
    assert _assignments() == 0


def test_f18_policy_version_changed_while_queued_stops_the_commit(runtime):
    authority_id, _ = _queue_authority(runtime)
    harness.mutate_authority(authority_id, policy_version="policy-2026-09")

    outcome = harness.consume(runtime, AUTHORITY_SUB)
    assert outcome.applied == 0
    assert rc.COMMIT_POLICY_VERSION_CHANGED in outcome.reason_codes
    assert _assignments() == 0


def test_f19_the_work_items_own_deadline_expiring_stops_the_commit(runtime):
    from datetime import datetime, timedelta, timezone

    authority_id, _ = _queue_authority(runtime)
    harness.mutate_authority(
        authority_id, deadline_at=datetime.now(timezone.utc) - timedelta(minutes=1)
    )

    outcome = harness.consume(runtime, AUTHORITY_SUB)
    assert outcome.applied == 0
    assert rc.COMMIT_DEADLINE_EXPIRED in outcome.reason_codes
    assert _assignments() == 0


def test_f16b_an_unchanged_authority_commits_and_records_its_basis(runtime):
    """The control for F-16 … F-19: without a change the same path commits, and
    the row carries the authority the commit actually relied on."""
    authority_id, _ = _queue_authority(runtime)
    outcome = harness.consume(runtime, AUTHORITY_SUB)
    assert outcome.applied == 1
    assert rc.COMMIT_AUTHORITY_BASIS_RECORDED in outcome.reason_codes

    rows = harness.query(
        "SELECT * FROM dom_governance.authority_assignment WHERE authority_id = %s",
        (authority_id,),
    )
    assert len(rows) == 1
    basis = rows[0]["authority_basis"]
    assert basis["service_principal"] == "governance-service"
    assert basis["object_version"] == 1
    assert basis["reason_code"] == rc.COMMIT_AUTHORITY_BASIS_RECORDED


# ---------------------------------------------------------------------------
# F-20  the database is unreachable when the consumer tries to commit
# ---------------------------------------------------------------------------
def test_f20_a_database_outage_leaves_the_message_on_the_queue(runtime):
    from epd2_data_plane_service.exceptions import DatabaseUnavailableError

    _submit(runtime)
    harness.dispatch(runtime, "membership-service")

    consumer = runtime.consumer_for(PROJECTION)
    working = consumer.connection_factory

    def unavailable():
        raise DatabaseUnavailableError(
            "the governed PostgreSQL instance is unreachable; the runtime is NOT READY"
        )

    consumer.connection_factory = unavailable
    with pytest.raises(DatabaseUnavailableError):
        consumer.poll_all_partitions()
    assert _projection_rows() == 0

    # Nothing was acknowledged, so the broker still owns the message. After the
    # connection that held it goes away, it is redelivered and applied once.
    consumer.connection_factory = working
    harness.reset_transport(runtime)
    recovered = harness.consume(runtime, PROJECTION)
    assert recovered.applied == 1
    assert _projection_rows() == 1


# ---------------------------------------------------------------------------
# F-21  a dispatcher dies holding a lease
# ---------------------------------------------------------------------------
def test_f21_an_expired_lease_is_reclaimed_and_the_record_still_goes_out(runtime):
    _, event_id = _submit(runtime)

    dead_dispatcher = runtime.dispatcher_for("membership-service")
    dead_dispatcher.lease_seconds = 1
    leased = dead_dispatcher.store.lease_batch(
        holder="dispatcher-that-died", batch_size=16, lease_seconds=1
    )
    assert len(leased) == 1
    assert harness.dispatch(runtime, "membership-service").leased == 0, "the lease is respected"

    time.sleep(1.2)
    runtime._dispatchers.clear()
    recovered = harness.dispatch(runtime, "membership-service")
    assert recovered.reclaimed >= 1
    assert rc.DISPATCH_LEASE_RECLAIMED_RECORDED in recovered.reason_codes
    assert recovered.published == 1
    assert harness.outbox_row("membership", event_id)["status"] == "acknowledged"


def test_f21b_two_dispatchers_never_lease_the_same_record(runtime):
    """`FOR UPDATE SKIP LOCKED`: the second dispatcher takes the next record,
    not the same one."""
    from epd2_events_messaging_runtime.persistence import db
    from epd2_events_messaging_runtime.persistence.postgres_stores import PostgresOutboxStore
    from epd2_data_plane_service.domain import DomainReference

    for _ in range(2):
        _submit(runtime)

    reference = DomainReference(domain_name="membership", is_reserved_boundary=False)
    first_conn, second_conn = db.connect(harness.POSTGRES_DSN), db.connect(harness.POSTGRES_DSN)
    try:
        first = PostgresOutboxStore(reference, first_conn).lease_batch(
            holder="worker-a", batch_size=1, lease_seconds=30
        )
        second = PostgresOutboxStore(reference, second_conn).lease_batch(
            holder="worker-b", batch_size=1, lease_seconds=30
        )
        assert len(first) == len(second) == 1
        assert first[0].outbox_record_id != second[0].outbox_record_id
    finally:
        first_conn.close()
        second_conn.close()


# ---------------------------------------------------------------------------
# F-22  the retry budget runs out
# ---------------------------------------------------------------------------
def test_f22_an_exhausted_retry_budget_quarantines_and_never_drops(runtime):
    """A retryable failure that never clears. The attempts are bounded by the
    subscription's own budget, each retry waits in its declared tier, and the
    end state is a quarantine record — never a discarded message."""
    _submit(runtime)
    harness.dispatch(runtime, "membership-service")

    subscription = runtime.topics.subscription(PROJECTION)
    runtime.identity_directory.set_available(False)
    retried = 0
    dead_lettered = 0
    codes: list[str] = []
    try:
        deadline = time.monotonic() + 40
        while time.monotonic() < deadline and dead_lettered == 0:
            harness.reset_transport(runtime)
            outcome = harness.consume(runtime, PROJECTION)
            retried += outcome.retried
            dead_lettered += outcome.dead_lettered
            codes.extend(outcome.reason_codes)
            if outcome.retried == 0 and outcome.dead_lettered == 0:
                time.sleep(0.2)
    finally:
        runtime.identity_directory.set_available(True)

    assert dead_lettered == 1, f"budget never ran out; codes seen: {sorted(set(codes))}"
    assert retried == subscription.max_attempts - 1
    assert rc.RETRY_SCHEDULED_RECORDED in codes
    assert rc.RETRY_BUDGET_EXHAUSTED_RECORDED in codes

    letters = harness.dead_letters(PROJECTION)
    assert len(letters) == 1
    assert letters[0]["reason_code"] == rc.RETRY_BUDGET_EXHAUSTED_RECORDED
    assert letters[0]["attempt_count"] == subscription.max_attempts
    assert harness.queue_depth(runtime, PROJECTION) == 0
    assert harness.queue_depth(runtime, PROJECTION, dead_letter=True) == 1
    assert _projection_rows() == 0
