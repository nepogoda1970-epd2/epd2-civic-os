"""The delivery contract, and that every decision on it is PACK-13's.

    at-least-once delivery + effectively-once consumer effect

Not the stronger unqualified phrase, which appears in this repository only in
the sentences forbidding it.
"""

from __future__ import annotations

import pathlib
from datetime import datetime, timedelta, timezone

import pytest

from epd2_data_plane_service.delivery import (
    DispatchAction,
    OrderingDecision,
    RetryPolicy,
    assess_ordering,
    decide_dispatch,
    lag_band_for,
)
from epd2_data_plane_service.outbox import OutboxStatus

from epd2_events_messaging_runtime.runtime import boundaries
from support import factories

NOW = datetime(2026, 8, 31, tzinfo=timezone.utc)
PACKAGE_ROOT = pathlib.Path(boundaries.PACKAGE_ROOT)


def test_the_contract_is_stated_in_the_package_docstring():
    import epd2_events_messaging_runtime as pkg

    text = (pkg.__doc__ or "").lower()
    assert "at-least-once delivery" in text
    assert "effectively-once consumer effect" in text


def test_the_stronger_phrase_appears_nowhere_unqualified():
    assert boundaries.assert_no_stronger_delivery_claim() == []


def test_ordering_is_assessed_by_pack13_and_not_reimplemented():
    assert assess_ordering(checkpoint_position=4, observed_sequence=5).decision is (
        OrderingDecision.IN_ORDER
    )
    assert assess_ordering(checkpoint_position=5, observed_sequence=5).decision is not (
        OrderingDecision.IN_ORDER
    )
    assert assess_ordering(checkpoint_position=4, observed_sequence=7).decision is not (
        OrderingDecision.IN_ORDER
    )


def test_a_gap_and_a_replay_are_distinguished_by_their_own_codes():
    gap = assess_ordering(checkpoint_position=4, observed_sequence=7)
    behind = assess_ordering(checkpoint_position=7, observed_sequence=4)
    assert gap.reason_code != behind.reason_code


def test_the_dispatch_decision_is_pack13s():
    record = factories.outbox_record()
    policy = RetryPolicy(max_attempts=3, initial_backoff=timedelta(milliseconds=200),
                         backoff_multiplier=4)
    dispatchable = decide_dispatch(record, now=NOW, broker_available=True, policy=policy)
    assert dispatchable.action is DispatchAction.DISPATCH_NOW

    unavailable = decide_dispatch(record, now=NOW, broker_available=False, policy=policy)
    assert unavailable.action is DispatchAction.DEFER
    assert unavailable.next_attempt_at is not None


def test_backoff_is_bounded_and_increasing():
    policy = RetryPolicy(max_attempts=5, initial_backoff=timedelta(milliseconds=200),
                         backoff_multiplier=4)
    delays = [policy.next_attempt_at(attempt_number=n, now=NOW) - NOW for n in range(1, 5)]
    assert delays == sorted(delays)
    assert all(delay > timedelta(0) for delay in delays)


def test_a_pending_record_is_neither_published_nor_acknowledged():
    record = factories.outbox_record()
    assert record.status is OutboxStatus.PENDING
    assert record.published is False
    assert record.acknowledged is False


def test_published_and_acknowledged_are_two_facts():
    """`ACKNOWLEDGEMENT_UNKNOWN` is a first-class outcome, so the adapter never
    has to guess which of the two it observed."""
    from epd2_data_plane_service.outbox import DeliveryOutcome

    assert DeliveryOutcome.ACKNOWLEDGEMENT_UNKNOWN.value != DeliveryOutcome.PUBLISHED.value


def test_an_undeclared_status_transition_is_refused():
    record = factories.outbox_record()
    with pytest.raises(ValueError):
        record.with_status(OutboxStatus.ACKNOWLEDGED)


def test_lag_banding_is_pack13s():
    assert lag_band_for(0) == "none"
    bands = [lag_band_for(n) for n in (0, 5, 500, 5000, 500000)]
    assert len(set(bands)) > 1


def test_the_runtime_defines_no_second_envelope():
    assert boundaries.assert_no_second_envelope() == []


def test_no_module_sorts_by_occurred_at():
    """Ordering is `sequence_number` and PACK-13's assessment. A sort on the
    producer's wall clock would be a second, silently weaker ordering.

    The scan runs over executable tokens only — comments and docstrings are
    skipped, so the sentence saying this never happens does not itself count as
    it happening."""
    import io
    import token as token_module
    import tokenize

    offenders = []
    for path in sorted(PACKAGE_ROOT.rglob("*.py")):
        source = path.read_text(encoding="utf-8")
        lines = source.splitlines()
        code_lines = set()
        for tok in tokenize.generate_tokens(io.StringIO(source).readline):
            if tok.type in (token_module.STRING, token_module.COMMENT, token_module.NL,
                            token_module.NEWLINE, token_module.INDENT, token_module.DEDENT):
                continue
            code_lines.add(tok.start[0])
        for number in sorted(code_lines):
            if number > len(lines):
                continue
            line = lines[number - 1]
            if ("sort" in line or "ORDER BY" in line) and "occurred_at" in line:
                offenders.append(f"{path.name}:{number}")
    assert offenders == []
