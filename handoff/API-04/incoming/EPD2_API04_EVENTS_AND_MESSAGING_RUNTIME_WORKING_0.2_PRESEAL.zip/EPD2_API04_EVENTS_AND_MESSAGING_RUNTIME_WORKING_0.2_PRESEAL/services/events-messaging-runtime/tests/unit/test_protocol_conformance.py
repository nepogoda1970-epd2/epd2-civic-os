"""Adapters implement PACK-13's ports; they do not resemble them.

The check is on the *signature*, compared member by member against the
`Protocol`, because a method that merely has the right name is how an adapter
drifts from the port it claims to satisfy.
"""

from __future__ import annotations

import inspect

import pytest

from epd2_data_plane_service import storage
from epd2_data_plane_service.delivery import BrokerPort

from epd2_events_messaging_runtime.persistence.postgres_stores import (
    PostgresAggregateVersionStore,
    PostgresConsumerCheckpointStore,
    PostgresDeadLetterStore,
    PostgresIdempotencyStore,
    PostgresOutboxStore,
    PostgresProjectionStore,
)
from epd2_events_messaging_runtime.transport.rabbitmq import RabbitMqBroker

PORTS = [
    (storage.OutboxStore, PostgresOutboxStore),
    (storage.IdempotencyStore, PostgresIdempotencyStore),
    (storage.ConsumerCheckpointStore, PostgresConsumerCheckpointStore),
    (storage.DeadLetterStore, PostgresDeadLetterStore),
    (storage.AggregateVersionStore, PostgresAggregateVersionStore),
    (storage.ProjectionStore, PostgresProjectionStore),
]


def _members(cls) -> dict[str, inspect.Signature]:
    out = {}
    for name, value in vars(cls).items():
        if name.startswith("_") or not callable(value):
            continue
        out[name] = inspect.signature(value)
    return out


@pytest.mark.parametrize("port, adapter", PORTS, ids=lambda x: getattr(x, "__name__", str(x)))
def test_the_adapter_implements_every_member_of_its_port(port, adapter):
    missing = [name for name in _members(port) if not hasattr(adapter, name)]
    assert missing == [], f"{adapter.__name__} is missing {missing} from {port.__name__}"


@pytest.mark.parametrize("port, adapter", PORTS, ids=lambda x: getattr(x, "__name__", str(x)))
def test_every_shared_member_keeps_the_ports_signature(port, adapter):
    """The port's own call form must still be callable, and anything the adapter
    adds must be keyword-only **with a default** — otherwise a caller holding
    the port could not call the adapter at all."""
    for name, expected in _members(port).items():
        observed = inspect.signature(getattr(adapter, name))
        expected_names = list(expected.parameters)
        observed_names = list(observed.parameters)
        assert observed_names[: len(expected_names)] == expected_names, (
            f"{adapter.__name__}.{name}{observed} does not begin with "
            f"{port.__name__}.{name}{expected}"
        )
        for extra in observed_names[len(expected_names):]:
            parameter = observed.parameters[extra]
            assert parameter.kind is inspect.Parameter.KEYWORD_ONLY, (
                f"{adapter.__name__}.{name} adds positional parameter {extra!r}"
            )
            assert parameter.default is not inspect.Parameter.empty, (
                f"{adapter.__name__}.{name} adds required parameter {extra!r}"
            )
        for shared in expected_names:
            assert observed.parameters[shared].kind is expected.parameters[shared].kind


def test_the_broker_adapter_implements_broker_port_exactly():
    expected = inspect.signature(BrokerPort.publish)
    observed = inspect.signature(RabbitMqBroker.publish)
    assert list(observed.parameters) == list(expected.parameters)
    assert observed.return_annotation == expected.return_annotation


def test_the_broker_adapter_is_also_the_additive_consumer_transport():
    from epd2_events_messaging_runtime.transport.ports import ConsumerTransportPort

    assert issubclass(RabbitMqBroker, ConsumerTransportPort)
    assert not inspect.isabstract(RabbitMqBroker)


def test_the_outbox_store_is_domain_owned():
    assert issubclass(PostgresOutboxStore, storage.DomainOwnedStore)
    assert issubclass(PostgresAggregateVersionStore, storage.DomainOwnedStore)


def test_no_adapter_redefines_a_canonical_port_name():
    from epd2_events_messaging_runtime.runtime import boundaries

    assert boundaries.assert_no_parallel_port() == []
