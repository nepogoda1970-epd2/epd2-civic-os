"""The consequential-effect guard, tested where it lives.

`revalidate_for_commit` normally refuses first, so this guard is the second
line: a wiring change that stopped calling the revalidation would otherwise
reach the effect with no basis at all. Defence in depth is only depth if it is
tested on its own.
"""

from __future__ import annotations

import inspect

import pytest

from epd2_data_plane_service.exceptions import ConcurrencyAuthorityLapsedError

from epd2_events_messaging_runtime.runtime import effects
from support import factories

CONSEQUENTIAL = (effects.authority_assignment,)


@pytest.mark.parametrize("effect", CONSEQUENTIAL, ids=lambda f: f.__name__)
def test_a_consequential_effect_refuses_an_absent_authority_basis(effect):
    record = factories.outbox_record(
        event_type="organizational_authority.assigned",
        payload={"authority_id": str(__import__('uuid').uuid4()), "status": "active"},
    )
    with pytest.raises(ConcurrencyAuthorityLapsedError):
        effect(None, record, None)


def test_the_guard_is_not_a_default():
    """`_require_basis` raises; it does not substitute one."""
    with pytest.raises(ConcurrencyAuthorityLapsedError):
        effects._require_basis(None, "organizational_authority.assigned")
    source = inspect.getsource(effects._require_basis)
    assert "return basis" in source
    assert "CommitAuthorityBasis(" not in source


def test_every_effect_in_the_register_is_bound_to_a_function():
    for subscription_id, function in effects.EFFECTS.items():
        assert callable(function), subscription_id
        parameters = list(inspect.signature(function).parameters)
        assert parameters == ["connection", "record", "basis"], subscription_id
