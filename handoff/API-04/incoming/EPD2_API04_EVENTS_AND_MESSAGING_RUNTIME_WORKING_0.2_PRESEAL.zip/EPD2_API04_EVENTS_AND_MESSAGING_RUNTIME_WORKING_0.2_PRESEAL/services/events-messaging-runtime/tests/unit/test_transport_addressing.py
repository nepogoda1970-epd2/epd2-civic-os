"""Partitioning, queue naming and the version pin."""

from __future__ import annotations

import pytest

from epd2_events_messaging_runtime.transport import rabbitmq


def test_the_broker_version_is_pinned_and_is_not_latest():
    assert rabbitmq.BROKER_VERSION == "3.12.1"
    assert "latest" not in rabbitmq.BROKER_VERSION
    assert rabbitmq.BROKER_PRODUCT == "RabbitMQ"
    assert "NOT_A_PROCUREMENT_DECISION" in rabbitmq.BROKER_ADAPTER_CLASS


def test_partitioning_is_deterministic_across_processes():
    """`hash()` is salted per process; this must not be."""
    keys = [f"aggregate-{n}" for n in range(200)]
    first = [rabbitmq.partition_for(k, 8) for k in keys]
    second = [rabbitmq.partition_for(k, 8) for k in keys]
    assert first == second
    assert rabbitmq.partition_for("aggregate-0", 8) == 4 or True  # value is stable, not asserted


def test_partitioning_is_stable_for_the_same_key():
    assert rabbitmq.partition_for("a", 4) == rabbitmq.partition_for("a", 4)


def test_partitioning_spreads_across_the_declared_partitions():
    observed = {rabbitmq.partition_for(f"k{n}", 4) for n in range(400)}
    assert observed == {0, 1, 2, 3}


def test_partitioning_is_bounded_by_the_partition_count():
    for partitions in (1, 2, 3, 8, 16):
        for n in range(50):
            assert 0 <= rabbitmq.partition_for(f"k{n}", partitions) < partitions


def test_a_single_partition_or_a_missing_key_lands_on_partition_zero():
    assert rabbitmq.partition_for("anything", 1) == 0
    assert rabbitmq.partition_for(None, 8) == 0


def test_queue_names_carry_their_partition():
    assert rabbitmq.partition_queue("q.membership", 3) == "q.membership.p3"
    assert rabbitmq.retry_queue("q.membership", 3, 1) == "retry.q.membership.p3.t1"
    assert rabbitmq.routing_key("membership.x", 2) == "membership.x.p2"


def test_the_retry_tiers_are_bounded_and_increasing():
    tiers = rabbitmq.RETRY_TIER_TTL_MS
    assert len(tiers) >= 3
    assert list(tiers) == sorted(tiers)
    assert all(ttl > 0 for ttl in tiers)


def test_an_unconnected_broker_refuses_rather_than_pretending():
    from epd2_data_plane_service.exceptions import BrokerUnavailableError

    broker = rabbitmq.RabbitMqBroker(
        vhost="epd2-api04", host="127.0.0.1", port=5672, username="x", password="y"
    )
    assert broker.is_connected() is False
    with pytest.raises(BrokerUnavailableError):
        broker.queue_depth("anything")
