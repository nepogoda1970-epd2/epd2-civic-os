"""Governed operations and structural invariants, against the live runtime."""
