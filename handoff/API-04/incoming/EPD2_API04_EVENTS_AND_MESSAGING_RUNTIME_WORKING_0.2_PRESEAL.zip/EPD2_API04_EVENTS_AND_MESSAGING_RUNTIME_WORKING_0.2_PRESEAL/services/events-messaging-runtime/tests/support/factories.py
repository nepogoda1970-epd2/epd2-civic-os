"""Pure builders for unit tests: no database, no broker.

These construct **canonical** objects — `epd2_core`'s envelope and PACK-13's
`OutboxRecord` — so a unit test that passes here is testing the same types the
live pipeline carries, not a local imitation.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Mapping

from epd2_core.event_envelope import ActorRef, SubjectRef, build_event_envelope
from epd2_data_plane_service.delivery import ConsumerCheckpoint
from epd2_data_plane_service.domain import (
    AggregateReference,
    DomainReference,
    OrganizationScopeKind,
    OrganizationScopeReference,
    RetentionScheduleReference,
)
from epd2_data_plane_service.outbox import OutboxRecord

ORGANIZATION = uuid.UUID("11111111-1111-4111-8111-111111111111")


def now() -> datetime:
    return datetime(2026, 8, 31, 12, 0, 0, tzinfo=timezone.utc)


def scope(kind: str = "bund") -> OrganizationScopeReference:
    return OrganizationScopeReference(
        organization_id=ORGANIZATION, scope_kind=OrganizationScopeKind(kind)
    )


def envelope(
    *,
    event_type: str = "membership.membership_application_submitted",
    event_version: str = "1.0",
    payload: Mapping[str, Any] | None = None,
    event_id: uuid.UUID | None = None,
    subject_id: uuid.UUID | None = None,
):
    subject_id = subject_id or uuid.uuid4()
    payload = dict(
        payload
        or {"membership_application_id": str(subject_id), "status": "application_pending"}
    )
    return build_event_envelope(
        event_id=event_id or uuid.uuid4(),
        event_type=event_type,
        event_version=event_version,
        occurred_at=now(),
        producer="membership-service",
        actor=ActorRef(
            actor_id=uuid.uuid5(uuid.NAMESPACE_URL, "service/membership-service"),
            actor_type="service",
        ),
        subject=SubjectRef(subject_type="membership_application_id", subject_id=subject_id),
        correlation_id=uuid.uuid4(),
        causation_id=None,
        payload=payload,
    )


def aggregate(subject_id: uuid.UUID, *, domain: str = "membership") -> AggregateReference:
    return AggregateReference(
        aggregate_type="membership_application_id",
        aggregate_id=subject_id,
        owning_domain=DomainReference(domain_name=domain, is_reserved_boundary=False),
    )


def outbox_record(
    *,
    sequence_number: int = 1,
    event_version: str = "1.0",
    event_type: str = "membership.membership_application_submitted",
    payload: Mapping[str, Any] | None = None,
    event_id: uuid.UUID | None = None,
    subject_id: uuid.UUID | None = None,
    domain: str = "membership",
) -> OutboxRecord:
    subject_id = subject_id or uuid.uuid4()
    env = envelope(
        event_type=event_type,
        event_version=event_version,
        payload=payload,
        event_id=event_id,
        subject_id=subject_id,
    )
    return OutboxRecord(
        outbox_record_id=uuid.uuid4(),
        event_id=env.event_id,
        event_type=env.event_type,
        event_version=env.event_version,
        envelope=env,
        aggregate=aggregate(subject_id, domain=domain),
        scope=scope(),
        created_at=now(),
        sequence_number=sequence_number,
        retention_schedule=RetentionScheduleReference(
            schedule_id=uuid.uuid5(uuid.NAMESPACE_URL, "retention/domain-event-p365d"),
            schedule_name="domain-event-p365d",
        ),
    )


def checkpoint(position: int = 0, *, consumer: str = "c", domain: str = "projection") -> ConsumerCheckpoint:
    return ConsumerCheckpoint(
        consumer_name=consumer,
        consumer_domain=domain,
        ordering_scope_key="scope",
        position=position,
        updated_at=now(),
    )


def privileged_grant(operation: str = "event_replay"):
    from datetime import timedelta

    from epd2_data_plane_service.domain import PrivilegedGrantReference

    return PrivilegedGrantReference(
        grant_id=uuid.uuid5(uuid.NAMESPACE_URL, f"grant/{operation}"),
        purpose="governed replay of a bounded range",
        operation=operation,
        scope=scope(),
        expires_at=now() + timedelta(days=1),
    )


def actor_reference(domain: str = "governance"):
    from epd2_data_plane_service.domain import ActorReference

    return ActorReference(
        actor_id=uuid.uuid5(uuid.NAMESPACE_URL, f"operator/{domain}"),
        actor_type="operator",
        acting_domain=DomainReference(domain_name=domain, is_reserved_boundary=False),
    )


def evidence_reference(digest: str = "sha256:" + "1" * 64):
    from epd2_data_plane_service.domain import EvidenceReference

    return EvidenceReference(
        evidence_bundle_id=uuid.uuid5(uuid.NAMESPACE_URL, f"evidence/{digest}"),
        content_digest=digest,
    )


def replay_reference(*, from_sequence: int = 1, to_sequence: int = 1, scope_key: str = "scope"):
    from epd2_data_plane_service.delivery import ReplayReference

    return ReplayReference(
        replay_id=uuid.uuid4(),
        requested_by=actor_reference(),
        grant=privileged_grant(),
        ordering_scope_key=scope_key,
        from_sequence=from_sequence,
        to_sequence=to_sequence,
        requested_at=now(),
        evidence=evidence_reference(),
        reason_code="EVENT_REPLAY_NOT_AUTHORIZED",
    )
