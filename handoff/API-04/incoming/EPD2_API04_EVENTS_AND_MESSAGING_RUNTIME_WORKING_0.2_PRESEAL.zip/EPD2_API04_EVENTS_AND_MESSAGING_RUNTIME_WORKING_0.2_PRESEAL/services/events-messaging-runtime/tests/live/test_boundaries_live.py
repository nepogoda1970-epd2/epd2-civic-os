"""The invariants, asserted where they actually hold: on the wire and in the database."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

import psycopg
import pytest

from epd2_data_plane_service.domain import DomainReference
from epd2_data_plane_service.exceptions import CrossDomainDirectAccessDeniedError

from epd2_events_messaging_runtime import reason_codes as rc
from epd2_events_messaging_runtime.exceptions import (
    NetworkCorrelationMetadataProhibitedError,
    VotingMaterialProhibitedError,
)
from epd2_events_messaging_runtime.persistence import db
from epd2_events_messaging_runtime.persistence.postgres_stores import PostgresOutboxStore
from epd2_events_messaging_runtime.runtime.dispatcher import PublishBeforeCommitRefused
from epd2_events_messaging_runtime.runtime.unit_of_work import (
    OutboxEventWithoutDomainWriteError,
    domain_unit_of_work,
)
from epd2_events_messaging_runtime.transport.rabbitmq import partition_queue
from support import factories, harness

pytestmark = pytest.mark.live

MEMBERSHIP = "membership.membership_application_submitted"
PROJECTION = "membership.membership_application_submitted::projection-service"
AUTHORITY = "organizational_authority.assigned"
AUTHORITY_SUB = "organizational_authority.assigned::governance-service"

CANONICAL_ENVELOPE_KEYS = {
    "event_id", "event_type", "event_version", "occurred_at", "producer", "actor",
    "subject", "correlation_id", "causation_id", "payload", "integrity",
}


def _pull_one(runtime, subscription_id: str):
    subscription = runtime.topics.subscription(subscription_id)
    topic = runtime.topics.topic(subscription.topic_id)
    broker = runtime.broker_for(role="service", service_id=subscription.consumer_service)
    for partition in range(topic.partitions):
        batch = broker.pull(queue=subscription.queue, partition=partition, max_messages=1)
        if batch:
            broker.acknowledge(batch[0])
            return batch[0]
    raise AssertionError("no message on the wire")


# --- the envelope on the wire ----------------------------------------------


def test_the_message_on_the_wire_is_the_canonical_envelope(runtime):
    harness.emit(
        runtime, "membership-service", MEMBERSHIP,
        harness.application_submitted(uuid.uuid4()),
    )
    harness.dispatch(runtime, "membership-service")
    message = _pull_one(runtime, PROJECTION)

    assert set(message.envelope) == CANONICAL_ENVELOPE_KEYS
    assert set(message.envelope["integrity"]) == {"payload_hash", "signature"}


def test_transport_metadata_rides_in_headers_and_never_in_the_envelope(runtime):
    """ADR-071: the envelope is canon-neutral; attempts, partitions and
    destinations live on the record and on the wire's headers."""
    harness.emit(
        runtime, "membership-service", MEMBERSHIP,
        harness.application_submitted(uuid.uuid4()), sequence_number=4,
    )
    harness.dispatch(runtime, "membership-service")
    message = _pull_one(runtime, PROJECTION)

    forbidden = {"attempt", "attempts", "delivery_count", "redelivered", "queue",
                 "routing_key", "partition", "offset", "delivery_tag", "status", "lease_id"}
    assert forbidden.isdisjoint(set(message.envelope))
    assert message.headers["x-epd2-sequence-number"] == 4
    assert message.headers["x-epd2-event-version"] == "1.0"
    assert "x-epd2-partition" in message.headers


def test_no_infrastructure_correlation_metadata_reaches_the_wire(runtime):
    from epd2_events_messaging_runtime.runtime import privacy

    harness.emit(
        runtime, "membership-service", MEMBERSHIP,
        harness.application_submitted(uuid.uuid4()),
    )
    harness.dispatch(runtime, "membership-service")
    message = _pull_one(runtime, PROJECTION)

    privacy.assert_no_network_correlation(dict(message.envelope), context="envelope")
    privacy.assert_no_network_correlation(dict(message.headers), context="headers")


def test_a_delivery_carrying_network_metadata_is_refused(runtime):
    """The other direction: a peer that adds an address header is refused
    rather than quietly accepted (FIR-VOTE-NET-001)."""
    harness.emit(
        runtime, "membership-service", MEMBERSHIP,
        harness.application_submitted(uuid.uuid4()),
    )
    harness.dispatch(runtime, "membership-service")
    message = _pull_one(runtime, PROJECTION)

    harness.publish_raw(
        runtime, MEMBERSHIP, dict(message.envelope),
        headers={"client_ip": "203.0.113.9", "x-epd2-sequence-number": 1},
    )
    outcome = harness.consume(runtime, PROJECTION)
    assert outcome.applied == 0
    assert outcome.dead_lettered == 1
    assert rc.NETWORK_CORRELATION_METADATA_PROHIBITED in outcome.reason_codes


def test_voting_material_cannot_be_written_to_an_outbox(runtime):
    """The isolation is structural: there is no voting plane to keep material
    off, because the material cannot enter the runtime at all."""
    with pytest.raises(VotingMaterialProhibitedError):
        harness.emit(
            runtime, "membership-service", MEMBERSHIP,
            {"membership_application_id": str(uuid.uuid4()), "status": "application_pending",
             "ballot_id": str(uuid.uuid4())},
        )


# --- quarantine evidence ----------------------------------------------------


def test_a_restricted_topic_quarantines_by_reference_only(runtime):
    authority_id = uuid.uuid4()
    harness.seed_authority(
        authority_id, organization_id=runtime.organization.organization_id, object_version=1
    )
    harness.emit(
        runtime, "organization-service", AUTHORITY, harness.authority_assigned(authority_id)
    )
    harness.dispatch(runtime, "organization-service")
    harness.mutate_authority(authority_id, authority_active=False)

    outcome = harness.consume(runtime, AUTHORITY_SUB)
    assert outcome.dead_lettered == 1

    letter = harness.dead_letters(AUTHORITY_SUB)[0]
    assert letter["payload_retained"] is False
    assert "payload" not in letter["envelope_reference"]
    assert set(letter["envelope_reference"]) <= {
        "event_id", "event_type", "event_version", "producer", "occurred_at",
        "correlation_id", "payload_hash",
    }
    assert letter["payload_hash"]


def test_quarantine_evidence_passes_the_evidence_gate(runtime):
    from epd2_events_messaging_runtime.runtime import privacy

    authority_id = uuid.uuid4()
    harness.seed_authority(
        authority_id, organization_id=runtime.organization.organization_id, object_version=1
    )
    harness.emit(
        runtime, "organization-service", AUTHORITY, harness.authority_assigned(authority_id)
    )
    harness.dispatch(runtime, "organization-service")
    harness.mutate_authority(authority_id, authority_active=False)
    harness.consume(runtime, AUTHORITY_SUB)

    for letter in harness.dead_letters():
        privacy.assert_evidence_safe(letter["envelope_reference"], context="quarantine")


# --- the transactional boundary --------------------------------------------


def test_an_event_without_a_domain_write_is_refused(runtime):
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        with pytest.raises(OutboxEventWithoutDomainWriteError) as excinfo:
            with domain_unit_of_work(
                conn, domain="membership", scope=runtime.organization,
                now=datetime.now(timezone.utc),
            ) as unit:
                unit.stage(factories.outbox_record())
        assert excinfo.value.reason_code == rc.OUTBOX_PUBLICATION_PENDING
    finally:
        conn.close()


def test_a_domain_write_that_declares_an_event_is_refused_without_one(runtime):
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        with pytest.raises(OutboxEventWithoutDomainWriteError):
            with domain_unit_of_work(
                conn, domain="membership", scope=runtime.organization,
                now=datetime.now(timezone.utc),
            ) as unit:
                unit.record_domain_write("membership_application/1")
    finally:
        conn.close()


def test_a_rolled_back_unit_leaves_neither_the_write_nor_the_event(runtime):
    application_id = uuid.uuid4()
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        with pytest.raises(RuntimeError):
            with domain_unit_of_work(
                conn, domain="membership", scope=runtime.organization,
                now=datetime.now(timezone.utc),
            ) as unit:
                record = factories.outbox_record()
                unit.record_domain_write("membership_application/1")
                unit.stage(record)
                PostgresOutboxStore(unit.domain, conn).append(record, writing_domain=unit.domain)
                raise RuntimeError("the domain decided not to proceed")
    finally:
        conn.close()

    assert harness.scalar("SELECT count(*) AS n FROM dom_membership.outbox_record") == 0
    del application_id


def test_the_dispatcher_refuses_the_domain_transactions_own_connection(runtime):
    dispatcher = runtime.dispatcher_for("membership-service")
    with pytest.raises(PublishBeforeCommitRefused) as excinfo:
        dispatcher.assert_not_domain_connection(dispatcher.connection)
    assert excinfo.value.reason_code == rc.OUTBOX_PUBLICATION_PENDING

    other = db.connect(harness.POSTGRES_DSN)
    try:
        dispatcher.assert_not_domain_connection(other)
    finally:
        other.close()


def test_an_uncommitted_outbox_row_is_invisible_to_the_dispatcher(runtime):
    """The structural half of "no publish before commit"."""
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        record = factories.outbox_record()
        reference = DomainReference(domain_name="membership", is_reserved_boundary=False)
        PostgresOutboxStore(reference, conn).append(record, writing_domain=reference)
        outcome = harness.dispatch(runtime, "membership-service")
        assert outcome.leased == 0
        conn.commit()
    finally:
        conn.close()
    assert harness.dispatch(runtime, "membership-service").leased == 1


def test_a_domain_may_not_write_another_domains_outbox(runtime):
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        membership = DomainReference(domain_name="membership", is_reserved_boundary=False)
        organization = DomainReference(domain_name="organization", is_reserved_boundary=False)
        with pytest.raises(CrossDomainDirectAccessDeniedError):
            PostgresOutboxStore(membership, conn).append(
                factories.outbox_record(), writing_domain=organization
            )
    finally:
        conn.close()


def test_the_event_identity_on_a_written_record_is_immutable(runtime):
    """A trigger, not a convention: the refusal survives a caller that forgets."""
    _, = [None]
    harness.emit(
        runtime, "membership-service", MEMBERSHIP,
        harness.application_submitted(uuid.uuid4()),
    )
    with pytest.raises(psycopg.errors.RaiseException) as excinfo:
        harness.execute(
            "UPDATE dom_membership.outbox_record SET event_id = %s", (uuid.uuid4(),)
        )
    assert rc.SCHEMA_VERSION_IDENTITY_IMMUTABLE in str(excinfo.value)


def test_the_payload_hash_on_a_written_record_is_immutable(runtime):
    harness.emit(
        runtime, "membership-service", MEMBERSHIP,
        harness.application_submitted(uuid.uuid4()),
    )
    with pytest.raises(psycopg.errors.RaiseException):
        harness.execute("UPDATE dom_membership.outbox_record SET payload_hash = 'sha256:0'")


# --- horizons ---------------------------------------------------------------


def test_a_deduplication_horizon_shorter_than_the_replay_horizon_is_refused(runtime):
    from datetime import timedelta

    from epd2_events_messaging_runtime.exceptions import DeduplicationHorizonTooShortError
    from epd2_events_messaging_runtime.persistence.postgres_stores import (
        PostgresDeduplicationStore,
    )

    conn = db.connect(harness.POSTGRES_DSN)
    try:
        store = PostgresDeduplicationStore("projection", conn)
        store.horizon_covers(
            deduplication_horizon=timedelta(days=90),
            replay_horizon=timedelta(days=30),
            subscription_id=PROJECTION,
        )
        with pytest.raises(DeduplicationHorizonTooShortError):
            store.horizon_covers(
                deduplication_horizon=timedelta(days=7),
                replay_horizon=timedelta(days=30),
                subscription_id=PROJECTION,
            )
    finally:
        conn.close()


def test_every_declared_queue_exists_and_every_live_queue_is_declared(runtime):
    broker = runtime.broker_for()
    declared = runtime.topics.declared_queues()
    for name in declared:
        broker.queue_depth(name)
    assert len(declared) == sum(
        runtime.topics.topic(s.topic_id).partitions * 2 for s in runtime.topics.subscriptions
    )
    assert partition_queue("q.x", 0) == "q.x.p0"
