"""Serialisation round trips.

The envelope that goes on the wire and the record that goes in the outbox are
canonical types. If a round trip loses or changes a field, a redelivery would
carry something the producer never wrote — so every field is asserted, not just
the ones the pipeline happens to read.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from epd2_core.event_envelope import compute_payload_hash
from epd2_data_plane_service.delivery import DeadLetterRecord
from epd2_data_plane_service.domain import ClassificationReference
from epd2_data_plane_service.outbox import (
    BrokerAcknowledgementReference,
    DeliveryAttempt,
    DeliveryOutcome,
    DestinationReference,
    PublicationEvidence,
)

from epd2_events_messaging_runtime.persistence import codec
from support import factories


def test_envelope_round_trip_is_byte_identical():
    original = factories.envelope()
    row = codec.envelope_to_json(original)
    restored = codec.envelope_from_json(row)
    assert restored == original
    assert codec.envelope_to_json(restored) == row


def test_envelope_json_carries_no_transport_metadata():
    row = codec.envelope_to_json(factories.envelope())
    forbidden = {"attempt", "attempts", "delivery_count", "redelivered", "queue",
                 "routing_key", "partition", "offset", "delivery_tag", "lease_id", "status"}
    assert forbidden.isdisjoint(set(row))


def test_envelope_json_preserves_the_payload_hash():
    envelope = factories.envelope()
    row = codec.envelope_to_json(envelope)
    assert row["integrity"]["payload_hash"] == compute_payload_hash(envelope.payload)


def test_outbox_record_round_trip():
    record = factories.outbox_record(sequence_number=7)
    restored = codec.outbox_record_from_row(codec.outbox_record_to_row(record))
    assert restored == record


def test_outbox_record_round_trip_with_attempts_and_evidence():
    import dataclasses

    record = factories.outbox_record()
    destination = DestinationReference(
        destination_id=uuid.uuid5(uuid.NAMESPACE_URL, "destination/topic"),
        destination_name="epd2.membership",
    )
    attempt = DeliveryAttempt(
        attempt_number=1,
        started_at=factories.now(),
        outcome=DeliveryOutcome.ACKNOWLEDGEMENT_UNKNOWN,
        destination=destination,
    )
    evidence = PublicationEvidence(
        event_id=record.event_id,
        published_at=factories.now(),
        destination=destination,
        acknowledgement=BrokerAcknowledgementReference(
            acknowledgement_reference="ex/key/id",
            received_at=factories.now(),
        ),
    )
    record = dataclasses.replace(record, attempts=(attempt,), publication_evidence=evidence)
    restored = codec.outbox_record_from_row(codec.outbox_record_to_row(record))
    assert restored.attempts == record.attempts
    assert restored.publication_evidence == record.publication_evidence
    assert restored.acknowledged is True


def test_dead_letter_round_trip():
    record = DeadLetterRecord(
        dead_letter_id=uuid.uuid4(),
        event_id=uuid.uuid4(),
        event_type="membership.membership_application_submitted",
        reason_code="SCHEMA_INCOMPATIBLE",
        attempt_count=3,
        failed_at=datetime(2026, 8, 31, tzinfo=timezone.utc),
        classification=ClassificationReference(
            classification_id=uuid.uuid4(), tier="internal"
        ),
        retention_schedule=None,
    )
    assert codec.dead_letter_from_row(codec.dead_letter_to_row(record)) == record


def test_checkpoint_round_trip():
    checkpoint = factories.checkpoint(position=42)
    assert codec.checkpoint_from_row(codec.checkpoint_to_row(checkpoint)) == checkpoint
