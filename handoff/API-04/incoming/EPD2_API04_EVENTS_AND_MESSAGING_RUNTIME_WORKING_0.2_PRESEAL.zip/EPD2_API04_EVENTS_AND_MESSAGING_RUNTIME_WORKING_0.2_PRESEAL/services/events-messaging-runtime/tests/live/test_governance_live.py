"""Governed operations against the live runtime.

Re-drive, replay, backpressure, readiness, topology drift, broker permissions
and migration immutability — the parts of the runtime that are *policy* rather
than delivery, exercised where they actually run.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import pytest

from epd2_data_plane_service.exceptions import (
    EventReplayNotAuthorizedError,
    MigrationChecksumMismatchError,
)

from epd2_events_messaging_runtime import reason_codes as rc
from epd2_events_messaging_runtime.exceptions import (
    RedriveAuthorityMissingError,
    RedriveTargetMismatchError,
)
from epd2_events_messaging_runtime.persistence import db
from epd2_events_messaging_runtime.persistence.postgres_stores import PostgresDeadLetterStore
from epd2_events_messaging_runtime.runtime import lag as lag_module
from epd2_events_messaging_runtime.runtime import redrive as redrive_module
from epd2_events_messaging_runtime.runtime import replay as replay_module
from epd2_events_messaging_runtime.runtime.backpressure import OverloadPolicy
from support import factories, harness

pytestmark = pytest.mark.live

MEMBERSHIP = "membership.membership_application_submitted"
PROJECTION = "membership.membership_application_submitted::projection-service"


def _quarantine_one(runtime) -> uuid.UUID:
    """Produce a real dead letter through the real pipeline."""
    envelope = {
        "event_id": str(uuid.uuid4()),
        "event_type": MEMBERSHIP,
        "event_version": "1.0",
        "occurred_at": harness.iso(),
        "producer": "membership-service",
        "actor": {"actor_id": str(uuid.uuid4()), "actor_type": "service"},
        "subject": {"subject_type": "membership_application_id", "subject_id": str(uuid.uuid4())},
        "correlation_id": str(uuid.uuid4()),
        "causation_id": None,
        "payload": {"membership_application_id": str(uuid.uuid4()), "status": "invalid_status"},
        "integrity": {"payload_hash": "sha256:" + "0" * 64, "signature": None},
    }
    harness.publish_raw(runtime, MEMBERSHIP, envelope)
    outcome = harness.consume(runtime, PROJECTION)
    assert outcome.dead_lettered == 1
    letters = harness.dead_letters(PROJECTION)
    assert len(letters) == 1
    return letters[0]["dead_letter_id"]


def _authority(reason: str = "schema corrected under change record CR-14"):
    return redrive_module.RedriveAuthority(
        operator_principal="operator:governance-desk",
        authority_reference="grant:PACK-12/redrive/2026-08",
        reason=reason,
    )


def _checks(**overrides):
    base = dict(
        schema_compatibility=lambda event_type, version: "compatible",
        authorization_check=lambda item: "authorized",
        state_check=lambda item: "current",
        republish=lambda item: "republished",
    )
    base.update(overrides)
    return base


# --- governed re-drive ------------------------------------------------------


def test_a_governed_redrive_records_its_evaluation_and_moves_the_message(runtime):
    dead_letter_id = _quarantine_one(runtime)
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        reference = redrive_module.perform_redrive(
            conn,
            redrive_module.RedriveRequest(
                dead_letter_id=dead_letter_id,
                target_subscription=PROJECTION,
                authority=_authority(),
            ),
            dead_letters=PostgresDeadLetterStore(conn),
            **_checks(),
        )
    finally:
        conn.close()

    rows = harness.query(
        "SELECT * FROM api04_gov.redrive_record WHERE redrive_reference = %s", (reference,)
    )
    assert len(rows) == 1
    record = rows[0]
    assert record["outcome_reason_code"] == rc.REDRIVE_RECORDED
    assert record["operator_principal"] == "operator:governance-desk"
    assert record["intended_range"]["kind"] == "single_item"
    assert harness.dead_letters(PROJECTION)[0]["redriven"] is True


def test_a_redrive_to_another_subscription_is_refused(runtime):
    dead_letter_id = _quarantine_one(runtime)
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        with pytest.raises(RedriveTargetMismatchError):
            redrive_module.perform_redrive(
                conn,
                redrive_module.RedriveRequest(
                    dead_letter_id=dead_letter_id,
                    target_subscription=
                    "membership.membership_application_submitted::notification-service",
                    authority=_authority(),
                ),
                dead_letters=PostgresDeadLetterStore(conn),
                **_checks(),
            )
    finally:
        conn.close()
    assert harness.dead_letters(PROJECTION)[0]["redriven"] is False


def test_a_second_redrive_of_the_same_dead_letter_is_refused(runtime):
    dead_letter_id = _quarantine_one(runtime)
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        request = redrive_module.RedriveRequest(
            dead_letter_id=dead_letter_id, target_subscription=PROJECTION, authority=_authority()
        )
        store = PostgresDeadLetterStore(conn)
        redrive_module.perform_redrive(conn, request, dead_letters=store, **_checks())
        with pytest.raises(RedriveTargetMismatchError):
            redrive_module.perform_redrive(conn, request, dead_letters=store, **_checks())
    finally:
        conn.close()


def test_a_failed_current_state_check_refuses_and_still_records_the_evaluation(runtime):
    dead_letter_id = _quarantine_one(runtime)
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        with pytest.raises(RedriveAuthorityMissingError):
            redrive_module.perform_redrive(
                conn,
                redrive_module.RedriveRequest(
                    dead_letter_id=dead_letter_id,
                    target_subscription=PROJECTION,
                    authority=_authority(),
                ),
                dead_letters=PostgresDeadLetterStore(conn),
                **_checks(authorization_check=lambda item: "revoked"),
            )
    finally:
        conn.close()

    rows = harness.query("SELECT * FROM api04_gov.redrive_record")
    assert len(rows) == 1, "a refused re-drive is still recorded"
    assert rows[0]["outcome_reason_code"] == rc.REDRIVE_AUTHORITY_MISSING
    assert rows[0]["authorization_result"] == "revoked"
    assert harness.dead_letters(PROJECTION)[0]["redriven"] is False


# --- governed replay --------------------------------------------------------


def _replay_request(kind: str = "bounded_range", **kw):
    return replay_module.ReplayRequest(
        kind=kind,
        topic_id=MEMBERSHIP,
        reference=factories.replay_reference(**kw.pop("reference", {})),
        target_subscription=PROJECTION,
        policy_version=kw.pop("policy_version", "policy-2026-08"),
    )


def _evaluate(conn, *, subject_reference: str, **overrides):
    base = dict(
        origin_occurred_at=datetime.now(timezone.utc) - timedelta(days=1),
        retention_horizon=timedelta(days=365),
        now=datetime.now(timezone.utc),
        schema_compatibility="compatible",
        subject_reference=subject_reference,
        origin_policy_version="policy-2026-08",
        current_policy_version="policy-2026-08",
        reinterpretation_permitted=False,
        authorization_result="authorized",
        object_state_result="current",
    )
    base.update(overrides)
    return replay_module.evaluate_replay(conn, _replay_request(), **base)


def test_a_clean_replay_is_authorised_and_recorded(runtime):
    subject = f"membership_application/{uuid.uuid4()}"
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        evaluation = _evaluate(conn, subject_reference=subject)
        assert evaluation.blocking_reason_code is None
        reference = replay_module.perform_replay(
            conn, _replay_request(), evaluation,
            current_policy_version="policy-2026-08", emit=lambda: 3,
        )
    finally:
        conn.close()

    row = harness.query(
        "SELECT * FROM api04_gov.replay_record WHERE replay_reference = %s", (reference,)
    )[0]
    assert row["outcome_reason_code"] == rc.REPLAY_RECORDED
    assert row["message_count"] == 3
    assert row["history_preserved"] is True


@pytest.mark.parametrize(
    "overrides, expected",
    [
        ({"origin_occurred_at": datetime.now(timezone.utc) - timedelta(days=800)},
         rc.EVENT_REPLAY_NOT_AUTHORIZED),
        ({"schema_compatibility": "incompatible"}, rc.SCHEMA_INCOMPATIBLE),
        ({"current_policy_version": "policy-2026-09"}, rc.REPLAY_REINTERPRETATION_PROHIBITED),
        ({"authorization_result": "revoked"}, rc.CONCURRENCY_AUTHORITY_LAPSED),
        ({"object_state_result": "superseded"}, rc.CONCURRENCY_STALE_AGGREGATE_VERSION),
    ],
)
def test_each_replay_check_blocks_with_its_own_reason_code(runtime, overrides, expected):
    subject = f"membership_application/{uuid.uuid4()}"
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        evaluation = _evaluate(conn, subject_reference=subject, **overrides)
        assert evaluation.blocking_reason_code == expected
        with pytest.raises(EventReplayNotAuthorizedError):
            replay_module.perform_replay(
                conn, _replay_request(), evaluation,
                current_policy_version="policy-2026-08",
                emit=lambda: pytest.fail("a blocked replay must never emit"),
            )
    finally:
        conn.close()

    row = harness.query("SELECT * FROM api04_gov.replay_record")[0]
    assert row["outcome_reason_code"] == expected
    assert row["message_count"] == 0


def test_a_legal_hold_blocks_a_replay(runtime):
    subject = f"membership_application/{uuid.uuid4()}"
    harness.execute(
        "INSERT INTO api04_gov.legal_hold (hold_reference, subject_kind, subject_reference, active) "
        "VALUES (%s,%s,%s,true)",
        (f"hold-{uuid.uuid4()}", "membership_application", subject),
    )
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        evaluation = _evaluate(conn, subject_reference=subject)
    finally:
        conn.close()
    assert evaluation.legal_hold_check == "hold_active"
    assert evaluation.blocking_reason_code == rc.RECORD_UNDER_LEGAL_HOLD


def test_a_purged_subject_does_not_come_back_through_replay(runtime):
    subject = f"membership_application/{uuid.uuid4()}"
    harness.execute(
        "INSERT INTO api04_gov.disposition_record "
        "(disposition_reference, derived_copy_kind, subject_reference, action, reason_code, evidence) "
        "VALUES (%s,'projection',%s,'purge','GOVERNED_RECORD_DELETION_FORBIDDEN','{}'::jsonb)",
        (uuid.uuid4(), subject),
    )
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        evaluation = _evaluate(conn, subject_reference=subject)
    finally:
        conn.close()
    assert evaluation.blocking_reason_code == rc.GOVERNED_RECORD_DELETION_FORBIDDEN


# --- lag, backpressure, readiness ------------------------------------------


def test_lag_is_read_from_the_live_broker_as_bands(runtime):
    for _ in range(3):
        harness.emit(
            runtime, "membership-service", MEMBERSHIP,
            harness.application_submitted(uuid.uuid4()),
        )
    harness.dispatch(runtime, "membership-service")

    reading = lag_module.read_lag(
        runtime.broker_for(), runtime.topics, now=datetime.now(timezone.utc)
    )
    assert set(reading.per_subscription) == {s.subscription_id for s in runtime.topics.subscriptions}
    for name, lag in reading.per_subscription.items():
        assert lag.lag_band in lag_module.BAND_ORDER
    body = reading.as_json()
    assert all(value in lag_module.BAND_ORDER for value in body.values())


def test_backpressure_pauses_a_subscription_whose_band_exceeds_its_ceiling(runtime):
    subscription = runtime.topics.subscription(PROJECTION)
    policy = OverloadPolicy()
    assert policy.apply(subscription, "none") is None
    assert policy.apply(subscription, "severe") == rc.BACKPRESSURE_APPLIED_RECORDED
    assert policy.is_paused(subscription.subscription_id)


def test_readiness_against_the_live_runtime_is_recorded(runtime):
    snapshot = runtime.readiness()
    assert snapshot.ready is True
    assert snapshot.blocking_reason_codes == ()
    assert snapshot.lineage_blocking_reason_codes == (rc.PREDECESSOR_NOT_ACCEPTED,)

    rows = harness.query("SELECT * FROM api04_gov.readiness_snapshot ORDER BY snapshot_reference")
    assert rows, "every readiness evaluation is recorded"
    assert rows[-1]["ready"] is True
    assert rows[-1]["signals"]["broker_version_pinned"] is True
    assert rows[-1]["signals"]["reconciliation_state"] == "PENDING_EXACT_ACCEPTED_API03"


def test_a_stale_projection_blocks_consequential_traffic_live(runtime):
    from epd2_events_messaging_runtime.persistence.postgres_stores import PostgresProjectionStore

    conn = db.connect(harness.POSTGRES_DSN)
    try:
        store = PostgresProjectionStore("projection", conn)
        harness.execute(
            "INSERT INTO dom_projection.projection_definition "
            "(projection_id, projection_name, applied_position, required_position) "
            "VALUES (%s,%s,1,9)",
            (uuid.uuid4(), "proj.stale.for.test"),
        )
        assert store.watermarks()["proj.stale.for.test"] == (1, 9)
        snapshot = runtime.readiness(conn)
    finally:
        conn.close()

    assert snapshot.ready is True
    assert snapshot.authoritatively_ready is False
    assert rc.PROJECTION_STALE in snapshot.consequential_blocking_reason_codes


# --- topology and permissions ----------------------------------------------


def test_the_live_topology_matches_the_register_in_both_directions(runtime):
    broker = runtime.broker_for()
    live_queues = set()
    for name in runtime.topics.declared_queues():
        broker.queue_depth(name)
        live_queues.add(name)
    assert runtime.topics.drift_against(
        {"exchanges": runtime.topics.declared_exchanges(), "queues": live_queues}
    ) == []


def test_a_service_principal_cannot_declare_a_queue(runtime):
    """`configure=^$`: a protected topic cannot come into existence by being
    used, and the broker refuses it independently of the ACL matrix."""
    from pika.exceptions import ChannelClosedByBroker

    broker = runtime.broker_for(role="service", service_id="membership-service")
    with pytest.raises(ChannelClosedByBroker) as excinfo:
        broker._require_channel().queue_declare(queue="q.invented.by.a.service", durable=True)
    assert excinfo.value.reply_code == 403
    harness.reset_transport(runtime)


def test_there_is_no_voting_virtual_host(runtime):
    listed = harness.broker_ctl("list_vhosts", "name")
    names = {line.strip() for line in listed.splitlines() if line.strip()}
    assert "epd2-api04" in names
    assert not [n for n in names if "vote" in n.lower() or "ballot" in n.lower()]
    assert runtime.topics.voting_plane_exists is False


def test_the_broker_reports_the_pinned_version(runtime):
    broker = runtime.broker_for()
    assert broker.reported_version() == "3.12.1"
    assert broker.assert_pinned_version() == "3.12.1"


# --- migrations -------------------------------------------------------------


def test_the_migration_state_is_complete_and_checksummed(runtime):
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        state = db.migration_state(conn)
    finally:
        conn.close()
    assert state["complete"] is True
    assert state["pending"] == [] and state["drifted"] == []
    assert len(state["defined"]) >= 8


def test_a_migration_that_changed_after_it_was_applied_has_no_repair_path(runtime, tmp_path):
    """The checksum is compared, and a mismatch raises. There is no `--force`
    here to find, which is the property being asserted."""
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        applied = harness.query(
            "SELECT migration_name FROM api04_gov.migration_applied ORDER BY migration_name"
        )
        name = applied[0]["migration_name"]
        (tmp_path / name).write_text("SELECT 1;\n", encoding="utf-8")
        with pytest.raises(MigrationChecksumMismatchError):
            db.apply_migrations(conn, tmp_path)
    finally:
        conn.close()

    assert not hasattr(db, "force_apply")
    assert "force" not in db.apply_migrations.__code__.co_varnames


def test_the_engine_is_the_governed_version(runtime):
    conn = db.connect(harness.POSTGRES_DSN)
    try:
        assert db.assert_engine(conn) == "16.15"
    finally:
        conn.close()


def test_every_record_this_runtime_writes_carries_its_retention_schedule(runtime):
    """A record with no retention schedule is a record nobody can dispose of.

    Both the outbox row and the quarantine row carry the schedule its topic
    declares, so retention is a property of the written evidence rather than of a
    policy document somebody has to remember to apply.
    """
    application_id = uuid.uuid4()
    event_id = harness.emit(
        runtime, "membership-service", MEMBERSHIP,
        harness.application_submitted(application_id),
    )
    topic = runtime.topics.topic(MEMBERSHIP)
    row = harness.outbox_row("membership", event_id)
    assert row["retention_schedule"]["schedule_name"] == topic.retention_schedule

    _quarantine_one(runtime)
    letter = harness.dead_letters(PROJECTION)[0]
    assert letter["retention_schedule"]["schedule_name"] == (
        topic.dead_letter_policy["retention_schedule"]
    )


def test_a_retention_schedule_reference_is_stable_across_runs(runtime):
    """The identifier is derived from the schedule's name, so two runs produce
    the same reference rather than a fresh one — a disposition record written
    today still names the same schedule tomorrow."""
    topic = runtime.topics.topic(MEMBERSHIP)
    assert topic.retention.schedule_id == topic.retention.schedule_id
    assert runtime.topics.topic(MEMBERSHIP).retention == topic.retention
    assert topic.retention.schedule_name == "domain-event-p365d"


def test_a_disposition_names_the_derived_copy_it_acted_on(runtime):
    """Every copy this stage creates is a `derived_copy_kind`, so a disposition
    says what it disposed of rather than gesturing at 'the record'."""
    subject = f"membership_application/{uuid.uuid4()}"
    for kind in ("outbox", "deduplication", "dead_letter", "broker_queue",
                 "projection", "replay_evidence"):
        harness.execute(
            "INSERT INTO api04_gov.disposition_record "
            "(disposition_reference, derived_copy_kind, subject_reference, action, "
            " reason_code, evidence) VALUES (%s,%s,%s,'not_applicable','READINESS_EVALUATED_RECORDED','{}'::jsonb)",
            (uuid.uuid4(), kind, subject),
        )
    rows = harness.query(
        "SELECT derived_copy_kind FROM api04_gov.disposition_record WHERE subject_reference = %s",
        (subject,),
    )
    assert len(rows) == 6
