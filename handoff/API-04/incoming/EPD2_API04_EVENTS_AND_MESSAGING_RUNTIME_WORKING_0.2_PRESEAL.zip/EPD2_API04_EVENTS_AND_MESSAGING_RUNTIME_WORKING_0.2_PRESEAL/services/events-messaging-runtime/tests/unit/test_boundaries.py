"""The structural guards, run as tests.

Each returns the list of violations it found. Empty is the only passing result,
and the guards are also exercised against a deliberately violating fixture so a
guard that silently stopped looking fails too.
"""

from __future__ import annotations

import pathlib
import textwrap

import pytest

from epd2_events_messaging_runtime.runtime import boundaries


def test_no_stronger_delivery_claim():
    assert boundaries.assert_no_stronger_delivery_claim() == []


def test_no_parallel_port():
    assert boundaries.assert_no_parallel_port() == []


def test_no_domain_decision():
    assert boundaries.assert_no_domain_decision() == []


def test_no_forward_scope():
    assert boundaries.assert_no_forward_scope() == []


def test_no_second_envelope():
    assert boundaries.assert_no_second_envelope() == []


@pytest.mark.parametrize(
    "source, guard",
    [
        ("# this runtime delivers each message exactly once\n",
         boundaries.assert_no_stronger_delivery_claim),
        ("class BrokerPort:\n    pass\n", boundaries.assert_no_parallel_port),
        ("class OutboxStore:\n    pass\n", boundaries.assert_no_parallel_port),
        ("def decide_eligibility():\n    pass\n", boundaries.assert_no_domain_decision),
        ("PROVIDER_GATEWAY = 1\n", boundaries.assert_no_forward_scope),
        ("class Api04EventEnvelope:\n    pass\n", boundaries.assert_no_second_envelope),
    ],
)
def test_guard_detects_its_own_violation(tmp_path: pathlib.Path, source: str, guard):
    (tmp_path / "offender.py").write_text(textwrap.dedent(source), encoding="utf-8")
    assert guard(tmp_path) != [], f"{guard.__name__} did not detect its own violation"


def test_the_permitted_new_ports_are_only_the_two_transport_seams():
    assert boundaries.PERMITTED_NEW_PORTS == frozenset(
        {"ConsumerTransportPort", "ServiceIdentityPort"}
    )
