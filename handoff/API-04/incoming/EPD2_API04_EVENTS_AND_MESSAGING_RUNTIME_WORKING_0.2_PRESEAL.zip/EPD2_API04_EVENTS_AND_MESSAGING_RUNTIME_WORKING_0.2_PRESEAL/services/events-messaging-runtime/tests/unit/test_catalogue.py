"""The canonical catalogue is read from the carried contracts, not restated."""

from __future__ import annotations

import hashlib
import json
import pathlib

import pytest

from epd2_events_messaging_runtime.exceptions import EventTypeNotInCanonicalCatalogueError
from epd2_events_messaging_runtime.topology.catalogue import load_canonical_catalogue

REPO_ROOT = pathlib.Path(__file__).resolve().parents[4]


@pytest.fixture(scope="module")
def catalogue():
    return load_canonical_catalogue(REPO_ROOT)


def test_the_catalogue_is_not_empty(catalogue):
    assert len(catalogue) >= 30


def test_every_entry_is_indexed_by_its_own_schema_title(catalogue):
    for event_type in catalogue.event_types():
        entry = catalogue.require(event_type)
        body = json.loads((REPO_ROOT / entry.payload_schema_path).read_text(encoding="utf-8"))
        assert body["title"].startswith(f"{event_type} event payload (v")


def test_digests_match_the_carried_bytes(catalogue):
    for event_type in catalogue.event_types():
        entry = catalogue.require(event_type)
        raw = (REPO_ROOT / entry.payload_schema_path).read_bytes()
        assert entry.payload_schema_sha256 == hashlib.sha256(raw).hexdigest()


def test_an_unknown_event_type_is_refused(catalogue):
    with pytest.raises(EventTypeNotInCanonicalCatalogueError) as excinfo:
        catalogue.require("api04.invented_event")
    assert excinfo.value.reason_code == "EVENT_TYPE_NOT_IN_CANONICAL_CATALOGUE"


def test_a_digest_mismatch_is_refused_with_the_canonical_code(catalogue):
    event_type = catalogue.event_types()[0]
    with pytest.raises(Exception) as excinfo:
        catalogue.assert_digest(event_type, "0" * 64)
    assert excinfo.value.reason_code == "SCHEMA_DIGEST_MISMATCH"


def test_api04_mints_no_event_type(catalogue):
    invented = [t for t in catalogue.event_types() if t.startswith(("api04", "api_04", "messaging."))]
    assert invented == []
