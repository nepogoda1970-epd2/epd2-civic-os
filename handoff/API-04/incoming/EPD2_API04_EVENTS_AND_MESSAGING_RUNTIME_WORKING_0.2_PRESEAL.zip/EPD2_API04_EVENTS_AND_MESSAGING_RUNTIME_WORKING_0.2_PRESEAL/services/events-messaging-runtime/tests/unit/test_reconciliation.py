"""The API-03 reconciliation is executable, and lineage stays frozen until it runs."""

from __future__ import annotations

import pytest

from epd2_events_messaging_runtime.exceptions import (
    AcceptedPredecessorClaimProhibitedError,
    PredecessorNotAcceptedError,
)
from epd2_events_messaging_runtime.identity import reconciliation as rec


def test_state_is_pending_without_an_exact_accepted_api03():
    assert rec.reconciliation_state(None) == "PENDING_EXACT_ACCEPTED_API03"
    assert rec.reconciliation_state("") == "PENDING_EXACT_ACCEPTED_API03"


def test_state_is_reconciled_only_with_an_exact_sha():
    assert rec.reconciliation_state("a" * 64) == "RECONCILED_AGAINST_EXACT_ACCEPTED_API03"


def test_lineage_cannot_be_frozen_before_the_accepted_predecessor():
    with pytest.raises(PredecessorNotAcceptedError) as excinfo:
        rec.assert_may_freeze_lineage(None)
    assert excinfo.value.reason_code == "PREDECESSOR_NOT_ACCEPTED"


def test_lineage_may_be_frozen_once_the_sha_is_bound():
    rec.assert_may_freeze_lineage("b" * 64)


def test_an_accepted_label_is_refused():
    with pytest.raises(AcceptedPredecessorClaimProhibitedError):
        rec.assert_label_is_not_accepted("API-03 ACCEPTED PREDECESSOR")
    rec.assert_label_is_not_accepted("WORKING_INTEGRATION_PREDECESSOR")


def test_identical_surfaces_produce_no_differences():
    assert rec.compare_surfaces(rec.CONSUMED_SURFACE, rec.CONSUMED_SURFACE) == []


def test_a_missing_member_is_reported():
    offered = {k: list(v) for k, v in rec.CONSUMED_SURFACE.items()}
    offered["Api03CredentialDirectory"].remove("revoke")
    rows = rec.compare_surfaces(rec.CONSUMED_SURFACE, offered)
    assert [r.kind for r in rows] == ["MEMBER_ABSENT"]
    assert rows[0].member == "revoke"


def test_a_missing_surface_is_reported():
    offered = {k: list(v) for k, v in rec.CONSUMED_SURFACE.items()}
    offered.pop("CredentialState")
    rows = rec.compare_surfaces(rec.CONSUMED_SURFACE, offered)
    assert any(r.kind == "SURFACE_ABSENT" and r.surface == "CredentialState" for r in rows)


def test_added_members_and_surfaces_are_reported_too():
    offered = {k: list(v) for k, v in rec.CONSUMED_SURFACE.items()}
    offered["Api03CredentialDirectory"].append("rotate")
    offered["Api03TokenIntrospection"] = ["introspect"]
    rows = rec.compare_surfaces(rec.CONSUMED_SURFACE, offered)
    kinds = {r.kind for r in rows}
    assert kinds == {"MEMBER_ADDED", "SURFACE_ADDED"}


def test_the_checklist_is_ordered_and_complete():
    assert len(rec.CHECKLIST) == 14
    for index, row in enumerate(rec.CHECKLIST, start=1):
        assert row.startswith(f"R-{index:02d} ")


def test_the_review_does_not_prove_list_names_acceptance_explicitly():
    joined = " ".join(rec.REVIEW_DOES_NOT_PROVE).lower()
    assert "accepted" in joined and "closed" in joined
