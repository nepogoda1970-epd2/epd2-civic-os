"""The producer/consumer matrix: an exact grant, or a refusal."""

from __future__ import annotations

import pathlib
from datetime import datetime, timedelta, timezone

import pytest

from epd2_events_messaging_runtime.exceptions import (
    ConsumerNotAuthorizedForSubscriptionError,
    MessagingAclClassificationMismatchError,
    MessagingAclWildcardProhibitedError,
    OrganizationScopeMismatchError,
    ProducerNotAuthorizedForTopicError,
    ServiceCredentialRevokedError,
)
from epd2_events_messaging_runtime.identity.port import (
    CredentialState,
    PrincipalClass,
    VerifiedServicePrincipal,
)
from epd2_events_messaging_runtime.topology.acl import AclMatrix, load_acl_matrix

REPO_ROOT = pathlib.Path(__file__).resolve().parents[4]
MATRIX = REPO_ROOT / "docs/api/API-04/API04_PRODUCER_CONSUMER_ACL_MATRIX.json"

NOW = datetime(2026, 8, 31, tzinfo=timezone.utc)


@pytest.fixture(scope="module")
def acl():
    return load_acl_matrix(MATRIX)


def principal(
    service_id: str,
    *,
    scopes=frozenset({"org:bund"}),
    classifications=frozenset({"internal", "restricted"}),
    state: CredentialState = CredentialState.ACTIVE,
    principal_class: PrincipalClass = PrincipalClass.SERVICE,
) -> VerifiedServicePrincipal:
    return VerifiedServicePrincipal(
        service_id=service_id,
        credential_id=f"cred-{service_id}",
        credential_state=state,
        principal_class=principal_class,
        organization_scopes=scopes,
        data_classifications=classifications,
        trust_anchor="api03:workload-mtls-intermediate",
        not_before=NOW - timedelta(days=1),
        not_after=NOW + timedelta(days=30),
        verified_at=NOW,
        source_boundary="API03_R13_WORKING_INTEGRATION_PREDECESSOR",
    )


def test_no_wildcard_row_can_be_loaded():
    for value in ("*", "*:*", "all", ""):
        document = {
            "service_principals": {},
            "produce_bindings": [
                {
                    "service_id": value, "topic_id": "t", "event_type": "e",
                    "event_versions": ["1.0"], "organization_scopes": ["org:bund"],
                    "data_classification": "internal",
                }
            ],
            "consume_bindings": [],
        }
        with pytest.raises(MessagingAclWildcardProhibitedError):
            AclMatrix(document)


def test_every_declared_binding_authorizes(acl):
    for binding in acl.produce_bindings:
        spec = acl.service_principals[binding.service_id]
        actor = principal(
            binding.service_id,
            scopes=frozenset(spec["organization_scopes"]),
            classifications=frozenset(spec["data_classifications"]),
        )
        for version in binding.event_versions:
            acl.authorize_publish(
                actor,
                topic_id=binding.topic_id,
                event_type=binding.event_type,
                event_version=version,
                organization_scope=sorted(binding.organization_scopes)[0],
                data_classification=binding.data_classification,
            )
    for binding in acl.consume_bindings:
        spec = acl.service_principals[binding.service_id]
        actor = principal(
            binding.service_id,
            scopes=frozenset(spec["organization_scopes"]),
            classifications=frozenset(spec["data_classifications"]),
        )
        for version in binding.event_versions:
            acl.authorize_consume(
                actor,
                subscription_id=binding.subscription_id,
                event_version=version,
                organization_scope=sorted(binding.organization_scopes)[0],
                data_classification=binding.data_classification,
            )


def test_a_principal_without_a_binding_is_refused(acl):
    binding = acl.produce_bindings[0]
    with pytest.raises(ProducerNotAuthorizedForTopicError):
        acl.authorize_publish(
            principal("audit-core"),
            topic_id=binding.topic_id,
            event_type=binding.event_type,
            event_version=sorted(binding.event_versions)[0],
            organization_scope="org:bund",
            data_classification=binding.data_classification,
        )


def test_an_unbound_event_version_is_refused(acl):
    binding = acl.produce_bindings[0]
    with pytest.raises(ProducerNotAuthorizedForTopicError):
        acl.authorize_publish(
            principal(binding.service_id),
            topic_id=binding.topic_id,
            event_type=binding.event_type,
            event_version="9.9",
            organization_scope="org:bund",
            data_classification=binding.data_classification,
        )


def test_an_unbound_event_type_is_refused(acl):
    binding = acl.produce_bindings[0]
    with pytest.raises(ProducerNotAuthorizedForTopicError):
        acl.authorize_publish(
            principal(binding.service_id),
            topic_id=binding.topic_id,
            event_type="membership.membership_activated",
            event_version=sorted(binding.event_versions)[0],
            organization_scope="org:bund",
            data_classification=binding.data_classification,
        )


def test_a_scope_outside_the_principal_is_refused(acl):
    binding = acl.produce_bindings[0]
    with pytest.raises(OrganizationScopeMismatchError):
        acl.authorize_publish(
            principal(binding.service_id, scopes=frozenset({"org:land"})),
            topic_id=binding.topic_id,
            event_type=binding.event_type,
            event_version=sorted(binding.event_versions)[0],
            organization_scope="org:bund",
            data_classification=binding.data_classification,
        )


def test_a_classification_mismatch_is_refused(acl):
    binding = acl.produce_bindings[0]
    presented = "restricted" if binding.data_classification != "restricted" else "internal"
    with pytest.raises(MessagingAclClassificationMismatchError):
        acl.authorize_publish(
            principal(binding.service_id),
            topic_id=binding.topic_id,
            event_type=binding.event_type,
            event_version=sorted(binding.event_versions)[0],
            organization_scope="org:bund",
            data_classification=presented,
        )


def test_a_principal_that_may_not_handle_the_classification_is_refused(acl):
    binding = acl.produce_bindings[0]
    with pytest.raises(MessagingAclClassificationMismatchError):
        acl.authorize_publish(
            principal(binding.service_id, classifications=frozenset({"public"})),
            topic_id=binding.topic_id,
            event_type=binding.event_type,
            event_version=sorted(binding.event_versions)[0],
            organization_scope="org:bund",
            data_classification=binding.data_classification,
        )


def test_a_revoked_credential_is_refused_before_the_binding_is_read(acl):
    binding = acl.produce_bindings[0]
    with pytest.raises(ServiceCredentialRevokedError):
        acl.authorize_publish(
            principal(binding.service_id, state=CredentialState.REVOKED),
            topic_id=binding.topic_id,
            event_type=binding.event_type,
            event_version=sorted(binding.event_versions)[0],
            organization_scope="org:bund",
            data_classification=binding.data_classification,
        )


def test_a_consumer_is_refused_on_a_subscription_it_does_not_hold(acl):
    binding = acl.consume_bindings[0]
    other = next(b for b in acl.consume_bindings if b.service_id != binding.service_id)
    with pytest.raises(ConsumerNotAuthorizedForSubscriptionError):
        acl.authorize_consume(
            principal(other.service_id),
            subscription_id=binding.subscription_id,
            event_version=sorted(binding.event_versions)[0],
            organization_scope="org:bund",
            data_classification=binding.data_classification,
        )


def test_the_matrix_agrees_with_the_topic_register(acl):
    from epd2_events_messaging_runtime.topology.catalogue import load_canonical_catalogue
    from epd2_events_messaging_runtime.topology.registry import load_topic_registry

    registry = load_topic_registry(
        REPO_ROOT / "docs/api/API-04/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json",
        catalogue=load_canonical_catalogue(REPO_ROOT),
    )
    produce = {(b.service_id, b.topic_id) for b in acl.produce_bindings}
    for topic in registry.topics:
        for service in topic.producer_services:
            assert (service, topic.topic_id) in produce

    consume = {(b.service_id, b.subscription_id) for b in acl.consume_bindings}
    for sub in registry.subscriptions:
        assert (sub.consumer_service, sub.subscription_id) in consume


def test_authorisation_versions_and_consumer_compatibility_are_two_different_facts():
    """A version the topic carries but this consumer cannot interpret must
    reach the compatibility layer and be dead-lettered as
    `EVENT_VERSION_UNSUPPORTED` — not be turned into an authorisation refusal,
    which would tell an operator to fix a grant rather than a consumer."""
    from epd2_events_messaging_runtime.topology.catalogue import load_canonical_catalogue
    from epd2_events_messaging_runtime.topology.registry import load_topic_registry

    acl = load_acl_matrix(MATRIX)
    registry = load_topic_registry(
        REPO_ROOT / "docs/api/API-04/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json",
        catalogue=load_canonical_catalogue(REPO_ROOT),
    )
    narrower = []
    for binding in acl.consume_bindings:
        topic = registry.topic(binding.topic_id)
        subscription = registry.subscription(binding.subscription_id)
        assert binding.event_versions == frozenset(topic.event_versions)
        if subscription.supported_event_versions < binding.event_versions:
            narrower.append(subscription.subscription_id)
    assert narrower, "the register must exercise at least one mixed-version window"

    subscription = registry.subscription(narrower[0])
    binding = next(b for b in acl.consume_bindings if b.subscription_id == subscription.subscription_id)
    unsupported = sorted(binding.event_versions - subscription.supported_event_versions)[0]
    spec = acl.service_principals[binding.service_id]
    acl.authorize_consume(
        principal(
            binding.service_id,
            scopes=frozenset(spec["organization_scopes"]),
            classifications=frozenset(spec["data_classifications"]),
        ),
        subscription_id=binding.subscription_id,
        event_version=unsupported,
        organization_scope="org:bund",
        data_classification=binding.data_classification,
    )
