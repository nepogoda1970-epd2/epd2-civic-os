"""The adversarial mutation catalogue and the harness that proves each is caught."""
