-- EPD2 API-04 migration 0005 — dead letters, governed re-drive and replay evidence, readiness snapshots
-- Kind: EXPAND. Immutable once applied: a checksum mismatch has no repair
-- path (MIGRATION_CHECKSUM_MISMATCH), exactly as PACK-13 requires.


CREATE TABLE IF NOT EXISTS api04_gov.dead_letter_record (
    dead_letter_id     uuid PRIMARY KEY,
    subscription_id    text NOT NULL,
    topic_id           text NOT NULL,
    event_id           uuid NOT NULL,
    event_type         text NOT NULL,
    reason_code        text NOT NULL,
    attempt_count      integer NOT NULL,
    failed_at          timestamptz NOT NULL,
    classification     jsonb NOT NULL,
    retention_schedule jsonb NOT NULL,
    review_required    boolean NOT NULL DEFAULT true,
    failure_reference  text,
    envelope_reference jsonb NOT NULL,
    payload_hash       text NOT NULL,
    payload_retained   boolean NOT NULL DEFAULT false,
    redriven           boolean NOT NULL DEFAULT false
);

CREATE TABLE IF NOT EXISTS api04_gov.redrive_record (
    redrive_reference    uuid PRIMARY KEY,
    dead_letter_id       uuid NOT NULL REFERENCES api04_gov.dead_letter_record (dead_letter_id),
    operator_principal   text NOT NULL,
    authority_reference  text NOT NULL,
    reason               text NOT NULL,
    target_subscription  text NOT NULL,
    intended_range       jsonb NOT NULL,
    schema_compatibility text NOT NULL,
    authorization_result text NOT NULL,
    state_result         text NOT NULL,
    performed_at         timestamptz NOT NULL DEFAULT now(),
    outcome_reason_code  text NOT NULL
);

CREATE TABLE IF NOT EXISTS api04_gov.replay_record (
    replay_reference     uuid PRIMARY KEY,
    replay_kind          text NOT NULL
                         CHECK (replay_kind IN ('exact_message','bounded_range',
                                                'projection_rebuild','selected_consumer')),
    topic_id             text NOT NULL,
    target_subscription  text,
    ordering_scope_key   text NOT NULL,
    from_sequence        bigint NOT NULL,
    to_sequence          bigint NOT NULL,
    operator_principal   text NOT NULL,
    authority_reference  text NOT NULL,
    grant_reference      text NOT NULL,
    reason_code          text NOT NULL,
    evidence_digest      text NOT NULL,
    schema_compatibility text NOT NULL,
    retention_check      text NOT NULL,
    legal_hold_check     text NOT NULL,
    authorization_result text NOT NULL,
    object_state_result  text NOT NULL,
    policy_version       text NOT NULL,
    history_preserved    boolean NOT NULL,
    performed_at         timestamptz NOT NULL DEFAULT now(),
    outcome_reason_code  text NOT NULL,
    message_count        integer NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS api04_gov.readiness_snapshot (
    snapshot_reference    uuid PRIMARY KEY,
    evaluated_at          timestamptz NOT NULL DEFAULT now(),
    ready                 boolean NOT NULL,
    authoritatively_ready boolean NOT NULL,
    blocking_reason_codes jsonb NOT NULL,
    signals               jsonb NOT NULL
);

CREATE TABLE IF NOT EXISTS api04_gov.legal_hold (
    hold_reference    text PRIMARY KEY,
    subject_kind      text NOT NULL,
    subject_reference text NOT NULL,
    active            boolean NOT NULL DEFAULT true,
    placed_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS api04_gov.disposition_record (
    disposition_reference uuid PRIMARY KEY,
    derived_copy_kind     text NOT NULL
                          CHECK (derived_copy_kind IN ('outbox','deduplication','dead_letter',
                                                       'broker_queue','projection','replay_evidence')),
    subject_reference     text NOT NULL,
    action                text NOT NULL CHECK (action IN ('purge','tombstone','blocked_by_hold','not_applicable')),
    reason_code           text NOT NULL,
    performed_at          timestamptz NOT NULL DEFAULT now(),
    evidence              jsonb NOT NULL
);

CREATE TABLE IF NOT EXISTS api04_gov.migration_applied (
    migration_name text PRIMARY KEY,
    checksum       text NOT NULL,
    applied_at     timestamptz NOT NULL DEFAULT now()
);
