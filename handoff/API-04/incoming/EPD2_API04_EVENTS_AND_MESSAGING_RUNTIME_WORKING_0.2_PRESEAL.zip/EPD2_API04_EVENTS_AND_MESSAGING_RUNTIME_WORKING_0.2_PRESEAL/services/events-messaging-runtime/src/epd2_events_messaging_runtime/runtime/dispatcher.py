"""The outbox dispatcher: a lease, PACK-13's decision, and a real broker.

Everything that *decides* here is PACK-13's. `decide_dispatch` decides whether
to dispatch, defer or dead-letter; `RetryPolicy` computes the next attempt;
`ReferenceDispatcher` performs the state transition and builds the delivery
attempt and the publication evidence. This module supplies the two things
PACK-13 left to a production adapter: a durable lease so several dispatchers can
run without doing each other's work, and a broker that is really there.

`assert_not_domain_connection` is the structural half of "no publish before
commit": the dispatcher refuses to run on the connection the domain
transaction is using, so an uncommitted row is invisible to it.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

import psycopg

from epd2_data_plane_service.delivery import (
    DispatchAction,
    ReferenceDispatcher,
    RetryPolicy,
    decide_dispatch,
)
from epd2_data_plane_service.domain import ClassificationReference
from epd2_data_plane_service.exceptions import BrokerUnavailableError
from epd2_data_plane_service.outbox import OutboxRecord, OutboxStatus

from .. import reason_codes as rc
from ..exceptions import MessagingRefusal
from ..identity.port import ServiceIdentityPort, TransportCredential
from ..persistence.postgres_stores import PostgresDeadLetterStore, PostgresOutboxStore
from ..topology.acl import AclMatrix
from ..topology.registry import Topic, TopicRegistry
from ..transport.rabbitmq import RabbitMqBroker


class PublishBeforeCommitRefused(MessagingRefusal):
    """The dispatcher was handed the domain transaction's own connection."""

    reason_code = rc.OUTBOX_PUBLICATION_PENDING


@dataclass
class DispatchOutcome:
    leased: int = 0
    reclaimed: int = 0
    published: int = 0
    acknowledged: int = 0
    acknowledgement_unknown: int = 0
    deferred: int = 0
    dead_lettered: int = 0
    refused: int = 0
    reason_codes: list[str] = field(default_factory=list)


def _stable_uuid(name: str) -> uuid.UUID:
    return uuid.uuid5(uuid.NAMESPACE_URL, f"https://epd2.example/api-04/{name}")


class OutboxDispatcher:
    def __init__(
        self,
        *,
        domain: str,
        store: PostgresOutboxStore,
        dead_letters: PostgresDeadLetterStore,
        connection: psycopg.Connection,
        broker: RabbitMqBroker,
        registry: TopicRegistry,
        acl: AclMatrix,
        identity: ServiceIdentityPort,
        producer_credential: TransportCredential,
        service_id: str,
        holder: str,
        lease_seconds: int = 30,
    ) -> None:
        self.domain = domain
        self.store = store
        self.dead_letters = dead_letters
        self.connection = connection
        self.broker = broker
        self.registry = registry
        self.acl = acl
        self.identity = identity
        self.producer_credential = producer_credential
        self.service_id = service_id
        self.holder = holder
        self.lease_seconds = lease_seconds
        self.healthy = True

    def assert_not_domain_connection(self, domain_connection: psycopg.Connection) -> None:
        if domain_connection is self.connection:
            raise PublishBeforeCommitRefused(
                "the dispatcher must not share the domain transaction's connection",
                detail={"domain": self.domain},
            )

    def _policy(self, topic: Topic) -> RetryPolicy:
        return RetryPolicy(
            max_attempts=int(topic.retry_policy["max_attempts"]),
            initial_backoff=timedelta(milliseconds=int(topic.retry_policy["initial_backoff_ms"])),
            backoff_multiplier=int(topic.retry_policy["backoff_multiplier"]),
        )

    def reconnect_if_needed(self) -> bool:
        """A supervised dispatcher reattaches when the broker comes back.

        It does not fail the loop when it cannot: the records stay leased or
        deferred, and `healthy` carries the fact into readiness."""
        if self.broker.is_connected():
            return True
        try:
            self.broker.connect()
            self.broker.assert_pinned_version()
        except (BrokerUnavailableError, MessagingRefusal):
            self.healthy = False
            return False
        self.healthy = True
        return True

    def run_once(self, *, batch_size: int = 16, now: datetime | None = None) -> DispatchOutcome:
        now = now or datetime.now(timezone.utc)
        outcome = DispatchOutcome()
        self.reconnect_if_needed()
        outcome.reclaimed = self.store.reclaim_expired_leases()
        if outcome.reclaimed:
            outcome.reason_codes.append(rc.DISPATCH_LEASE_RECLAIMED_RECORDED)

        batch = self.store.lease_batch(
            holder=self.holder, batch_size=batch_size, lease_seconds=self.lease_seconds
        )
        outcome.leased = len(batch)
        if not batch:
            return outcome

        principal = self.identity.verify(self.producer_credential, purpose=f"dispatch:{self.domain}")

        for record in batch:
            topic = self.registry.topic(record.event_type)
            try:
                self.acl.authorize_publish(
                    principal,
                    topic_id=topic.topic_id,
                    event_type=record.event_type,
                    event_version=record.event_version,
                    organization_scope=self._scope_label(record),
                    data_classification=topic.data_classification,
                )
            except MessagingRefusal as refusal:
                outcome.refused += 1
                outcome.reason_codes.append(refusal.reason_code)
                self._dead_letter(record, topic, refusal.reason_code, now, outcome)
                continue

            self.broker.bind_partitioning(topic.partitions)
            dispatcher = ReferenceDispatcher(
                self.broker, destination=topic.destination, policy=self._policy(topic)
            )
            broker_available = self.broker.is_connected()
            try:
                result = dispatcher.dispatch(
                    record,
                    now=now,
                    broker_available=broker_available,
                    classification=self._classification(topic),
                    retention_schedule=topic.retention,
                    dead_letter_id=_stable_uuid(f"dead-letter/{record.event_id}"),
                )
            except BrokerUnavailableError:
                self.healthy = False
                outcome.reason_codes.append(rc.BROKER_UNAVAILABLE)
                self._defer(record, topic, now, outcome)
                continue

            if result.decision.action is DispatchAction.DEFER:
                outcome.deferred += 1
                # PACK-13's own reason for deferring, carried through rather
                # than replaced: an operator reading the outcome sees *why* the
                # batch did not go out, not merely that a retry was scheduled.
                if result.decision.reason_code:
                    outcome.reason_codes.append(result.decision.reason_code)
                self._defer(record, topic, now, outcome, decision_next=result.decision.next_attempt_at)
                continue

            self.store.update_delivery_state(result.record)
            if result.dead_letter is not None:
                self.dead_letters.append(
                    result.dead_letter,
                    subscription_id="",
                    topic_id=topic.topic_id,
                    envelope_reference=self._minimised(record),
                    payload_hash=record.envelope.integrity.payload_hash,
                )
                outcome.dead_lettered += 1
                outcome.reason_codes.append(result.dead_letter.reason_code)
            elif result.record.status is OutboxStatus.ACKNOWLEDGED:
                outcome.published += 1
                outcome.acknowledged += 1
            elif result.record.status is OutboxStatus.PUBLISHED:
                # Published, acknowledgement unknown. Not an error and not a
                # success: the record keeps its published status as the fact it
                # is, and is scheduled for another attempt so the delivery
                # guarantee does not quietly depend on a confirmation that never
                # arrived. Any duplicate this produces is absorbed downstream.
                outcome.published += 1
                outcome.acknowledgement_unknown += 1
                outcome.reason_codes.append(rc.DELIVERY_ACKNOWLEDGEMENT_MISSING)
                # `published -> failed` is one of PACK-13's declared transitions
                # for exactly this case, and `with_status` is what proves it is
                # declared. The publication evidence stays on the record, so the
                # fact that a publish was emitted without a confirmation is not
                # lost by re-attempting it.
                requeued = result.record.with_status(OutboxStatus.FAILED)
                self.store.update_delivery_state(requeued)
                self.store.defer(
                    requeued.outbox_record_id,
                    next_attempt_at=self._policy(topic).next_attempt_at(
                        attempt_number=requeued.attempt_count + 1, now=now
                    ),
                    status=OutboxStatus.FAILED,
                )
            self.connection.commit()
        return outcome

    # -- helpers ------------------------------------------------------------
    @staticmethod
    def _scope_label(record: OutboxRecord) -> str:
        return f"org:{record.scope.scope_kind.value}"

    @staticmethod
    def _classification(topic: Topic) -> ClassificationReference:
        return ClassificationReference(
            classification_id=_stable_uuid(f"classification/{topic.data_classification}"),
            tier=topic.data_classification,
        )

    @staticmethod
    def _minimised(record: OutboxRecord) -> dict[str, Any]:
        """Reference fields only. The payload never enters quarantine evidence
        from here; the topic's own dead-letter policy decides whether a
        minimised copy is retained, and restricted topics say no."""
        envelope = record.envelope
        return {
            "event_id": str(envelope.event_id),
            "event_type": envelope.event_type,
            "event_version": envelope.event_version,
            "producer": envelope.producer,
            "occurred_at": envelope.occurred_at.isoformat(),
            "correlation_id": str(envelope.correlation_id),
            "payload_hash": envelope.integrity.payload_hash,
            "sequence_number": record.sequence_number,
        }

    def _defer(
        self, record: OutboxRecord, topic: Topic, now: datetime,
        outcome: DispatchOutcome, decision_next: datetime | None = None,
    ) -> None:
        policy = self._policy(topic)
        next_at = decision_next or policy.next_attempt_at(
            attempt_number=record.attempt_count + 1, now=now
        )
        self.store.defer(record.outbox_record_id, next_attempt_at=next_at, status=OutboxStatus.FAILED)
        self.connection.commit()
        outcome.reason_codes.append(rc.RETRY_SCHEDULED_RECORDED)

    def _dead_letter(
        self, record: OutboxRecord, topic: Topic, reason_code: str,
        now: datetime, outcome: DispatchOutcome,
    ) -> None:
        from epd2_data_plane_service.delivery import DeadLetterRecord

        moved = record
        if moved.status is OutboxStatus.PENDING:
            moved = moved.with_status(OutboxStatus.DISPATCHING)
        moved = moved.with_status(OutboxStatus.DEAD_LETTERED)
        self.store.update_delivery_state(moved)
        self.dead_letters.append(
            DeadLetterRecord(
                dead_letter_id=_stable_uuid(f"dead-letter/{record.event_id}"),
                event_id=record.event_id,
                event_type=record.event_type,
                reason_code=reason_code,
                attempt_count=record.attempt_count,
                failed_at=now,
                classification=self._classification(topic),
                retention_schedule=topic.retention,
            ),
            subscription_id="",
            topic_id=topic.topic_id,
            envelope_reference=self._minimised(record),
            payload_hash=record.envelope.integrity.payload_hash,
        )
        self.connection.commit()
        outcome.dead_lettered += 1
