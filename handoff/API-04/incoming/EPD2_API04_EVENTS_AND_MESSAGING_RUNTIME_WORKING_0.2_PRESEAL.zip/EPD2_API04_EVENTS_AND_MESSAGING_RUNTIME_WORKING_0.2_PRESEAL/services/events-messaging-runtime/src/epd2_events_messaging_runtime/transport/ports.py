"""The transport seams.

`epd2_data_plane_service.delivery.BrokerPort` is PACK-13's and is used
unchanged: one method, `publish(record, destination)`, returning the broker's
own acknowledgement reference or `None` when the acknowledgement is unknown.
API-04 defines no second publishing port.

What API-04 does add is the other direction. PACK-13 has no consumer transport
at all — its `ReferenceConsumer` is handed a record, not a delivery — because it
models no wire. `ConsumerTransportPort` is therefore additive rather than a
re-implementation, and it is deliberately small: pull a bounded batch,
acknowledge, or abandon without acknowledging.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class DeliveredMessage:
    """One delivery off the wire.

    `envelope` is the canonical envelope exactly as it was published — payload
    and integrity included, because the canon puts them there. `headers` is
    transport metadata and never merges into the envelope.
    """

    queue: str
    partition: int
    delivery_tag: int
    redelivered: bool
    envelope: Mapping[str, Any]
    headers: Mapping[str, Any]

    @property
    def transport_attempt(self) -> int:
        return int(self.headers.get("x-epd2-attempt") or self.headers.get("x-delivery-count") or 0)


class ConsumerTransportPort(ABC):
    """Pull-side transport. Bounded by construction: a caller asks for at most
    `max_messages` and the adapter holds at most one unacknowledged delivery."""

    @abstractmethod
    def pull(self, *, queue: str, partition: int, max_messages: int) -> list[DeliveredMessage]: ...

    @abstractmethod
    def acknowledge(self, message: DeliveredMessage) -> None: ...

    @abstractmethod
    def abandon_without_acknowledgement(self) -> None:
        """Model a consumer that dies mid-flight: the connection goes away and
        the broker redelivers. Used by the failure fixtures; never by production
        wiring."""

    @abstractmethod
    def republish(
        self, *, exchange: str, routing_key: str, envelope: Mapping[str, Any],
        headers: Mapping[str, Any],
    ) -> str: ...

    @abstractmethod
    def queue_depth(self, queue: str) -> int: ...
