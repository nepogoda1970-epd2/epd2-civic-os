"""Governed replay, built on PACK-13's own replay vocabulary.

`ReplayReference` is PACK-13's, and it is bounded by construction: it carries
`from_sequence`, `to_sequence`, a `PrivilegedGrantReference`, an
`EvidenceReference` and a reason code, so an unbounded replay is not a thing the
type can express. `replay_preserves_history` is PACK-13's too, and it is what
makes "replay repeats history, it does not rewrite it" checkable rather than
asserted.

What API-04 adds is the set of checks a *transport* replay needs before a single
message moves, and the record of all of them:

1. schema compatibility of the historical version against what the consumer
   accepts now;
2. the retention horizon — outside it, refused, not truncated;
3. legal hold;
4. disposition history — a purged or tombstoned subject does not come back;
5. **current** authorization, not the authorization that existed at origin;
6. current object state and policy version, with an explicit re-interpretation
   refusal when the policy has moved and the topic does not permit re-evaluation.

Every replay writes its evaluation, whether it proceeded or not. A refused
replay records `message_count = 0`, and the emit callback is never reached.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Callable, Sequence

import psycopg

from epd2_data_plane_service.delivery import ReplayReference, replay_preserves_history
from epd2_data_plane_service.exceptions import (
    EventReplayNotAuthorizedError,
    RecordUnderLegalHoldError,
)
from epd2_data_plane_service.outbox import OutboxRecord

from .. import reason_codes as rc
from ..exceptions import (
    ReplayRangeUnboundedProhibitedError,
    ReplayReinterpretationProhibitedError,
)

REPLAY_KINDS = ("exact_message", "bounded_range", "projection_rebuild", "selected_consumer")


@dataclass(frozen=True, slots=True)
class ReplayRequest:
    kind: str
    topic_id: str
    reference: ReplayReference
    target_subscription: str | None = None
    policy_version: str = ""

    def validate(self) -> None:
        if self.kind not in REPLAY_KINDS:
            raise EventReplayNotAuthorizedError(f"unknown replay kind {self.kind!r}")
        if self.reference.to_sequence < self.reference.from_sequence:
            raise ReplayRangeUnboundedProhibitedError(
                "the replay range is empty or inverted",
                detail={"kind": self.kind},
            )
        if self.kind == "exact_message" and self.reference.to_sequence != self.reference.from_sequence:
            raise ReplayRangeUnboundedProhibitedError(
                "an exact-message replay names exactly one sequence position",
                detail={"kind": self.kind},
            )


@dataclass(frozen=True, slots=True)
class ReplayEvaluation:
    schema_compatibility: str
    retention_check: str
    legal_hold_check: str
    authorization_result: str
    object_state_result: str
    history_preserved: bool
    blocking_reason_code: str | None


def evaluate_replay(
    connection: psycopg.Connection,
    request: ReplayRequest,
    *,
    origin_occurred_at: datetime,
    retention_horizon: timedelta,
    now: datetime,
    schema_compatibility: str,
    subject_reference: str,
    origin_policy_version: str,
    current_policy_version: str,
    reinterpretation_permitted: bool,
    authorization_result: str,
    object_state_result: str,
    original: Sequence[OutboxRecord] = (),
    replayed: Sequence[OutboxRecord] = (),
) -> ReplayEvaluation:
    request.validate()
    blocking: str | None = None

    retention = "within_horizon"
    if now - origin_occurred_at > retention_horizon:
        retention = "outside_horizon"
        blocking = rc.EVENT_REPLAY_NOT_AUTHORIZED

    with connection.cursor() as cur:
        cur.execute(
            "SELECT bool_or(active) AS held FROM api04_gov.legal_hold WHERE subject_reference = %s",
            (subject_reference,),
        )
        row = cur.fetchone()
    held = bool(row and row["held"])
    legal_hold = "hold_active" if held else "no_hold"
    if held and blocking is None:
        blocking = rc.RECORD_UNDER_LEGAL_HOLD

    with connection.cursor() as cur:
        cur.execute(
            "SELECT count(*) AS n FROM api04_gov.disposition_record "
            "WHERE subject_reference = %s AND action IN ('purge','tombstone')",
            (subject_reference,),
        )
        row = cur.fetchone()
    if row and int(row["n"]) and blocking is None:
        blocking = rc.GOVERNED_RECORD_DELETION_FORBIDDEN

    if schema_compatibility != "compatible" and blocking is None:
        blocking = rc.SCHEMA_INCOMPATIBLE

    if origin_policy_version != current_policy_version and not reinterpretation_permitted:
        if blocking is None:
            blocking = rc.REPLAY_REINTERPRETATION_PROHIBITED

    if authorization_result != "authorized" and blocking is None:
        blocking = rc.CONCURRENCY_AUTHORITY_LAPSED

    if object_state_result not in ("current", "not_applicable") and blocking is None:
        blocking = rc.CONCURRENCY_STALE_AGGREGATE_VERSION

    preserved = replay_preserves_history(list(original), list(replayed)) if original else True
    if not preserved and blocking is None:
        blocking = rc.EVENT_REPLAY_NOT_AUTHORIZED

    return ReplayEvaluation(
        schema_compatibility=schema_compatibility,
        retention_check=retention,
        legal_hold_check=legal_hold,
        authorization_result=authorization_result,
        object_state_result=object_state_result,
        history_preserved=preserved,
        blocking_reason_code=blocking,
    )


def perform_replay(
    connection: psycopg.Connection,
    request: ReplayRequest,
    evaluation: ReplayEvaluation,
    *,
    current_policy_version: str,
    emit: Callable[[], int],
) -> uuid.UUID:
    reference = uuid.uuid4()
    outcome = evaluation.blocking_reason_code or rc.REPLAY_RECORDED
    count = emit() if evaluation.blocking_reason_code is None else 0

    replay = request.reference
    with connection.cursor() as cur:
        cur.execute(
            """
            INSERT INTO api04_gov.replay_record (
                replay_reference, replay_kind, topic_id, target_subscription, ordering_scope_key,
                from_sequence, to_sequence, operator_principal, authority_reference,
                grant_reference, reason_code, evidence_digest, schema_compatibility,
                retention_check, legal_hold_check, authorization_result, object_state_result,
                policy_version, history_preserved, outcome_reason_code, message_count
            ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """,
            (
                reference, request.kind, request.topic_id, request.target_subscription,
                replay.ordering_scope_key, replay.from_sequence, replay.to_sequence,
                str(replay.requested_by.actor_id), replay.requested_by.acting_domain.domain_name,
                str(replay.grant.grant_id), replay.reason_code, replay.evidence.content_digest,
                evaluation.schema_compatibility, evaluation.retention_check,
                evaluation.legal_hold_check, evaluation.authorization_result,
                evaluation.object_state_result, current_policy_version,
                evaluation.history_preserved, outcome, count,
            ),
        )
    connection.commit()

    if evaluation.blocking_reason_code:
        raise EventReplayNotAuthorizedError(
            f"replay refused with {evaluation.blocking_reason_code}; the evaluation is "
            f"recorded as {reference}"
        )
    return reference
