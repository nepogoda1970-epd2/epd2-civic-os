"""Transport-layer privacy. The payload half is PACK-13's; only the wire half is new.

PACK-13 already decides which payload keys may exist:
``epd2_data_plane_service.domain.reject_prohibited_payload_keys`` refuses secret
material, global person correlation keys, voting material and bulk content, with
a distinct reason code for each. This module **calls it** rather than keeping a
second list, and that choice fixes a real defect in the earlier round: a local
list had blanket-prohibited ``account_id``, which the canonical
``GLOBAL_IDENTITY_KEYS`` deliberately does not, because FIR-ID-001 names the IAM
account identifier as a legitimate *domain-local* class and prohibits only the
universal one. Three canonical event families declare ``account_id``; a blanket
ban would have refused all three.

What is genuinely new here is the layer PACK-13 has no reason to model, because
PACK-13 has no transport: **infrastructure correlation metadata**. An address, an
ASN, a TLS session id, a CDN or WAF request id, a proxy id, a device fingerprint
— FIR-VOTE-NET-001 exists because application-layer unlinkability is not
infrastructure-layer unlinkability, and a broker header is exactly where that
metadata would otherwise ride along.
"""

from __future__ import annotations

import re
from typing import Any, Iterable, Mapping

from epd2_data_plane_service.domain import (
    GLOBAL_IDENTITY_KEYS,
    PROHIBITED_PAYLOAD_KEYS,
    SECRET_PAYLOAD_KEYS,
    VOTING_MATERIAL_KEYS,
    reject_prohibited_payload_keys,
)

#: Infrastructure correlation metadata. PACK-13 models none of this because it
#: has no wire; API-04 does, so it must refuse it (FIR-VOTE-NET-001, FIR-OPS-001).
NETWORK_CORRELATION_KEYS: frozenset[str] = frozenset(
    {
        "ip",
        "ip_address",
        "client_ip",
        "remote_addr",
        "remote_address",
        "x_forwarded_for",
        "forwarded_for",
        "asn",
        "source_asn",
        "user_agent",
        "tls_session_id",
        "tls_fingerprint",
        "ja3",
        "ja4",
        "cdn_request_id",
        "waf_request_id",
        "edge_request_id",
        "proxy_id",
        "load_balancer_id",
        "device_fingerprint",
        "browser_fingerprint",
        "client_port",
        "source_port",
    }
)

#: Value shapes that are credentials whatever key they sit under.
_SECRET_VALUE_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"^Bearer\s+[A-Za-z0-9._~+/=-]{16,}$", re.IGNORECASE),
    re.compile(r"^Basic\s+[A-Za-z0-9+/=]{16,}$", re.IGNORECASE),
    re.compile(r"^eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}$"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"^(amqp|amqps|postgres|postgresql)://[^:]+:[^@]+@", re.IGNORECASE),
)

#: The governed shape of a request-scoped correlation reference used in a
#: transport header. The canonical envelope's own ``correlation_id`` is a UUID
#: and is governed there; this is the *header* form.
_REQUEST_SCOPED = re.compile(r"^req-[0-9a-f]{32}$")


def _normalise(key: object) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(key).lower()).strip("_")


def _walk(obj: Any, path: str = "") -> Iterable[tuple[str, str, Any]]:
    if isinstance(obj, Mapping):
        for key, value in obj.items():
            here = f"{path}.{key}" if path else str(key)
            yield here, _normalise(key), value
            yield from _walk(value, here)
    elif isinstance(obj, (list, tuple, set, frozenset)):
        for index, value in enumerate(obj):
            yield from _walk(value, f"{path}[{index}]")


def find_network_correlation_keys(obj: Any) -> list[str]:
    return [path for path, key, _ in _walk(obj) if key in NETWORK_CORRELATION_KEYS]


def find_secret_material(obj: Any) -> list[str]:
    found: list[str] = []
    for path, key, value in _walk(obj):
        if key in SECRET_PAYLOAD_KEYS:
            found.append(path)
            continue
        if isinstance(value, str) and any(p.search(value) for p in _SECRET_VALUE_PATTERNS):
            found.append(path)
    return found


def find_global_identity_keys(obj: Any) -> list[str]:
    return [path for path, key, _ in _walk(obj) if key in GLOBAL_IDENTITY_KEYS]


# --- assertions ------------------------------------------------------------


def assert_payload_admissible(payload: Any, *, context: str) -> None:
    """PACK-13's own payload gate, unchanged, called before anything is written."""
    reject_prohibited_payload_keys(payload, context=context)


def assert_no_network_correlation(obj: Any, *, context: str) -> None:
    from ..exceptions import NetworkCorrelationMetadataProhibitedError

    offenders = find_network_correlation_keys(obj)
    if offenders:
        raise NetworkCorrelationMetadataProhibitedError(
            f"{context} carries infrastructure correlation metadata",
            detail={"context": context, "field_count": len(offenders)},
        )


def assert_evidence_safe(obj: Any, *, context: str) -> None:
    """The single gate every durable evidence record and every refusal passes.

    Called from ``MessagingRefusal.__init__``, so an unsafe refusal cannot be
    constructed; and from the dead-letter writer and the re-drive/replay
    recorders. It raises. It never redacts, because a silent redaction hides the
    defect that produced it.
    """
    from ..exceptions import (
        GlobalUserIdentifierProhibitedError,
        NetworkCorrelationMetadataProhibitedError,
        PayloadNotMinimalError,
    )

    secrets = find_secret_material(obj)
    if secrets:
        raise PayloadNotMinimalError(
            f"{context}: evidence must not carry secret material; "
            f"{len(secrets)} offending field(s)"
        )
    identity = find_global_identity_keys(obj)
    if identity:
        raise GlobalUserIdentifierProhibitedError(
            f"{context}: a cross-domain person correlation key is prohibited; "
            f"forbidden key(s): {sorted(identity)}"
        )
    network = find_network_correlation_keys(obj)
    if network:
        raise NetworkCorrelationMetadataProhibitedError(
            f"{context} carries infrastructure correlation metadata",
            detail={"context": context, "field_count": len(network)},
        )


def assert_no_voting_material(obj: Any, *, context: str) -> None:
    """API-04 has no voting plane; voting material cannot enter it at all."""
    from ..exceptions import VotingMaterialProhibitedError

    offenders = sorted({key for _, key, _ in _walk(obj)} & VOTING_MATERIAL_KEYS)
    if offenders:
        raise VotingMaterialProhibitedError(
            f"{context}: voting material is prohibited on the API-04 plane; "
            f"forbidden key(s): {offenders}"
        )


def assert_correlation_header_request_scoped(value: str | None, *, context: str) -> None:
    from ..exceptions import CorrelationReferenceNotRequestScopedError

    if value is None:
        return
    if not _REQUEST_SCOPED.match(value):
        raise CorrelationReferenceNotRequestScopedError(
            f"{context} correlation header is not request-scoped",
            detail={"context": context},
        )


#: Re-exported so callers do not build a second list.
PROHIBITED_PAYLOAD_KEYS = PROHIBITED_PAYLOAD_KEYS
