"""FIR-TIME-001 — the runtime's governed time.

Three things "time" would otherwise conflate, kept apart:

``occurred_at``   a producer wall-clock assertion, carried as evidence of what
                  the producer believed and never read as an order. Ordering is
                  `sequence_number` and PACK-13's `assess_ordering`; there is no
                  code path here that sorts by `occurred_at`.
elapsed duration  leases and backoff, from a monotonic source, so a wall-clock
                  rollback cannot revive an expired lease.
decision time     the basis for a deadline or a retention horizon. Losing trust
                  fails consequential decisions closed rather than silently
                  using the local clock.
"""

from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone

from ..exceptions import MessagingRuntimeNotReadyError


class TimeAuthority:
    def __init__(self, *, max_skew: timedelta = timedelta(seconds=5)) -> None:
        self._max_skew = max_skew
        self._trusted = True

    def now_utc(self) -> datetime:
        return datetime.now(timezone.utc)

    def monotonic(self) -> float:
        return time.monotonic()

    @property
    def trusted(self) -> bool:
        return self._trusted

    def lose_trust(self) -> None:
        self._trusted = False

    def restore_trust(self) -> None:
        self._trusted = True

    def require_trusted(self, purpose: str) -> datetime:
        if not self._trusted:
            raise MessagingRuntimeNotReadyError(
                f"trusted time is required for {purpose}; the runtime fails closed rather than "
                f"using an untrusted local clock",
                detail={"purpose": purpose},
            )
        return self.now_utc()
