"""PostgreSQL adapters for the PACK-13 storage ports.

This is what API-04 is: the production half of the ports PACK-13 defined and
left with in-memory reference implementations. Each class below satisfies one
`Protocol` from `epd2_data_plane_service.storage`, keeps its shape, and adds
nothing to it except what a real database requires — a connection, and, for the
outbox, the leasing a real dispatcher needs.

Two rules hold throughout.

**No store commits.** The caller owns the transaction, because that is the only
way a domain effect and its outbox record — or a consumer effect and its
deduplication marker — can be atomic without claiming a distributed transaction
this runtime does not implement. The two lease methods are the single exception
and they say so.

**Ownership is enforced, not documented.** `DomainOwnedStore._require_owner` is
PACK-13's, reused unchanged, so a cross-domain write raises PACK-13's own
`CrossDomainDirectAccessDeniedError` before the SQL is built. The database's
per-domain roles refuse it a second time, at the privilege level.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Mapping, Sequence

import psycopg

from epd2_data_plane_service.concurrency import AggregateVersion
from epd2_data_plane_service.delivery import ConsumerCheckpoint, DeadLetterRecord
from epd2_data_plane_service.domain import (
    AggregateReference,
    DomainReference,
    OrganizationScopeReference,
)
from epd2_data_plane_service.exceptions import RecordNotFoundError
from epd2_data_plane_service.idempotency import (
    DeduplicationRecord,
    IdempotencyKey,
    IdempotencyRecord,
    IdempotencyScope,
    OperationClass,
)
from epd2_data_plane_service.outbox import OutboxRecord, OutboxStatus
from epd2_data_plane_service.projections import ProjectedRow, ProjectionDefinition
from epd2_data_plane_service.storage import DomainOwnedStore

from . import codec

Json = psycopg.types.json.Jsonb


# ---------------------------------------------------------------------------
# Outbox
# ---------------------------------------------------------------------------


class PostgresOutboxStore(DomainOwnedStore):
    """`epd2_data_plane_service.storage.OutboxStore`, on PostgreSQL."""

    def __init__(self, owning_domain: DomainReference, connection: psycopg.Connection) -> None:
        super().__init__(owning_domain)
        self._conn = connection
        self._table = f"dom_{owning_domain.domain_name}.outbox_record"

    # -- protocol -----------------------------------------------------------
    def append(self, record: OutboxRecord, *, writing_domain: DomainReference) -> None:
        self._require_owner(writing_domain, what="an outbox record")
        row = codec.outbox_record_to_row(record)
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {self._table} (
                    outbox_record_id, event_id, event_type, event_version, envelope, aggregate,
                    scope, created_at, status, sequence_number, attempts, publication_evidence,
                    retention_schedule, under_legal_hold, payload_hash
                ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (event_id) DO NOTHING
                """,
                (
                    row["outbox_record_id"], row["event_id"], row["event_type"], row["event_version"],
                    Json(row["envelope"]), Json(row["aggregate"]), Json(row["scope"]),
                    row["created_at"], row["status"], row["sequence_number"],
                    Json(row["attempts"]), Json(row["publication_evidence"]),
                    Json(row["retention_schedule"]), row["under_legal_hold"], row["payload_hash"],
                ),
            )

    def update_delivery_state(self, record: OutboxRecord) -> None:
        row = codec.outbox_record_to_row(record)
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                UPDATE {self._table}
                SET status = %s, attempts = %s, publication_evidence = %s,
                    under_legal_hold = %s,
                    lease_id = NULL, lease_holder = NULL, lease_expires_at = NULL
                WHERE outbox_record_id = %s
                """,
                (row["status"], Json(row["attempts"]), Json(row["publication_evidence"]),
                 row["under_legal_hold"], row["outbox_record_id"]),
            )

    def by_id(self, outbox_record_id: uuid.UUID) -> OutboxRecord:
        with self._conn.cursor() as cur:
            cur.execute(f"SELECT * FROM {self._table} WHERE outbox_record_id = %s", (outbox_record_id,))
            row = cur.fetchone()
        if row is None:
            raise RecordNotFoundError(f"no outbox record {outbox_record_id}")
        return codec.outbox_record_from_row(row)

    def pending(self, *, scope: OrganizationScopeReference) -> tuple[OutboxRecord, ...]:
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT * FROM {self._table}
                WHERE status IN ('pending','failed') AND scope->>'organization_id' = %s
                ORDER BY created_at
                """,
                (str(scope.organization_id),),
            )
            rows = cur.fetchall()
        return tuple(codec.outbox_record_from_row(r) for r in rows)

    # -- adapter additions a real dispatcher needs --------------------------
    def by_event_id(self, event_id: uuid.UUID) -> OutboxRecord | None:
        with self._conn.cursor() as cur:
            cur.execute(f"SELECT * FROM {self._table} WHERE event_id = %s", (event_id,))
            row = cur.fetchone()
        return codec.outbox_record_from_row(row) if row else None

    def lease_batch(self, *, holder: str, batch_size: int, lease_seconds: int) -> tuple[OutboxRecord, ...]:
        """Claim dispatchable records. Commits: a lease that is not visible to the
        other dispatchers is not a lease."""
        lease_id = uuid.uuid4()
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                WITH candidate AS (
                    SELECT outbox_record_id FROM {self._table}
                    -- A record another dispatcher holds a live lease on is not
                    -- a candidate. `FOR UPDATE SKIP LOCKED` alone would not say
                    -- this: the lease is committed, so its row lock is long
                    -- gone and a second dispatcher would happily take the work.
                    -- The lease is the durable claim; the row lock only keeps
                    -- two dispatchers from racing inside this one statement.
                    --
                    -- 'failed' includes a record whose acknowledgement never
                    -- arrived: P13-DEL-007 makes ACKNOWLEDGEMENT_UNKNOWN neither
                    -- success nor failure, so the dispatcher moves it along the
                    -- declared published -> failed transition and it is
                    -- re-attempted here rather than assumed delivered.
                    WHERE (lease_expires_at IS NULL OR lease_expires_at < now())
                      AND ((status IN ('pending','failed') AND next_attempt_at <= now())
                        OR (lease_expires_at IS NOT NULL AND lease_expires_at < now()))
                      AND status NOT IN ('acknowledged','dead_lettered','superseded_by_replay')
                    ORDER BY created_at
                    FOR UPDATE SKIP LOCKED
                    LIMIT %s
                )
                UPDATE {self._table} o
                SET lease_id = %s, lease_holder = %s,
                    lease_expires_at = now() + make_interval(secs => %s)
                FROM candidate c
                WHERE o.outbox_record_id = c.outbox_record_id
                RETURNING o.*
                """,
                (batch_size, lease_id, holder, lease_seconds),
            )
            rows = cur.fetchall()
        self._conn.commit()
        return tuple(codec.outbox_record_from_row(r) for r in rows)

    def reclaim_expired_leases(self) -> int:
        """Return leases whose holder died to the dispatchable pool. Commits."""
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                UPDATE {self._table}
                SET lease_id = NULL, lease_holder = NULL, lease_expires_at = NULL
                WHERE lease_expires_at IS NOT NULL AND lease_expires_at < now()
                """
            )
            count = cur.rowcount
        self._conn.commit()
        return count

    def defer(self, outbox_record_id: uuid.UUID, *, next_attempt_at: datetime, status: OutboxStatus) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                UPDATE {self._table}
                SET next_attempt_at = %s, status = %s,
                    lease_id = NULL, lease_holder = NULL, lease_expires_at = NULL
                WHERE outbox_record_id = %s
                """,
                (next_attempt_at, status.value, outbox_record_id),
            )

    def unacknowledged_age(self) -> timedelta | None:
        with self._conn.cursor() as cur:
            cur.execute(
                f"SELECT min(created_at) AS oldest FROM {self._table} WHERE status <> 'acknowledged'"
            )
            row = cur.fetchone()
        if not row or row["oldest"] is None:
            return None
        from datetime import timezone

        return datetime.now(timezone.utc) - row["oldest"]

    def count_by_status(self) -> dict[str, int]:
        with self._conn.cursor() as cur:
            cur.execute(f"SELECT status, count(*) AS n FROM {self._table} GROUP BY status")
            return {r["status"]: int(r["n"]) for r in cur.fetchall()}


# ---------------------------------------------------------------------------
# Aggregate versions
# ---------------------------------------------------------------------------


class PostgresAggregateVersionStore(DomainOwnedStore):
    """`storage.AggregateVersionStore`, on PostgreSQL."""

    def __init__(self, owning_domain: DomainReference, connection: psycopg.Connection) -> None:
        super().__init__(owning_domain)
        self._conn = connection
        self._table = f"dom_{owning_domain.domain_name}.aggregate_version"

    def current(self, aggregate: AggregateReference) -> AggregateVersion:
        with self._conn.cursor() as cur:
            cur.execute(
                f"SELECT version FROM {self._table} WHERE aggregate_type = %s AND aggregate_id = %s FOR UPDATE",
                (aggregate.aggregate_type, aggregate.aggregate_id),
            )
            row = cur.fetchone()
        return AggregateVersion(aggregate=aggregate, version=int(row["version"]) if row else 0)

    def commit(self, version: AggregateVersion, *, writing_domain: DomainReference) -> AggregateVersion:
        self._require_owner(writing_domain, what="an aggregate version")
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {self._table} (aggregate_type, aggregate_id, owning_domain, version)
                VALUES (%s,%s,%s,%s)
                ON CONFLICT (aggregate_type, aggregate_id)
                DO UPDATE SET version = EXCLUDED.version, updated_at = now()
                """,
                (
                    version.aggregate.aggregate_type,
                    version.aggregate.aggregate_id,
                    version.aggregate.owning_domain.domain_name,
                    version.version,
                ),
            )
        return version


# ---------------------------------------------------------------------------
# Idempotency (command side)
# ---------------------------------------------------------------------------


class PostgresIdempotencyStore:
    """`storage.IdempotencyStore`, on PostgreSQL."""

    def __init__(self, domain: str, connection: psycopg.Connection) -> None:
        self._conn = connection
        self._table = f"dom_{domain}.idempotency_record"

    def find(self, key: IdempotencyKey) -> IdempotencyRecord | None:
        with self._conn.cursor() as cur:
            cur.execute(f"SELECT * FROM {self._table} WHERE qualified_key = %s", (key.qualified_key,))
            row = cur.fetchone()
        if row is None:
            return None
        return IdempotencyRecord(
            key=key,
            request_digest=row["request_digest"],
            result_reference=row["result_reference"],
            recorded_at=row["recorded_at"],
            expires_at=row["expires_at"],
        )

    def put(self, record: IdempotencyRecord) -> None:
        scope = record.key.scope
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {self._table} (
                    qualified_key, domain_name, operation_name, operation_class, key_value,
                    organization_id, scope_kind, request_digest, result_reference,
                    recorded_at, expires_at
                ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (qualified_key) DO UPDATE
                    SET request_digest = EXCLUDED.request_digest,
                        result_reference = EXCLUDED.result_reference,
                        expires_at = EXCLUDED.expires_at
                """,
                (
                    record.key.qualified_key, scope.domain_name, scope.operation_name,
                    scope.operation_class.value, record.key.key_value,
                    scope.organization_scope.organization_id if scope.organization_scope else None,
                    scope.organization_scope.scope_kind.value if scope.organization_scope else None,
                    record.request_digest, record.result_reference,
                    record.recorded_at, record.expires_at,
                ),
            )


# ---------------------------------------------------------------------------
# Consumer checkpoints
# ---------------------------------------------------------------------------


class PostgresConsumerCheckpointStore:
    """`storage.ConsumerCheckpointStore`, on PostgreSQL.

    `latest` raises `RecordNotFoundError` when no checkpoint exists, exactly as
    the in-memory reference does: "no checkpoint" is not "position zero", and a
    consumer that treats it as zero would silently reprocess history.
    """

    def __init__(self, domain: str, connection: psycopg.Connection) -> None:
        self._conn = connection
        self._table = f"dom_{domain}.consumer_checkpoint"

    def save(self, checkpoint: ConsumerCheckpoint) -> None:
        row = codec.checkpoint_to_row(checkpoint)
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {self._table}
                    (consumer_name, consumer_domain, ordering_scope_key, position, updated_at)
                VALUES (%s,%s,%s,%s,%s)
                ON CONFLICT (consumer_name, ordering_scope_key)
                DO UPDATE SET position = EXCLUDED.position, updated_at = EXCLUDED.updated_at
                """,
                (row["consumer_name"], row["consumer_domain"], row["ordering_scope_key"],
                 row["position"], row["updated_at"]),
            )

    def latest(self, *, consumer_name: str, ordering_scope_key: str) -> ConsumerCheckpoint:
        with self._conn.cursor() as cur:
            cur.execute(
                f"SELECT * FROM {self._table} WHERE consumer_name = %s AND ordering_scope_key = %s FOR UPDATE",
                (consumer_name, ordering_scope_key),
            )
            row = cur.fetchone()
        if row is None:
            raise RecordNotFoundError(
                f"no checkpoint for consumer {consumer_name!r} in scope {ordering_scope_key!r}"
            )
        return codec.checkpoint_from_row(row)

    def latest_or_start(
        self, *, consumer_name: str, consumer_domain: str, ordering_scope_key: str, now: datetime
    ) -> ConsumerCheckpoint:
        """Adapter helper: the governed way to begin a scope, written down once
        instead of at every call site."""
        try:
            return self.latest(consumer_name=consumer_name, ordering_scope_key=ordering_scope_key)
        except RecordNotFoundError:
            return ConsumerCheckpoint(
                consumer_name=consumer_name,
                consumer_domain=consumer_domain,
                ordering_scope_key=ordering_scope_key,
                position=0,
                updated_at=now,
            )


# ---------------------------------------------------------------------------
# Deduplication (consumer side) — durable, where PACK-13's reference is a dict
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class DeduplicationOutcome:
    record: DeduplicationRecord
    first_observation: bool
    completed: bool
    effect_reference: str | None
    effect_result: Mapping[str, Any] | None


class PostgresDeduplicationStore:
    """Durable consumer deduplication.

    `ReferenceConsumer` keeps `_seen` in a process dictionary — appropriate for a
    reference implementation, and exactly the thing a production adapter has to
    replace: a guarantee that lasts as long as a process is not a guarantee, and
    two workers racing on a redelivery would each believe they were first.

    Uniqueness is a primary key. The race is lost in the storage engine.
    """

    def __init__(self, domain: str, connection: psycopg.Connection) -> None:
        self._conn = connection
        self._table = f"dom_{domain}.deduplication_record"

    def observe(
        self,
        *,
        consumer_name: str,
        consumer_domain: str,
        event_id: uuid.UUID,
        payload_hash: str,
        now: datetime,
        expires_at: datetime,
    ) -> DeduplicationOutcome:
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {self._table}
                    (consumer_domain, consumer_name, event_id, first_seen_at,
                     observation_count, payload_hash, expires_at)
                VALUES (%s,%s,%s,%s,1,%s,%s)
                ON CONFLICT (consumer_domain, consumer_name, event_id) DO UPDATE
                    SET observation_count = {self._table.split('.')[-1]}.observation_count + 1
                RETURNING first_seen_at, observation_count, payload_hash, effect_reference,
                          effect_result, reason_code, (xmax = 0) AS inserted
                """,
                (consumer_domain, consumer_name, event_id, now, payload_hash, expires_at),
            )
            row = cur.fetchone()
        assert row is not None
        if row["payload_hash"] != payload_hash:
            from epd2_data_plane_service.exceptions import (
                IdempotencyKeyReusedWithDifferentPayloadError,
            )

            raise IdempotencyKeyReusedWithDifferentPayloadError(
                f"event {event_id} was already observed by {consumer_name!r} with a different "
                f"payload hash; the same identity with different bytes is a conflict, not a duplicate"
            )
        record = DeduplicationRecord(
            consumer_name=consumer_name,
            consumer_domain=consumer_domain,
            event_id=event_id,
            first_seen_at=row["first_seen_at"],
            observation_count=int(row["observation_count"]),
        )
        return DeduplicationOutcome(
            record=record,
            first_observation=bool(row["inserted"]),
            completed=row["effect_reference"] is not None,
            effect_reference=row["effect_reference"],
            effect_result=row["effect_result"],
        )

    def complete(
        self,
        *,
        consumer_name: str,
        consumer_domain: str,
        event_id: uuid.UUID,
        effect_reference: str,
        effect_result: Mapping[str, Any],
        reason_code: str,
    ) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                UPDATE {self._table}
                SET effect_reference = %s, effect_result = %s, reason_code = %s
                WHERE consumer_domain = %s AND consumer_name = %s AND event_id = %s
                """,
                (effect_reference, Json(dict(effect_result)), reason_code,
                 consumer_domain, consumer_name, event_id),
            )

    def horizon_covers(self, *, deduplication_horizon: timedelta, replay_horizon: timedelta,
                       subscription_id: str) -> None:
        from ..exceptions import DeduplicationHorizonTooShortError

        if deduplication_horizon < replay_horizon:
            raise DeduplicationHorizonTooShortError(
                "deduplication would expire before the replay horizon",
                detail={"subscription_id": subscription_id,
                        "dedup_days": deduplication_horizon.days,
                        "replay_days": replay_horizon.days},
            )


# ---------------------------------------------------------------------------
# Dead letters
# ---------------------------------------------------------------------------


class PostgresDeadLetterStore:
    """`storage.DeadLetterStore`, on PostgreSQL, plus the quarantine evidence
    API-04 attaches to it: which subscription, which topic, the minimised
    envelope reference and the payload hash."""

    def __init__(self, connection: psycopg.Connection) -> None:
        self._conn = connection

    def append(self, record: DeadLetterRecord, *, subscription_id: str = "", topic_id: str = "",
               envelope_reference: Mapping[str, Any] | None = None, payload_hash: str = "",
               payload_retained: bool = False) -> None:
        from ..runtime import privacy

        reference = dict(envelope_reference or {})
        privacy.assert_evidence_safe(reference, context=f"dead letter {subscription_id}")
        row = codec.dead_letter_to_row(record)
        with self._conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO api04_gov.dead_letter_record (
                    dead_letter_id, subscription_id, topic_id, event_id, event_type, reason_code,
                    attempt_count, failed_at, classification, retention_schedule, review_required,
                    failure_reference, envelope_reference, payload_hash, payload_retained
                ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (dead_letter_id) DO NOTHING
                """,
                (row["dead_letter_id"], subscription_id, topic_id, row["event_id"], row["event_type"],
                 row["reason_code"], row["attempt_count"], row["failed_at"],
                 Json(row["classification"]), Json(row["retention_schedule"]),
                 row["review_required"], row["failure_reference"], Json(reference),
                 payload_hash, payload_retained),
            )

    def by_id(self, dead_letter_id: uuid.UUID) -> DeadLetterRecord:
        with self._conn.cursor() as cur:
            cur.execute("SELECT * FROM api04_gov.dead_letter_record WHERE dead_letter_id = %s",
                        (dead_letter_id,))
            row = cur.fetchone()
        if row is None:
            raise RecordNotFoundError(f"no dead letter {dead_letter_id}")
        return codec.dead_letter_from_row(row)

    def awaiting_review(self) -> tuple[uuid.UUID, ...]:
        with self._conn.cursor() as cur:
            cur.execute(
                "SELECT dead_letter_id FROM api04_gov.dead_letter_record "
                "WHERE review_required AND NOT redriven ORDER BY failed_at"
            )
            return tuple(r["dead_letter_id"] for r in cur.fetchall())

    def raw(self, dead_letter_id: uuid.UUID) -> dict[str, Any]:
        with self._conn.cursor() as cur:
            cur.execute("SELECT * FROM api04_gov.dead_letter_record WHERE dead_letter_id = %s FOR UPDATE",
                        (dead_letter_id,))
            row = cur.fetchone()
        if row is None:
            raise RecordNotFoundError(f"no dead letter {dead_letter_id}")
        return dict(row)

    def open_count(self, subscription_id: str | None = None) -> int:
        with self._conn.cursor() as cur:
            if subscription_id:
                cur.execute(
                    "SELECT count(*) AS n FROM api04_gov.dead_letter_record "
                    "WHERE NOT redriven AND subscription_id = %s", (subscription_id,))
            else:
                cur.execute("SELECT count(*) AS n FROM api04_gov.dead_letter_record WHERE NOT redriven")
            row = cur.fetchone()
        return int(row["n"]) if row else 0

    def mark_redriven(self, dead_letter_id: uuid.UUID) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                "UPDATE api04_gov.dead_letter_record SET redriven = true WHERE dead_letter_id = %s",
                (dead_letter_id,),
            )


# ---------------------------------------------------------------------------
# Projections
# ---------------------------------------------------------------------------


class PostgresProjectionStore:
    """`storage.ProjectionStore`, on PostgreSQL, plus the watermark a
    consequential read has to consult."""

    def __init__(self, domain: str, connection: psycopg.Connection) -> None:
        self._conn = connection
        self._definitions = f"dom_{domain}.projection_definition"
        self._rows = f"dom_{domain}.projection_row"

    def declare(self, definition: ProjectionDefinition) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {self._definitions} (projection_id, projection_name)
                VALUES (%s,%s) ON CONFLICT (projection_id) DO NOTHING
                """,
                (definition.projection_id, definition.projection_name),
            )

    def upsert_row(self, row: ProjectedRow) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {self._rows}
                    (projection_id, row_key, organization_id, scope_kind, row_version, body)
                VALUES (%s,%s,%s,%s,%s,%s)
                ON CONFLICT (projection_id, row_key) DO UPDATE
                    SET row_version = EXCLUDED.row_version, body = EXCLUDED.body,
                        updated_at = now()
                    WHERE {self._rows.split('.')[-1]}.row_version <= EXCLUDED.row_version
                """,
                (row.projection_id, row.row_key, row.scope.organization_id,
                 row.scope.scope_kind.value, row.row_version, Json(dict(row.body))),
            )

    def rows(self, projection_id: uuid.UUID, *, scope: OrganizationScopeReference) -> tuple[dict[str, Any], ...]:
        with self._conn.cursor() as cur:
            cur.execute(
                f"SELECT * FROM {self._rows} WHERE projection_id = %s AND organization_id = %s "
                f"AND NOT tombstoned",
                (projection_id, scope.organization_id),
            )
            return tuple(dict(r) for r in cur.fetchall())

    def tombstone_row(self, projection_id: uuid.UUID, row_key: str) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                f"UPDATE {self._rows} SET tombstoned = true, updated_at = now() "
                f"WHERE projection_id = %s AND row_key = %s",
                (projection_id, row_key),
            )

    # -- watermark ----------------------------------------------------------
    def advance(self, projection_name: str, *, by: int = 1) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {self._definitions} (projection_id, projection_name, applied_position)
                VALUES (%s,%s,%s)
                ON CONFLICT (projection_name) DO UPDATE
                    SET applied_position = {self._definitions.split('.')[-1]}.applied_position + %s,
                        updated_at = now()
                """,
                (uuid.uuid5(uuid.NAMESPACE_URL, projection_name), projection_name, by, by),
            )

    def set_required_position(self, projection_name: str, position: int) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {self._definitions} (projection_id, projection_name, required_position)
                VALUES (%s,%s,%s)
                ON CONFLICT (projection_name) DO UPDATE
                    SET required_position = EXCLUDED.required_position, updated_at = now()
                """,
                (uuid.uuid5(uuid.NAMESPACE_URL, projection_name), projection_name, position),
            )

    def watermarks(self) -> dict[str, tuple[int, int]]:
        with self._conn.cursor() as cur:
            cur.execute(f"SELECT projection_name, applied_position, required_position FROM {self._definitions}")
            return {r["projection_name"]: (int(r["applied_position"]), int(r["required_position"]))
                    for r in cur.fetchall()}

    def require_fresh(self, projection_name: str) -> int:
        """A consequential read never uses a projection that is behind."""
        from epd2_data_plane_service.exceptions import ProjectionStaleError

        marks = self.watermarks()
        if projection_name not in marks:
            raise ProjectionStaleError(
                f"no watermark exists for projection {projection_name!r}; absence is not freshness"
            )
        applied, required = marks[projection_name]
        if applied < required:
            raise ProjectionStaleError(
                f"projection {projection_name!r} is at {applied}, behind the required {required}; "
                f"a consequential read does not use it"
            )
        return applied


def idempotency_key(
    *, domain: str, operation: str, operation_class: OperationClass, key_value: str,
    scope: OrganizationScopeReference | None = None,
) -> IdempotencyKey:
    return IdempotencyKey(
        scope=IdempotencyScope(
            domain_name=domain, operation_name=operation,
            operation_class=operation_class, organization_scope=scope,
        ),
        key_value=key_value,
    )
