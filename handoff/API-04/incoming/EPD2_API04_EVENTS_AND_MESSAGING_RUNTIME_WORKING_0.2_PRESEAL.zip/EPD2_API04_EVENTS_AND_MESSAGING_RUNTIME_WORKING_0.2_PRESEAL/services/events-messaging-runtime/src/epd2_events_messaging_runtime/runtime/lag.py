"""Consumer lag, reported as a band.

PACK-13 reports lag as a **band** and not as an exact figure, for the reason
`P13-EVT-009` gives: an exact figure across organizations is itself information.
This module uses `lag_band_for` and `ConsumerLag` unchanged and never exposes the
raw count outside the band it maps to — which is a correction to an earlier
round of this runtime that reported exact per-subscription counts.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Mapping

from epd2_data_plane_service.delivery import LAG_BANDS, ConsumerLag, lag_band_for

from ..topology.registry import TopicRegistry
from ..transport.rabbitmq import RabbitMqBroker, partition_queue

#: Band order, worst last. A ceiling is "this band or better".
BAND_ORDER: tuple[str, ...] = tuple(LAG_BANDS)


@dataclass(frozen=True, slots=True)
class LagReading:
    per_subscription: Mapping[str, ConsumerLag]
    ceilings: Mapping[str, str]
    breached: tuple[str, ...]

    def as_json(self) -> dict[str, str]:
        return {name: lag.lag_band for name, lag in self.per_subscription.items()}


def band_exceeds(observed: str, ceiling: str) -> bool:
    return BAND_ORDER.index(observed) > BAND_ORDER.index(ceiling)


def read_lag(broker: RabbitMqBroker, registry: TopicRegistry, *, now: datetime) -> LagReading:
    per: dict[str, ConsumerLag] = {}
    ceilings: dict[str, str] = {}
    for sub in registry.subscriptions:
        topic = registry.topic(sub.topic_id)
        behind = 0
        for partition in range(topic.partitions):
            try:
                behind += broker.queue_depth(partition_queue(sub.queue, partition))
            except Exception:
                # a queue that is not declared is not zero lag; it is NOT READY,
                # and readiness reports it as a topology problem rather than here
                continue
        scope_key = f"{sub.subscription_id}"
        per[sub.subscription_id] = ConsumerLag(
            consumer_name=sub.subscription_id,
            ordering_scope_key=scope_key,
            lag_band=lag_band_for(behind),
            observed_at=now,
        )
        ceilings[sub.subscription_id] = sub.lag_band_ceiling
    breached = tuple(
        name for name, lag in per.items() if band_exceeds(lag.lag_band, ceilings[name])
    )
    return LagReading(per_subscription=per, ceilings=ceilings, breached=breached)
