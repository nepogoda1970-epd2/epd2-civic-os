"""Structural boundary guards, asserted over this service's own sources.

These are tests that happen to live in the source tree, not documentation. The
unit suite runs each of them over `epd2_events_messaging_runtime`, so a property
that stops being true fails as a test rather than as prose.

``assert_no_stronger_delivery_claim``
    PACK-13's phrase scan, inherited. The contract is *at-least-once delivery
    with an effectively-once consumer effect*; the stronger unqualified phrase
    appears nowhere outside the sentence forbidding it.

``assert_no_parallel_port``
    the guard this round exists for. API-04 must implement PACK-13's ports, not
    define its own: a class named `BrokerPort`, `OutboxStore`, `IdempotencyStore`
    or any other `*Store` **defined** in this package is a re-implementation, and
    the only permitted transport port is the consumer side PACK-13 does not have.

``assert_no_domain_decision`` / ``assert_no_forward_scope``
    the messaging layer decides no domain question, and carries no API-05 logic.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Iterable

PACKAGE_ROOT = Path(__file__).resolve().parent.parent

#: The forbidden phrase, split so this file does not contain it either.
_FORBIDDEN_DELIVERY_PHRASE = "exactly" + " " + "once"

_ALLOWED_PHRASE_CONTEXT = (
    "forbidden", "must not", "never", "refus", "prohibit", "not claimed",
    "appears nowhere", "the stronger", "_FORBIDDEN_DELIVERY_PHRASE", "not strengthened",
)

#: Names PACK-13 already defines. Defining one here would be a parallel port.
CANONICAL_PORT_NAMES = frozenset(
    {
        "BrokerPort", "OutboxStore", "OutboxRecord", "OutboxWriter", "OutboxStatus",
        "IdempotencyStore", "IdempotencyKey", "IdempotencyPolicy", "IdempotencyRecord",
        "ConsumerCheckpointStore", "ConsumerCheckpoint", "DeadLetterStore", "DeadLetterRecord",
        "AggregateVersionStore", "ProjectionStore", "SchemaVersionStore",
        "ConsumerRegistrationStore", "AppliedMigrationStore", "BackfillCheckpointStore",
        "RetryPolicy", "OrderingScope", "OrderingScopeKind", "OrderingAssessment",
        "ReplayReference", "ConsumerLag", "DeduplicationRecord", "SchemaVersion",
        "CompatibilityMode", "EventEnvelope", "ActorRef", "SubjectRef", "EventIntegrity",
        "DestinationReference", "BrokerAcknowledgementReference", "DeliveryAttempt",
        "PublicationEvidence", "AggregateVersion", "UnitOfWorkReference", "TransactionBoundary",
    }
)

#: The one transport seam PACK-13 has no equivalent for.
PERMITTED_NEW_PORTS = frozenset({"ConsumerTransportPort", "ServiceIdentityPort"})

DOMAIN_DECISION_VERBS = (
    "decide_eligibility", "grant_membership", "approve_payment_amount", "compute_tally",
    "resolve_conflict_of_interest", "assign_mandate_powers", "determine_voting_right",
    "adjudicate_case",
)

FORWARD_SCOPE_MARKERS = ("api-05", "api05", "provider_gateway", "vendor_callback")


def _sources(root: Path | None = None) -> Iterable[Path]:
    return sorted((root or PACKAGE_ROOT).rglob("*.py"))


def assert_no_stronger_delivery_claim(root: Path | None = None) -> list[str]:
    problems: list[str] = []
    for path in _sources(root):
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            lowered = line.lower()
            if _FORBIDDEN_DELIVERY_PHRASE in lowered and not any(
                token in lowered for token in _ALLOWED_PHRASE_CONTEXT
            ):
                problems.append(f"{path.name}:{number}: unqualified delivery claim")
    return problems


def assert_no_parallel_port(root: Path | None = None) -> list[str]:
    """A canonical port name **defined** in this package is a re-implementation."""
    problems: list[str] = []
    for path in _sources(root):
        if path.name == "boundaries.py":
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name in CANONICAL_PORT_NAMES:
                if node.name in PERMITTED_NEW_PORTS:
                    continue
                problems.append(
                    f"{path.name}:{node.lineno}: {node.name} is a PACK-13 name defined here"
                )
    return problems


def assert_no_domain_decision(root: Path | None = None) -> list[str]:
    problems: list[str] = []
    for path in _sources(root):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name in DOMAIN_DECISION_VERBS:
                    problems.append(f"{path.name}:{node.lineno}: domain decision {node.name}")
    return problems


def assert_no_forward_scope(root: Path | None = None) -> list[str]:
    problems: list[str] = []
    pattern = re.compile("|".join(FORWARD_SCOPE_MARKERS), re.IGNORECASE)
    for path in _sources(root):
        if path.name == "boundaries.py":
            continue
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if pattern.search(line):
                problems.append(f"{path.name}:{number}: forward-scope marker")
    return problems


def assert_no_second_envelope(root: Path | None = None) -> list[str]:
    """There is exactly one envelope, and it is `epd2_core`'s."""
    problems: list[str] = []
    for path in _sources(root):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and "Envelope" in node.name:
                problems.append(f"{path.name}:{node.lineno}: {node.name} defines an envelope type")
    return problems
