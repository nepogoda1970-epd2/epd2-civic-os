-- EPD2 API-04 migration 0008 — per-domain least-privilege roles, enforced by the server
-- Kind: EXPAND. Immutable once applied: a checksum mismatch has no repair
-- path (MIGRATION_CHECKSUM_MISMATCH), exactly as PACK-13 requires.
--
-- A domain role writes its own schema and reads no other domain's tables. The
-- refusal in the evidence is a server refusal: revoking the privilege is what makes
-- the write fail (DATAPLANE_CROSS_DOMAIN_DIRECT_ACCESS_DENIED).


DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'api04_audit') THEN
        CREATE ROLE api04_audit LOGIN PASSWORD NULL;
    END IF;
END $$;
REVOKE ALL ON SCHEMA dom_audit FROM PUBLIC;
GRANT USAGE ON SCHEMA dom_audit TO api04_audit;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA dom_audit TO api04_audit;
GRANT USAGE ON SCHEMA api04_gov TO api04_audit;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA api04_gov TO api04_audit;
GRANT UPDATE ON api04_gov.dead_letter_record TO api04_audit;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'api04_casework') THEN
        CREATE ROLE api04_casework LOGIN PASSWORD NULL;
    END IF;
END $$;
REVOKE ALL ON SCHEMA dom_casework FROM PUBLIC;
GRANT USAGE ON SCHEMA dom_casework TO api04_casework;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA dom_casework TO api04_casework;
GRANT USAGE ON SCHEMA api04_gov TO api04_casework;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA api04_gov TO api04_casework;
GRANT UPDATE ON api04_gov.dead_letter_record TO api04_casework;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'api04_compliance') THEN
        CREATE ROLE api04_compliance LOGIN PASSWORD NULL;
    END IF;
END $$;
REVOKE ALL ON SCHEMA dom_compliance FROM PUBLIC;
GRANT USAGE ON SCHEMA dom_compliance TO api04_compliance;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA dom_compliance TO api04_compliance;
GRANT USAGE ON SCHEMA api04_gov TO api04_compliance;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA api04_gov TO api04_compliance;
GRANT UPDATE ON api04_gov.dead_letter_record TO api04_compliance;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'api04_governance') THEN
        CREATE ROLE api04_governance LOGIN PASSWORD NULL;
    END IF;
END $$;
REVOKE ALL ON SCHEMA dom_governance FROM PUBLIC;
GRANT USAGE ON SCHEMA dom_governance TO api04_governance;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA dom_governance TO api04_governance;
GRANT USAGE ON SCHEMA api04_gov TO api04_governance;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA api04_gov TO api04_governance;
GRANT UPDATE ON api04_gov.dead_letter_record TO api04_governance;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'api04_membership') THEN
        CREATE ROLE api04_membership LOGIN PASSWORD NULL;
    END IF;
END $$;
REVOKE ALL ON SCHEMA dom_membership FROM PUBLIC;
GRANT USAGE ON SCHEMA dom_membership TO api04_membership;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA dom_membership TO api04_membership;
GRANT USAGE ON SCHEMA api04_gov TO api04_membership;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA api04_gov TO api04_membership;
GRANT UPDATE ON api04_gov.dead_letter_record TO api04_membership;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'api04_notification') THEN
        CREATE ROLE api04_notification LOGIN PASSWORD NULL;
    END IF;
END $$;
REVOKE ALL ON SCHEMA dom_notification FROM PUBLIC;
GRANT USAGE ON SCHEMA dom_notification TO api04_notification;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA dom_notification TO api04_notification;
GRANT USAGE ON SCHEMA api04_gov TO api04_notification;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA api04_gov TO api04_notification;
GRANT UPDATE ON api04_gov.dead_letter_record TO api04_notification;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'api04_organization') THEN
        CREATE ROLE api04_organization LOGIN PASSWORD NULL;
    END IF;
END $$;
REVOKE ALL ON SCHEMA dom_organization FROM PUBLIC;
GRANT USAGE ON SCHEMA dom_organization TO api04_organization;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA dom_organization TO api04_organization;
GRANT USAGE ON SCHEMA api04_gov TO api04_organization;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA api04_gov TO api04_organization;
GRANT UPDATE ON api04_gov.dead_letter_record TO api04_organization;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'api04_projection') THEN
        CREATE ROLE api04_projection LOGIN PASSWORD NULL;
    END IF;
END $$;
REVOKE ALL ON SCHEMA dom_projection FROM PUBLIC;
GRANT USAGE ON SCHEMA dom_projection TO api04_projection;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA dom_projection TO api04_projection;
GRANT USAGE ON SCHEMA api04_gov TO api04_projection;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA api04_gov TO api04_projection;
GRANT UPDATE ON api04_gov.dead_letter_record TO api04_projection;

-- No GRANT above names another domain's schema. That absence is the control.

