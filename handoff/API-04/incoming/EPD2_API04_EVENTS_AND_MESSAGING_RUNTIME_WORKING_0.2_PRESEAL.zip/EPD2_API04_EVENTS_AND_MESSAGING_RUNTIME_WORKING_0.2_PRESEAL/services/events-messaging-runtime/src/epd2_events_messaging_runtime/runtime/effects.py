"""Consumer effects: owned by their domain, invoked by the messaging runtime.

Each function writes one domain table inside the transaction the consumer opened
for the deduplication marker. None of them decides anything. The consequential
ones receive a `CommitAuthorityBasis` that `revalidate_for_commit` already
produced under lock, and they write it alongside the effect so the audit can
answer "on what authority" from the row itself.

In the assembled repository these belong to the owning services' own code paths;
what API-04 owns is the transaction boundary, the deduplication marker and the
authority revalidation, not the business write. That boundary is why a `None`
basis on a consequential effect is refused rather than defaulted.
"""

from __future__ import annotations

import json
import uuid
from typing import Any, Mapping

import psycopg

from epd2_data_plane_service.exceptions import ConcurrencyAuthorityLapsedError
from epd2_data_plane_service.outbox import OutboxRecord

from .reauthorization import CommitAuthorityBasis

Json = psycopg.types.json.Jsonb


def _require_basis(basis: CommitAuthorityBasis | None, topic_id: str) -> CommitAuthorityBasis:
    if basis is None:
        raise ConcurrencyAuthorityLapsedError(
            f"a consequential effect on {topic_id!r} requires a revalidated authority basis; "
            f"absence is a wiring defect, not a default"
        )
    return basis


def projection_upsert(
    connection: psycopg.Connection, record: OutboxRecord, basis: CommitAuthorityBasis | None
) -> tuple[str, dict[str, Any]]:
    payload = dict(record.envelope.payload)
    projection_name = f"proj.{record.event_type}"
    projection_id = uuid.uuid5(uuid.NAMESPACE_URL, projection_name)
    row_key = str(record.aggregate.aggregate_id)
    with connection.cursor() as cur:
        cur.execute(
            """
            INSERT INTO dom_projection.projection_definition (projection_id, projection_name, applied_position)
            VALUES (%s,%s,1)
            ON CONFLICT (projection_name) DO UPDATE
                SET applied_position = dom_projection.projection_definition.applied_position + 1,
                    updated_at = now()
            """,
            (projection_id, projection_name),
        )
        cur.execute(
            """
            INSERT INTO dom_projection.projection_row
                (projection_id, row_key, organization_id, scope_kind, row_version, body)
            VALUES (%s,%s,%s,%s,%s,%s)
            ON CONFLICT (projection_id, row_key) DO UPDATE
                SET row_version = EXCLUDED.row_version, body = EXCLUDED.body, updated_at = now()
                WHERE projection_row.row_version <= EXCLUDED.row_version
            """,
            (projection_id, row_key, record.scope.organization_id,
             record.scope.scope_kind.value, record.sequence_number, Json(payload)),
        )
    return f"{projection_name}/{row_key}", {"row_version": record.sequence_number}


def notification_delivery(
    connection: psycopg.Connection, record: OutboxRecord, basis: CommitAuthorityBasis | None
) -> tuple[str, dict[str, Any]]:
    reference = f"nd-{record.event_id}"
    with connection.cursor() as cur:
        cur.execute(
            """
            INSERT INTO dom_notification.notification_delivery
                (delivery_reference, subject_reference, organization_id)
            VALUES (%s,%s,%s)
            ON CONFLICT (delivery_reference) DO NOTHING
            """,
            (reference, str(record.aggregate.aggregate_id), record.scope.organization_id),
        )
    return reference, {"delivered": True}


def deadline_state(
    connection: psycopg.Connection, record: OutboxRecord, basis: CommitAuthorityBasis | None
) -> tuple[str, dict[str, Any]]:
    payload = dict(record.envelope.payload)
    with connection.cursor() as cur:
        cur.execute(
            """
            INSERT INTO dom_casework.deadline_state (case_id, deadline_code, state)
            VALUES (%s,%s,%s)
            ON CONFLICT (case_id) DO UPDATE
                SET deadline_code = EXCLUDED.deadline_code, state = EXCLUDED.state,
                    recorded_at = now()
            """,
            (payload["case_id"], payload["deadline_code"], payload.get("event_type", "state_changed")),
        )
    return str(payload["case_id"]), {"recorded": True}


def audit_ingest(
    connection: psycopg.Connection, record: OutboxRecord, basis: CommitAuthorityBasis | None
) -> tuple[str, dict[str, Any]]:
    """The governed audit-ingestion contract (`P13-DP-014a`): a domain submits,
    audit-core persists. Nothing else writes audit persistence."""
    payload = dict(record.envelope.payload)
    reference = f"{record.event_type}/{record.aggregate.aggregate_id}"
    with connection.cursor() as cur:
        cur.execute(
            """
            INSERT INTO dom_audit.ingested_record (reference, event_type, digest, organization_id)
            VALUES (%s,%s,%s,%s)
            ON CONFLICT (reference) DO NOTHING
            """,
            (reference, record.event_type, record.envelope.integrity.payload_hash,
             record.scope.organization_id),
        )
    return reference, {"ingested": True}


def authority_assignment(
    connection: psycopg.Connection, record: OutboxRecord, basis: CommitAuthorityBasis | None
) -> tuple[str, dict[str, Any]]:
    checked = _require_basis(basis, record.event_type)
    payload = dict(record.envelope.payload)
    with connection.cursor() as cur:
        cur.execute(
            """
            INSERT INTO dom_governance.authority_assignment
                (authority_id, decision_reference, status, effective_time, object_version,
                 authority_basis, organization_id)
            VALUES (%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (authority_id) DO UPDATE
                SET status = EXCLUDED.status, effective_time = EXCLUDED.effective_time,
                    object_version = EXCLUDED.object_version,
                    authority_basis = EXCLUDED.authority_basis, recorded_at = now()
            """,
            (
                payload["authority_id"],
                payload.get("decision_reference") or payload.get("revocation_reason_reference", ""),
                payload["status"], payload["effective_time"], checked.object_version,
                Json(json.loads(checked.as_json())), checked.organization_id,
            ),
        )
    return str(payload["authority_id"]), {
        "status": payload["status"], "object_version": checked.object_version
    }


EFFECTS: Mapping[str, Any] = {
    "membership.membership_application_submitted::projection-service": projection_upsert,
    "membership.membership_application_submitted::notification-service": notification_delivery,
    "membership.membership_decision_recorded::projection-service": projection_upsert,
    "membership.membership_decision_recorded::notification-service": notification_delivery,
    "membership.membership_eligibility_evaluated::projection-service": projection_upsert,
    "organizational_authority.assigned::governance-service": authority_assignment,
    "organizational_authority.revoked::governance-service": authority_assignment,
    "procedural_deadline.state_changed::casework-service": deadline_state,
    "procedural_deadline.state_changed::notification-service": notification_delivery,
    "legal_hold.status_changed::audit-core": audit_ingest,
    "governed_record.retention_started::audit-core": audit_ingest,
}
