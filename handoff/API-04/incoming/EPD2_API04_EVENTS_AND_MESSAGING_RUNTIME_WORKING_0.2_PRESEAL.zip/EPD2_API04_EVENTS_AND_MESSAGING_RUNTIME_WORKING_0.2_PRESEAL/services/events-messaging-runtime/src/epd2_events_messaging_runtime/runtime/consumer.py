"""The consumer: PACK-13's decisions, made durable, driven from a real wire.

`DurableConsumer` subclasses `ReferenceConsumer` and changes exactly one thing:
where the deduplication record lives. Everything else — the order of the checks,
the fail-closed on an unsupported version for a consequential consumer, the
ordering assessment, the result shape, `detect_poison` — is inherited, so a
change upstream reaches this consumer instead of drifting away from it. A
parity test asserts the two produce the same `ConsumerResult` for the same
inputs.

Why the override is necessary: `ReferenceConsumer` keeps `_seen` in a process
dictionary. That is right for a reference implementation and wrong for a
runtime — the guarantee would last exactly as long as the process, and two
workers racing on a redelivery would each believe they were first. Here the
uniqueness is a primary key and the race is lost in the storage engine.

`SubscriptionConsumer` is the pipeline around it:

    verify transport identity (API-03)
    → authorize consume (ACL matrix)
    → validate the payload against its canonical schema
    → deduplicate, check version, assess ordering  (PACK-13, durable)
    → if consequential: revalidate authority AT the commit point (FIR-AUTH-001)
    → commit effect + dedup marker + checkpoint in ONE transaction
    → acknowledge

Nothing is dropped. A message that is neither applied nor quarantined is not an
outcome this pipeline can produce.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Mapping

import psycopg

from epd2_core.event_envelope import compute_payload_hash
from epd2_data_plane_service.delivery import (
    ConsumerCheckpoint,
    ConsumerEffect,
    ConsumerResult,
    DeadLetterRecord,
    OrderingDecision,
    ReferenceConsumer,
    assess_ordering,
)
from epd2_data_plane_service.domain import ClassificationReference, OrganizationScopeReference
from epd2_data_plane_service.exceptions import (
    DataPlaneError,
    EventVersionUnsupportedError,
    IdempotencyKeyReusedWithDifferentPayloadError,
)
from epd2_data_plane_service.idempotency import DeduplicationRecord
from epd2_data_plane_service.outbox import OutboxRecord

from .. import reason_codes as rc
from ..exceptions import MessagingRefusal
from ..identity.port import ServiceIdentityPort, TransportCredential
from ..persistence import codec
from ..persistence.postgres_stores import (
    PostgresConsumerCheckpointStore,
    PostgresDeadLetterStore,
    PostgresDeduplicationStore,
)
from ..topology.acl import AclMatrix
from ..topology.catalogue import CanonicalCatalogue
from ..topology.registry import Subscription, Topic, TopicRegistry
from ..transport.ports import ConsumerTransportPort, DeliveredMessage
from ..transport.rabbitmq import RETRY_TIER_TTL_MS, partition_queue, retry_queue
from . import privacy
from .reauthorization import CommitAuthorityBasis, revalidate_for_commit

#: (effect_reference, effect_result)
EffectFn = Callable[
    [psycopg.Connection, OutboxRecord, "CommitAuthorityBasis | None"], tuple[str, dict[str, Any]]
]


def _stable_uuid(name: str) -> uuid.UUID:
    return uuid.uuid5(uuid.NAMESPACE_URL, f"https://epd2.example/api-04/{name}")


class DurableConsumer(ReferenceConsumer):
    """`ReferenceConsumer` with its deduplication in PostgreSQL."""

    def __init__(
        self,
        *,
        consumer_name: str,
        consumer_domain: str,
        supported_event_versions: frozenset[str],
        deduplication: PostgresDeduplicationStore,
        connection: psycopg.Connection,
        deduplication_horizon: timedelta,
        consequential: bool = True,
    ) -> None:
        super().__init__(
            consumer_name=consumer_name,
            consumer_domain=consumer_domain,
            supported_event_versions=supported_event_versions,
            consequential=consequential,
        )
        self._deduplication = deduplication
        self._connection = connection
        self._horizon = deduplication_horizon

    def consume(
        self, record: OutboxRecord, *, checkpoint: ConsumerCheckpoint, now: datetime
    ) -> ConsumerResult:
        """The same order of checks as the reference: deduplication, then version
        support, then ordering."""
        outcome = self._deduplication.observe(
            consumer_name=self.consumer_name,
            consumer_domain=self.consumer_domain,
            event_id=record.event_id,
            payload_hash=record.envelope.integrity.payload_hash,
            now=now,
            expires_at=now + self._horizon,
        )
        if outcome.completed:
            return ConsumerResult(
                effect=ConsumerEffect.SUPPRESSED_DUPLICATE,
                reason_code=rc.EVENT_DUPLICATE_SUPPRESSED,
                checkpoint=checkpoint,
                deduplication=outcome.record,
            )

        if record.event_version not in self.supported_event_versions:
            if self.consequential:
                raise EventVersionUnsupportedError(
                    f"consumer {self.consumer_name!r} supports "
                    f"{sorted(self.supported_event_versions)} and received "
                    f"{record.event_version!r}; a consequential consumer fails closed rather "
                    f"than applying a partial interpretation"
                )
            return ConsumerResult(
                effect=ConsumerEffect.DEAD_LETTERED, reason_code=rc.EVENT_VERSION_UNSUPPORTED
            )

        assessment = assess_ordering(
            checkpoint_position=checkpoint.position, observed_sequence=record.sequence_number
        )
        if assessment.decision is not OrderingDecision.IN_ORDER:
            return ConsumerResult(
                effect=ConsumerEffect.REFUSED,
                reason_code=assessment.reason_code,
                checkpoint=checkpoint,
                ordering=assessment,
            )

        return ConsumerResult(
            effect=ConsumerEffect.APPLIED,
            checkpoint=checkpoint.advance_to(record.sequence_number, now=now),
            deduplication=outcome.record,
            ordering=assessment,
        )

    def record_effect(
        self, record: OutboxRecord, *, effect_reference: str, effect_result: Mapping[str, Any],
        reason_code: str,
    ) -> None:
        self._deduplication.complete(
            consumer_name=self.consumer_name,
            consumer_domain=self.consumer_domain,
            event_id=record.event_id,
            effect_reference=effect_reference,
            effect_result=effect_result,
            reason_code=reason_code,
        )


@dataclass(frozen=True, slots=True)
class _ConsumerStores:
    """The three durable stores, all on one connection."""

    deduplication: PostgresDeduplicationStore
    checkpoints: PostgresConsumerCheckpointStore
    dead_letters: PostgresDeadLetterStore


@dataclass
class ConsumeOutcome:
    applied: int = 0
    duplicates: int = 0
    refused: int = 0
    retried: int = 0
    dead_lettered: int = 0
    reason_codes: list[str] = field(default_factory=list)
    effects: list[str] = field(default_factory=list)


class SubscriptionConsumer:
    def __init__(
        self,
        *,
        subscription: Subscription,
        topic: Topic,
        registry: TopicRegistry,
        catalogue: CanonicalCatalogue,
        acl: AclMatrix,
        identity: ServiceIdentityPort,
        consumer_credential: TransportCredential,
        transport: ConsumerTransportPort,
        store_domain: str,
        connection_factory: Callable[[], psycopg.Connection],
        clock: Any,
        effect: EffectFn,
        organization: OrganizationScopeReference,
        plane: str,
        deduplication_horizon: timedelta = timedelta(days=90),
        abandon_after_effect: bool = False,
    ) -> None:
        self.subscription = subscription
        self.topic = topic
        self.registry = registry
        self.catalogue = catalogue
        self.acl = acl
        self.identity = identity
        self.consumer_credential = consumer_credential
        self.transport = transport
        #: The schema the consumer's own durable state lives in. The stores are
        #: built **per message, on the transaction's own connection** — see
        #: `_stores`. Holding them on a long-lived connection would put the
        #: deduplication marker and the effect in two different transactions,
        #: which is precisely the atomicity this consumer exists to provide.
        self.store_domain = store_domain
        self.connection_factory = connection_factory
        self.clock = clock
        self.effect = effect
        self.organization = organization
        self.plane = plane
        self.deduplication_horizon = deduplication_horizon
        #: A failure-fixture seam: models a consumer that dies after the effect
        #: commits and before the acknowledgement. Production wiring leaves it off.
        self.abandon_after_effect = abandon_after_effect

    # -- public -------------------------------------------------------------
    def poll(self, *, partition: int = 0, max_messages: int | None = None) -> ConsumeOutcome:
        outcome = ConsumeOutcome()
        limit = max_messages if max_messages is not None else self.subscription.prefetch
        pulled = 0
        while pulled < limit:
            batch = self.transport.pull(
                queue=self.subscription.queue, partition=partition, max_messages=1
            )
            if not batch:
                break
            pulled += 1
            self._handle(batch[0], outcome)
            if self.abandon_after_effect:
                break
        return outcome

    def poll_all_partitions(self, *, max_messages: int | None = None) -> ConsumeOutcome:
        from epd2_data_plane_service.exceptions import BrokerUnavailableError

        total = ConsumeOutcome()
        for partition in range(self.topic.partitions):
            try:
                part = self.poll(partition=partition, max_messages=max_messages)
            except BrokerUnavailableError:
                break
            total.applied += part.applied
            total.duplicates += part.duplicates
            total.refused += part.refused
            total.retried += part.retried
            total.dead_lettered += part.dead_lettered
            total.reason_codes.extend(part.reason_codes)
            total.effects.extend(part.effects)
        return total

    # -- pipeline -----------------------------------------------------------
    def _handle(self, message: DeliveredMessage, outcome: ConsumeOutcome) -> None:
        now = self.clock.now_utc()
        connection = self.connection_factory()
        stores = self._stores(connection)
        try:
            try:
                record = self._rebuild_record(message)
                principal = self.identity.verify(
                    self.consumer_credential,
                    purpose=f"consume:{self.subscription.subscription_id}",
                )
                self.acl.authorize_consume(
                    principal,
                    subscription_id=self.subscription.subscription_id,
                    event_version=record.event_version,
                    organization_scope=f"org:{record.scope.scope_kind.value}",
                    data_classification=self.topic.data_classification,
                )
                self._validate_payload(record)
            except (MessagingRefusal, DataPlaneError) as refusal:
                self._dispose(message, refusal, outcome, connection, now)
                return

            consumer = DurableConsumer(
                consumer_name=self.subscription.subscription_id,
                consumer_domain=self.subscription.consumer_domain,
                supported_event_versions=self.subscription.supported_event_versions,
                deduplication=stores.deduplication,
                connection=connection,
                deduplication_horizon=self.deduplication_horizon,
                consequential=self.subscription.consequential_effect,
            )
            scope_key = self._ordering_scope_key(record)
            try:
                with connection.transaction():
                    checkpoint = stores.checkpoints.latest_or_start(
                        consumer_name=self.subscription.subscription_id,
                        consumer_domain=self.subscription.consumer_domain,
                        ordering_scope_key=scope_key,
                        now=now,
                    )
                    result = consumer.consume(record, checkpoint=checkpoint, now=now)

                    if result.effect is ConsumerEffect.SUPPRESSED_DUPLICATE:
                        outcome.duplicates += 1
                        outcome.reason_codes.append(rc.EVENT_DUPLICATE_SUPPRESSED)
                        self.transport.acknowledge(message)
                        return
                    if result.effect is ConsumerEffect.REFUSED:
                        raise _OrderingRefused(result.reason_code or rc.EVENT_OUT_OF_ORDER)
                    if result.effect is ConsumerEffect.DEAD_LETTERED:
                        raise _NonConsequentialVersionRefusal(
                            result.reason_code or rc.EVENT_VERSION_UNSUPPORTED
                        )

                    basis: CommitAuthorityBasis | None = None
                    if self.subscription.commit_reauthorisation_required:
                        basis = revalidate_for_commit(
                            connection,
                            topic_id=self.topic.topic_id,
                            payload=record.envelope.payload,
                            principal=principal,
                            organization_id=record.scope.organization_id,
                            requested_object_version=record.sequence_number,
                            now=now,
                        )

                    effect_reference, effect_result = self.effect(connection, record, basis)
                    consumer.record_effect(
                        record,
                        effect_reference=effect_reference,
                        effect_result=effect_result,
                        reason_code=rc.COMMIT_AUTHORITY_BASIS_RECORDED
                        if basis
                        else rc.CONSUMER_EFFECT_APPLIED_RECORDED,
                    )
                    if result.checkpoint is not None:
                        stores.checkpoints.save(result.checkpoint)
            except (MessagingRefusal, DataPlaneError, _OrderingRefused,
                    _NonConsequentialVersionRefusal) as refusal:
                self._dispose(message, refusal, outcome, connection, now)
                return
            except Exception as exc:  # unclassified: fail closed
                self._dispose(message, _Unclassified(type(exc).__name__), outcome, connection, now)
                return

            outcome.applied += 1
            outcome.effects.append(effect_reference)
            outcome.reason_codes.append(
                rc.COMMIT_AUTHORITY_BASIS_RECORDED if basis else rc.CONSUMER_EFFECT_APPLIED_RECORDED
            )
            if self.abandon_after_effect:
                self.transport.abandon_without_acknowledgement()
                return
            self.transport.acknowledge(message)
        finally:
            connection.close()

    # -- helpers ------------------------------------------------------------
    def _rebuild_record(self, message: DeliveredMessage) -> OutboxRecord:
        """Rebuild the PACK-13 record from the wire.

        The envelope on the wire is the canonical one. Transport headers supply
        the sequence number and nothing that belongs in the envelope; a header
        that tries to be an envelope field is refused.
        """
        from ..exceptions import EnvelopeTransportMetadataProhibitedError

        envelope_json = dict(message.envelope)
        for forbidden in ("attempt", "attempts", "delivery_count", "redelivered", "queue",
                          "routing_key", "partition", "offset", "delivery_tag", "lease_id"):
            if forbidden in envelope_json:
                raise EnvelopeTransportMetadataProhibitedError(
                    "transport metadata does not belong in the canonical envelope",
                    detail={"field": forbidden},
                )
        privacy.assert_no_network_correlation(envelope_json, context="delivered envelope")
        privacy.assert_no_network_correlation(dict(message.headers), context="delivery headers")
        envelope = codec.envelope_from_json(envelope_json)
        entry = self.catalogue.require(envelope.event_type)
        del entry  # required for its refusal, not its value
        return OutboxRecord(
            outbox_record_id=_stable_uuid(f"delivery/{envelope.event_id}"),
            event_id=envelope.event_id,
            event_type=envelope.event_type,
            event_version=envelope.event_version,
            envelope=envelope,
            aggregate=self._aggregate_for(envelope),
            scope=self.organization,
            created_at=envelope.occurred_at,
            sequence_number=int(message.headers.get("x-epd2-sequence-number", 1)),
        )

    def _aggregate_for(self, envelope: Any) -> Any:
        from epd2_data_plane_service.domain import AggregateReference, DomainReference

        return AggregateReference(
            aggregate_type=self.topic.partition_key,
            aggregate_id=uuid.UUID(str(envelope.payload[self.topic.partition_key])),
            owning_domain=DomainReference(
                domain_name=self.topic.owner.replace("-service", "").replace("-", "_"),
                is_reserved_boundary=False,
            ),
        )

    def _ordering_scope_key(self, record: OutboxRecord) -> str:
        scope = self.topic.ordering_scope(
            aggregate_id=record.aggregate.aggregate_id, organization=record.scope
        )
        return scope.key

    def _validate_payload(self, record: OutboxRecord) -> None:
        import jsonschema

        from epd2_data_plane_service.exceptions import SchemaIncompatibleError

        entry = self.catalogue.require(record.event_type)
        try:
            jsonschema.validate(instance=dict(record.envelope.payload), schema=dict(entry.body))
        except jsonschema.ValidationError as exc:
            raise SchemaIncompatibleError(
                f"payload for {record.event_type!r} does not satisfy its canonical schema "
                f"at {list(exc.absolute_path)}"
            ) from None
        expected = compute_payload_hash(record.envelope.payload)
        if expected != record.envelope.integrity.payload_hash:
            from epd2_data_plane_service.exceptions import SchemaDigestMismatchError

            raise SchemaDigestMismatchError(
                f"the payload hash on {record.event_id} does not match its payload"
            )

    # -- disposition --------------------------------------------------------
    def _stores(self, connection: psycopg.Connection) -> "_ConsumerStores":
        """Every durable write this consumer makes, bound to one connection.

        The effect, the deduplication marker and the checkpoint commit together
        or not at all; a quarantine record commits on the same connection after
        that transaction rolled back. Binding the stores to the connection is
        what makes "one transaction" a fact rather than an intention."""
        return _ConsumerStores(
            deduplication=PostgresDeduplicationStore(self.store_domain, connection),
            checkpoints=PostgresConsumerCheckpointStore(self.store_domain, connection),
            dead_letters=PostgresDeadLetterStore(connection),
        )

    def _dispose(
        self, message: DeliveredMessage, refusal: Exception, outcome: ConsumeOutcome,
        connection: psycopg.Connection, now: datetime,
    ) -> None:
        stores = self._stores(connection)
        reason_code = getattr(refusal, "reason_code", rc.FAILURE_CLASS_UNKNOWN)
        outcome.reason_codes.append(reason_code)
        retryable = reason_code in _RETRYABLE
        attempt = max(message.transport_attempt + 1, 1)
        exhausted = attempt >= self.subscription.max_attempts

        if retryable and not exhausted:
            tier = min(attempt - 1, len(RETRY_TIER_TTL_MS) - 1)
            self.transport.republish(
                exchange=f"dlx.retry.{self.plane}",
                routing_key=retry_queue(self.subscription.queue, message.partition, tier),
                envelope=message.envelope,
                headers={"x-epd2-attempt": attempt, "x-epd2-reason-code": reason_code,
                         "x-epd2-sequence-number": message.headers.get("x-epd2-sequence-number", 1)},
            )
            outcome.retried += 1
            outcome.reason_codes.append(rc.RETRY_SCHEDULED_RECORDED)
            self.transport.acknowledge(message)
            return

        final_code = rc.RETRY_BUDGET_EXHAUSTED_RECORDED if (retryable and exhausted) else reason_code
        if final_code != reason_code:
            outcome.reason_codes.append(final_code)
        try:
            with connection.transaction():
                stores.dead_letters.append(
                    DeadLetterRecord(
                        dead_letter_id=_stable_uuid(
                            f"dead-letter/{self.subscription.subscription_id}/"
                            f"{message.envelope.get('event_id')}"
                        ),
                        event_id=uuid.UUID(str(message.envelope["event_id"])),
                        event_type=str(message.envelope["event_type"]),
                        reason_code=final_code,
                        attempt_count=attempt,
                        failed_at=now,
                        classification=ClassificationReference(
                            classification_id=_stable_uuid(
                                f"classification/{self.topic.data_classification}"
                            ),
                            tier=self.topic.data_classification,
                        ),
                        retention_schedule=self.topic.retention,
                    ),
                    subscription_id=self.subscription.subscription_id,
                    topic_id=self.topic.topic_id,
                    envelope_reference=_minimised(message.envelope),
                    payload_hash=str(message.envelope.get("integrity", {}).get("payload_hash", "")),
                    payload_retained=self.topic.dead_letter_policy.get("payload")
                    != "REFERENCE_ONLY",
                )
        except Exception:
            connection.rollback()
            raise

        self.transport.republish(
            exchange=f"dlx.quarantine.{self.plane}",
            routing_key=partition_queue(self.subscription.dead_letter_queue, message.partition),
            envelope=message.envelope,
            headers={"x-epd2-reason-code": final_code, "x-epd2-attempt": attempt},
        )
        outcome.dead_lettered += 1
        self.transport.acknowledge(message)


def _minimised(envelope: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "event_id": envelope.get("event_id"),
        "event_type": envelope.get("event_type"),
        "event_version": envelope.get("event_version"),
        "producer": envelope.get("producer"),
        "occurred_at": envelope.get("occurred_at"),
        "correlation_id": envelope.get("correlation_id"),
        "payload_hash": (envelope.get("integrity") or {}).get("payload_hash"),
    }


class _OrderingRefused(MessagingRefusal):
    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code  # type: ignore[misc]
        super().__init__("ordering refused")


class _NonConsequentialVersionRefusal(MessagingRefusal):
    def __init__(self, reason_code: str) -> None:
        self.reason_code = reason_code  # type: ignore[misc]
        super().__init__("unsupported event version on a non-consequential consumer")


class _Unclassified(MessagingRefusal):
    reason_code = rc.FAILURE_CLASS_UNKNOWN

    def __init__(self, error_class: str) -> None:
        super().__init__("unclassified consumer failure", detail={"error_class": error_class})


#: Reason codes whose disposition is a bounded retry. Everything else
#: quarantines, including anything unclassified.
_RETRYABLE: frozenset[str] = frozenset(
    {
        rc.BROKER_UNAVAILABLE,
        rc.DATAPLANE_DATABASE_UNAVAILABLE,
        rc.SCHEMA_REGISTRY_UNAVAILABLE,
        rc.SERVICE_IDENTITY_UNAVAILABLE,
        rc.CONSUMER_NOT_READY,
        rc.EVENT_ORDERING_GAP_DETECTED,
        rc.RETRY_SCHEDULED_RECORDED,
    }
)
