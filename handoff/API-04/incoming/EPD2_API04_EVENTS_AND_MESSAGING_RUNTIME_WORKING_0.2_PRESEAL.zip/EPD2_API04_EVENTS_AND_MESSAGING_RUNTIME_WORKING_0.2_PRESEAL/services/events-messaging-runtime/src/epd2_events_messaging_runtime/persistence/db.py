"""PostgreSQL access and the migration runner.

The governed engine for this stage is PostgreSQL **16.15**. ``assert_engine``
reads the server's own ``server_version`` and refuses anything else, so evidence
cannot quietly be produced on a different engine.

Migrations are immutable and checksummed. A checksum mismatch raises
``MIGRATION_CHECKSUM_MISMATCH`` and has no repair path: there is no ``--force``
and no auto-repair, because a migration that can be rewritten after it was
applied is not a migration. That is PACK-13's rule, not a local one.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

import psycopg
from psycopg.rows import dict_row

from epd2_data_plane_service.exceptions import (
    DatabaseUnavailableError,
    MigrationChecksumMismatchError,
)

REQUIRED_ENGINE_VERSION = "16.15"
MIGRATION_DIR = Path(__file__).parent / "migrations" / "postgresql"


@dataclass(frozen=True, slots=True)
class Migration:
    name: str
    sql: str
    checksum: str


def load_migrations(directory: Path | None = None) -> tuple[Migration, ...]:
    directory = directory or MIGRATION_DIR
    out: list[Migration] = []
    for path in sorted(directory.glob("*.sql")):
        sql = path.read_text(encoding="utf-8")
        out.append(Migration(path.name, sql, "sha256:" + hashlib.sha256(sql.encode()).hexdigest()))
    return tuple(out)


def connect(dsn: str) -> psycopg.Connection:
    try:
        conn = psycopg.connect(dsn, row_factory=dict_row)
    except psycopg.OperationalError as exc:
        raise DatabaseUnavailableError(
            "the governed PostgreSQL instance is unreachable; the runtime is NOT READY"
        ) from exc
    conn.autocommit = False
    return conn


def server_version(conn: psycopg.Connection) -> str:
    with conn.cursor() as cur:
        cur.execute("SHOW server_version")
        row = cur.fetchone()
    assert row is not None
    return str(row["server_version"]).split(" ")[0]


def assert_engine(conn: psycopg.Connection, *, required: str = REQUIRED_ENGINE_VERSION) -> str:
    version = server_version(conn)
    if version != required:
        raise DatabaseUnavailableError(
            f"the governed engine is PostgreSQL {required}; this server reports {version}"
        )
    return version


def apply_migrations(conn: psycopg.Connection, directory: Path | None = None) -> list[str]:
    migrations = load_migrations(directory)
    applied: list[str] = []
    with conn.cursor() as cur:
        cur.execute("CREATE SCHEMA IF NOT EXISTS api04_gov")
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS api04_gov.migration_applied (
                migration_name text PRIMARY KEY,
                checksum       text NOT NULL,
                applied_at     timestamptz NOT NULL DEFAULT now()
            )
            """
        )
    conn.commit()
    with conn.cursor() as cur:
        cur.execute("SELECT migration_name, checksum FROM api04_gov.migration_applied")
        known = {r["migration_name"]: r["checksum"] for r in cur.fetchall()}

    for migration in migrations:
        if migration.name in known:
            if known[migration.name] != migration.checksum:
                raise MigrationChecksumMismatchError(
                    f"migration {migration.name!r} changed on disk after it was applied; "
                    f"there is no repair path"
                )
            continue
        with conn.cursor() as cur:
            cur.execute(migration.sql)
            cur.execute(
                "INSERT INTO api04_gov.migration_applied (migration_name, checksum) VALUES (%s, %s)",
                (migration.name, migration.checksum),
            )
        conn.commit()
        applied.append(migration.name)
    return applied


def migration_state(conn: psycopg.Connection, directory: Path | None = None) -> dict[str, Any]:
    migrations = load_migrations(directory)
    with conn.cursor() as cur:
        cur.execute("SELECT migration_name, checksum FROM api04_gov.migration_applied")
        known = {r["migration_name"]: r["checksum"] for r in cur.fetchall()}
    pending = [m.name for m in migrations if m.name not in known]
    drifted = [m.name for m in migrations if m.name in known and known[m.name] != m.checksum]
    return {
        "defined": [m.name for m in migrations],
        "applied": sorted(known),
        "pending": pending,
        "drifted": drifted,
        "complete": not pending and not drifted,
    }


def fetch_all(conn: psycopg.Connection, sql: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
    with conn.cursor() as cur:
        cur.execute(sql, params)
        return list(cur.fetchall())


def fetch_one(conn: psycopg.Connection, sql: str, params: Sequence[Any] = ()) -> dict[str, Any] | None:
    with conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchone()


def execute(conn: psycopg.Connection, sql: str, params: Sequence[Any] = ()) -> int:
    with conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.rowcount
