"""FIR-AUTH-001 at the asynchronous commit point.

```text
authorization at request != authorization at consequential commit
queued authority         != permanent authority
```

PACK-13 already owns most of this vocabulary, and this module uses it rather
than restating it: `ConcurrencyPolicy.require_authority_effective_at_execution`
raises `CONCURRENCY_AUTHORITY_LAPSED`, a moved object version raises
`CONCURRENCY_STALE_AGGREGATE_VERSION`, and a scope that no longer matches raises
`ORGANIZATION_SCOPE_MISMATCH`. Two conditions have no canonical code because
PACK-13 has no queue: a governing policy version that moved, and the work item's
own deadline passing while it waited. Those two are additive.

The read happens with `SELECT … FOR UPDATE` **inside the transaction that will
write the effect**, so a concurrent revocation either lands before the read or
waits behind the commit. That is the difference between a re-check and a fix for
the window between check and commit.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping
from uuid import UUID

import psycopg

from epd2_data_plane_service.concurrency import ConcurrencyPolicy
from epd2_data_plane_service.exceptions import (
    ConcurrencyAuthorityLapsedError,
    ConcurrencyStaleAggregateVersionError,
    OrganizationScopeMismatchError,
)

from .. import reason_codes as rc
from ..exceptions import CommitDeadlineExpiredError, CommitPolicyVersionChangedError
from ..identity.port import VerifiedServicePrincipal

#: The authority table each consequential topic revalidates against. A topic
#: that is consequential and absent from this map cannot commit: there is no
#: default authority source, and inventing one would be the defect.
AUTHORITY_SOURCES: Mapping[str, tuple[str, str, str]] = {
    "organizational_authority.assigned": (
        "dom_governance.authority_state", "authority_id", "authority_id",
    ),
    "organizational_authority.revoked": (
        "dom_governance.authority_state", "authority_id", "authority_id",
    ),
}


@dataclass(frozen=True, slots=True)
class CommitAuthorityBasis:
    """What the commit actually relied on. Written with the effect, so the audit
    answers "on what authority" from the row rather than by reconstruction."""

    authority_id: UUID
    organization_id: UUID
    scope_kind: str
    object_version: int
    policy_version: str
    service_principal: str
    credential_id: str
    revalidated_at: datetime

    def as_json(self) -> str:
        return json.dumps(
            {
                "authority_id": str(self.authority_id),
                "organization_id": str(self.organization_id),
                "scope_kind": self.scope_kind,
                "object_version": self.object_version,
                "policy_version": self.policy_version,
                "service_principal": self.service_principal,
                "credential_id": self.credential_id,
                "revalidated_at": self.revalidated_at.isoformat(),
                "reason_code": rc.COMMIT_AUTHORITY_BASIS_RECORDED,
            },
            sort_keys=True,
        )


def revalidate_for_commit(
    connection: psycopg.Connection,
    *,
    topic_id: str,
    payload: Mapping[str, Any],
    principal: VerifiedServicePrincipal,
    organization_id: UUID,
    requested_object_version: int,
    now: datetime,
) -> CommitAuthorityBasis:
    """Read the current authority under lock and refuse anything that moved."""
    principal.require_active(f"consequential commit on {topic_id}")

    try:
        table, key_column, payload_key = AUTHORITY_SOURCES[topic_id]
    except KeyError:
        raise ConcurrencyAuthorityLapsedError(
            f"no authority source is declared for consequential topic {topic_id!r}; "
            f"a consequential commit does not proceed on an assumed authority"
        ) from None

    subject = payload[payload_key]
    with connection.cursor() as cur:
        cur.execute(f"SELECT * FROM {table} WHERE {key_column} = %s FOR UPDATE", (subject,))
        row = cur.fetchone()

    if row is None:
        raise ConcurrencyAuthorityLapsedError(
            f"no current authority record exists for {subject}; the queued work does not "
            f"inherit an authority that is no longer there"
        )
    if not row["authority_active"]:
        raise ConcurrencyAuthorityLapsedError(
            f"the authority for {subject} is no longer active; the work was queued while it changed"
        )

    # The canonical organizational_authority payloads carry no object version, so
    # the version this commit was requested against is the aggregate version the
    # producer committed — PACK-13's OutboxRecord.sequence_number, which is that
    # version by construction. Recorded as OG-API04-16: an event that carried its
    # own object version would let the check stand on the payload alone.
    if int(row["object_version"]) != int(requested_object_version):
        raise ConcurrencyStaleAggregateVersionError(
            f"object version moved from {requested_object_version} to {row['object_version']} while "
            f"the work was queued; the queued commit does not overwrite it"
        )

    if row["organization_id"] != organization_id:
        raise OrganizationScopeMismatchError(
            f"organization scope changed between request and commit for {subject}"
        )

    requested_policy = str(payload.get("policy_version", row["policy_version"]))
    if row["policy_version"] != requested_policy:
        raise CommitPolicyVersionChangedError(
            "the governing policy version changed between request and commit",
            detail={"topic_id": topic_id},
        )

    if row["authority_expires_at"] is not None:
        ConcurrencyPolicy.require_authority_effective_at_execution(
            authority_expires_at=row["authority_expires_at"],
            executing_at=now,
            context=f"consequential commit on {topic_id}",
        )

    if row["deadline_at"] is not None and now > row["deadline_at"]:
        raise CommitDeadlineExpiredError(
            "the work item's own deadline passed while it was queued",
            detail={"topic_id": topic_id},
        )

    if f"org:{row['scope_kind']}" not in principal.organization_scopes:
        raise OrganizationScopeMismatchError(
            f"the acting principal {principal.service_id!r} no longer holds this organization scope"
        )

    return CommitAuthorityBasis(
        authority_id=row["authority_id"],
        organization_id=row["organization_id"],
        scope_kind=row["scope_kind"],
        object_version=int(row["object_version"]),
        policy_version=row["policy_version"],
        service_principal=principal.service_id,
        credential_id=principal.credential_id,
        revalidated_at=now,
    )
