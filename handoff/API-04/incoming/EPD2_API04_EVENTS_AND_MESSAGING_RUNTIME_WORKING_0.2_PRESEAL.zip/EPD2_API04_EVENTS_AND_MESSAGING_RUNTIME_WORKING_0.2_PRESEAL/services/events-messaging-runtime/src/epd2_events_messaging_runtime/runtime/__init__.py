"""The runtime: the composition root, the dispatcher and consumer pipelines,
and the policy modules — privacy, readiness, lag, backpressure, re-drive,
replay and the commit-time reauthorization."""
