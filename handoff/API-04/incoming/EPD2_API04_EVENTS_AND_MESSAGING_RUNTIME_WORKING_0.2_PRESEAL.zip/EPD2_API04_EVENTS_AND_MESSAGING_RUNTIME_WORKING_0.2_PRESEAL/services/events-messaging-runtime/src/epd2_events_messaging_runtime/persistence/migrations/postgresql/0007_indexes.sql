-- EPD2 API-04 migration 0007 — dispatch, lag and evidence indexes
-- Kind: EXPAND. Immutable once applied: a checksum mismatch has no repair
-- path (MIGRATION_CHECKSUM_MISMATCH), exactly as PACK-13 requires.


CREATE INDEX IF NOT EXISTS ix_membership_outbox_dispatchable
    ON dom_membership.outbox_record (status, next_attempt_at)
    WHERE status IN ('pending','dispatching','failed');
CREATE INDEX IF NOT EXISTS ix_membership_outbox_age
    ON dom_membership.outbox_record (created_at) WHERE status <> 'acknowledged';
CREATE INDEX IF NOT EXISTS ix_membership_outbox_topic
    ON dom_membership.outbox_record (event_type, created_at);

CREATE INDEX IF NOT EXISTS ix_organization_outbox_dispatchable
    ON dom_organization.outbox_record (status, next_attempt_at)
    WHERE status IN ('pending','dispatching','failed');
CREATE INDEX IF NOT EXISTS ix_organization_outbox_age
    ON dom_organization.outbox_record (created_at) WHERE status <> 'acknowledged';
CREATE INDEX IF NOT EXISTS ix_organization_outbox_topic
    ON dom_organization.outbox_record (event_type, created_at);

CREATE INDEX IF NOT EXISTS ix_compliance_outbox_dispatchable
    ON dom_compliance.outbox_record (status, next_attempt_at)
    WHERE status IN ('pending','dispatching','failed');
CREATE INDEX IF NOT EXISTS ix_compliance_outbox_age
    ON dom_compliance.outbox_record (created_at) WHERE status <> 'acknowledged';
CREATE INDEX IF NOT EXISTS ix_compliance_outbox_topic
    ON dom_compliance.outbox_record (event_type, created_at);

CREATE INDEX IF NOT EXISTS ix_projection_dedup_expiry
    ON dom_projection.deduplication_record (expires_at);

CREATE INDEX IF NOT EXISTS ix_notification_dedup_expiry
    ON dom_notification.deduplication_record (expires_at);

CREATE INDEX IF NOT EXISTS ix_governance_dedup_expiry
    ON dom_governance.deduplication_record (expires_at);

CREATE INDEX IF NOT EXISTS ix_casework_dedup_expiry
    ON dom_casework.deduplication_record (expires_at);

CREATE INDEX IF NOT EXISTS ix_audit_dedup_expiry
    ON dom_audit.deduplication_record (expires_at);

CREATE INDEX IF NOT EXISTS ix_dead_letter_open
    ON api04_gov.dead_letter_record (subscription_id, redriven, failed_at);
