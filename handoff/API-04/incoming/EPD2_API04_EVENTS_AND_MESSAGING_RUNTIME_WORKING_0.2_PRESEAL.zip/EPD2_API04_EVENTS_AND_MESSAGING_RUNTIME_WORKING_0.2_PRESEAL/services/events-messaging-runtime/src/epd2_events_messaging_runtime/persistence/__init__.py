"""Durable state: the PostgreSQL adapters for PACK-13's storage ports, the
migration runner, and the serialisation that keeps the canonical envelope
intact across a write and a read."""
