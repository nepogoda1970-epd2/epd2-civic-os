"""The canonical event catalogue, read rather than restated.

`contracts/events/*.schema.json` is the authority for which event types exist
and what each payload may contain. Each schema declares its own event type in
its title (`"<event_type> event payload (v<major>)"`), so the index below is
*derived* from the carried files and cannot drift from them.

API-04 mints no event type. A topic whose event type is absent from this index
is refused with `EVENT_TYPE_NOT_IN_CANONICAL_CATALOGUE`, and a payload schema
whose bytes do not match the digest the register recorded is refused with
`SCHEMA_DIGEST_MISMATCH` — the same code PACK-13 uses for the same fact.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from ..exceptions import EventTypeNotInCanonicalCatalogueError
from .. import reason_codes as rc

_TITLE = re.compile(r"^([a-z0-9_.]+) event payload \(v(\d+)\)")


@dataclass(frozen=True, slots=True)
class CanonicalEventType:
    event_type: str
    payload_schema_path: str
    payload_schema_major: int
    payload_schema_sha256: str
    body: Mapping[str, Any]

    @property
    def required_fields(self) -> tuple[str, ...]:
        return tuple(sorted(self.body.get("required", [])))

    @property
    def properties(self) -> tuple[str, ...]:
        return tuple(sorted(self.body.get("properties", {})))


class CanonicalCatalogue:
    def __init__(self, entries: Mapping[str, CanonicalEventType]) -> None:
        self._entries = dict(entries)

    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, event_type: object) -> bool:
        return event_type in self._entries

    def require(self, event_type: str) -> CanonicalEventType:
        try:
            return self._entries[event_type]
        except KeyError:
            raise EventTypeNotInCanonicalCatalogueError(
                "the event type is not in the canonical catalogue; API-04 mints none",
                detail={"event_type": event_type},
            ) from None

    def event_types(self) -> tuple[str, ...]:
        return tuple(sorted(self._entries))

    def assert_digest(self, event_type: str, expected_sha256: str) -> None:
        from ..exceptions import MessagingRefusal

        entry = self.require(event_type)
        if entry.payload_schema_sha256 != expected_sha256:
            refusal = type(
                "SchemaDigestMismatchError", (MessagingRefusal,), {"reason_code": rc.SCHEMA_DIGEST_MISMATCH}
            )
            raise refusal(
                "the carried payload schema does not match the digest the register recorded",
                detail={"event_type": event_type, "path": entry.payload_schema_path},
            )


def load_canonical_catalogue(repository_root: str | Path) -> CanonicalCatalogue:
    root = Path(repository_root)
    entries: dict[str, CanonicalEventType] = {}
    for path in sorted((root / "contracts/events").glob("*.schema.json")):
        raw = path.read_bytes()
        body = json.loads(raw)
        match = _TITLE.match(str(body.get("title", "")))
        if not match:
            continue
        entries[match.group(1)] = CanonicalEventType(
            event_type=match.group(1),
            payload_schema_path=str(path.relative_to(root)),
            payload_schema_major=int(match.group(2)),
            payload_schema_sha256=hashlib.sha256(raw).hexdigest(),
            body=body,
        )
    return CanonicalCatalogue(entries)
