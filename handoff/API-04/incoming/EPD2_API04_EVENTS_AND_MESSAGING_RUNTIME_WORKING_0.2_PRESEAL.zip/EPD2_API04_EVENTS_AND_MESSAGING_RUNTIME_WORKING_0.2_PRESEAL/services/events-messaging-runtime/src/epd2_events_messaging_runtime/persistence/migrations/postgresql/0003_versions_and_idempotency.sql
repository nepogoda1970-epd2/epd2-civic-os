-- EPD2 API-04 migration 0003 — aggregate versions and command idempotency
-- Kind: EXPAND. Immutable once applied: a checksum mismatch has no repair
-- path (MIGRATION_CHECKSUM_MISMATCH), exactly as PACK-13 requires.
--
-- epd2_data_plane_service.storage.AggregateVersionStore and IdempotencyStore.


CREATE TABLE IF NOT EXISTS dom_audit.aggregate_version (
    aggregate_type text NOT NULL,
    aggregate_id   uuid NOT NULL,
    owning_domain  text NOT NULL,
    version        bigint NOT NULL CHECK (version >= 0),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (aggregate_type, aggregate_id)
);

CREATE TABLE IF NOT EXISTS dom_audit.idempotency_record (
    qualified_key   text PRIMARY KEY,
    domain_name     text NOT NULL,
    operation_name  text NOT NULL,
    operation_class text NOT NULL,
    key_value       text NOT NULL,
    organization_id uuid,
    scope_kind      text,
    request_digest  text NOT NULL,
    result_reference uuid NOT NULL,
    recorded_at     timestamptz NOT NULL,
    expires_at      timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS dom_casework.aggregate_version (
    aggregate_type text NOT NULL,
    aggregate_id   uuid NOT NULL,
    owning_domain  text NOT NULL,
    version        bigint NOT NULL CHECK (version >= 0),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (aggregate_type, aggregate_id)
);

CREATE TABLE IF NOT EXISTS dom_casework.idempotency_record (
    qualified_key   text PRIMARY KEY,
    domain_name     text NOT NULL,
    operation_name  text NOT NULL,
    operation_class text NOT NULL,
    key_value       text NOT NULL,
    organization_id uuid,
    scope_kind      text,
    request_digest  text NOT NULL,
    result_reference uuid NOT NULL,
    recorded_at     timestamptz NOT NULL,
    expires_at      timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS dom_compliance.aggregate_version (
    aggregate_type text NOT NULL,
    aggregate_id   uuid NOT NULL,
    owning_domain  text NOT NULL,
    version        bigint NOT NULL CHECK (version >= 0),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (aggregate_type, aggregate_id)
);

CREATE TABLE IF NOT EXISTS dom_compliance.idempotency_record (
    qualified_key   text PRIMARY KEY,
    domain_name     text NOT NULL,
    operation_name  text NOT NULL,
    operation_class text NOT NULL,
    key_value       text NOT NULL,
    organization_id uuid,
    scope_kind      text,
    request_digest  text NOT NULL,
    result_reference uuid NOT NULL,
    recorded_at     timestamptz NOT NULL,
    expires_at      timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS dom_governance.aggregate_version (
    aggregate_type text NOT NULL,
    aggregate_id   uuid NOT NULL,
    owning_domain  text NOT NULL,
    version        bigint NOT NULL CHECK (version >= 0),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (aggregate_type, aggregate_id)
);

CREATE TABLE IF NOT EXISTS dom_governance.idempotency_record (
    qualified_key   text PRIMARY KEY,
    domain_name     text NOT NULL,
    operation_name  text NOT NULL,
    operation_class text NOT NULL,
    key_value       text NOT NULL,
    organization_id uuid,
    scope_kind      text,
    request_digest  text NOT NULL,
    result_reference uuid NOT NULL,
    recorded_at     timestamptz NOT NULL,
    expires_at      timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS dom_membership.aggregate_version (
    aggregate_type text NOT NULL,
    aggregate_id   uuid NOT NULL,
    owning_domain  text NOT NULL,
    version        bigint NOT NULL CHECK (version >= 0),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (aggregate_type, aggregate_id)
);

CREATE TABLE IF NOT EXISTS dom_membership.idempotency_record (
    qualified_key   text PRIMARY KEY,
    domain_name     text NOT NULL,
    operation_name  text NOT NULL,
    operation_class text NOT NULL,
    key_value       text NOT NULL,
    organization_id uuid,
    scope_kind      text,
    request_digest  text NOT NULL,
    result_reference uuid NOT NULL,
    recorded_at     timestamptz NOT NULL,
    expires_at      timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS dom_notification.aggregate_version (
    aggregate_type text NOT NULL,
    aggregate_id   uuid NOT NULL,
    owning_domain  text NOT NULL,
    version        bigint NOT NULL CHECK (version >= 0),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (aggregate_type, aggregate_id)
);

CREATE TABLE IF NOT EXISTS dom_notification.idempotency_record (
    qualified_key   text PRIMARY KEY,
    domain_name     text NOT NULL,
    operation_name  text NOT NULL,
    operation_class text NOT NULL,
    key_value       text NOT NULL,
    organization_id uuid,
    scope_kind      text,
    request_digest  text NOT NULL,
    result_reference uuid NOT NULL,
    recorded_at     timestamptz NOT NULL,
    expires_at      timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS dom_organization.aggregate_version (
    aggregate_type text NOT NULL,
    aggregate_id   uuid NOT NULL,
    owning_domain  text NOT NULL,
    version        bigint NOT NULL CHECK (version >= 0),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (aggregate_type, aggregate_id)
);

CREATE TABLE IF NOT EXISTS dom_organization.idempotency_record (
    qualified_key   text PRIMARY KEY,
    domain_name     text NOT NULL,
    operation_name  text NOT NULL,
    operation_class text NOT NULL,
    key_value       text NOT NULL,
    organization_id uuid,
    scope_kind      text,
    request_digest  text NOT NULL,
    result_reference uuid NOT NULL,
    recorded_at     timestamptz NOT NULL,
    expires_at      timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS dom_projection.aggregate_version (
    aggregate_type text NOT NULL,
    aggregate_id   uuid NOT NULL,
    owning_domain  text NOT NULL,
    version        bigint NOT NULL CHECK (version >= 0),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (aggregate_type, aggregate_id)
);

CREATE TABLE IF NOT EXISTS dom_projection.idempotency_record (
    qualified_key   text PRIMARY KEY,
    domain_name     text NOT NULL,
    operation_name  text NOT NULL,
    operation_class text NOT NULL,
    key_value       text NOT NULL,
    organization_id uuid,
    scope_kind      text,
    request_digest  text NOT NULL,
    result_reference uuid NOT NULL,
    recorded_at     timestamptz NOT NULL,
    expires_at      timestamptz NOT NULL
);
