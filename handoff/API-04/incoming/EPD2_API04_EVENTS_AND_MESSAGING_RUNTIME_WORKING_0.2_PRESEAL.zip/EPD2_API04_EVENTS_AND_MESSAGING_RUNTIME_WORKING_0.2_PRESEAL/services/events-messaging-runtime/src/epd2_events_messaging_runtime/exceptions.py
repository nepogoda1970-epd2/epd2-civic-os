"""Reason-coded refusals, in PACK-13's own style.

Every class carries a `reason_code` class attribute, the same way
`epd2_data_plane_service.exceptions` does, so a caller that catches one can read
the code without a lookup table. Where PACK-13 already has an exception for a
condition, this module does **not** define a second one — it re-exports
PACK-13's, so `except EventPoisonMessageError` catches the same class whether it
was raised by the reference consumer or by an adapter here.
"""

from __future__ import annotations

from typing import Any, Mapping

# Re-exported PACK-13 refusals. Raised by adapters here, defined there.
from epd2_data_plane_service.exceptions import (  # noqa: F401
    BrokerUnavailableError,
    ConcurrencyApprovalOnChangedVersionError,
    ConcurrencyAuthorityLapsedError,
    ConcurrencyStaleAggregateVersionError,
    ConsumerNotReadyError,
    CrossDomainDirectAccessDeniedError,
    DatabaseUnavailableError,
    DeliveryAcknowledgementMissingError,
    EventDeadLetterRequiredError,
    EventDuplicateSuppressedError,
    EventOrderingGapDetectedError,
    EventOutOfOrderError,
    EventPoisonMessageError,
    EventReplayNotAuthorizedError,
    EventVersionUnsupportedError,
    GlobalUserIdentifierProhibitedError,
    IdempotencyKeyReusedWithDifferentPayloadError,
    LegalHoldStateUnknownError,
    MigrationChecksumMismatchError,
    OrganizationScopeMismatchError as CanonicalOrganizationScopeMismatchError,
    ProjectionStaleError,
    RecordNotFoundError,
    RecordUnderLegalHoldError,
    SchemaDigestMismatchError,
    SchemaRegistryUnavailableError,
    VotingMaterialProhibitedError,
)
from epd2_data_plane_service.domain import PayloadNotMinimalError  # noqa: F401

from . import reason_codes as rc


class MessagingRefusal(Exception):
    """A refusal raised by the API-04 transport, identity or topology layer.

    Carries an exact reason code and a detail mapping that has already passed
    the evidence-sanitation gate: an unsafe refusal cannot be constructed,
    because the check runs in ``__init__`` rather than at the log line.
    """

    reason_code: str = rc.FAILURE_CLASS_UNKNOWN

    def __init__(self, message: str = "", *, detail: Mapping[str, Any] | None = None) -> None:
        from .runtime import privacy

        self.detail: dict[str, Any] = dict(detail or {})
        privacy.assert_evidence_safe(self.detail, context=f"refusal:{self.reason_code}")
        super().__init__(f"{self.reason_code}: {message}" if message else self.reason_code)


def _refusal(name: str, code: str, doc: str) -> type[MessagingRefusal]:
    return type(name, (MessagingRefusal,), {"reason_code": code, "__doc__": doc})


# --- service identity ------------------------------------------------------
ServiceIdentityUnavailableError = _refusal(
    "ServiceIdentityUnavailableError", rc.SERVICE_IDENTITY_UNAVAILABLE,
    "The API-03 boundary could not be reached. NOT READY, never open.")
ServiceIdentityNotVerifiedError = _refusal(
    "ServiceIdentityNotVerifiedError", rc.SERVICE_IDENTITY_NOT_VERIFIED,
    "The evidence did not resolve to a verified service principal.")
ServiceIdentityAssertedByMessageError = _refusal(
    "ServiceIdentityAssertedByMessageError", rc.SERVICE_IDENTITY_ASSERTED_BY_MESSAGE,
    "A message tried to assert its own producer identity.")
HumanCredentialAsServiceIdentityError = _refusal(
    "HumanCredentialAsServiceIdentityError", rc.HUMAN_CREDENTIAL_AS_SERVICE_IDENTITY,
    "A human credential was offered where a service identity is required.")
ServiceCredentialRevokedError = _refusal(
    "ServiceCredentialRevokedError", rc.SERVICE_CREDENTIAL_REVOKED,
    "The acting service credential is revoked.")
ServiceCredentialExpiredError = _refusal(
    "ServiceCredentialExpiredError", rc.SERVICE_CREDENTIAL_EXPIRED,
    "The acting service credential is outside its validity window.")

# --- topology and ACL ------------------------------------------------------
TopicNotRegisteredError = _refusal(
    "TopicNotRegisteredError", rc.TOPIC_NOT_REGISTERED,
    "The topic is absent from the governed register.")
SubscriptionNotRegisteredError = _refusal(
    "SubscriptionNotRegisteredError", rc.SUBSCRIPTION_NOT_REGISTERED,
    "The subscription is absent from the governed register.")
TopicAutoCreationProhibitedError = _refusal(
    "TopicAutoCreationProhibitedError", rc.TOPIC_AUTO_CREATION_PROHIBITED,
    "A protected topic is never created by being used.")
TopicRegistryRuntimeDriftError = _refusal(
    "TopicRegistryRuntimeDriftError", rc.TOPIC_REGISTRY_RUNTIME_DRIFT,
    "The live broker topology and the register disagree.")
EventTypeNotInCanonicalCatalogueError = _refusal(
    "EventTypeNotInCanonicalCatalogueError", rc.EVENT_TYPE_NOT_IN_CANONICAL_CATALOGUE,
    "The event type is not a canonical one. API-04 mints none.")
ProducerNotAuthorizedForTopicError = _refusal(
    "ProducerNotAuthorizedForTopicError", rc.PRODUCER_NOT_AUTHORIZED_FOR_TOPIC,
    "No produce binding for this principal, topic, event type or version.")
ConsumerNotAuthorizedForSubscriptionError = _refusal(
    "ConsumerNotAuthorizedForSubscriptionError", rc.CONSUMER_NOT_AUTHORIZED_FOR_SUBSCRIPTION,
    "No consume binding for this principal and subscription.")
MessagingAclWildcardProhibitedError = _refusal(
    "MessagingAclWildcardProhibitedError", rc.MESSAGING_ACL_WILDCARD_PROHIBITED,
    "A wildcard ACL row cannot be loaded.")
MessagingAclClassificationMismatchError = _refusal(
    "MessagingAclClassificationMismatchError", rc.MESSAGING_ACL_CLASSIFICATION_MISMATCH,
    "Data classification does not match the binding or the principal.")
OrganizationScopeMismatchError = _refusal(
    "OrganizationScopeMismatchError", rc.ORGANIZATION_SCOPE_MISMATCH,
    "Organization scope is outside the grant or the verified principal.")

# --- transport privacy -----------------------------------------------------
NetworkCorrelationMetadataProhibitedError = _refusal(
    "NetworkCorrelationMetadataProhibitedError", rc.NETWORK_CORRELATION_METADATA_PROHIBITED,
    "Infrastructure correlation metadata reached a message or durable evidence.")
VotingPlaneCrossingProhibitedError = _refusal(
    "VotingPlaneCrossingProhibitedError", rc.VOTING_PLANE_CROSSING_PROHIBITED,
    "An attempt to span the ordinary plane and a voting plane.")
CorrelationReferenceNotRequestScopedError = _refusal(
    "CorrelationReferenceNotRequestScopedError", rc.CORRELATION_REFERENCE_NOT_REQUEST_SCOPED,
    "A correlation reference was not request- or session-scoped.")
EnvelopeTransportMetadataProhibitedError = _refusal(
    "EnvelopeTransportMetadataProhibitedError", rc.ENVELOPE_TRANSPORT_METADATA_PROHIBITED,
    "Transport metadata was offered for the canonical envelope.")

# --- transport operations --------------------------------------------------
BrokerVersionNotPinnedError = _refusal(
    "BrokerVersionNotPinnedError", rc.BROKER_VERSION_NOT_PINNED,
    "The connected broker is not the pinned version.")
MessageSilentDropProhibitedError = _refusal(
    "MessageSilentDropProhibitedError", rc.MESSAGE_SILENT_DROP_PROHIBITED,
    "A message was about to be discarded without quarantine evidence.")
ConsequentialMessageShedProhibitedError = _refusal(
    "ConsequentialMessageShedProhibitedError", rc.CONSEQUENTIAL_MESSAGE_SHED_PROHIBITED,
    "Load shedding was attempted on a consequential subscription.")
FailureClassUnknownError = _refusal(
    "FailureClassUnknownError", rc.FAILURE_CLASS_UNKNOWN,
    "A failure could not be classified; it quarantines rather than looping.")
DeduplicationHorizonTooShortError = _refusal(
    "DeduplicationHorizonTooShortError", rc.DEDUPLICATION_HORIZON_BELOW_REPLAY_HORIZON,
    "Deduplication would expire before the replay horizon.")

# --- governed re-drive and replay -----------------------------------------
RedriveAuthorityMissingError = _refusal(
    "RedriveAuthorityMissingError", rc.REDRIVE_AUTHORITY_MISSING,
    "A re-drive lacks an operator principal, authority and reason, or a check refused it.")
RedriveTargetMismatchError = _refusal(
    "RedriveTargetMismatchError", rc.REDRIVE_TARGET_MISMATCH,
    "A dead letter was aimed somewhere other than its own subscription.")
RedriveBulkUnboundedProhibitedError = _refusal(
    "RedriveBulkUnboundedProhibitedError", rc.REDRIVE_BULK_UNBOUNDED_PROHIBITED,
    "There is no unbounded requeue path.")
ReplayRangeUnboundedProhibitedError = _refusal(
    "ReplayRangeUnboundedProhibitedError", rc.REPLAY_RANGE_UNBOUNDED_PROHIBITED,
    "A replay must be bounded at both ends.")
ReplayReinterpretationProhibitedError = _refusal(
    "ReplayReinterpretationProhibitedError", rc.REPLAY_REINTERPRETATION_PROHIBITED,
    "A historical event would have been re-judged under a newer policy.")

# --- consequential asynchronous commit ------------------------------------
CommitPolicyVersionChangedError = _refusal(
    "CommitPolicyVersionChangedError", rc.COMMIT_POLICY_VERSION_CHANGED,
    "The governing policy version changed between request and commit.")
CommitDeadlineExpiredError = _refusal(
    "CommitDeadlineExpiredError", rc.COMMIT_DEADLINE_EXPIRED,
    "The work item's own deadline passed while it was queued.")

# --- readiness and lineage -------------------------------------------------
MessagingRuntimeNotReadyError = _refusal(
    "MessagingRuntimeNotReadyError", rc.MESSAGING_RUNTIME_NOT_READY,
    "The runtime is not ready for the work offered.")
PredecessorNotAcceptedError = _refusal(
    "PredecessorNotAcceptedError", rc.PREDECESSOR_NOT_ACCEPTED,
    "An independently accepted predecessor is required and none is bound.")
AcceptedPredecessorClaimProhibitedError = _refusal(
    "AcceptedPredecessorClaimProhibitedError", rc.ACCEPTED_PREDECESSOR_CLAIM_PROHIBITED,
    "A working integration predecessor was labelled accepted.")
