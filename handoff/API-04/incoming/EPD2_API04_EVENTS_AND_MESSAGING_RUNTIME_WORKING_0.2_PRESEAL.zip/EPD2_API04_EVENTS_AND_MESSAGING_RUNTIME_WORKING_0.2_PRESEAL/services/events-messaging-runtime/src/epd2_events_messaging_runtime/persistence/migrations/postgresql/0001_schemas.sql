-- EPD2 API-04 migration 0001 — domain-owned schemas and the governance schema
-- Kind: EXPAND. Immutable once applied: a checksum mismatch has no repair
-- path (MIGRATION_CHECKSUM_MISMATCH), exactly as PACK-13 requires.
--
-- ADR-070: the outbox is co-located with its domain. There is no central outbox
-- table here, because a shared one is a shared mutable table across authority domains.

CREATE SCHEMA IF NOT EXISTS api04_gov;
CREATE SCHEMA IF NOT EXISTS dom_audit;
CREATE SCHEMA IF NOT EXISTS dom_casework;
CREATE SCHEMA IF NOT EXISTS dom_compliance;
CREATE SCHEMA IF NOT EXISTS dom_governance;
CREATE SCHEMA IF NOT EXISTS dom_membership;
CREATE SCHEMA IF NOT EXISTS dom_notification;
CREATE SCHEMA IF NOT EXISTS dom_organization;
CREATE SCHEMA IF NOT EXISTS dom_projection;
