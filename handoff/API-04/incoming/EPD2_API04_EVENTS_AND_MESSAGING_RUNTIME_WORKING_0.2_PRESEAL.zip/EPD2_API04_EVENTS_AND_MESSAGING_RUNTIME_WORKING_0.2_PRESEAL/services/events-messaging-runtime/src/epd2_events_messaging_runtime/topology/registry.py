"""The governed topic and subscription register.

PACK-13 prescribes no topic naming and no broker topology, for the general plane
or the voting plane (`P13-VOTE-008`). That gap is API-04's to fill, and this is
where it is filled — governed, machine-readable, and derived from the canonical
event catalogue rather than invented alongside it.

Three consequences, each a gate somewhere:

* a topic absent from the register cannot be published to, consumed from or
  declared — `TOPIC_NOT_REGISTERED`;
* the provisioner declares exactly this register's entities, so a protected topic
  cannot come into existence by being used — `TOPIC_AUTO_CREATION_PROHIBITED`,
  and the broker refuses it too because service principals hold `configure=^$`;
* the validator walks the live broker in both directions against this file —
  `TOPIC_REGISTRY_RUNTIME_DRIFT`.

Ordering uses PACK-13's own `OrderingScopeKind`. There is no API-04 ordering
vocabulary.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping
from uuid import UUID, uuid5, NAMESPACE_URL

from epd2_data_plane_service.delivery import OrderingScope, OrderingScopeKind
from epd2_data_plane_service.outbox import DestinationReference
from epd2_data_plane_service.domain import (
    OrganizationScopeKind,
    OrganizationScopeReference,
    RetentionScheduleReference,
)

from ..exceptions import (
    SubscriptionNotRegisteredError,
    TopicAutoCreationProhibitedError,
    TopicNotRegisteredError,
)
from .catalogue import CanonicalCatalogue

ORDERED_KINDS = frozenset(
    {OrderingScopeKind.PER_AGGREGATE, OrderingScopeKind.PER_ORGANIZATION_AND_AGGREGATE}
)


def _stable_uuid(name: str) -> UUID:
    """A deterministic identifier for a named topology object, so two runs of the
    provisioner produce the same reference rather than a fresh one."""
    return uuid5(NAMESPACE_URL, f"https://epd2.example/api-04/{name}")


@dataclass(frozen=True, slots=True)
class Topic:
    topic_id: str
    event_type: str
    owner: str
    producer_services: frozenset[str]
    consumer_services: frozenset[str]
    event_versions: tuple[str, ...]
    payload_schema: str
    payload_schema_sha256: str
    data_classification: str
    retention_schedule: str
    ordering_scope_kind: OrderingScopeKind
    ordering_stream_name: str | None
    partition_key: str
    partitions: int
    retry_policy: Mapping[str, Any]
    dead_letter_policy: Mapping[str, Any]
    replay_permission: str
    redrive_permission: str
    readiness_dependency: tuple[str, ...]
    consequential_effect: bool
    commit_reauthorisation_required: bool
    destination_name: str
    prefetch: int
    lag_band_ceiling: str

    @property
    def ordered(self) -> bool:
        return self.ordering_scope_kind in ORDERED_KINDS

    @property
    def destination(self) -> DestinationReference:
        return DestinationReference(
            destination_id=_stable_uuid(f"destination/{self.destination_name}"),
            destination_name=self.destination_name,
        )

    @property
    def retention(self) -> RetentionScheduleReference:
        return RetentionScheduleReference(
            schedule_id=_stable_uuid(f"retention/{self.retention_schedule}"),
            schedule_name=self.retention_schedule,
        )

    def ordering_scope(self, *, aggregate_id: UUID | None, organization: OrganizationScopeReference | None) -> OrderingScope:
        if self.ordering_scope_kind is OrderingScopeKind.PER_STREAM:
            return OrderingScope(
                kind=self.ordering_scope_kind,
                aggregate_id=None,
                stream_name=self.ordering_stream_name or self.topic_id,
                organization_scope=None,
            )
        if self.ordering_scope_kind is OrderingScopeKind.PER_ORGANIZATION_AND_AGGREGATE:
            return OrderingScope(
                kind=self.ordering_scope_kind,
                aggregate_id=aggregate_id,
                stream_name=None,
                organization_scope=organization,
            )
        return OrderingScope(
            kind=self.ordering_scope_kind,
            aggregate_id=aggregate_id,
            stream_name=None,
            organization_scope=None,
        )


@dataclass(frozen=True, slots=True)
class Subscription:
    subscription_id: str
    topic_id: str
    consumer_service: str
    consumer_domain: str
    queue: str
    dead_letter_queue: str
    partitions: int
    supported_event_versions: frozenset[str]
    ordering_scope_kind: OrderingScopeKind
    deduplication_required: bool
    consequential_effect: bool
    commit_reauthorisation_required: bool
    max_attempts: int
    prefetch: int
    lag_band_ceiling: str


class TopicRegistry:
    def __init__(self, document: Mapping[str, Any], *, catalogue: CanonicalCatalogue) -> None:
        self._document = document
        self.catalogue = catalogue
        self.planes: Mapping[str, Any] = document["planes"]
        self.voting_plane_exists: bool = bool(document["voting_plane"]["exists"])
        self._topics: dict[str, Topic] = {}
        self._subscriptions: dict[str, Subscription] = {}

        for row in document["topics"]:
            catalogue.require(row["event_type"])
            catalogue.assert_digest(row["event_type"], row["payload_schema_sha256"])
            topic = Topic(
                topic_id=row["topic_id"],
                event_type=row["event_type"],
                owner=row["owner"],
                producer_services=frozenset(row["producer_services"]),
                consumer_services=frozenset(row["consumer_services"]),
                event_versions=tuple(row["event_versions"]),
                payload_schema=row["payload_schema"],
                payload_schema_sha256=row["payload_schema_sha256"],
                data_classification=row["data_classification"],
                retention_schedule=row["retention_schedule"],
                ordering_scope_kind=OrderingScopeKind(row["ordering_scope_kind"]),
                ordering_stream_name=row["ordering_stream_name"],
                partition_key=row["partition_key"],
                partitions=int(row["partitions"]),
                retry_policy=row["retry_policy"],
                dead_letter_policy=row["dead_letter_policy"],
                replay_permission=row["replay_permission"],
                redrive_permission=row["redrive_permission"],
                readiness_dependency=tuple(row["readiness_dependency"]),
                consequential_effect=bool(row["consequential_effect"]),
                commit_reauthorisation_required=bool(row["commit_reauthorisation_required"]),
                destination_name=row["destination_name"],
                prefetch=int(row["prefetch"]),
                lag_band_ceiling=row["lag_band_ceiling"],
            )
            self._topics[topic.topic_id] = topic

        for row in document["subscriptions"]:
            sub = Subscription(
                subscription_id=row["subscription_id"],
                topic_id=row["topic_id"],
                consumer_service=row["consumer_service"],
                consumer_domain=row["consumer_domain"],
                queue=row["queue"],
                dead_letter_queue=row["dead_letter_queue"],
                partitions=int(row["partitions"]),
                supported_event_versions=frozenset(row["supported_event_versions"]),
                ordering_scope_kind=OrderingScopeKind(row["ordering_scope_kind"]),
                deduplication_required=bool(row["deduplication_required"]),
                consequential_effect=bool(row["consequential_effect"]),
                commit_reauthorisation_required=bool(row["commit_reauthorisation_required"]),
                max_attempts=int(row["max_attempts"]),
                prefetch=int(row["prefetch"]),
                lag_band_ceiling=row["lag_band_ceiling"],
            )
            self._subscriptions[sub.subscription_id] = sub

    # -- lookups ------------------------------------------------------------
    def topic(self, topic_id: str) -> Topic:
        try:
            return self._topics[topic_id]
        except KeyError:
            raise TopicNotRegisteredError(
                "topic is not in the governed register", detail={"topic_id": topic_id}
            ) from None

    def subscription(self, subscription_id: str) -> Subscription:
        try:
            return self._subscriptions[subscription_id]
        except KeyError:
            raise SubscriptionNotRegisteredError(
                "subscription is not in the governed register",
                detail={"subscription_id": subscription_id},
            ) from None

    @property
    def topics(self) -> tuple[Topic, ...]:
        return tuple(self._topics.values())

    @property
    def subscriptions(self) -> tuple[Subscription, ...]:
        return tuple(self._subscriptions.values())

    def subscriptions_for(self, topic_id: str) -> tuple[Subscription, ...]:
        return tuple(s for s in self._subscriptions.values() if s.topic_id == topic_id)

    def refuse_auto_creation(self, topic_id: str) -> None:
        raise TopicAutoCreationProhibitedError(
            "a protected topic is never created by being used", detail={"topic_id": topic_id}
        )

    # -- drift --------------------------------------------------------------
    def declared_exchanges(self) -> set[str]:
        return {t.destination_name for t in self._topics.values()}

    def declared_queues(self) -> set[str]:
        out: set[str] = set()
        for sub in self._subscriptions.values():
            topic = self._topics[sub.topic_id]
            for partition in range(topic.partitions):
                out.add(f"{sub.queue}.p{partition}")
                out.add(f"{sub.dead_letter_queue}.p{partition}")
        return out

    def drift_against(self, runtime: Mapping[str, set[str]]) -> list[str]:
        problems: list[str] = []
        for label, declared, live in (
            ("exchange", self.declared_exchanges(), runtime.get("exchanges", set())),
            ("queue", self.declared_queues(), runtime.get("queues", set())),
        ):
            for missing in sorted(declared - live):
                problems.append(f"registered {label} absent from runtime: {missing}")
            for extra in sorted(live - declared):
                problems.append(f"runtime {label} absent from register: {extra}")
        return problems


def load_topic_registry(path: str | Path, *, catalogue: CanonicalCatalogue) -> TopicRegistry:
    document = json.loads(Path(path).read_text(encoding="utf-8"))
    return TopicRegistry(document, catalogue=catalogue)


def organization_scope(organization_id: UUID, kind: str = "bund") -> OrganizationScopeReference:
    return OrganizationScopeReference(
        organization_id=organization_id, scope_kind=OrganizationScopeKind(kind)
    )
