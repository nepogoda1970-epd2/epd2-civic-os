"""Bounded concurrency, and an overload rule that never drops.

```text
degraded mode != weakened invariant
```

The consumer pulls one unacknowledged delivery at a time, so memory is bounded
by one message rather than by queue depth; `prefetch` bounds how many a single
poll will process. `OverloadPolicy` decides what to do when the observed lag
band exceeds a subscription's declared ceiling: pause it, throttle its producer,
or shed *non*-consequential work. It may never shed a consequential message —
`shed` refuses — because the cheapest way to reduce lag is exactly the one that
must stay unavailable.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .. import reason_codes as rc
from ..exceptions import ConsequentialMessageShedProhibitedError
from ..topology.registry import Subscription
from .lag import band_exceeds


@dataclass
class OverloadPolicy:
    paused: set[str] = field(default_factory=set)
    producer_throttle_ms: dict[str, int] = field(default_factory=dict)

    def pause(self, subscription_id: str) -> str:
        self.paused.add(subscription_id)
        return rc.BACKPRESSURE_APPLIED_RECORDED

    def resume(self, subscription_id: str) -> None:
        self.paused.discard(subscription_id)

    def is_paused(self, subscription_id: str) -> bool:
        return subscription_id in self.paused

    def throttle_producer(self, service_id: str, delay_ms: int) -> str:
        self.producer_throttle_ms[service_id] = max(0, delay_ms)
        return rc.BACKPRESSURE_APPLIED_RECORDED

    @staticmethod
    def shed(subscription: Subscription) -> str:
        if subscription.consequential_effect:
            raise ConsequentialMessageShedProhibitedError(
                "a consequential message is never shed to reduce lag",
                detail={"subscription_id": subscription.subscription_id},
            )
        return rc.BACKPRESSURE_APPLIED_RECORDED

    def apply(self, subscription: Subscription, observed_band: str) -> str | None:
        if not band_exceeds(observed_band, subscription.lag_band_ceiling):
            self.resume(subscription.subscription_id)
            return None
        return self.pause(subscription.subscription_id)

    @staticmethod
    def fair_partition_order(partitions: int, cursor: int) -> list[int]:
        """Round-robin, so one hot partition cannot starve the others."""
        if partitions <= 1:
            return [0]
        start = cursor % partitions
        return [(start + offset) % partitions for offset in range(partitions)]
