"""Producer / consumer authorization — the layer above the broker's own ACL.

Two independent layers, and both must hold.

**Broker ACL** — a per-service credential with `configure=^$` (declare nothing)
and `write`/`read` regexes bounded to that principal's own exchanges and queues.
This is what makes an unauthorized *connection* fail.

**This matrix** — a verified API-03 principal, an exact topic or subscription,
the event type, the event version, the organization scope and the data
classification. This is what makes an unauthorized *publish* fail even from a
peer whose broker credential happens to work.

Neither layer is domain authorization. A publish that passes both says nothing
about whether the resulting domain effect is permitted; that is the owning
service's question, and for a consequential effect it is asked again at the
commit point.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from ..exceptions import (
    ConsumerNotAuthorizedForSubscriptionError,
    MessagingAclClassificationMismatchError,
    MessagingAclWildcardProhibitedError,
    OrganizationScopeMismatchError,
    ProducerNotAuthorizedForTopicError,
)
from ..identity.port import VerifiedServicePrincipal

WILDCARDS = frozenset({"*", "*:*", "**", ".*", "all", "any", ""})


@dataclass(frozen=True, slots=True)
class ProduceBinding:
    service_id: str
    topic_id: str
    event_type: str
    event_versions: frozenset[str]
    organization_scopes: frozenset[str]
    data_classification: str


@dataclass(frozen=True, slots=True)
class ConsumeBinding:
    """One governed consume grant.

    `event_versions` are the versions the **topic** legitimately carries — what
    this layer authorises. What the consumer can *interpret* is the
    subscription's `supported_event_versions`, and a version it cannot
    interpret is a compatibility failure, not an authorisation failure: two
    different facts an operator acts on differently, so two codes."""

    service_id: str
    subscription_id: str
    topic_id: str
    event_versions: frozenset[str]
    organization_scopes: frozenset[str]
    data_classification: str


class AclMatrix:
    def __init__(self, document: Mapping[str, Any]) -> None:
        self._document = document
        self.service_principals: Mapping[str, Any] = document["service_principals"]
        self._produce: dict[tuple[str, str], ProduceBinding] = {}
        self._consume: dict[tuple[str, str], ConsumeBinding] = {}

        for row in document["produce_bindings"]:
            self._reject_wildcards(row["service_id"], row["topic_id"])
            binding = ProduceBinding(
                service_id=row["service_id"],
                topic_id=row["topic_id"],
                event_type=row["event_type"],
                event_versions=frozenset(row["event_versions"]),
                organization_scopes=frozenset(row["organization_scopes"]),
                data_classification=row["data_classification"],
            )
            self._produce[(binding.service_id, binding.topic_id)] = binding

        for row in document["consume_bindings"]:
            self._reject_wildcards(row["service_id"], row["subscription_id"])
            binding = ConsumeBinding(
                service_id=row["service_id"],
                subscription_id=row["subscription_id"],
                topic_id=row["topic_id"],
                event_versions=frozenset(row["event_versions"]),
                organization_scopes=frozenset(row["organization_scopes"]),
                data_classification=row["data_classification"],
            )
            self._consume[(binding.service_id, binding.subscription_id)] = binding

    @staticmethod
    def _reject_wildcards(*values: str) -> None:
        for value in values:
            if value.strip().lower() in WILDCARDS:
                raise MessagingAclWildcardProhibitedError(
                    "a wildcard ACL row is never a governed grant", detail={"value": value}
                )

    # -- publish ------------------------------------------------------------
    def authorize_publish(
        self,
        principal: VerifiedServicePrincipal,
        *,
        topic_id: str,
        event_type: str,
        event_version: str,
        organization_scope: str,
        data_classification: str,
    ) -> ProduceBinding:
        principal.require_active(f"publish to {topic_id}")
        binding = self._produce.get((principal.service_id, topic_id))
        if binding is None:
            raise ProducerNotAuthorizedForTopicError(
                "no produce binding for this principal and topic",
                detail={"service_id": principal.service_id, "topic_id": topic_id},
            )
        if event_type != binding.event_type:
            raise ProducerNotAuthorizedForTopicError(
                "producer is not bound to this event type",
                detail={"service_id": principal.service_id, "event_type": event_type},
            )
        if event_version not in binding.event_versions:
            raise ProducerNotAuthorizedForTopicError(
                "producer is not bound to this event version",
                detail={
                    "service_id": principal.service_id,
                    "topic_id": topic_id,
                    "event_version": event_version,
                },
            )
        self._assert_scope(principal, binding.organization_scopes, organization_scope, topic_id)
        self._assert_classification(principal, binding.data_classification, data_classification, topic_id)
        return binding

    # -- consume ------------------------------------------------------------
    def authorize_consume(
        self,
        principal: VerifiedServicePrincipal,
        *,
        subscription_id: str,
        event_version: str,
        organization_scope: str,
        data_classification: str,
    ) -> ConsumeBinding:
        principal.require_active(f"consume {subscription_id}")
        binding = self._consume.get((principal.service_id, subscription_id))
        if binding is None:
            raise ConsumerNotAuthorizedForSubscriptionError(
                "no consume binding for this principal and subscription",
                detail={"service_id": principal.service_id, "subscription_id": subscription_id},
            )
        if event_version not in binding.event_versions:
            raise ConsumerNotAuthorizedForSubscriptionError(
                "the topic does not carry this event version",
                detail={
                    "service_id": principal.service_id,
                    "subscription_id": subscription_id,
                    "event_version": event_version,
                },
            )
        self._assert_scope(principal, binding.organization_scopes, organization_scope, subscription_id)
        self._assert_classification(
            principal, binding.data_classification, data_classification, subscription_id
        )
        return binding

    # -- shared checks ------------------------------------------------------
    @staticmethod
    def _assert_scope(
        principal: VerifiedServicePrincipal,
        granted: frozenset[str],
        organization_scope: str,
        target: str,
    ) -> None:
        if organization_scope not in granted or organization_scope not in principal.organization_scopes:
            raise OrganizationScopeMismatchError(
                "organization scope is outside the binding or the verified principal",
                detail={
                    "service_id": principal.service_id,
                    "target": target,
                    "organization_scope": organization_scope,
                },
            )

    @staticmethod
    def _assert_classification(
        principal: VerifiedServicePrincipal,
        bound: str,
        presented: str,
        target: str,
    ) -> None:
        if presented != bound:
            raise MessagingAclClassificationMismatchError(
                "data classification does not match the governed binding",
                detail={"target": target, "presented": presented},
            )
        if presented not in principal.data_classifications:
            raise MessagingAclClassificationMismatchError(
                "verified principal may not handle this data classification",
                detail={"service_id": principal.service_id, "target": target, "presented": presented},
            )

    @property
    def produce_bindings(self) -> tuple[ProduceBinding, ...]:
        return tuple(self._produce.values())

    @property
    def consume_bindings(self) -> tuple[ConsumeBinding, ...]:
        return tuple(self._consume.values())


def load_acl_matrix(path: str | Path) -> AclMatrix:
    return AclMatrix(json.loads(Path(path).read_text(encoding="utf-8")))
