"""Serialising a PACK-13 record to a row, and back, without changing it.

The rule this module exists to keep: a round trip is the identity. An
``OutboxRecord`` written to PostgreSQL and read back must be equal to the one
that went in, including its envelope's payload hash — otherwise "the payload is
immutable" would be a claim about the database and not about the record. The
unit suite asserts the round trip on every field, and the database refuses a
payload rewrite with its own trigger on top of that.

No shape is invented here. Every field name below is a PACK-13 or `epd2_core`
field name, so a rename upstream breaks the codec loudly instead of silently
dropping a column.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping
from uuid import UUID

from epd2_core.event_envelope import ActorRef, EventEnvelope, EventIntegrity, SubjectRef
from epd2_data_plane_service.domain import (
    AggregateReference,
    DomainReference,
    OrganizationScopeKind,
    OrganizationScopeReference,
    RetentionScheduleReference,
)
from epd2_data_plane_service.delivery import ConsumerCheckpoint, DeadLetterRecord
from epd2_data_plane_service.domain import ClassificationReference
from epd2_data_plane_service.outbox import (
    BrokerAcknowledgementReference,
    DeliveryAttempt,
    DeliveryOutcome,
    DestinationReference,
    OutboxRecord,
    OutboxStatus,
    PublicationEvidence,
)


def _dt(value: str) -> datetime:
    return datetime.fromisoformat(value)


# --- envelope --------------------------------------------------------------

def envelope_to_json(envelope: EventEnvelope) -> dict[str, Any]:
    return {
        "event_id": str(envelope.event_id),
        "event_type": envelope.event_type,
        "event_version": envelope.event_version,
        "occurred_at": envelope.occurred_at.isoformat(),
        "producer": envelope.producer,
        "actor": {"actor_id": str(envelope.actor.actor_id), "actor_type": envelope.actor.actor_type},
        "subject": {
            "subject_type": envelope.subject.subject_type,
            "subject_id": str(envelope.subject.subject_id),
        },
        "correlation_id": str(envelope.correlation_id),
        "causation_id": str(envelope.causation_id) if envelope.causation_id else None,
        "payload": dict(envelope.payload),
        "integrity": {
            "payload_hash": envelope.integrity.payload_hash,
            "signature": envelope.integrity.signature,
        },
    }


def envelope_from_json(row: Mapping[str, Any]) -> EventEnvelope:
    return EventEnvelope(
        event_id=UUID(row["event_id"]),
        event_type=row["event_type"],
        event_version=row["event_version"],
        occurred_at=_dt(row["occurred_at"]),
        producer=row["producer"],
        actor=ActorRef(actor_id=UUID(row["actor"]["actor_id"]), actor_type=row["actor"]["actor_type"]),
        subject=SubjectRef(
            subject_type=row["subject"]["subject_type"], subject_id=UUID(row["subject"]["subject_id"])
        ),
        correlation_id=UUID(row["correlation_id"]),
        causation_id=UUID(row["causation_id"]) if row["causation_id"] else None,
        payload=dict(row["payload"]),
        integrity=EventIntegrity(
            payload_hash=row["integrity"]["payload_hash"], signature=row["integrity"]["signature"]
        ),
    )


# --- references ------------------------------------------------------------

def aggregate_to_json(aggregate: AggregateReference) -> dict[str, Any]:
    return {
        "aggregate_type": aggregate.aggregate_type,
        "aggregate_id": str(aggregate.aggregate_id),
        "owning_domain": {
            "domain_name": aggregate.owning_domain.domain_name,
            "is_reserved_boundary": aggregate.owning_domain.is_reserved_boundary,
        },
    }


def aggregate_from_json(row: Mapping[str, Any]) -> AggregateReference:
    return AggregateReference(
        aggregate_type=row["aggregate_type"],
        aggregate_id=UUID(row["aggregate_id"]),
        owning_domain=DomainReference(
            domain_name=row["owning_domain"]["domain_name"],
            is_reserved_boundary=row["owning_domain"]["is_reserved_boundary"],
        ),
    )


def scope_to_json(scope: OrganizationScopeReference) -> dict[str, Any]:
    return {"organization_id": str(scope.organization_id), "scope_kind": scope.scope_kind.value}


def scope_from_json(row: Mapping[str, Any]) -> OrganizationScopeReference:
    return OrganizationScopeReference(
        organization_id=UUID(row["organization_id"]),
        scope_kind=OrganizationScopeKind(row["scope_kind"]),
    )


def destination_to_json(destination: DestinationReference) -> dict[str, Any]:
    return {
        "destination_id": str(destination.destination_id),
        "destination_name": destination.destination_name,
    }


def destination_from_json(row: Mapping[str, Any]) -> DestinationReference:
    return DestinationReference(
        destination_id=UUID(row["destination_id"]), destination_name=row["destination_name"]
    )


def retention_to_json(schedule: RetentionScheduleReference | None) -> dict[str, Any] | None:
    if schedule is None:
        return None
    return {"schedule_id": str(schedule.schedule_id), "schedule_name": schedule.schedule_name}


def retention_from_json(row: Mapping[str, Any] | None) -> RetentionScheduleReference | None:
    if row is None:
        return None
    return RetentionScheduleReference(
        schedule_id=UUID(row["schedule_id"]), schedule_name=row["schedule_name"]
    )


def attempt_to_json(attempt: DeliveryAttempt) -> dict[str, Any]:
    return {
        "attempt_number": attempt.attempt_number,
        "started_at": attempt.started_at.isoformat(),
        "outcome": attempt.outcome.value,
        "destination": destination_to_json(attempt.destination),
        "error_reference": attempt.error_reference,
    }


def attempt_from_json(row: Mapping[str, Any]) -> DeliveryAttempt:
    return DeliveryAttempt(
        attempt_number=row["attempt_number"],
        started_at=_dt(row["started_at"]),
        outcome=DeliveryOutcome(row["outcome"]),
        destination=destination_from_json(row["destination"]),
        error_reference=row["error_reference"],
    )


def evidence_to_json(evidence: PublicationEvidence | None) -> dict[str, Any] | None:
    if evidence is None:
        return None
    ack = evidence.acknowledgement
    return {
        "event_id": str(evidence.event_id),
        "published_at": evidence.published_at.isoformat(),
        "destination": destination_to_json(evidence.destination),
        "acknowledgement": None
        if ack is None
        else {
            "acknowledgement_reference": ack.acknowledgement_reference,
            "received_at": ack.received_at.isoformat(),
        },
    }


def evidence_from_json(row: Mapping[str, Any] | None) -> PublicationEvidence | None:
    if row is None:
        return None
    ack = row["acknowledgement"]
    return PublicationEvidence(
        event_id=UUID(row["event_id"]),
        published_at=_dt(row["published_at"]),
        destination=destination_from_json(row["destination"]),
        acknowledgement=None
        if ack is None
        else BrokerAcknowledgementReference(
            acknowledgement_reference=ack["acknowledgement_reference"],
            received_at=_dt(ack["received_at"]),
        ),
    )


# --- outbox record ---------------------------------------------------------

def outbox_record_to_row(record: OutboxRecord) -> dict[str, Any]:
    return {
        "outbox_record_id": record.outbox_record_id,
        "event_id": record.event_id,
        "event_type": record.event_type,
        "event_version": record.event_version,
        "envelope": envelope_to_json(record.envelope),
        "aggregate": aggregate_to_json(record.aggregate),
        "scope": scope_to_json(record.scope),
        "created_at": record.created_at,
        "status": record.status.value,
        "sequence_number": record.sequence_number,
        "attempts": [attempt_to_json(a) for a in record.attempts],
        "publication_evidence": evidence_to_json(record.publication_evidence),
        "retention_schedule": retention_to_json(record.retention_schedule),
        "under_legal_hold": record.under_legal_hold,
        "payload_hash": record.envelope.integrity.payload_hash,
    }


def outbox_record_from_row(row: Mapping[str, Any]) -> OutboxRecord:
    return OutboxRecord(
        outbox_record_id=row["outbox_record_id"],
        event_id=row["event_id"],
        event_type=row["event_type"],
        event_version=row["event_version"],
        envelope=envelope_from_json(row["envelope"]),
        aggregate=aggregate_from_json(row["aggregate"]),
        scope=scope_from_json(row["scope"]),
        created_at=row["created_at"],
        status=OutboxStatus(row["status"]),
        sequence_number=row["sequence_number"],
        attempts=tuple(attempt_from_json(a) for a in row["attempts"]),
        publication_evidence=evidence_from_json(row["publication_evidence"]),
        retention_schedule=retention_from_json(row["retention_schedule"]),
        under_legal_hold=row["under_legal_hold"],
    )


# --- dead letter -----------------------------------------------------------

def dead_letter_to_row(record: DeadLetterRecord) -> dict[str, Any]:
    return {
        "dead_letter_id": record.dead_letter_id,
        "event_id": record.event_id,
        "event_type": record.event_type,
        "reason_code": record.reason_code,
        "attempt_count": record.attempt_count,
        "failed_at": record.failed_at,
        "classification": {
            "classification_id": str(record.classification.classification_id),
            "tier": record.classification.tier,
        },
        "retention_schedule": retention_to_json(record.retention_schedule),
        "review_required": record.review_required,
        "failure_reference": record.failure_reference,
    }


def dead_letter_from_row(row: Mapping[str, Any]) -> DeadLetterRecord:
    return DeadLetterRecord(
        dead_letter_id=row["dead_letter_id"],
        event_id=row["event_id"],
        event_type=row["event_type"],
        reason_code=row["reason_code"],
        attempt_count=row["attempt_count"],
        failed_at=row["failed_at"],
        classification=ClassificationReference(
            classification_id=UUID(row["classification"]["classification_id"]),
            tier=row["classification"]["tier"],
        ),
        retention_schedule=retention_from_json(row["retention_schedule"]),
        review_required=row["review_required"],
        failure_reference=row["failure_reference"],
    )


# --- consumer checkpoint ---------------------------------------------------

def checkpoint_to_row(checkpoint: ConsumerCheckpoint) -> dict[str, Any]:
    return {
        "consumer_name": checkpoint.consumer_name,
        "consumer_domain": checkpoint.consumer_domain,
        "ordering_scope_key": checkpoint.ordering_scope_key,
        "position": checkpoint.position,
        "updated_at": checkpoint.updated_at,
    }


def checkpoint_from_row(row: Mapping[str, Any]) -> ConsumerCheckpoint:
    return ConsumerCheckpoint(
        consumer_name=row["consumer_name"],
        consumer_domain=row["consumer_domain"],
        ordering_scope_key=row["ordering_scope_key"],
        position=row["position"],
        updated_at=row["updated_at"],
    )
