"""The API-03 reconciliation, executable rather than narrated.

When the exact accepted API-03 arrives, the comparison is not a reading
exercise: ``compare_surfaces`` takes the surface API-04 consumed and the surface
the accepted API-03 offers and returns every difference as a typed row, in both
directions.

Until that has run against the exact accepted bytes, ``reconciliation_state``
returns ``PENDING_EXACT_ACCEPTED_API03``, and ``assert_may_freeze_lineage``
refuses to produce a final predecessor binding.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

from ..exceptions import AcceptedPredecessorClaimProhibitedError, PredecessorNotAcceptedError

PENDING = "PENDING_EXACT_ACCEPTED_API03"
RECONCILED = "RECONCILED_AGAINST_EXACT_ACCEPTED_API03"

#: The exact surface API-04 consumes from API-03. Nothing else may be used.
CONSUMED_SURFACE: Mapping[str, tuple[str, ...]] = {
    "Api03CredentialDirectory": (
        "lookup_by_peer_identity",
        "is_available",
        "revoke",
        "scopes_for",
    ),
    "Api03ServiceCredentialRecord": (
        "service_id",
        "credential_id",
        "state",
        "organization_scopes",
        "data_classifications",
        "trust_anchor",
        "not_before",
        "not_after",
        "principal_class",
    ),
    "CredentialState": ("active", "suspended", "revoked", "expired", "unknown"),
    "PrincipalClass": ("service", "human", "unknown"),
}

CHECKLIST: tuple[str, ...] = (
    "R-01 obtain the exact independently accepted API-03 archive and its SHA-256",
    "R-02 verify the archive against the governed acceptance record, not against R13",
    "R-03 extract fresh and enumerate the accepted S2S identity surface",
    "R-04 run compare_surfaces(CONSUMED_SURFACE, accepted_surface) and record every row",
    "R-05 classify each difference: NAME | SHAPE | SEMANTIC | LIFECYCLE | TRUST_ANCHOR",
    "R-06 update api03_r13_adapter.py for every SHAPE/NAME row; no other module changes",
    "R-07 re-derive the ACL matrix scopes from the accepted directory, not from R13",
    "R-08 re-run the whole API-04 suite: unit, live fixtures, mutations, validator",
    "R-09 re-run the inherited API-chain non-regression phase against the accepted tree",
    "R-10 bind the exact accepted API-03 SHA-256 into API04_LINEAGE.json",
    "R-11 regenerate the transition inventory against the accepted predecessor",
    "R-12 regenerate the sealed file manifest and SHA256SUMS",
    "R-13 set reconciliation_state to RECONCILED_AGAINST_EXACT_ACCEPTED_API03",
    "R-14 only then assemble CANDIDATE_0.1_C1 with internal status CANDIDATE_NOT_ACCEPTED",
)

REVIEW_DOES_NOT_PROVE: tuple[str, ...] = (
    "that API-03 is accepted or closed",
    "that R13 may be recorded as an accepted predecessor",
    "that R13 has been reconciled against the exact accepted API-02",
    "that the R13 S2S surface is final",
    "that any API-04 lineage may be frozen",
)


@dataclass(frozen=True, slots=True)
class SurfaceDifference:
    kind: str
    surface: str
    member: str
    detail: str


def compare_surfaces(
    consumed: Mapping[str, Iterable[str]], offered: Mapping[str, Iterable[str]]
) -> list[SurfaceDifference]:
    rows: list[SurfaceDifference] = []
    for surface, members in consumed.items():
        if surface not in offered:
            rows.append(SurfaceDifference("SURFACE_ABSENT", surface, "*", "consumed surface is not offered"))
            continue
        offered_members = set(offered[surface])
        for member in members:
            if member not in offered_members:
                rows.append(SurfaceDifference("MEMBER_ABSENT", surface, member, "consumed member is not offered"))
        for member in sorted(offered_members - set(members)):
            rows.append(SurfaceDifference("MEMBER_ADDED", surface, member, "offered member is not consumed"))
    for surface in sorted(set(offered) - set(consumed)):
        rows.append(SurfaceDifference("SURFACE_ADDED", surface, "*", "offered surface is not consumed"))
    return rows


def reconciliation_state(accepted_api03_sha256: str | None = None) -> str:
    return RECONCILED if accepted_api03_sha256 else PENDING


def assert_may_freeze_lineage(accepted_api03_sha256: str | None) -> None:
    if not accepted_api03_sha256:
        raise PredecessorNotAcceptedError(
            "final API-04 lineage requires the exact accepted API-03 SHA-256",
            detail={"reconciliation_state": PENDING},
        )


def assert_label_is_not_accepted(label: str) -> None:
    if "ACCEPTED" in label.upper():
        raise AcceptedPredecessorClaimProhibitedError(
            "API-03 R13 may not carry an accepted label", detail={"presented_label": label}
        )
