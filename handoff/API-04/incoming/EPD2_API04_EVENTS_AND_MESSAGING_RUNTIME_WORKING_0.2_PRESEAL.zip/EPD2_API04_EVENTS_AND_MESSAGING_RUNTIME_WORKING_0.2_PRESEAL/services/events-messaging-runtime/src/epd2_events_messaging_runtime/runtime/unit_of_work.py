"""The transactional boundary: domain state and its outbox record, or neither.

PACK-13 supplies the shape — `UnitOfWorkReference`, `TransactionBoundary`,
`OutboxWriter.write_within` — and refuses three things at write time: a
cross-domain write, a prohibited payload key, and an invented scope. This module
supplies the transaction those refusals sit inside, on PostgreSQL.

Two properties hold, and neither is a comment.

*No publish before commit.* The dispatcher runs on a **different connection**
and refuses the domain one. An uncommitted outbox row is therefore not "not
published yet" — it is invisible to the only code that can publish it.

*No committed state without its event, and no event without committed state.*
The unit refuses to commit when either direction is violated. Both directions,
because only one of them is the obvious one.
"""

from __future__ import annotations

import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterator

import psycopg

from epd2_data_plane_service.concurrency import (
    TransactionBoundary,
    UnitOfWorkReference,
)
from epd2_data_plane_service.domain import DomainReference, OrganizationScopeReference
from epd2_data_plane_service.outbox import OutboxRecord

from ..exceptions import MessagingRefusal
from .. import reason_codes as rc


class OutboxEventWithoutDomainWriteError(MessagingRefusal):
    """An outbox event was staged with no authoritative domain write behind it,
    or a domain write that declares an event committed without one."""

    reason_code = rc.OUTBOX_PUBLICATION_PENDING


@dataclass
class DomainUnitOfWork:
    """One domain transaction, on one connection."""

    connection: psycopg.Connection
    reference: UnitOfWorkReference
    domain: DomainReference
    declares_event: bool = True
    domain_writes: list[str] = field(default_factory=list)
    staged: list[OutboxRecord] = field(default_factory=list)

    def record_domain_write(self, description: str) -> None:
        self.domain_writes.append(description)

    def stage(self, record: OutboxRecord) -> None:
        self.reference.assert_same_domain(record.aggregate)
        self.staged.append(record)

    def _assert_consistent(self) -> None:
        if self.staged and not self.domain_writes:
            raise OutboxEventWithoutDomainWriteError(
                "an outbox event was staged without an authoritative domain write",
                detail={"domain": self.domain.domain_name, "staged": len(self.staged)},
            )
        if self.declares_event and self.domain_writes and not self.staged:
            raise OutboxEventWithoutDomainWriteError(
                "a domain write that declares an event committed without one",
                detail={"domain": self.domain.domain_name, "writes": len(self.domain_writes)},
            )


@contextmanager
def domain_unit_of_work(
    connection: psycopg.Connection,
    *,
    domain: str,
    scope: OrganizationScopeReference,
    now: datetime,
    declares_event: bool = True,
) -> Iterator[DomainUnitOfWork]:
    reference = UnitOfWorkReference(
        unit_of_work_id=uuid.uuid4(),
        boundary=TransactionBoundary(
            owning_domain=DomainReference(domain_name=domain, is_reserved_boundary=False),
            schema_name=f"dom_{domain}",
            permits_external_effect=False,
        ),
        scope=scope,
        started_at=now,
    )
    unit = DomainUnitOfWork(
        connection=connection,
        reference=reference,
        domain=reference.boundary.owning_domain,
        declares_event=declares_event,
    )
    try:
        yield unit
        unit._assert_consistent()
    except BaseException:
        connection.rollback()
        raise
    connection.commit()
