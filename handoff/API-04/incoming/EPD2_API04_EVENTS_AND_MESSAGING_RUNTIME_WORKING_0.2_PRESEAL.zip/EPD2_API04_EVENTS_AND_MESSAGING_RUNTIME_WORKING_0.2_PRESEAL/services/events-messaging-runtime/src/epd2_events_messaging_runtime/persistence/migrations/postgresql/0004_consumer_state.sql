-- EPD2 API-04 migration 0004 — consumer checkpoints, deduplication and projections
-- Kind: EXPAND. Immutable once applied: a checksum mismatch has no repair
-- path (MIGRATION_CHECKSUM_MISMATCH), exactly as PACK-13 requires.
--
-- The deduplication record is PACK-13's DeduplicationRecord made durable.
-- PACK-13's ReferenceConsumer keeps it in a process dict; a guarantee that lasts
-- exactly as long as a process is not a guarantee, so it lives here instead.


CREATE TABLE IF NOT EXISTS dom_projection.consumer_checkpoint (
    consumer_name      text NOT NULL,
    consumer_domain    text NOT NULL,
    ordering_scope_key text NOT NULL,
    position           bigint NOT NULL CHECK (position >= 0),
    updated_at         timestamptz NOT NULL,
    PRIMARY KEY (consumer_name, ordering_scope_key)
);

CREATE TABLE IF NOT EXISTS dom_projection.deduplication_record (
    consumer_domain   text NOT NULL,
    consumer_name     text NOT NULL,
    event_id          uuid NOT NULL,
    first_seen_at     timestamptz NOT NULL,
    observation_count integer NOT NULL DEFAULT 1 CHECK (observation_count >= 1),
    payload_hash      text NOT NULL,
    effect_reference  text,
    effect_result     jsonb,
    reason_code       text,
    expires_at        timestamptz NOT NULL,
    PRIMARY KEY (consumer_domain, consumer_name, event_id)
);

CREATE TABLE IF NOT EXISTS dom_projection.projection_definition (
    projection_id   uuid PRIMARY KEY,
    projection_name text NOT NULL UNIQUE,
    required_position bigint NOT NULL DEFAULT 0,
    applied_position  bigint NOT NULL DEFAULT 0,
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dom_projection.projection_row (
    projection_id uuid NOT NULL,
    row_key       text NOT NULL,
    organization_id uuid NOT NULL,
    scope_kind    text NOT NULL,
    row_version   bigint NOT NULL,
    body          jsonb NOT NULL,
    tombstoned    boolean NOT NULL DEFAULT false,
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (projection_id, row_key)
);

CREATE TABLE IF NOT EXISTS dom_notification.consumer_checkpoint (
    consumer_name      text NOT NULL,
    consumer_domain    text NOT NULL,
    ordering_scope_key text NOT NULL,
    position           bigint NOT NULL CHECK (position >= 0),
    updated_at         timestamptz NOT NULL,
    PRIMARY KEY (consumer_name, ordering_scope_key)
);

CREATE TABLE IF NOT EXISTS dom_notification.deduplication_record (
    consumer_domain   text NOT NULL,
    consumer_name     text NOT NULL,
    event_id          uuid NOT NULL,
    first_seen_at     timestamptz NOT NULL,
    observation_count integer NOT NULL DEFAULT 1 CHECK (observation_count >= 1),
    payload_hash      text NOT NULL,
    effect_reference  text,
    effect_result     jsonb,
    reason_code       text,
    expires_at        timestamptz NOT NULL,
    PRIMARY KEY (consumer_domain, consumer_name, event_id)
);

CREATE TABLE IF NOT EXISTS dom_notification.projection_definition (
    projection_id   uuid PRIMARY KEY,
    projection_name text NOT NULL UNIQUE,
    required_position bigint NOT NULL DEFAULT 0,
    applied_position  bigint NOT NULL DEFAULT 0,
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dom_notification.projection_row (
    projection_id uuid NOT NULL,
    row_key       text NOT NULL,
    organization_id uuid NOT NULL,
    scope_kind    text NOT NULL,
    row_version   bigint NOT NULL,
    body          jsonb NOT NULL,
    tombstoned    boolean NOT NULL DEFAULT false,
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (projection_id, row_key)
);

CREATE TABLE IF NOT EXISTS dom_governance.consumer_checkpoint (
    consumer_name      text NOT NULL,
    consumer_domain    text NOT NULL,
    ordering_scope_key text NOT NULL,
    position           bigint NOT NULL CHECK (position >= 0),
    updated_at         timestamptz NOT NULL,
    PRIMARY KEY (consumer_name, ordering_scope_key)
);

CREATE TABLE IF NOT EXISTS dom_governance.deduplication_record (
    consumer_domain   text NOT NULL,
    consumer_name     text NOT NULL,
    event_id          uuid NOT NULL,
    first_seen_at     timestamptz NOT NULL,
    observation_count integer NOT NULL DEFAULT 1 CHECK (observation_count >= 1),
    payload_hash      text NOT NULL,
    effect_reference  text,
    effect_result     jsonb,
    reason_code       text,
    expires_at        timestamptz NOT NULL,
    PRIMARY KEY (consumer_domain, consumer_name, event_id)
);

CREATE TABLE IF NOT EXISTS dom_governance.projection_definition (
    projection_id   uuid PRIMARY KEY,
    projection_name text NOT NULL UNIQUE,
    required_position bigint NOT NULL DEFAULT 0,
    applied_position  bigint NOT NULL DEFAULT 0,
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dom_governance.projection_row (
    projection_id uuid NOT NULL,
    row_key       text NOT NULL,
    organization_id uuid NOT NULL,
    scope_kind    text NOT NULL,
    row_version   bigint NOT NULL,
    body          jsonb NOT NULL,
    tombstoned    boolean NOT NULL DEFAULT false,
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (projection_id, row_key)
);

CREATE TABLE IF NOT EXISTS dom_casework.consumer_checkpoint (
    consumer_name      text NOT NULL,
    consumer_domain    text NOT NULL,
    ordering_scope_key text NOT NULL,
    position           bigint NOT NULL CHECK (position >= 0),
    updated_at         timestamptz NOT NULL,
    PRIMARY KEY (consumer_name, ordering_scope_key)
);

CREATE TABLE IF NOT EXISTS dom_casework.deduplication_record (
    consumer_domain   text NOT NULL,
    consumer_name     text NOT NULL,
    event_id          uuid NOT NULL,
    first_seen_at     timestamptz NOT NULL,
    observation_count integer NOT NULL DEFAULT 1 CHECK (observation_count >= 1),
    payload_hash      text NOT NULL,
    effect_reference  text,
    effect_result     jsonb,
    reason_code       text,
    expires_at        timestamptz NOT NULL,
    PRIMARY KEY (consumer_domain, consumer_name, event_id)
);

CREATE TABLE IF NOT EXISTS dom_casework.projection_definition (
    projection_id   uuid PRIMARY KEY,
    projection_name text NOT NULL UNIQUE,
    required_position bigint NOT NULL DEFAULT 0,
    applied_position  bigint NOT NULL DEFAULT 0,
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dom_casework.projection_row (
    projection_id uuid NOT NULL,
    row_key       text NOT NULL,
    organization_id uuid NOT NULL,
    scope_kind    text NOT NULL,
    row_version   bigint NOT NULL,
    body          jsonb NOT NULL,
    tombstoned    boolean NOT NULL DEFAULT false,
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (projection_id, row_key)
);

CREATE TABLE IF NOT EXISTS dom_audit.consumer_checkpoint (
    consumer_name      text NOT NULL,
    consumer_domain    text NOT NULL,
    ordering_scope_key text NOT NULL,
    position           bigint NOT NULL CHECK (position >= 0),
    updated_at         timestamptz NOT NULL,
    PRIMARY KEY (consumer_name, ordering_scope_key)
);

CREATE TABLE IF NOT EXISTS dom_audit.deduplication_record (
    consumer_domain   text NOT NULL,
    consumer_name     text NOT NULL,
    event_id          uuid NOT NULL,
    first_seen_at     timestamptz NOT NULL,
    observation_count integer NOT NULL DEFAULT 1 CHECK (observation_count >= 1),
    payload_hash      text NOT NULL,
    effect_reference  text,
    effect_result     jsonb,
    reason_code       text,
    expires_at        timestamptz NOT NULL,
    PRIMARY KEY (consumer_domain, consumer_name, event_id)
);

CREATE TABLE IF NOT EXISTS dom_audit.projection_definition (
    projection_id   uuid PRIMARY KEY,
    projection_name text NOT NULL UNIQUE,
    required_position bigint NOT NULL DEFAULT 0,
    applied_position  bigint NOT NULL DEFAULT 0,
    updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dom_audit.projection_row (
    projection_id uuid NOT NULL,
    row_key       text NOT NULL,
    organization_id uuid NOT NULL,
    scope_kind    text NOT NULL,
    row_version   bigint NOT NULL,
    body          jsonb NOT NULL,
    tombstoned    boolean NOT NULL DEFAULT false,
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (projection_id, row_key)
);
