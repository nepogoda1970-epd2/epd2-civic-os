-- EPD2 API-04 migration 0002 — per-domain transactional outbox
-- Kind: EXPAND. Immutable once applied: a checksum mismatch has no repair
-- path (MIGRATION_CHECKSUM_MISMATCH), exactly as PACK-13 requires.
--
-- The row shape is a serialisation of epd2_data_plane_service.outbox.OutboxRecord.
-- Every column name below is one of that record's own field names.


CREATE TABLE IF NOT EXISTS dom_membership.outbox_record (
    outbox_record_id     uuid PRIMARY KEY,
    event_id             uuid NOT NULL UNIQUE,
    event_type           text NOT NULL,
    event_version        text NOT NULL,
    envelope             jsonb NOT NULL,
    aggregate            jsonb NOT NULL,
    scope                jsonb NOT NULL,
    created_at           timestamptz NOT NULL,
    status               text NOT NULL
                         CHECK (status IN ('pending','dispatching','published','acknowledged',
                                           'failed','dead_lettered','superseded_by_replay')),
    sequence_number      bigint NOT NULL CHECK (sequence_number >= 1),
    attempts             jsonb NOT NULL DEFAULT '[]'::jsonb,
    publication_evidence jsonb,
    retention_schedule   jsonb,
    under_legal_hold     boolean NOT NULL DEFAULT false,
    payload_hash         text NOT NULL,
    next_attempt_at      timestamptz NOT NULL DEFAULT now(),
    lease_id             uuid,
    lease_holder         text,
    lease_expires_at     timestamptz,
    CONSTRAINT dom_membership_outbox_lease_consistent
        CHECK ((lease_id IS NULL) = (lease_holder IS NULL))
);

CREATE TABLE IF NOT EXISTS dom_organization.outbox_record (
    outbox_record_id     uuid PRIMARY KEY,
    event_id             uuid NOT NULL UNIQUE,
    event_type           text NOT NULL,
    event_version        text NOT NULL,
    envelope             jsonb NOT NULL,
    aggregate            jsonb NOT NULL,
    scope                jsonb NOT NULL,
    created_at           timestamptz NOT NULL,
    status               text NOT NULL
                         CHECK (status IN ('pending','dispatching','published','acknowledged',
                                           'failed','dead_lettered','superseded_by_replay')),
    sequence_number      bigint NOT NULL CHECK (sequence_number >= 1),
    attempts             jsonb NOT NULL DEFAULT '[]'::jsonb,
    publication_evidence jsonb,
    retention_schedule   jsonb,
    under_legal_hold     boolean NOT NULL DEFAULT false,
    payload_hash         text NOT NULL,
    next_attempt_at      timestamptz NOT NULL DEFAULT now(),
    lease_id             uuid,
    lease_holder         text,
    lease_expires_at     timestamptz,
    CONSTRAINT dom_organization_outbox_lease_consistent
        CHECK ((lease_id IS NULL) = (lease_holder IS NULL))
);

CREATE TABLE IF NOT EXISTS dom_compliance.outbox_record (
    outbox_record_id     uuid PRIMARY KEY,
    event_id             uuid NOT NULL UNIQUE,
    event_type           text NOT NULL,
    event_version        text NOT NULL,
    envelope             jsonb NOT NULL,
    aggregate            jsonb NOT NULL,
    scope                jsonb NOT NULL,
    created_at           timestamptz NOT NULL,
    status               text NOT NULL
                         CHECK (status IN ('pending','dispatching','published','acknowledged',
                                           'failed','dead_lettered','superseded_by_replay')),
    sequence_number      bigint NOT NULL CHECK (sequence_number >= 1),
    attempts             jsonb NOT NULL DEFAULT '[]'::jsonb,
    publication_evidence jsonb,
    retention_schedule   jsonb,
    under_legal_hold     boolean NOT NULL DEFAULT false,
    payload_hash         text NOT NULL,
    next_attempt_at      timestamptz NOT NULL DEFAULT now(),
    lease_id             uuid,
    lease_holder         text,
    lease_expires_at     timestamptz,
    CONSTRAINT dom_compliance_outbox_lease_consistent
        CHECK ((lease_id IS NULL) = (lease_holder IS NULL))
);

-- The published event is immutable. A retry re-publishes the same bytes under the
-- same logical event id; it never rewrites them. This is a trigger and not a
-- convention, so the refusal survives a caller that forgets.
CREATE OR REPLACE FUNCTION api04_gov.refuse_outbox_event_mutation()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.event_id IS DISTINCT FROM OLD.event_id
       OR NEW.envelope IS DISTINCT FROM OLD.envelope
       OR NEW.payload_hash IS DISTINCT FROM OLD.payload_hash
       OR NEW.event_type IS DISTINCT FROM OLD.event_type
       OR NEW.event_version IS DISTINCT FROM OLD.event_version
       OR NEW.aggregate IS DISTINCT FROM OLD.aggregate
       OR NEW.created_at IS DISTINCT FROM OLD.created_at
       OR NEW.sequence_number IS DISTINCT FROM OLD.sequence_number THEN
        RAISE EXCEPTION 'SCHEMA_VERSION_IDENTITY_IMMUTABLE';
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_membership_outbox_immutable ON dom_membership.outbox_record;
CREATE TRIGGER trg_membership_outbox_immutable
    BEFORE UPDATE ON dom_membership.outbox_record
    FOR EACH ROW EXECUTE FUNCTION api04_gov.refuse_outbox_event_mutation();

DROP TRIGGER IF EXISTS trg_organization_outbox_immutable ON dom_organization.outbox_record;
CREATE TRIGGER trg_organization_outbox_immutable
    BEFORE UPDATE ON dom_organization.outbox_record
    FOR EACH ROW EXECUTE FUNCTION api04_gov.refuse_outbox_event_mutation();

DROP TRIGGER IF EXISTS trg_compliance_outbox_immutable ON dom_compliance.outbox_record;
CREATE TRIGGER trg_compliance_outbox_immutable
    BEFORE UPDATE ON dom_compliance.outbox_record
    FOR EACH ROW EXECUTE FUNCTION api04_gov.refuse_outbox_event_mutation();
