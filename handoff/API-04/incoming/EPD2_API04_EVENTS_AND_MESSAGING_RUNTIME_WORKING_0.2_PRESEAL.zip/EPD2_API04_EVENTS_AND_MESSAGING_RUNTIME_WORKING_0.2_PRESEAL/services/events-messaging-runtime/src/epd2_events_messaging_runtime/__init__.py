"""EPD2 API-04 — Events & Messaging Runtime.

```text
STATUS  PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED
```

This service is a set of **production adapters behind PACK-13's unchanged
ports**, plus the two things PACK-13 deliberately left out because it had no
transport layer: a service-identity boundary and a governed topic topology.

    epd2_data_plane_service.delivery.BrokerPort   ← transport.rabbitmq
    epd2_data_plane_service.storage.OutboxStore   ← persistence.postgres_stores
    …IdempotencyStore, ConsumerCheckpointStore,
     DeadLetterStore, AggregateVersionStore,
     ProjectionStore                              ← persistence.postgres_stores

Nothing in `services/data-plane-service` is modified by this service, and
nothing here re-implements a decision PACK-13 already makes: ordering comes from
`assess_ordering`, dispatch from `decide_dispatch`, retry from `RetryPolicy`,
idempotency from `IdempotencyPolicy`, lag banding from `lag_band_for`, and the
payload-minimality refusal from `reject_prohibited_payload_keys`.

The delivery contract is PACK-13's, restated and not strengthened:

    at-least-once delivery + effectively-once consumer effect
"""

from __future__ import annotations

__all__ = ["STATUS", "VERSION", "CANONICAL_PORTS"]

STATUS = "PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED"
VERSION = "0.2.0-preseal"

#: Every PACK-13 seam this service implements or drives. The unit suite asserts
#: each name still resolves in the carried data-plane package, so a port that is
#: renamed upstream fails here as a test rather than as a silent divergence.
CANONICAL_PORTS: tuple[str, ...] = (
    "epd2_data_plane_service.delivery:BrokerPort",
    "epd2_data_plane_service.delivery:ReferenceDispatcher",
    "epd2_data_plane_service.delivery:ReferenceConsumer",
    "epd2_data_plane_service.delivery:RetryPolicy",
    "epd2_data_plane_service.delivery:decide_dispatch",
    "epd2_data_plane_service.delivery:assess_ordering",
    "epd2_data_plane_service.delivery:require_in_order",
    "epd2_data_plane_service.delivery:lag_band_for",
    "epd2_data_plane_service.delivery:ConsumerCheckpoint",
    "epd2_data_plane_service.delivery:DeadLetterRecord",
    "epd2_data_plane_service.delivery:ReplayReference",
    "epd2_data_plane_service.delivery:replay_preserves_history",
    "epd2_data_plane_service.outbox:OutboxRecord",
    "epd2_data_plane_service.outbox:OutboxWriter",
    "epd2_data_plane_service.outbox:OutboxStatus",
    "epd2_data_plane_service.outbox:DestinationReference",
    "epd2_data_plane_service.storage:OutboxStore",
    "epd2_data_plane_service.storage:IdempotencyStore",
    "epd2_data_plane_service.storage:ConsumerCheckpointStore",
    "epd2_data_plane_service.storage:DeadLetterStore",
    "epd2_data_plane_service.storage:AggregateVersionStore",
    "epd2_data_plane_service.storage:ProjectionStore",
    "epd2_data_plane_service.idempotency:IdempotencyPolicy",
    "epd2_data_plane_service.idempotency:IdempotencyKey",
    "epd2_data_plane_service.idempotency:DeduplicationRecord",
    "epd2_data_plane_service.concurrency:ConcurrencyPolicy",
    "epd2_data_plane_service.concurrency:UnitOfWorkReference",
    "epd2_data_plane_service.domain:reject_prohibited_payload_keys",
    "epd2_core.event_envelope:build_event_envelope",
)
