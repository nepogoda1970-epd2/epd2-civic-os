"""Governed re-drive of a dead letter.

PACK-13 governs *replay*; it has no dead-letter re-drive, because it has no
transport to re-drive onto. This is therefore additive, and it is written to the
same discipline: one item, one target, evidence before the message moves.

There is no `requeue all`. `redrive_bulk` exists only to raise
`REDRIVE_BULK_UNBOUNDED_PROHIBITED`.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Mapping

import psycopg

from .. import reason_codes as rc
from ..exceptions import (
    RedriveAuthorityMissingError,
    RedriveBulkUnboundedProhibitedError,
    RedriveTargetMismatchError,
)


@dataclass(frozen=True, slots=True)
class RedriveAuthority:
    operator_principal: str
    authority_reference: str
    reason: str

    def validate(self) -> None:
        if not self.operator_principal or not self.authority_reference or not self.reason.strip():
            raise RedriveAuthorityMissingError(
                "a re-drive requires an operator principal, an authority reference and a reason",
                detail={"has_operator": bool(self.operator_principal)},
            )


@dataclass(frozen=True, slots=True)
class RedriveRequest:
    dead_letter_id: uuid.UUID
    target_subscription: str
    authority: RedriveAuthority


def redrive_bulk(*_: Any, **__: Any) -> None:
    raise RedriveBulkUnboundedProhibitedError("there is no unbounded requeue-all path")


def perform_redrive(
    connection: psycopg.Connection,
    request: RedriveRequest,
    *,
    dead_letters: Any,
    schema_compatibility: Callable[[str, str], str],
    authorization_check: Callable[[Mapping[str, Any]], str],
    state_check: Callable[[Mapping[str, Any]], str],
    republish: Callable[[Mapping[str, Any]], str],
) -> uuid.UUID:
    request.authority.validate()

    item = dead_letters.raw(request.dead_letter_id)
    if item["subscription_id"] != request.target_subscription:
        raise RedriveTargetMismatchError(
            "a dead letter may only be re-driven to its own subscription",
            detail={
                "dead_letter_subscription": item["subscription_id"],
                "requested_target": request.target_subscription,
            },
        )
    if item["redriven"]:
        raise RedriveTargetMismatchError(
            "this dead letter was already re-driven",
            detail={"dead_letter_id": str(request.dead_letter_id)},
        )

    compatibility = schema_compatibility(item["event_type"], item["envelope_reference"].get("event_version", ""))
    authorization = authorization_check(item)
    state = state_check(item)

    blocked = [
        name
        for name, value in (("schema", compatibility), ("authorization", authorization), ("state", state))
        if value not in ("compatible", "authorized", "current", "not_applicable")
    ]
    reference = uuid.uuid4()
    outcome = rc.REDRIVE_RECORDED if not blocked else rc.REDRIVE_AUTHORITY_MISSING

    with connection.cursor() as cur:
        cur.execute(
            """
            INSERT INTO api04_gov.redrive_record (
                redrive_reference, dead_letter_id, operator_principal, authority_reference,
                reason, target_subscription, intended_range, schema_compatibility,
                authorization_result, state_result, outcome_reason_code
            ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """,
            (
                reference, request.dead_letter_id, request.authority.operator_principal,
                request.authority.authority_reference, request.authority.reason,
                request.target_subscription,
                json.dumps({"kind": "single_item", "dead_letter_id": str(request.dead_letter_id)}),
                compatibility, authorization, state, outcome,
            ),
        )
    connection.commit()

    if blocked:
        raise RedriveAuthorityMissingError(
            "re-drive refused by a current-state check; the evaluation is recorded",
            detail={"blocked_by": blocked, "redrive_reference": str(reference)},
        )

    republish(item)
    dead_letters.mark_redriven(request.dead_letter_id)
    connection.commit()
    return reference
