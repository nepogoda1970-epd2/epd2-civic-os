"""The API-03 R13 adapter — working integration predecessor, and nothing more.

```text
API-03 R13 = WORKING_INTEGRATION_PREDECESSOR
API-03 R13 is not, and may not be recorded as, an accepted predecessor
```

R13 is externally reviewed: GitHub Actions run ``33280355709``, branch
``review/api03-r13-external``, head ``5904ef7212b368f3e734f8be54f5c63f374ea503``,
conclusion ``SUCCESS``. That review is evidence that a fresh extraction of R13
passes its own V24 validator. It is not an acceptance decision, and API-03's own
handoff forbids treating it as one before reconciliation with the exact accepted
API-02.

The exact R13 archive is **not present in this authoring environment**. What
this adapter binds is therefore the R13 *interface contract* as the handoff
documents it — service identity, service authentication, S2S authorization,
credential lifecycle, trust boundaries — through a directory port that the real
R13 runtime satisfies. ``binding_state`` records that rather than implying more.

The adapter implements no authorization rule. It answers "who is this peer, and
is its credential currently good?". Whether that peer may publish to a topic is
``topology.acl``'s question; whether the resulting domain effect is permitted is
the owning domain's, and for consequential effects it is asked again at the
commit point.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping, Protocol

from ..exceptions import (
    AcceptedPredecessorClaimProhibitedError,
    PredecessorNotAcceptedError,
    ServiceIdentityNotVerifiedError,
    ServiceIdentityUnavailableError,
)
from .port import (
    CredentialState,
    PrincipalClass,
    ServiceIdentityPort,
    TransportCredential,
    VerifiedServicePrincipal,
)

#: The external review, carried verbatim as *review* evidence.
API03_R13_REVIEW_EVIDENCE: Mapping[str, str] = {
    "run_id": "33280355709",
    "workflow": "API-03 R13 external governed review",
    "branch": "review/api03-r13-external",
    "head_sha": "5904ef7212b368f3e734f8be54f5c63f374ea503",
    "conclusion": "SUCCESS",
    "artifact": "api03-r13-external-review-33280355709",
    "artifact_id": "9722794132",
    "artifact_sha256": "1f10da8aff6d4966ba018c7105d5dcabdd75430644a4fe6d281b323633cb6e40",
    "archive_name": "API 03_R13.zip",
    "archive_size_bytes": "40735799",
}

WORKING_INTEGRATION_PREDECESSOR = "WORKING_INTEGRATION_PREDECESSOR"


@dataclass(frozen=True, slots=True)
class Api03ServiceCredentialRecord:
    """One row of the API-03 service-credential directory."""

    service_id: str
    credential_id: str
    state: CredentialState
    organization_scopes: frozenset[str]
    data_classifications: frozenset[str]
    trust_anchor: str
    not_before: datetime
    not_after: datetime
    principal_class: PrincipalClass = PrincipalClass.SERVICE


class Api03CredentialDirectory(Protocol):
    """The R13 surface API-04 consumes. Four methods, no more."""

    def lookup_by_peer_identity(self, peer_identity: str) -> Api03ServiceCredentialRecord | None: ...

    def is_available(self) -> bool: ...

    def revoke(self, credential_id: str) -> None: ...

    def scopes_for(self, service_id: str) -> frozenset[str]: ...


class Api03R13ServiceIdentityAdapter(ServiceIdentityPort):
    binding_state = "API03_R13_WORKING_INTEGRATION_PREDECESSOR"

    def __init__(
        self,
        directory: Api03CredentialDirectory,
        *,
        clock: Any,
        predecessor_label: str = WORKING_INTEGRATION_PREDECESSOR,
    ) -> None:
        if "ACCEPTED" in predecessor_label.upper() or "CLOSED" in predecessor_label.upper():
            raise AcceptedPredecessorClaimProhibitedError(
                "API-03 R13 may not be recorded as an accepted predecessor",
                detail={"presented_label": predecessor_label},
            )
        if predecessor_label != WORKING_INTEGRATION_PREDECESSOR:
            raise PredecessorNotAcceptedError(
                "unknown predecessor label", detail={"presented_label": predecessor_label}
            )
        self._directory = directory
        self._clock = clock
        self.predecessor_label = predecessor_label

    def _verify_transport_credential(
        self, credential: TransportCredential, *, purpose: str
    ) -> VerifiedServicePrincipal:
        if not self._directory.is_available():
            raise ServiceIdentityUnavailableError(
                "the API-03 credential directory is unavailable", detail={"purpose": purpose}
            )
        record = self._directory.lookup_by_peer_identity(credential.peer_identity)
        if record is None:
            raise ServiceIdentityNotVerifiedError(
                "no API-03 service credential matches this transport peer",
                detail={"purpose": purpose, "authenticated_by": credential.authenticated_by},
            )
        now = self._clock.now_utc()
        state = record.state
        if state is CredentialState.ACTIVE and not (record.not_before <= now <= record.not_after):
            state = CredentialState.EXPIRED
        principal = VerifiedServicePrincipal(
            service_id=record.service_id,
            credential_id=record.credential_id,
            credential_state=state,
            principal_class=record.principal_class,
            organization_scopes=record.organization_scopes,
            data_classifications=record.data_classifications,
            trust_anchor=record.trust_anchor,
            not_before=record.not_before,
            not_after=record.not_after,
            verified_at=now,
            source_boundary=self.binding_state,
            attributes={"predecessor_label": self.predecessor_label},
        )
        return principal.require_active(purpose)

    def is_available(self) -> bool:
        return self._directory.is_available()


class StandInApi03CredentialDirectory:
    """A directory that behaves as the R13 contract says a directory behaves.

    Used where the exact R13 archive is absent. It is a **stand-in for the
    predecessor**, not a second identity service, and it implements the lifecycle
    transitions the reconciliation has to re-verify against the real thing:
    active, suspended, revoked, expired, unknown.
    """

    def __init__(self, records: Mapping[str, Api03ServiceCredentialRecord] | None = None) -> None:
        self._by_peer: dict[str, Api03ServiceCredentialRecord] = dict(records or {})
        self._available = True

    def add(self, peer_identity: str, record: Api03ServiceCredentialRecord) -> None:
        self._by_peer[peer_identity] = record

    def lookup_by_peer_identity(self, peer_identity: str) -> Api03ServiceCredentialRecord | None:
        return self._by_peer.get(peer_identity)

    def is_available(self) -> bool:
        return self._available

    def set_available(self, value: bool) -> None:
        self._available = value

    def set_state(self, credential_id: str, state: CredentialState) -> None:
        for peer, record in list(self._by_peer.items()):
            if record.credential_id == credential_id:
                self._by_peer[peer] = Api03ServiceCredentialRecord(
                    service_id=record.service_id,
                    credential_id=record.credential_id,
                    state=state,
                    organization_scopes=record.organization_scopes,
                    data_classifications=record.data_classifications,
                    trust_anchor=record.trust_anchor,
                    not_before=record.not_before,
                    not_after=record.not_after,
                    principal_class=record.principal_class,
                )

    def revoke(self, credential_id: str) -> None:
        self.set_state(credential_id, CredentialState.REVOKED)

    def scopes_for(self, service_id: str) -> frozenset[str]:
        for record in self._by_peer.values():
            if record.service_id == service_id:
                return record.organization_scopes
        return frozenset()


def utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, tzinfo=timezone.utc)
