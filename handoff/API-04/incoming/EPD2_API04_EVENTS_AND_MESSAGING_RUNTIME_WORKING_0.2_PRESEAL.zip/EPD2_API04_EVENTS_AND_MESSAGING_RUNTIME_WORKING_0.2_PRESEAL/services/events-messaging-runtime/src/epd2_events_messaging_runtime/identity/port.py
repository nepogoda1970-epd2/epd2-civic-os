"""The service-identity port — API-04's whole view of API-03.

PACK-13 has no such port, and deliberately: it models no transport, so it never
needs to know who is on the other end of one. API-04 does, which is why this is
additive rather than a re-implementation.

The load-bearing decision is a **type** decision, not a check. ``verify``
accepts a ``TransportCredential`` and nothing else. A ``TransportCredential`` can
only be produced by a transport that authenticated its peer. A message body, an
AMQP header and an envelope field cannot produce one, because the two types that
model those — ``MessageAssertedIdentity`` and ``HumanCredential`` — are separate
classes with no conversion, and ``verify`` refuses them by type before it reads
any value.

That is why "trust a message-supplied producer" is not a defect this runtime can
acquire by forgetting an ``if``: there is no code path that turns a message field
into a principal.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any, Mapping

from ..exceptions import (
    HumanCredentialAsServiceIdentityError,
    ServiceCredentialExpiredError,
    ServiceCredentialRevokedError,
    ServiceIdentityAssertedByMessageError,
    ServiceIdentityNotVerifiedError,
    ServiceIdentityUnavailableError,
)


class PrincipalClass(StrEnum):
    SERVICE = "service"
    HUMAN = "human"
    UNKNOWN = "unknown"


class CredentialState(StrEnum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    REVOKED = "revoked"
    EXPIRED = "expired"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class TransportCredential:
    """Evidence that *the transport* authenticated this peer.

    ``authenticated_by`` names the mechanism; ``peer_identity`` is whatever it
    proved. Neither is an authorization decision — both are inputs to API-03,
    which owns the decision.
    """

    authenticated_by: str
    peer_identity: str
    connection_reference: str
    presented_at: datetime

    def __post_init__(self) -> None:
        if not self.authenticated_by or not self.peer_identity:
            raise ServiceIdentityNotVerifiedError("a transport credential names its mechanism and its peer")


@dataclass(frozen=True, slots=True)
class MessageAssertedIdentity:
    """Identity a *message* claims. Never authoritative. A type, so the refusal
    is structural rather than a remembered check."""

    claimed_service: str
    source: str = "message"


@dataclass(frozen=True, slots=True)
class HumanCredential:
    """A human or member session credential. Never a service identity."""

    credential_reference: str
    assurance: str = "unknown"


@dataclass(frozen=True, slots=True)
class VerifiedServicePrincipal:
    """The result of API-03 verification: the only identity this runtime uses."""

    service_id: str
    credential_id: str
    credential_state: CredentialState
    principal_class: PrincipalClass
    organization_scopes: frozenset[str]
    data_classifications: frozenset[str]
    trust_anchor: str
    not_before: datetime
    not_after: datetime
    verified_at: datetime
    source_boundary: str
    attributes: Mapping[str, Any] = field(default_factory=dict)

    def require_active(self, purpose: str) -> "VerifiedServicePrincipal":
        if self.credential_state is CredentialState.REVOKED:
            raise ServiceCredentialRevokedError(
                f"credential revoked; {purpose} refused",
                detail={"service_id": self.service_id, "purpose": purpose},
            )
        if self.credential_state is CredentialState.EXPIRED:
            raise ServiceCredentialExpiredError(
                f"credential expired; {purpose} refused",
                detail={"service_id": self.service_id, "purpose": purpose},
            )
        if self.credential_state is not CredentialState.ACTIVE:
            raise ServiceIdentityNotVerifiedError(
                f"credential state {self.credential_state.value}; {purpose} refused",
                detail={"service_id": self.service_id, "purpose": purpose},
            )
        if self.principal_class is not PrincipalClass.SERVICE:
            raise HumanCredentialAsServiceIdentityError(
                f"principal class {self.principal_class.value} is not a service",
                detail={"service_id": self.service_id, "purpose": purpose},
            )
        return self


class ServiceIdentityPort(ABC):
    binding_state: str = "UNBOUND"

    def verify(self, credential: Any, *, purpose: str) -> VerifiedServicePrincipal:
        """Type gate first, adapter second."""
        if isinstance(credential, MessageAssertedIdentity):
            raise ServiceIdentityAssertedByMessageError(
                "a message may not assert its own producer identity",
                detail={"purpose": purpose, "source": credential.source},
            )
        if isinstance(credential, HumanCredential):
            raise HumanCredentialAsServiceIdentityError(
                "a human credential is not a service identity", detail={"purpose": purpose}
            )
        if not isinstance(credential, TransportCredential):
            raise ServiceIdentityNotVerifiedError(
                f"{type(credential).__name__} is not transport-authenticated evidence",
                detail={"purpose": purpose, "presented_type": type(credential).__name__},
            )
        return self._verify_transport_credential(credential, purpose=purpose)

    @abstractmethod
    def _verify_transport_credential(
        self, credential: TransportCredential, *, purpose: str
    ) -> VerifiedServicePrincipal: ...

    @abstractmethod
    def is_available(self) -> bool:
        """Readiness input. Unavailable identity means NOT READY, never open."""


class RefusingServiceIdentityPort(ServiceIdentityPort):
    """The default binding. An unbound identity port refuses; it never allows."""

    binding_state = "REFUSING_UNBOUND"

    def _verify_transport_credential(
        self, credential: TransportCredential, *, purpose: str
    ) -> VerifiedServicePrincipal:
        raise ServiceIdentityUnavailableError(
            "no API-03 service-identity adapter is bound", detail={"purpose": purpose}
        )

    def is_available(self) -> bool:
        return False
