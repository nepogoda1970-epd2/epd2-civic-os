"""FIR-READY-001 — machine-readable readiness.

```text
process alive != service ready
service ready != authoritatively ready
port open     != safe for consequential traffic
```

Two levels, because they are not the same question. `ready` means the runtime
may carry ordinary traffic. `authoritatively_ready` means it may carry
consequential traffic, which additionally requires every consumer's lag band to
be within its declared ceiling and every projection watermark to be at or past
its required position.

Blocking codes are PACK-13's wherever PACK-13 has one — `CONSUMER_NOT_READY`,
`PROJECTION_STALE`, `SCHEMA_REGISTRY_UNAVAILABLE`, `BROKER_UNAVAILABLE`,
`DATAPLANE_DATABASE_UNAVAILABLE` — so an operator sees the same code here as
elsewhere for the same fact.

The API-03 reconciliation state appears in a **third** list. It does not block
the working runtime; it blocks final lineage, and the snapshot says which.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from typing import Any, Mapping

import psycopg

from .. import reason_codes as rc


@dataclass
class ReadinessSignals:
    broker_connected: bool = False
    broker_version_pinned: bool = False
    topology_matches_register: bool = False
    identity_available: bool = False
    canonical_catalogue_loaded: bool = False
    migrations_complete: bool = False
    dispatcher_healthy: bool = False
    oldest_unacknowledged_seconds: float | None = None
    lag_bands: Mapping[str, str] = field(default_factory=dict)
    lag_ceilings: Mapping[str, str] = field(default_factory=dict)
    lag_breached: tuple[str, ...] = ()
    projection_watermarks: Mapping[str, tuple[int, int]] = field(default_factory=dict)
    open_dead_letters: int = 0
    dead_letter_blocking_threshold: int = 25
    reconciliation_state: str = "PENDING_EXACT_ACCEPTED_API03"


@dataclass(frozen=True, slots=True)
class ReadinessSnapshot:
    ready: bool
    authoritatively_ready: bool
    blocking_reason_codes: tuple[str, ...]
    consequential_blocking_reason_codes: tuple[str, ...]
    lineage_blocking_reason_codes: tuple[str, ...]
    signals: Mapping[str, Any]

    def as_json(self) -> dict[str, Any]:
        return {
            "ready": self.ready,
            "authoritatively_ready": self.authoritatively_ready,
            "blocking_reason_codes": list(self.blocking_reason_codes),
            "consequential_blocking_reason_codes": list(self.consequential_blocking_reason_codes),
            "lineage_blocking_reason_codes": list(self.lineage_blocking_reason_codes),
            "signals": dict(self.signals),
        }


def evaluate(signals: ReadinessSignals) -> ReadinessSnapshot:
    blocking: list[str] = []
    if not signals.broker_connected:
        blocking.append(rc.BROKER_UNAVAILABLE)
    if signals.broker_connected and not signals.broker_version_pinned:
        blocking.append(rc.BROKER_VERSION_NOT_PINNED)
    if not signals.topology_matches_register:
        blocking.append(rc.TOPIC_REGISTRY_RUNTIME_DRIFT)
    if not signals.identity_available:
        blocking.append(rc.SERVICE_IDENTITY_UNAVAILABLE)
    if not signals.canonical_catalogue_loaded:
        blocking.append(rc.EVENT_TYPE_NOT_IN_CANONICAL_CATALOGUE)
    if not signals.migrations_complete:
        blocking.append(rc.DATAPLANE_DATABASE_UNAVAILABLE)
    if not signals.dispatcher_healthy:
        blocking.append(rc.CONSUMER_NOT_READY)
    if signals.open_dead_letters >= signals.dead_letter_blocking_threshold:
        blocking.append(rc.EVENT_DEAD_LETTER_REQUIRED)

    consequential: list[str] = []
    if signals.lag_breached:
        consequential.append(rc.CONSUMER_NOT_READY)
    for name, (applied, required) in signals.projection_watermarks.items():
        if applied < required:
            consequential.append(rc.PROJECTION_STALE)
            break

    lineage: list[str] = []
    if signals.reconciliation_state != "RECONCILED_AGAINST_EXACT_ACCEPTED_API03":
        lineage.append(rc.PREDECESSOR_NOT_ACCEPTED)

    ready = not blocking
    return ReadinessSnapshot(
        ready=ready,
        authoritatively_ready=ready and not consequential,
        blocking_reason_codes=tuple(blocking),
        consequential_blocking_reason_codes=tuple(dict.fromkeys(consequential)),
        lineage_blocking_reason_codes=tuple(lineage),
        signals={
            "broker_connected": signals.broker_connected,
            "broker_version_pinned": signals.broker_version_pinned,
            "topology_matches_register": signals.topology_matches_register,
            "identity_available": signals.identity_available,
            "canonical_catalogue_loaded": signals.canonical_catalogue_loaded,
            "migrations_complete": signals.migrations_complete,
            "dispatcher_healthy": signals.dispatcher_healthy,
            "oldest_unacknowledged_seconds": signals.oldest_unacknowledged_seconds,
            "lag_bands": dict(signals.lag_bands),
            "lag_ceilings": dict(signals.lag_ceilings),
            "lag_breached": list(signals.lag_breached),
            "projection_watermarks": {k: list(v) for k, v in signals.projection_watermarks.items()},
            "open_dead_letters": signals.open_dead_letters,
            "reconciliation_state": signals.reconciliation_state,
        },
    )


def record(connection: psycopg.Connection, snapshot: ReadinessSnapshot) -> uuid.UUID:
    reference = uuid.uuid4()
    with connection.cursor() as cur:
        cur.execute(
            """
            INSERT INTO api04_gov.readiness_snapshot
                (snapshot_reference, ready, authoritatively_ready, blocking_reason_codes, signals)
            VALUES (%s,%s,%s,%s,%s)
            """,
            (
                reference,
                snapshot.ready,
                snapshot.authoritatively_ready,
                json.dumps(
                    list(snapshot.blocking_reason_codes)
                    + list(snapshot.consequential_blocking_reason_codes)
                ),
                json.dumps(snapshot.as_json()["signals"]),
            ),
        )
    connection.commit()
    return reference
