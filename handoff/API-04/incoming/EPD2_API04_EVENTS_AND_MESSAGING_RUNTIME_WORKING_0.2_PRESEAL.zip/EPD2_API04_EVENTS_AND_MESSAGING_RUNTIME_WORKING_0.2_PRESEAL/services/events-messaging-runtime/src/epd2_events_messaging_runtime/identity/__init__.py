"""The API-03 dependency, behind one boundary.

Nothing outside this package imports an API-03 type, so the mechanical
comparison against the exact accepted API-03 has exactly one surface to
reconcile.
"""

from .port import (
    CredentialState,
    HumanCredential,
    MessageAssertedIdentity,
    PrincipalClass,
    RefusingServiceIdentityPort,
    ServiceIdentityPort,
    TransportCredential,
    VerifiedServicePrincipal,
)

__all__ = [
    "CredentialState",
    "HumanCredential",
    "MessageAssertedIdentity",
    "PrincipalClass",
    "RefusingServiceIdentityPort",
    "ServiceIdentityPort",
    "TransportCredential",
    "VerifiedServicePrincipal",
]
