"""The pinned reference broker adapter.

```text
product : RabbitMQ
version : 3.12.1  (Ubuntu 24.04 package 3.12.1-1ubuntu1.2, Erlang/OTP 25)
class   : REFERENCE ADAPTER — not an EPD2 infrastructure or procurement decision
```

`RabbitMqBroker` implements `epd2_data_plane_service.delivery.BrokerPort`
unchanged: `publish(record, destination)` returns a
`BrokerAcknowledgementReference` when the broker confirmed, and `None` when the
acknowledgement is unknown. `None` is not an error and is not a success —
PACK-13's `DeliveryOutcome.ACKNOWLEDGEMENT_UNKNOWN` is a first-class outcome and
this adapter produces it rather than guessing.

PACK-13 prescribes no topic naming and no topology (`P13-VOTE-008`); the
topology this adapter declares comes from API-04's governed register and from
nowhere else.

The version is pinned and `assert_pinned_version` refuses a server that reports
anything else, so evidence cannot be produced against a different broker.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Mapping

import pika
from pika.exceptions import AMQPConnectionError, ChannelClosedByBroker, UnroutableError

from epd2_data_plane_service.exceptions import BrokerUnavailableError
from epd2_data_plane_service.outbox import (
    BrokerAcknowledgementReference,
    DestinationReference,
    OutboxRecord,
)

from ..exceptions import BrokerVersionNotPinnedError
from ..persistence import codec
from .ports import ConsumerTransportPort, DeliveredMessage

BROKER_PRODUCT = "RabbitMQ"
BROKER_VERSION = "3.12.1"
BROKER_ADAPTER_CLASS = "REFERENCE_ADAPTER_NOT_A_PROCUREMENT_DECISION"

#: Bounded, tiered consumer-side backoff in milliseconds. Queue TTLs are fixed
#: at declaration time, so this backoff is bounded and exponential but not
#: jittered; the dispatcher's own backoff, which it computes, is jittered.
RETRY_TIER_TTL_MS = (200, 800, 3200)


def partition_queue(queue: str, partition: int) -> str:
    return f"{queue}.p{partition}"


def retry_queue(queue: str, partition: int, tier: int) -> str:
    return f"retry.{queue}.p{partition}.t{tier}"


def routing_key(event_type: str, partition: int) -> str:
    return f"{event_type}.p{partition}"


def partition_for(key: str | None, partitions: int) -> int:
    """Deterministic across processes: no dependence on hash randomisation."""
    if partitions <= 1 or key is None:
        return 0
    digest = 0
    for byte in str(key).encode("utf-8"):
        digest = (digest * 131 + byte) & 0xFFFFFFFF
    return digest % partitions


class RabbitMqBroker(ConsumerTransportPort):
    """Implements `delivery.BrokerPort` and `ConsumerTransportPort`."""

    product = BROKER_PRODUCT
    version = BROKER_VERSION
    adapter_class = BROKER_ADAPTER_CLASS

    def __init__(
        self, *, vhost: str, host: str, port: int, username: str, password: str,
        heartbeat: int = 30, prefetch: int = 8,
    ) -> None:
        self.vhost = vhost
        self._host, self._port = host, port
        self._username, self._password = username, password
        self._heartbeat, self._prefetch = heartbeat, prefetch
        self._connection: pika.BlockingConnection | None = None
        self._channel: Any = None
        self._server_properties: dict[str, Any] = {}
        self._last_partition: int = 0

    # -- lifecycle ----------------------------------------------------------
    def connect(self) -> None:
        parameters = pika.ConnectionParameters(
            host=self._host, port=self._port, virtual_host=self.vhost,
            credentials=pika.PlainCredentials(self._username, self._password),
            heartbeat=self._heartbeat, blocked_connection_timeout=15,
            connection_attempts=1, socket_timeout=10,
        )
        try:
            self._connection = pika.BlockingConnection(parameters)
        except AMQPConnectionError as exc:
            raise BrokerUnavailableError(
                f"broker {self._host}:{self._port} vhost {self.vhost!r} could not be reached; "
                f"a command that committed is pending publication, not lost"
            ) from exc
        self._server_properties = dict(self._connection._impl.server_properties or {})
        self._channel = self._connection.channel()
        self._channel.basic_qos(prefetch_count=self._prefetch)
        self._channel.confirm_delivery()

    def close(self) -> None:
        try:
            if self._connection is not None and self._connection.is_open:
                self._connection.close()
        except Exception:  # pragma: no cover - closing a broken socket
            pass
        finally:
            self._connection, self._channel = None, None

    def is_connected(self) -> bool:
        return self._connection is not None and self._connection.is_open

    def _require_channel(self) -> Any:
        if not self.is_connected() or self._channel is None:
            raise BrokerUnavailableError("broker connection is not open")
        return self._channel

    def reported_version(self) -> str:
        raw = self._server_properties.get("version", b"")
        return raw.decode() if isinstance(raw, bytes) else str(raw)

    def assert_pinned_version(self) -> str:
        observed = self.reported_version()
        if observed != BROKER_VERSION:
            raise BrokerVersionNotPinnedError(
                f"the pinned broker is {BROKER_PRODUCT} {BROKER_VERSION}; the server reports {observed!r}",
                detail={"expected": BROKER_VERSION, "observed": observed},
            )
        return observed

    # -- provisioning -------------------------------------------------------
    def declare_from_registry(self, registry: Any) -> dict[str, Any]:
        """Declare exactly the register's entities. Provisioner credential only:
        runtime principals hold `configure=^$` and the broker refuses them."""
        channel = self._require_channel()
        declared: dict[str, Any] = {"exchanges": [], "queues": [], "bindings": 0}

        retry_exchange = f"dlx.retry.{self.vhost}"
        quarantine_exchange = f"dlx.quarantine.{self.vhost}"
        # A retry must come back to the queue it left, and to no other. Sending
        # an expired retry back through the topic exchange would re-fan it out
        # to every other subscription on that topic: harmless to correctness,
        # because those consumers deduplicate, and wrong anyway — one
        # subscription's retry is not another subscription's delivery.
        return_exchange = f"dlx.return.{self.vhost}"
        for name in (retry_exchange, quarantine_exchange, return_exchange):
            channel.exchange_declare(exchange=name, exchange_type="direct", durable=True)
            declared["exchanges"].append(name)

        for topic in registry.topics:
            channel.exchange_declare(exchange=topic.destination_name, exchange_type="topic", durable=True)
            if topic.destination_name not in declared["exchanges"]:
                declared["exchanges"].append(topic.destination_name)

        for sub in registry.subscriptions:
            topic = registry.topic(sub.topic_id)
            for partition in range(topic.partitions):
                main = partition_queue(sub.queue, partition)
                dead = partition_queue(sub.dead_letter_queue, partition)
                channel.queue_declare(
                    queue=main, durable=True,
                    arguments={"x-queue-type": "quorum",
                               "x-delivery-limit": max(sub.max_attempts * 2, 4)},
                )
                channel.queue_bind(queue=main, exchange=topic.destination_name,
                                   routing_key=routing_key(topic.event_type, partition))
                channel.queue_bind(queue=main, exchange=return_exchange, routing_key=main)
                declared["queues"].append(main)
                declared["bindings"] += 2

                channel.queue_declare(queue=dead, durable=True, arguments={"x-queue-type": "quorum"})
                channel.queue_bind(queue=dead, exchange=quarantine_exchange, routing_key=dead)
                declared["queues"].append(dead)
                declared["bindings"] += 1

                for tier, ttl in enumerate(RETRY_TIER_TTL_MS):
                    name = retry_queue(sub.queue, partition, tier)
                    channel.queue_declare(
                        queue=name, durable=True,
                        arguments={"x-queue-type": "quorum", "x-message-ttl": ttl,
                                   "x-dead-letter-exchange": return_exchange,
                                   "x-dead-letter-routing-key": main},
                    )
                    channel.queue_bind(queue=name, exchange=retry_exchange, routing_key=name)
                    declared["queues"].append(name)
                    declared["bindings"] += 1
        return declared

    # -- delivery.BrokerPort ------------------------------------------------
    def publish(
        self, record: OutboxRecord, destination: DestinationReference
    ) -> BrokerAcknowledgementReference | None:
        """PACK-13's port, implemented. The wire message is the canonical
        envelope; transport metadata rides in AMQP headers and never in it."""
        channel = self._require_channel()
        envelope = codec.envelope_to_json(record.envelope)
        partition = partition_for(str(record.aggregate.aggregate_id), self._last_partition_count)
        key = routing_key(record.event_type, partition)
        properties = pika.BasicProperties(
            delivery_mode=2,
            content_type="application/json",
            message_id=str(record.event_id),
            type=record.event_type,
            headers={
                "x-epd2-event-version": record.event_version,
                "x-epd2-sequence-number": record.sequence_number,
                "x-epd2-partition": partition,
                "x-epd2-destination": destination.destination_name,
            },
        )
        try:
            channel.basic_publish(
                exchange=destination.destination_name, routing_key=key,
                body=json.dumps(envelope).encode("utf-8"),
                properties=properties, mandatory=True,
            )
        except UnroutableError as exc:
            raise BrokerUnavailableError(
                f"publish to {destination.destination_name}/{key} was unroutable"
            ) from exc
        except (AMQPConnectionError, ChannelClosedByBroker) as exc:
            raise BrokerUnavailableError(
                f"publish to {destination.destination_name} failed: {type(exc).__name__}"
            ) from exc
        if self._acknowledgements_suppressed:
            return None
        return BrokerAcknowledgementReference(
            acknowledgement_reference=f"{destination.destination_name}/{key}/{record.event_id}",
            received_at=datetime.now(timezone.utc),
        )

    #: Publisher confirms are on; this flag exists only so a fixture can model a
    #: confirmation that never arrives, which is a real condition and not a mock.
    _acknowledgements_suppressed: bool = False
    #: Set by the dispatcher from the governed register before each publish, so
    #: the adapter never invents a partition count.
    _last_partition_count: int = 1

    def bind_partitioning(self, partitions: int) -> None:
        self._last_partition_count = max(1, int(partitions))

    def suppress_acknowledgements(self, value: bool = True) -> None:
        self._acknowledgements_suppressed = value

    # -- ConsumerTransportPort ---------------------------------------------
    def pull(self, *, queue: str, partition: int, max_messages: int) -> list[DeliveredMessage]:
        channel = self._require_channel()
        name = partition_queue(queue, partition)
        out: list[DeliveredMessage] = []
        for _ in range(max_messages):
            method, properties, body = channel.basic_get(queue=name, auto_ack=False)
            if method is None:
                break
            out.append(
                DeliveredMessage(
                    queue=name, partition=partition, delivery_tag=method.delivery_tag,
                    redelivered=bool(method.redelivered),
                    envelope=json.loads(body.decode("utf-8")),
                    headers=dict(properties.headers or {}),
                )
            )
            break  # one unacknowledged delivery at a time: memory is bounded by one message
        return out

    def acknowledge(self, message: DeliveredMessage) -> None:
        self._require_channel().basic_ack(delivery_tag=message.delivery_tag)

    def abandon_without_acknowledgement(self) -> None:
        try:
            if self._channel is not None and self._channel.is_open:
                self._channel.close()
        finally:
            self.close()

    def republish(
        self, *, exchange: str, routing_key: str, envelope: Mapping[str, Any],
        headers: Mapping[str, Any],
    ) -> str:
        channel = self._require_channel()
        channel.basic_publish(
            exchange=exchange, routing_key=routing_key,
            body=json.dumps(dict(envelope)).encode("utf-8"),
            properties=pika.BasicProperties(
                delivery_mode=2, content_type="application/json",
                message_id=str(envelope.get("event_id", "")), headers=dict(headers),
            ),
            mandatory=True,
        )
        return f"{exchange}/{routing_key}/{envelope.get('event_id')}"

    def queue_depth(self, queue: str) -> int:
        declared = self._require_channel().queue_declare(queue=queue, passive=True)
        return int(declared.method.message_count)

    def purge(self, queue: str) -> None:
        self._require_channel().queue_purge(queue)

    def drain(self, queue: str, limit: int = 1000) -> list[dict[str, Any]]:
        channel = self._require_channel()
        out: list[dict[str, Any]] = []
        for _ in range(limit):
            method, _props, body = channel.basic_get(queue=queue, auto_ack=True)
            if method is None:
                break
            out.append(json.loads(body.decode("utf-8")))
        return out

    def wait(self, seconds: float) -> None:
        if self._connection is not None and self._connection.is_open:
            self._connection.sleep(seconds)
