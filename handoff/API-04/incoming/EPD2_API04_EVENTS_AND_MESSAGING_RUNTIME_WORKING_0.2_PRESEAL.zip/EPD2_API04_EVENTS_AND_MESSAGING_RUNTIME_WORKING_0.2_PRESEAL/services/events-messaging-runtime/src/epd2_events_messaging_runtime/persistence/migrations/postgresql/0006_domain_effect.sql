-- EPD2 API-04 migration 0006 — domain effect and authority state for the consequential flows
-- Kind: EXPAND. Immutable once applied: a checksum mismatch has no repair
-- path (MIGRATION_CHECKSUM_MISMATCH), exactly as PACK-13 requires.
--
-- These belong to the owning domain services. API-04 writes them only through the
-- consumer's own effect function, in the same transaction as the dedup marker, and
-- decides nothing about their contents.


CREATE TABLE IF NOT EXISTS dom_governance.authority_state (
    authority_id        uuid PRIMARY KEY,
    authority_active    boolean NOT NULL DEFAULT true,
    organization_id     uuid NOT NULL,
    scope_kind          text NOT NULL,
    object_version      bigint NOT NULL DEFAULT 1,
    policy_version      text NOT NULL,
    authority_expires_at timestamptz,
    deadline_at         timestamptz
);

CREATE TABLE IF NOT EXISTS dom_governance.authority_assignment (
    authority_id       uuid PRIMARY KEY,
    decision_reference text NOT NULL,
    status             text NOT NULL,
    effective_time     timestamptz NOT NULL,
    object_version     bigint NOT NULL,
    authority_basis    jsonb NOT NULL,
    organization_id    uuid NOT NULL,
    recorded_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dom_notification.notification_delivery (
    delivery_reference text PRIMARY KEY,
    subject_reference  text NOT NULL,
    organization_id    uuid NOT NULL,
    delivered_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dom_casework.deadline_state (
    case_id       uuid PRIMARY KEY,
    deadline_code text NOT NULL,
    state         text NOT NULL,
    recorded_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dom_audit.ingested_record (
    reference       text PRIMARY KEY,
    event_type      text NOT NULL,
    digest          text NOT NULL,
    organization_id uuid NOT NULL,
    received_at     timestamptz NOT NULL DEFAULT now()
);
