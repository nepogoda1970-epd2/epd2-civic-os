"""The transport seams: PACK-13's `BrokerPort` implemented against a pinned
RabbitMQ, plus the pull-side port PACK-13 has no equivalent for."""
