"""The composition root.

Everything is wired explicitly here: the governed registers, the canonical
catalogue, the pinned broker, the live PostgreSQL, the API-03 identity adapter
and the per-domain stores. Nothing constructs a default in a corner — an unbound
identity port refuses, and an unprovisioned broker credential is an error at
startup rather than an anonymous connection at runtime.
"""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Mapping

import psycopg

from epd2_core.event_envelope import ActorRef, SubjectRef, build_event_envelope
from epd2_data_plane_service.exceptions import BrokerUnavailableError
from epd2_data_plane_service.domain import (
    AggregateReference,
    DomainReference,
    OrganizationScopeKind,
    OrganizationScopeReference,
)
from epd2_data_plane_service.outbox import OutboxWriter

from ..identity.api03_r13_adapter import (
    API03_R13_REVIEW_EVIDENCE,
    Api03R13ServiceIdentityAdapter,
    Api03ServiceCredentialRecord,
    StandInApi03CredentialDirectory,
)
from ..identity.port import CredentialState, PrincipalClass, TransportCredential
from ..identity.reconciliation import reconciliation_state
from ..persistence import db
from ..persistence.postgres_stores import (
    PostgresAggregateVersionStore,
    PostgresConsumerCheckpointStore,
    PostgresDeadLetterStore,
    PostgresDeduplicationStore,
    PostgresIdempotencyStore,
    PostgresOutboxStore,
    PostgresProjectionStore,
)
from ..topology.acl import load_acl_matrix
from ..topology.catalogue import load_canonical_catalogue
from ..topology.registry import load_topic_registry
from ..transport.rabbitmq import BROKER_PRODUCT, BROKER_VERSION, RabbitMqBroker, partition_queue
from . import lag as lag_module
from . import readiness as readiness_module
from .backpressure import OverloadPolicy
from .clock import TimeAuthority
from .consumer import SubscriptionConsumer
from .dispatcher import OutboxDispatcher
from .effects import EFFECTS
from .unit_of_work import domain_unit_of_work

STATUS = "PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED"

SERVICE_DOMAIN = {
    "membership-service": "membership",
    "organization-service": "organization",
    "compliance-service": "compliance",
    "projection-service": "projection",
    "notification-service": "notification",
    "governance-service": "governance",
    "casework-service": "casework",
    "audit-core": "audit",
}

DEFAULT_ORGANIZATION = uuid.UUID("11111111-1111-4111-8111-111111111111")


@dataclass
class RuntimeConfig:
    repository_root: Path
    postgres_dsn: str
    broker_host: str = "127.0.0.1"
    broker_port: int = 5672
    broker_secrets_path: Path | None = None
    plane: str = "epd2-api04"
    deduplication_horizon: timedelta = timedelta(days=90)
    accepted_api03_sha256: str | None = None

    @property
    def topic_register(self) -> Path:
        return self.repository_root / "docs/api/API-04/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json"

    @property
    def acl_register(self) -> Path:
        return self.repository_root / "docs/api/API-04/API04_PRODUCER_CONSUMER_ACL_MATRIX.json"

    @classmethod
    def from_env(cls) -> "RuntimeConfig":
        secrets = os.environ.get("API04_BROKER_SECRETS")
        return cls(
            repository_root=Path(os.environ.get("API04_REPOSITORY_ROOT", ".")).resolve(),
            postgres_dsn=os.environ["API04_POSTGRES_DSN"],
            broker_host=os.environ.get("API04_BROKER_HOST", "127.0.0.1"),
            broker_port=int(os.environ.get("API04_BROKER_PORT", "5672")),
            broker_secrets_path=Path(secrets) if secrets else None,
            accepted_api03_sha256=os.environ.get("API04_ACCEPTED_API03_SHA256") or None,
        )


class Api04Runtime:
    status = STATUS

    def __init__(self, config: RuntimeConfig, *, clock: TimeAuthority | None = None) -> None:
        self.config = config
        self.clock = clock or TimeAuthority()
        self.catalogue = load_canonical_catalogue(config.repository_root)
        self.topics = load_topic_registry(config.topic_register, catalogue=self.catalogue)
        self.acl = load_acl_matrix(config.acl_register)
        self.secrets: dict[str, str] = (
            json.loads(config.broker_secrets_path.read_text())
            if config.broker_secrets_path and config.broker_secrets_path.exists()
            else {}
        )
        self.identity_directory = StandInApi03CredentialDirectory()
        self.identity = Api03R13ServiceIdentityAdapter(self.identity_directory, clock=self.clock)
        self.overload = OverloadPolicy()
        self.organization = OrganizationScopeReference(
            organization_id=DEFAULT_ORGANIZATION, scope_kind=OrganizationScopeKind.BUND
        )
        self.brokers: dict[str, RabbitMqBroker] = {}
        self._connections: list[psycopg.Connection] = []
        self._dispatchers: dict[str, OutboxDispatcher] = {}
        self.dispatcher_healthy = True

    # -- infrastructure -----------------------------------------------------
    def connect(self) -> psycopg.Connection:
        conn = db.connect(self.config.postgres_dsn)
        self._connections.append(conn)
        return conn

    def close(self) -> None:
        for conn in self._connections:
            try:
                conn.close()
            except Exception:
                pass
        self._connections.clear()
        for broker in self.brokers.values():
            broker.close()
        self.brokers.clear()
        self._dispatchers.clear()

    def broker_for(
        self, *, role: str = "provisioner", service_id: str | None = None, required: bool = True
    ) -> RabbitMqBroker:
        """Return a connected broker, or — with ``required=False`` — an
        unconnected one.

        A dispatcher must exist even while the broker does not: a command that
        committed is pending publication, and the loop that has to defer it
        cannot be the thing that fails to start. `required=False` is therefore
        how the dispatcher asks for its transport; everything else asks for a
        connection and gets a refusal when there is none.
        """
        key = f"{role}:{service_id or ''}"
        existing = self.brokers.get(key)
        if existing is not None and existing.is_connected():
            return existing
        username = (
            f"api04-provisioner-{self.config.plane}" if role == "provisioner" else f"svc-{service_id}"
        )
        password = self.secrets.get(username)
        if password is None:
            raise KeyError(f"no provisioned broker credential for {username}")
        broker = RabbitMqBroker(
            vhost=self.config.plane, host=self.config.broker_host, port=self.config.broker_port,
            username=username, password=password,
        )
        try:
            broker.connect()
            broker.assert_pinned_version()
        except BrokerUnavailableError:
            if required:
                raise
        self.brokers[key] = broker
        return broker

    # -- identity -----------------------------------------------------------
    def register_service_credentials(self) -> int:
        not_before = self.clock.now_utc() - timedelta(days=1)
        not_after = self.clock.now_utc() + timedelta(days=30)
        for service, spec in self.acl.service_principals.items():
            self.identity_directory.add(
                f"svc-{service}",
                Api03ServiceCredentialRecord(
                    service_id=service,
                    credential_id=f"cred-{service}",
                    state=CredentialState.ACTIVE,
                    organization_scopes=frozenset(spec["organization_scopes"]),
                    data_classifications=frozenset(spec["data_classifications"]),
                    trust_anchor="api03:workload-mtls-intermediate",
                    not_before=not_before,
                    not_after=not_after,
                    principal_class=PrincipalClass.SERVICE,
                ),
            )
        return len(self.acl.service_principals)

    def transport_credential(self, service_id: str) -> TransportCredential:
        return TransportCredential(
            authenticated_by="amqp-plain-over-authenticated-connection",
            peer_identity=f"svc-{service_id}",
            connection_reference=f"conn-{uuid.uuid4()}",
            presented_at=self.clock.now_utc(),
        )

    # -- bootstrap ----------------------------------------------------------
    def bootstrap(self) -> dict[str, Any]:
        conn = self.connect()
        engine = db.assert_engine(conn)
        applied = db.apply_migrations(conn)
        state = db.migration_state(conn)
        self.register_service_credentials()
        broker = self.broker_for()
        declared = broker.declare_from_registry(self.topics)
        return {
            "postgresql_version": engine,
            "migrations_applied_now": applied,
            "migration_state": state,
            "broker_product": BROKER_PRODUCT,
            "broker_version": BROKER_VERSION,
            "declared": {
                "exchanges": len(declared["exchanges"]),
                "queues": len(declared["queues"]),
                "bindings": declared["bindings"],
            },
            "canonical_event_types": len(self.catalogue),
            "topics": len(self.topics.topics),
            "subscriptions": len(self.topics.subscriptions),
            "voting_plane_exists": self.topics.voting_plane_exists,
            "reconciliation_state": reconciliation_state(self.config.accepted_api03_sha256),
            "api03_r13_review_evidence": dict(API03_R13_REVIEW_EVIDENCE),
            "status": self.status,
        }

    # -- producing ----------------------------------------------------------
    def publish_from_domain(
        self,
        *,
        service_id: str,
        topic_id: str,
        payload: Mapping[str, Any],
        sequence_number: int,
        event_version: str | None = None,
        domain_write: Callable[[psycopg.Connection], None] | None = None,
        event_id: uuid.UUID | None = None,
        correlation_id: uuid.UUID | None = None,
        causation_id: uuid.UUID | None = None,
        occurred_at: datetime | None = None,
    ) -> uuid.UUID:
        """One domain transaction: the domain write and the canonical event."""
        topic = self.topics.topic(topic_id)
        domain = SERVICE_DOMAIN[service_id]
        now = self.clock.now_utc()
        event_id = event_id or uuid.uuid4()
        aggregate = AggregateReference(
            aggregate_type=topic.partition_key,
            aggregate_id=uuid.UUID(str(payload[topic.partition_key])),
            owning_domain=DomainReference(domain_name=domain, is_reserved_boundary=False),
        )
        envelope = build_event_envelope(
            event_id=event_id,
            event_type=topic.event_type,
            event_version=event_version or topic.event_versions[0],
            occurred_at=occurred_at or now,
            producer=service_id,
            actor=ActorRef(
                actor_id=uuid.uuid5(uuid.NAMESPACE_URL, f"service/{service_id}"),
                actor_type="service",
            ),
            subject=SubjectRef(
                subject_type=topic.partition_key, subject_id=aggregate.aggregate_id
            ),
            correlation_id=correlation_id or uuid.uuid4(),
            causation_id=causation_id,
            payload=dict(payload),
        )
        conn = self.connect()
        try:
            with domain_unit_of_work(
                conn, domain=domain, scope=self.organization, now=now
            ) as unit:
                if domain_write is not None:
                    domain_write(conn)
                unit.record_domain_write(f"{topic_id}:{aggregate.aggregate_id}")
                record = OutboxWriter.write_within(
                    unit.reference,
                    outbox_record_id=uuid.uuid4(),
                    envelope=envelope,
                    aggregate=aggregate,
                    created_at=now,
                    sequence_number=sequence_number,
                    retention_schedule=topic.retention,
                )
                unit.stage(record)
                store = PostgresOutboxStore(unit.domain, conn)
                store.append(record, writing_domain=unit.domain)
        finally:
            conn.close()
            self._connections.remove(conn)
        return event_id

    def dispatcher_for(self, service_id: str) -> OutboxDispatcher:
        domain = SERVICE_DOMAIN[service_id]
        existing = self._dispatchers.get(domain)
        if existing is not None:
            return existing
        connection = self.connect()
        reference = DomainReference(domain_name=domain, is_reserved_boundary=False)
        dispatcher = OutboxDispatcher(
            domain=domain,
            store=PostgresOutboxStore(reference, connection),
            dead_letters=PostgresDeadLetterStore(connection),
            connection=connection,
            broker=self.broker_for(role="service", service_id=service_id, required=False),
            registry=self.topics,
            acl=self.acl,
            identity=self.identity,
            producer_credential=self.transport_credential(service_id),
            service_id=service_id,
            holder=f"dispatcher-{domain}",
        )
        self._dispatchers[domain] = dispatcher
        return dispatcher

    # -- consuming ----------------------------------------------------------
    def consumer_for(self, subscription_id: str, *, abandon_after_effect: bool = False) -> SubscriptionConsumer:
        subscription = self.topics.subscription(subscription_id)
        topic = self.topics.topic(subscription.topic_id)
        service_id = subscription.consumer_service
        domain = SERVICE_DOMAIN[service_id]
        return SubscriptionConsumer(
            subscription=subscription,
            topic=topic,
            registry=self.topics,
            catalogue=self.catalogue,
            acl=self.acl,
            identity=self.identity,
            consumer_credential=self.transport_credential(service_id),
            transport=self.broker_for(role="service", service_id=service_id),
            store_domain=domain,
            connection_factory=lambda: db.connect(self.config.postgres_dsn),
            clock=self.clock,
            effect=EFFECTS[subscription_id],
            organization=self.organization,
            plane=self.config.plane,
            deduplication_horizon=self.config.deduplication_horizon,
            abandon_after_effect=abandon_after_effect,
        )

    # -- readiness ----------------------------------------------------------
    def readiness(self, connection: psycopg.Connection | None = None) -> readiness_module.ReadinessSnapshot:
        owned = connection is None
        connection = connection or self.connect()
        now = self.clock.now_utc()
        broker_ok = version_ok = topology_ok = True
        lag_reading = None
        try:
            broker = self.broker_for()
            broker_ok = broker.is_connected()
            version_ok = broker.reported_version() == BROKER_VERSION
            live_queues = set()
            for sub in self.topics.subscriptions:
                topic = self.topics.topic(sub.topic_id)
                for partition in range(topic.partitions):
                    for name in (partition_queue(sub.queue, partition),
                                 partition_queue(sub.dead_letter_queue, partition)):
                        try:
                            broker.queue_depth(name)
                            live_queues.add(name)
                        except Exception:
                            broker.close()
                            broker = self.broker_for()
            topology_ok = self.topics.declared_queues() <= live_queues
            lag_reading = lag_module.read_lag(broker, self.topics, now=now)
        except Exception:
            broker_ok = version_ok = topology_ok = False

        projection = PostgresProjectionStore("projection", connection)
        signals = readiness_module.ReadinessSignals(
            broker_connected=broker_ok,
            broker_version_pinned=version_ok,
            topology_matches_register=topology_ok,
            identity_available=self.identity.is_available(),
            canonical_catalogue_loaded=len(self.catalogue) > 0,
            migrations_complete=db.migration_state(connection)["complete"],
            dispatcher_healthy=self.dispatcher_healthy
            and all(d.healthy for d in self._dispatchers.values()),
            lag_bands=lag_reading.as_json() if lag_reading else {},
            lag_ceilings=dict(lag_reading.ceilings) if lag_reading else {},
            lag_breached=lag_reading.breached if lag_reading else (),
            projection_watermarks=projection.watermarks(),
            open_dead_letters=PostgresDeadLetterStore(connection).open_count(),
            reconciliation_state=reconciliation_state(self.config.accepted_api03_sha256),
        )
        snapshot = readiness_module.evaluate(signals)
        readiness_module.record(connection, snapshot)
        if owned:
            connection.close()
            self._connections.remove(connection)
        return snapshot
