# events-messaging-runtime (API-04)

Production adapters behind PACK-13's **unchanged** ports, plus the two things
PACK-13 deliberately has no equivalent for because it models no transport: a
service-identity boundary (API-03) and a governed topic topology.

```text
epd2_data_plane_service.delivery.BrokerPort        <- transport.rabbitmq.RabbitMqBroker
epd2_data_plane_service.storage.OutboxStore        <- persistence.postgres_stores
                       .IdempotencyStore
                       .ConsumerCheckpointStore
                       .DeadLetterStore
                       .AggregateVersionStore
                       .ProjectionStore
```

Nothing under `services/data-plane-service` is modified by this service, and
nothing here re-implements a decision PACK-13 already makes: ordering is
`assess_ordering`, dispatch is `decide_dispatch`, retry is `RetryPolicy`,
idempotency is `IdempotencyPolicy`, lag banding is `lag_band_for`, and payload
minimality is `reject_prohibited_payload_keys`. `runtime/boundaries.py` asserts
that as a test: a PACK-13 port name *defined* in this package is a failure.

Delivery contract, PACK-13's and not strengthened:

```text
at-least-once delivery + effectively-once consumer effect
```

Status: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`.
