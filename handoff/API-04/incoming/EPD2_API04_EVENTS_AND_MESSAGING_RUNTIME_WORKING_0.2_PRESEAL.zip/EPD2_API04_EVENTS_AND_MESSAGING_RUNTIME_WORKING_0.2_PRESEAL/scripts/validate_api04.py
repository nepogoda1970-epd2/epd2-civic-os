#!/usr/bin/env python3
"""The API-04 validator.

Twenty-eight gates, G0 through G27. Every gate is either a static check over the
tree or a check that terminates in live evidence — the PostgreSQL 16.15 server,
the RabbitMQ 3.12.1 broker, or the JUnit results of the suite this script runs.

A gate that cannot execute because an input does not exist in this environment
reports ``NOT_RUN_ENVIRONMENT_BLOCKED`` with the exact missing input and is
listed under ``environment_blocked_gates``. It is never silently passed, and it
is never counted as a pass.

Terminal line while API-03 is not yet independently accepted:

    API04_PRESEAL_RESULT:PASS:validation/api04/validator_result.json

Usage:

    validate_api04.py [--root TREE] [--no-suite] [--gates 0,3,17]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

VALIDATOR_VERSION = "api04-validator/0.2.0"

PASS = "PASS"
FAIL = "FAIL"
BLOCKED = "NOT_RUN_ENVIRONMENT_BLOCKED"

SERVICE = "services/events-messaging-runtime"
SRC = f"{SERVICE}/src/epd2_events_messaging_runtime"
DOCS = "docs/api/API-04"

#: The claims this stage may not make, in any file of the tree.
FORBIDDEN_CLAIMS = (
    "api-04 accepted",
    "api-04 closed",
    "api04 accepted",
    "final pass",
    "api-05 next",
    "api-03 accepted predecessor",
    "production ready",
    "production-ready",
    "legally activated",
)

#: The *detectors*: these files must contain the forbidden vocabulary in order
#: to look for it. The exclusion is not a loophole — G25's companion unit test
#: asserts each of these still contains the patterns, so the list cannot be
#: reused to hide a real claim somewhere else.
CLAIM_SCAN_EXEMPT = (
    "scripts/validate_api04.py",
    f"{SERVICE}/tests/unit/test_canonical_ports.py",
    f"{SERVICE}/tests/unit/test_reconciliation.py",
    f"{DOCS}/03_ENTERING_BASELINE_AND_PARALLEL_STATUS.md",
)

#: The host-path detector contains the patterns it looks for.
HOST_PATH_EXEMPT = ("scripts/validate_api04.py",)

#: The forward-scope detectors: they name the markers in order to refuse them.
FORWARD_SCOPE_EXEMPT = (
    "scripts/validate_api04.py",
    f"{SRC}/runtime/boundaries.py",
    f"{SERVICE}/tests/unit/test_boundaries.py",
    f"{SERVICE}/tests/mutation/mutations.py",
    f"{SERVICE}/tests/unit/test_validator_exemptions.py",
)

#: A forbidden phrase inside one of these constructions is a refusal, not a claim.
CLAIM_NEGATIONS = (
    "!=", "not ", "no ", "never", "must not", "may not", "cannot", "forbidden",
    "prohibit", "refus", "absence", "is not", "are not", "without", "rather than",
    "instead of", "may only", "until", "pending", "would be",
)

SECRET_PATTERNS = (
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"\b(aws_secret_access_key|api[_-]?key|client_secret)\b\s*[:=]\s*\S{8,}", re.I),
    re.compile(r"^Bearer\s+[A-Za-z0-9._~+/=-]{20,}$", re.M),
    re.compile(r"\b(amqp|amqps|postgres|postgresql)://[^\s:@]+:[^\s@]+@", re.I),
    re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
)

#: Files that legitimately contain secret-*shaped* values, with the reason. Same
#: discipline as the claim exemptions: each is asserted by a test to still
#: contain them.
SECRET_SCAN_ALLOWLIST = {
    f"{SERVICE}/tests/unit/test_privacy.py":
        "negative fixtures for the secret scanner: the values it must catch",
}

#: Directories that never belong in a sealed archive.
FORBIDDEN_PATHS = ("__pycache__", ".pytest_cache", ".git", ".mypy_cache", ".DS_Store", ".idea")

#: The twenty-two mandated cross-service failure fixtures.
MANDATED_FIXTURES = tuple(f"f{n:02d}" for n in range(1, 23))


@dataclass
class GateResult:
    number: int
    title: str
    result: str
    problems: list[str] = field(default_factory=list)
    evidence: dict[str, Any] = field(default_factory=dict)


class EnvironmentBlocked(Exception):
    """A gate's input does not exist in this environment. Never a pass."""


class Validator:
    def __init__(self, root: Path, *, run_suite: bool = True) -> None:
        self.root = root
        self.run_suite = run_suite
        self.results: list[GateResult] = []
        self.suite: dict[str, Any] = {}
        self._cache: dict[str, Any] = {}

    # -- helpers ------------------------------------------------------------
    def path(self, relative: str) -> Path:
        return self.root / relative

    def read(self, relative: str) -> str:
        target = self.path(relative)
        if not target.exists():
            raise EnvironmentBlocked(f"missing input: {relative}")
        return target.read_text(encoding="utf-8")

    def read_json(self, relative: str) -> Any:
        key = f"json:{relative}"
        if key not in self._cache:
            self._cache[key] = json.loads(self.read(relative))
        return self._cache[key]

    def tree_files(self) -> list[Path]:
        if "files" not in self._cache:
            self._cache["files"] = sorted(
                p for p in self.root.rglob("*")
                if p.is_file() and not any(part in FORBIDDEN_PATHS for part in p.parts)
            )
        return self._cache["files"]

    def text_files(self) -> list[Path]:
        suffixes = {".py", ".md", ".json", ".txt", ".yml", ".yaml", ".sql", ".toml", ".ini", ".cfg"}
        return [p for p in self.tree_files() if p.suffix in suffixes]

    def carried_paths(self) -> set[str]:
        """The canonical dependency closure, carried verbatim.

        These files are governed elsewhere and are verified byte-for-byte by G1.
        Scans that ask *what does API-04 claim* exclude them: a sentence in the
        carried V26 roadmap is not a claim this stage is making, and rewriting a
        carried file to satisfy a scan here would be the actual violation.
        """
        if "carried" not in self._cache:
            rows = set()
            for digest, relative in self.carried_rows():
                del digest
                rows.add(relative)
            self._cache["carried"] = rows
        return self._cache["carried"]

    #: Two manifests, because the closure has two parts: the V26 governance
    #: documents this stage works under, and the dependency closure its adapters
    #: are compiled against.
    CARRIED_MANIFESTS = ("CANONICAL_SHA256SUMS.txt", "CARRIED_CANONICAL_SHA256SUMS.txt")

    def carried_rows(self) -> list[tuple[str, str]]:
        if "carried_rows" not in self._cache:
            rows: list[tuple[str, str]] = []
            for manifest in self.CARRIED_MANIFESTS:
                listing = self.path(manifest)
                if not listing.exists():
                    raise EnvironmentBlocked(f"missing input: {manifest}")
                for line in listing.read_text(encoding="utf-8").splitlines():
                    if line.strip() and not line.startswith("#"):
                        digest, relative = line.split(maxsplit=1)
                        rows.append((digest, relative.strip()))
            self._cache["carried_rows"] = rows
        return self._cache["carried_rows"]

    def api04_text_files(self) -> list[Path]:
        """Only what API-04 authored."""
        carried = self.carried_paths()
        return [
            p for p in self.text_files()
            if self.relative(p) not in carried and not self.relative(p).startswith("validation/")
        ]

    def relative(self, path: Path) -> str:
        return str(path.relative_to(self.root))

    def source_files(self) -> list[Path]:
        return sorted(self.path(SRC).rglob("*.py"))

    def gate(self, number: int, title: str, check: Callable[[], tuple[str, list[str], dict]]) -> None:
        try:
            result, problems, evidence = check()
        except EnvironmentBlocked as blocked:
            self.results.append(GateResult(number, title, BLOCKED, [str(blocked)], {}))
            return
        except Exception as error:  # a gate that crashed did not pass
            self.results.append(
                GateResult(number, title, FAIL, [f"{type(error).__name__}: {error}"], {})
            )
            return
        self.results.append(GateResult(number, title, result, problems, evidence))

    # -- the suite ----------------------------------------------------------
    def execute_suite(self) -> None:
        report = self.root / "validation/api04/junit.xml"
        report.parent.mkdir(parents=True, exist_ok=True)
        environment = dict(os.environ)
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        environment["API04_REPOSITORY_ROOT"] = str(self.root)
        process = subprocess.run(
            [sys.executable, "-m", "pytest", "tests", "-q", "-p", "no:cacheprovider",
             f"--junitxml={report}"],
            cwd=self.root / SERVICE, env=environment, capture_output=True, text=True, timeout=5400,
        )
        self.suite = {
            "command": f"pytest tests --junitxml={report.relative_to(self.root)}",
            "exit_code": process.returncode,
            "tail": process.stdout.strip().splitlines()[-6:],
        }
        self.suite.update(self.parse_junit(report))

    def parse_junit(self, report: Path) -> dict[str, Any]:
        if not report.exists():
            return {"parsed": False}
        tree = ET.parse(report)
        cases = list(tree.iter("testcase"))
        failed = [
            c for c in cases
            if c.find("failure") is not None or c.find("error") is not None
        ]
        return {
            "parsed": True,
            "total": len(cases),
            "failed": len(failed),
            "skipped": sum(1 for c in cases if c.find("skipped") is not None),
            "failed_names": [c.get("name", "") for c in failed][:25],
            "names": [c.get("name", "") for c in cases],
        }

    def suite_names(self) -> list[str]:
        if not self.suite.get("parsed"):
            raise EnvironmentBlocked(
                "missing input: the test suite has not been run in this invocation "
                "(--no-suite); gate needs validation/api04/junit.xml"
            )
        return self.suite.get("names", [])

    def require_suite_green(self, problems: list[str]) -> None:
        if self.suite.get("failed"):
            problems.append(f"{self.suite['failed']} test(s) failed: {self.suite['failed_names']}")

    def matching_tests(self, *fragments: str) -> list[str]:
        names = self.suite_names()
        return [n for n in names if any(f in n for f in fragments)]

    # -- live probes --------------------------------------------------------
    def live_python(self, snippet: str) -> Any:
        environment = dict(os.environ)
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        environment["API04_REPOSITORY_ROOT"] = str(self.root)
        process = subprocess.run(
            [sys.executable, "-c", snippet],
            cwd=self.root / SERVICE, env=environment, capture_output=True, text=True, timeout=180,
        )
        if process.returncode != 0:
            raise EnvironmentBlocked(
                f"missing input: live runtime probe failed: {process.stderr.strip()[-400:]}"
            )
        return json.loads(process.stdout.strip().splitlines()[-1])

    # ==================================================================
    # G0  archive / root / hygiene
    # ==================================================================
    def g0_hygiene(self):
        problems: list[str] = []
        for path in self.root.rglob("*"):
            if any(part in FORBIDDEN_PATHS for part in path.parts):
                problems.append(f"forbidden path in the tree: {path.relative_to(self.root)}")
        carried = self.carried_paths()
        for path in self.tree_files():
            if path.stat().st_size == 0 and self.relative(path) not in carried:
                problems.append(f"empty file: {self.relative(path)}")
        host = re.compile(r"/home/[a-z]+/work|/Users/|C:\\\\")
        for path in self.api04_text_files():
            if self.relative(path) in HOST_PATH_EXEMPT:
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            if host.search(text):
                problems.append(f"absolute authoring path in {self.relative(path)}")
        return (PASS if not problems else FAIL), problems[:40], {
            "file_count": len(self.tree_files()),
            "api04_authored_files": len(self.api04_text_files()),
            "host_path_exempt": list(HOST_PATH_EXEMPT),
        }

    # ==================================================================
    # G1  canonical governance and the carried dependency closure
    # ==================================================================
    def g1_canonical_governance(self):
        problems: list[str] = []
        rows = self.carried_rows()
        verified = 0
        for digest, relative in rows:
            target = self.path(relative.strip())
            if not target.exists():
                problems.append(f"carried canonical file missing: {relative.strip()}")
                continue
            actual = hashlib.sha256(target.read_bytes()).hexdigest()
            if actual != digest:
                problems.append(f"carried canonical file modified: {relative.strip()}")
            else:
                verified += 1

        metadata = self.read("V26_AUTHORITY_METADATA.txt")
        if "V26" not in metadata:
            problems.append("V26_AUTHORITY_METADATA.txt does not name the V26 maintenance level")

        # API-04 adds exactly one registry file to contracts/ and modifies none.
        carried_paths = self.carried_paths()
        for path in sorted(self.path("contracts").rglob("*")):
            if not path.is_file():
                continue
            relative = self.relative(path)
            if relative not in carried_paths and relative != "contracts/reason-codes/api-04.yml":
                problems.append(f"uncarried, unregistered file under contracts/: {relative}")
        for area in ("packages/python/epd2-core", "services/data-plane-service",
                     "services/audit-core", "docs/canonical", "docs/roadmap",
                     "docs/security"):
            for path in sorted(self.path(area).rglob("*")):
                if path.is_file() and self.relative(path) not in carried_paths:
                    problems.append(f"file in a carried area is not in the digest list: "
                                    f"{self.relative(path)}")
        return (PASS if not problems else FAIL), problems[:40], {
            "manifests": list(self.CARRIED_MANIFESTS),
            "carried_files_verified": verified,
            "carried_files_declared": len(rows),
        }

    # ==================================================================
    # G2  PRESEAL status correctness
    # ==================================================================
    def g2_preseal_status(self):
        problems: list[str] = []
        status = self.read("docs/api/API-04/API04_STATUS.txt").strip()
        if status != "PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED":
            problems.append(f"archive status is {status!r}")
        module = self.read(f"{SRC}/__init__.py")
        if 'STATUS = "PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED"' not in module:
            problems.append("the package does not declare the working preseal status")

        found: list[str] = []
        for path in self.api04_text_files():
            relative = self.relative(path)
            if relative in CLAIM_SCAN_EXEMPT:
                continue
            for number, line in enumerate(
                path.read_text(encoding="utf-8", errors="replace").splitlines(), start=1
            ):
                lowered = line.lower()
                for claim in FORBIDDEN_CLAIMS:
                    if claim in lowered and not any(n in lowered for n in CLAIM_NEGATIONS):
                        found.append(f"{relative}:{number}: {claim!r}")
        problems.extend(found)
        return (PASS if not problems else FAIL), problems[:40], {
            "claim_scan_exempt": list(CLAIM_SCAN_EXEMPT),
            "api04_files_scanned": len(self.api04_text_files()),
            "carried_files_excluded": len(self.carried_paths()),
            "carried_exclusion_note":
                "carried canonical files are governed elsewhere and are verified "
                "byte-for-byte by G1; a sentence in them is not an API-04 claim",
        }

    # ==================================================================
    # G3  API-03 R13 recorded only as a working integration predecessor
    # ==================================================================
    def g3_api03_working_predecessor(self):
        problems: list[str] = []
        adapter = self.read(f"{SRC}/identity/api03_r13_adapter.py")
        evidence = {
            "run_id": "33280355709",
            "head_sha": "5904ef7212b368f3e734f8be54f5c63f374ea503",
            "artifact_id": "9722794132",
            "artifact_sha256":
                "1f10da8aff6d4966ba018c7105d5dcabdd75430644a4fe6d281b323633cb6e40",
            "archive_size_bytes": "40735799",
        }
        for key, value in evidence.items():
            if value not in adapter:
                problems.append(f"the R13 review evidence does not carry {key} verbatim")
        if "WORKING_INTEGRATION_PREDECESSOR" not in adapter:
            problems.append("R13 is not labelled a working integration predecessor")

        lineage = self.read_json(f"{DOCS}/API04_LINEAGE.json")
        if lineage.get("predecessor_binding_state") != "PENDING_EXACT_ACCEPTED_API03":
            problems.append("the lineage record does not report a pending predecessor binding")
        if lineage.get("accepted_predecessor_sha256") not in (None, ""):
            problems.append("a predecessor SHA-256 is frozen before an accepted API-03 exists")
        if str(lineage.get("self_acceptance_claim", "")).strip().upper() != "NONE":
            problems.append("the lineage record makes a self-acceptance claim")
        reconciliation = self.read(f"{SRC}/identity/reconciliation.py")
        if "PENDING_EXACT_ACCEPTED_API03" not in reconciliation:
            problems.append("the reconciliation module has no pending state")
        return (PASS if not problems else FAIL), problems, {
            "predecessor_label": "WORKING_INTEGRATION_PREDECESSOR",
            "reconciliation_state": "PENDING_EXACT_ACCEPTED_API03",
        }

    # ==================================================================
    # G4  inventory and accounting
    # ==================================================================
    def g4_inventory(self):
        problems: list[str] = []
        inventory = self.read_json(f"{DOCS}/API04_PRESEAL_INVENTORY.json")
        registry = self.read_json(f"{DOCS}/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json")
        acl = self.read_json(f"{DOCS}/API04_PRODUCER_CONSUMER_ACL_MATRIX.json")

        counted = {
            "topics": len(registry["topics"]),
            "subscriptions": len(registry["subscriptions"]),
            "produce_bindings": len(acl["produce_bindings"]),
            "consume_bindings": len(acl["consume_bindings"]),
            "source_modules": len(self.source_files()),
            "migrations": len(list(self.path(f"{SRC}/persistence/migrations/postgresql").glob("*.sql"))),
            "documents": len(sorted(self.path(DOCS).glob("*.md"))),
            "registers": len(sorted(self.path(DOCS).glob("*.json"))),
        }
        for key, value in counted.items():
            declared = inventory.get("counts", {}).get(key)
            if declared != value:
                problems.append(f"inventory says {key}={declared}, the tree has {value}")
        if inventory.get("status") != "PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED":
            problems.append("the inventory does not carry the working preseal status")
        return (PASS if not problems else FAIL), problems, {"counted": counted}

    # ==================================================================
    # G5  one canonical envelope, and no parallel port
    # ==================================================================
    def g5_envelope_and_ports(self):
        problems: list[str] = []
        probe = self.live_python(
            "import json,sys;"
            "sys.path[:0]=['src','../../packages/python/epd2-core/src',"
            "'../audit-core/src','../data-plane-service/src'];"
            "from epd2_events_messaging_runtime.runtime import boundaries as b;"
            "print(json.dumps({"
            "'stronger_claim': b.assert_no_stronger_delivery_claim(),"
            "'parallel_port': b.assert_no_parallel_port(),"
            "'domain_decision': b.assert_no_domain_decision(),"
            "'forward_scope': b.assert_no_forward_scope(),"
            "'second_envelope': b.assert_no_second_envelope()}))"
        )
        for name, rows in probe.items():
            for row in rows:
                problems.append(f"{name}: {row}")

        # The envelope is imported from the canon and not defined here.
        if "from epd2_core.event_envelope import" not in self.read(f"{SRC}/persistence/codec.py"):
            problems.append("the codec does not use the canonical envelope")
        if "build_event_envelope" not in self.read(f"{SRC}/runtime/composition.py"):
            problems.append("the producer path does not build the canonical envelope")
        return (PASS if not problems else FAIL), problems, {"guards": probe}

    # ==================================================================
    # G6  runtime topic / subscription registry
    # ==================================================================
    REQUIRED_TOPIC_FIELDS = (
        "topic_id", "event_type", "owner", "producer_services", "consumer_services",
        "event_versions", "payload_schema", "payload_schema_sha256", "data_classification",
        "retention_schedule", "ordering_scope_kind", "partition_key", "partitions",
        "retry_policy", "dead_letter_policy", "replay_permission", "redrive_permission",
        "readiness_dependency", "consequential_effect", "commit_reauthorisation_required",
    )

    def g6_topic_registry(self):
        problems: list[str] = []
        registry = self.read_json(f"{DOCS}/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json")
        for topic in registry["topics"]:
            missing = [f for f in self.REQUIRED_TOPIC_FIELDS if f not in topic]
            if missing:
                problems.append(f"topic {topic.get('topic_id')} is missing {missing}")
            schema = self.path(topic["payload_schema"])
            if not schema.exists():
                problems.append(f"payload schema absent: {topic['payload_schema']}")
                continue
            digest = hashlib.sha256(schema.read_bytes()).hexdigest()
            if digest != topic["payload_schema_sha256"]:
                problems.append(f"payload schema digest drifted: {topic['topic_id']}")
            body = json.loads(schema.read_text(encoding="utf-8"))
            if not str(body.get("title", "")).startswith(topic["event_type"] + " "):
                problems.append(f"topic {topic['topic_id']} is not its schema's own event type")

        live = self.live_python(
            "import json,sys;"
            "sys.path[:0]=['src','tests','../../packages/python/epd2-core/src',"
            "'../audit-core/src','../data-plane-service/src'];"
            "from support import harness;"
            "rt=harness.make_runtime();rt.bootstrap();"
            "b=rt.broker_for();live=set();"
            "[live.add(n) for n in rt.topics.declared_queues() if b.queue_depth(n) >= 0];"
            "print(json.dumps({'drift': rt.topics.drift_against("
            "{'exchanges': rt.topics.declared_exchanges(), 'queues': live}),"
            "'queues': len(live)}))"
        )
        problems.extend(f"runtime drift: {row}" for row in live["drift"])
        return (PASS if not problems else FAIL), problems, {
            "topics": len(registry["topics"]),
            "subscriptions": len(registry["subscriptions"]),
            "live_queues": live["queues"],
        }

    # ==================================================================
    # G7  service identity and the ACL matrix
    # ==================================================================
    def g7_identity_and_acl(self):
        problems: list[str] = []
        acl = self.read_json(f"{DOCS}/API04_PRODUCER_CONSUMER_ACL_MATRIX.json")
        registry = self.read_json(f"{DOCS}/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json")
        wildcards = {"*", "*:*", "**", ".*", "all", "any", ""}
        for binding in acl["produce_bindings"] + acl["consume_bindings"]:
            for key, value in binding.items():
                if isinstance(value, str) and value.strip().lower() in wildcards:
                    problems.append(f"wildcard in ACL row {binding.get('binding_id')}: {key}")
        produce = {(b["service_id"], b["topic_id"]) for b in acl["produce_bindings"]}
        for topic in registry["topics"]:
            for service in topic["producer_services"]:
                if (service, topic["topic_id"]) not in produce:
                    problems.append(f"registered producer without a binding: {service}")
        consume = {(b["service_id"], b["subscription_id"]) for b in acl["consume_bindings"]}
        for subscription in registry["subscriptions"]:
            if (subscription["consumer_service"], subscription["subscription_id"]) not in consume:
                problems.append(f"subscription without a binding: {subscription['subscription_id']}")

        permissions = self.broker_permissions()
        for user, (configure, _write, _read) in permissions.items():
            if user.startswith("svc-") and configure not in ("^$", ""):
                problems.append(f"service principal {user} may declare topology: configure={configure}")
            if ".*" in (configure, _write, _read) and user.startswith("svc-"):
                problems.append(f"service principal {user} holds an unbounded permission")
        return (PASS if not problems else FAIL), problems, {
            "produce_bindings": len(acl["produce_bindings"]),
            "consume_bindings": len(acl["consume_bindings"]),
            "broker_principals": sorted(permissions),
        }

    def broker_permissions(self) -> dict[str, tuple[str, str, str]]:
        if "permissions" in self._cache:
            return self._cache["permissions"]
        environment = dict(os.environ)
        environment["HOME"] = "/var/lib/rabbitmq"
        node = environment.get("RABBITMQ_NODENAME", "epd2api04@localhost")
        process = subprocess.run(
            ["rabbitmqctl", "-n", node, "-p", "epd2-api04", "list_permissions"],
            capture_output=True, text=True, env=environment, timeout=120,
        )
        if process.returncode != 0:
            raise EnvironmentBlocked(
                f"missing input: the live broker could not be queried: "
                f"{process.stderr.strip()[-300:]}"
            )
        out: dict[str, tuple[str, str, str]] = {}
        for line in process.stdout.splitlines():
            parts = line.split("\t")
            if len(parts) == 4 and not parts[0].startswith("Listing"):
                out[parts[0]] = (parts[1], parts[2], parts[3])
        self._cache["permissions"] = out
        return out

    # ==================================================================
    # G8  transactional outbox
    # ==================================================================
    def g8_outbox(self):
        problems: list[str] = []
        migrations = "\n".join(
            p.read_text(encoding="utf-8")
            for p in sorted(self.path(f"{SRC}/persistence/migrations/postgresql").glob("*.sql"))
        )
        for domain in ("membership", "organization", "compliance"):
            if f"dom_{domain}.outbox_record" not in migrations:
                problems.append(f"no per-domain outbox for {domain}")
        if re.search(r"CREATE TABLE[^;]*\bpublic\.outbox", migrations, re.I):
            problems.append("a central shared outbox table exists (ADR-070 refuses one)")
        if "SCHEMA_VERSION_IDENTITY_IMMUTABLE" not in migrations:
            problems.append("no trigger makes a written event's identity immutable")

        unit = self.read(f"{SRC}/runtime/unit_of_work.py")
        for direction in ("staged and not self.domain_writes", "domain_writes and not self.staged"):
            if direction not in unit:
                problems.append(f"the unit of work does not refuse: {direction}")
        if "assert_not_domain_connection" not in self.read(f"{SRC}/runtime/dispatcher.py"):
            problems.append("the dispatcher does not refuse the domain transaction's connection")

        self.require_suite_green(problems)
        covered = self.matching_tests("without_a_domain_write", "domain_transactions_own_connection",
                                      "uncommitted_outbox_row")
        if len(covered) < 3:
            problems.append(f"outbox invariants under-tested: {covered}")
        return (PASS if not problems else FAIL), problems, {"tests": covered}

    # ==================================================================
    # G9  durable inbox / deduplication
    # ==================================================================
    def g9_inbox(self):
        problems: list[str] = []
        migrations = "\n".join(
            p.read_text(encoding="utf-8")
            for p in sorted(self.path(f"{SRC}/persistence/migrations/postgresql").glob("*.sql"))
        )
        if "deduplication_record" not in migrations:
            problems.append("no durable deduplication table")
        if not re.search(r"PRIMARY KEY \(consumer_domain, consumer_name, event_id\)", migrations):
            problems.append("deduplication uniqueness is not a primary key")
        stores = self.read(f"{SRC}/persistence/postgres_stores.py")
        if "ON CONFLICT (consumer_domain, consumer_name, event_id)" not in stores:
            problems.append("the deduplication store does not rely on the primary key")
        consumer = self.read(f"{SRC}/runtime/consumer.py")
        if re.search(r"self\._seen\s*[:=]", consumer):
            problems.append("the runtime keeps deduplication state in a process dictionary")
        covered = self.matching_tests("durable", "racing", "f05", "f04")
        if len(covered) < 4:
            problems.append(f"deduplication under-tested: {covered}")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {"tests": covered}

    # ==================================================================
    # G10  acknowledgement, crash and redelivery
    # ==================================================================
    def g10_ack_crash_redelivery(self):
        problems: list[str] = []
        covered = self.matching_tests("f02", "f03", "f04", "f05")
        for fixture in ("f02", "f03", "f04", "f05"):
            if not any(fixture in name for name in covered):
                problems.append(f"no fixture exercises {fixture}")
        broker = self.read(f"{SRC}/transport/rabbitmq.py")
        if "confirm_delivery" not in broker:
            problems.append("publisher confirms are not enabled")
        if "x-queue-type\": \"quorum\"" not in broker and "'x-queue-type': 'quorum'" not in broker:
            problems.append("queues are not quorum queues")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {"tests": covered}

    # ==================================================================
    # G11  ordering and versioning
    # ==================================================================
    def g11_ordering(self):
        problems: list[str] = []
        registry = self.read_json(f"{DOCS}/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json")
        allowed = {"per_aggregate", "per_stream", "per_organization_and_aggregate"}
        for topic in registry["topics"]:
            if topic["ordering_scope_kind"] not in allowed:
                problems.append(f"undeclared ordering model on {topic['topic_id']}")
        if "GLOBAL_ORDERING" in json.dumps(registry).upper():
            problems.append("a global ordering assumption appears in the register")
        if str(registry.get("ordering_vocabulary", "")).find("PACK-13") < 0:
            problems.append("the register does not name PACK-13's ordering vocabulary")
        registry_module = self.read(f"{SRC}/topology/registry.py")
        if "from epd2_data_plane_service.delivery import OrderingScope, OrderingScopeKind" not in registry_module:
            problems.append("ordering does not come from PACK-13")
        mixed = [t for t in registry["topics"] if len(t["event_versions"]) > 1]
        if not mixed:
            problems.append("the register exercises no mixed-version window")
        covered = self.matching_tests("f06", "f11", "out_of_order")
        if len(covered) < 3:
            problems.append(f"ordering and versioning under-tested: {covered}")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {
            "mixed_version_topics": [t["topic_id"] for t in mixed], "tests": covered,
        }

    # ==================================================================
    # G12  schema and compatibility
    # ==================================================================
    def g12_schema_compatibility(self):
        problems: list[str] = []
        catalogue = self.read(f"{SRC}/topology/catalogue.py")
        if "contracts/events" not in catalogue:
            problems.append("the catalogue is not derived from the canonical contracts")
        for path in self.source_files():
            text = path.read_text(encoding="utf-8")
            if re.search(r"class \w*SchemaRegistry\b", text):
                problems.append(f"a second schema registry is defined in {self.relative(path)}")
        register = self.read_json(f"{DOCS}/API04_EVENT_SCHEMA_REGISTER.json")
        if register.get("registry_authority") != "contracts/events":
            problems.append("the schema register does not point at the canonical registry")
        for entry in register["event_types"]:
            schema = self.path(entry["payload_schema"])
            if not schema.exists():
                problems.append(f"registered schema missing: {entry['payload_schema']}")
                continue
            if hashlib.sha256(schema.read_bytes()).hexdigest() != entry["payload_schema_sha256"]:
                problems.append(f"schema digest drifted: {entry['event_type']}")
        covered = self.matching_tests("f07", "f08", "f09", "f10", "digest_mismatch")
        if len(covered) < 5:
            problems.append(f"schema handling under-tested: {covered}")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {
            "canonical_event_types": len(register["event_types"]), "tests": covered,
        }

    # ==================================================================
    # G13  retry, dead-letter and quarantine
    # ==================================================================
    def g13_retry_dlq(self):
        problems: list[str] = []
        registry = self.read_json(f"{DOCS}/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json")
        for topic in registry["topics"]:
            budget = int(topic["retry_policy"]["max_attempts"])
            if not 1 <= budget <= 10:
                problems.append(f"unbounded retry budget on {topic['topic_id']}: {budget}")
            if not topic["dead_letter_policy"].get("queue"):
                problems.append(f"no dead-letter queue declared for {topic['topic_id']}")
            if topic["data_classification"] == "restricted" and \
                    topic["dead_letter_policy"].get("payload") != "REFERENCE_ONLY":
                problems.append(f"restricted topic retains payload in quarantine: {topic['topic_id']}")
        consumer = self.read(f"{SRC}/runtime/consumer.py")
        if "_RETRYABLE" not in consumer:
            problems.append("there is no declared retryable set; everything or nothing would retry")
        if "MESSAGE_SILENT_DROP_PROHIBITED" not in self.read(f"{SRC}/reason_codes.py"):
            problems.append("no reason code names a silent drop as prohibited")
        covered = self.matching_tests("f07", "f22", "restricted_topic_quarantines")
        if len(covered) < 3:
            problems.append(f"quarantine behaviour under-tested: {covered}")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {"tests": covered}

    # ==================================================================
    # G14  replay and re-drive governance
    # ==================================================================
    def g14_replay_redrive(self):
        problems: list[str] = []
        policy = self.read_json(f"{DOCS}/API04_REPLAY_REDRIVE_POLICY.json")
        for required in ("replay_kinds", "redrive_kinds", "prohibited_operations",
                         "required_evidence", "checks_before_a_message_moves"):
            if required not in policy:
                problems.append(f"the replay/re-drive policy has no {required}")
        prohibited = json.dumps(policy.get("prohibited_operations", [])).lower()
        for phrase in ("requeue all", "replay all"):
            if phrase not in prohibited:
                problems.append(f"the policy does not prohibit {phrase!r}")
        redrive = self.read(f"{SRC}/runtime/redrive.py")
        if "RedriveBulkUnboundedProhibitedError" not in redrive:
            problems.append("there is no refusal for an unbounded re-drive")
        replay = self.read(f"{SRC}/runtime/replay.py")
        if "replay_preserves_history" not in replay:
            problems.append("replay does not use PACK-13's history-preservation check")
        covered = self.matching_tests("redrive", "replay")
        if len(covered) < 8:
            problems.append(f"replay and re-drive under-tested: {len(covered)} tests")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {"tests": len(covered)}

    # ==================================================================
    # G15  FIR-AUTH-001 at the asynchronous commit
    # ==================================================================
    def g15_async_reauthorization(self):
        problems: list[str] = []
        register = self.read_json(f"{DOCS}/API04_CONSEQUENTIAL_ASYNC_REGISTER.json")
        registry = self.read_json(f"{DOCS}/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json")
        consequential = {
            s["subscription_id"] for s in registry["subscriptions"] if s["consequential_effect"]
        }
        registered = {row["subscription_id"] for row in register["consequential_subscriptions"]}
        if consequential != registered:
            problems.append(
                f"consequential register and topic register disagree: "
                f"{sorted(consequential ^ registered)}"
            )
        for subscription in registry["subscriptions"]:
            if subscription["consequential_effect"] and not subscription["commit_reauthorisation_required"]:
                problems.append(f"consequential subscription without reauthorisation: "
                                f"{subscription['subscription_id']}")
        module = self.read(f"{SRC}/runtime/reauthorization.py")
        if "FOR UPDATE" not in module:
            problems.append("the commit-time authority read is not taken under lock")
        for condition in ("authority_active", "object_version", "policy_version", "deadline_at"):
            if condition not in module:
                problems.append(f"no commit-time check for {condition}")
        covered = self.matching_tests("f16", "f17", "f18", "f19")
        for fixture in ("f16", "f17", "f18", "f19"):
            if not any(fixture in name for name in covered):
                problems.append(f"no fixture exercises {fixture}")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {"tests": covered}

    # ==================================================================
    # G16  readiness and lag
    # ==================================================================
    def g16_readiness(self):
        problems: list[str] = []
        readiness = self.read(f"{SRC}/runtime/readiness.py")
        for level in ("ready", "authoritatively_ready", "lineage_blocking_reason_codes"):
            if level not in readiness:
                problems.append(f"readiness has no {level}")
        lag = self.read(f"{SRC}/runtime/lag.py")
        if "lag_band_for" not in lag:
            problems.append("lag is not banded through PACK-13")
        probe = self.live_python(
            "import json,sys;"
            "sys.path[:0]=['src','tests','../../packages/python/epd2-core/src',"
            "'../audit-core/src','../data-plane-service/src'];"
            "from support import harness;"
            "rt=harness.make_runtime();rt.bootstrap();s=rt.readiness();"
            "print(json.dumps(s.as_json()))"
        )
        if probe["ready"] is not True:
            problems.append(f"the live runtime is not ready: {probe['blocking_reason_codes']}")
        if probe["lineage_blocking_reason_codes"] != ["PREDECESSOR_NOT_ACCEPTED"]:
            problems.append("the lineage block is not reported separately")
        for name, band in probe["signals"]["lag_bands"].items():
            if band.isdigit():
                problems.append(f"lag reported as an exact figure for {name}")
        return (PASS if not problems else FAIL), problems, {"readiness": probe}

    # ==================================================================
    # G17  identifier and privacy governance
    # ==================================================================
    def g17_identifier_privacy(self):
        problems: list[str] = []
        privacy = self.read(f"{SRC}/runtime/privacy.py")
        if "reject_prohibited_payload_keys" not in privacy:
            problems.append("the payload gate is not PACK-13's")
        if "GLOBAL_IDENTITY_KEYS" not in privacy:
            problems.append("the global-identity refusal does not use the canonical key set")
        if re.search(r"^PROHIBITED_PAYLOAD_KEYS\s*=\s*(frozenset|\{)", privacy, re.M):
            problems.append("a second prohibited-key list is defined here")
        if "NETWORK_CORRELATION_KEYS" not in privacy:
            problems.append("infrastructure correlation metadata is not refused")

        registers = sorted(self.path(DOCS).glob("*.json"))
        banned = {"global_user_id", "global_person_id", "universal_id", "national_id", "email"}
        for register in registers:
            body = register.read_text(encoding="utf-8").lower()
            for key in banned:
                if f'"{key}"' in body:
                    problems.append(f"a universal person identifier appears in {register.name}")
        covered = self.matching_tests("account_id", "network_correlation", "unsafe_refusal")
        if len(covered) < 3:
            problems.append(f"privacy under-tested: {covered}")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {"tests": len(covered)}

    # ==================================================================
    # G18  voting isolation
    # ==================================================================
    def g18_voting_isolation(self):
        problems: list[str] = []
        registry = self.read_json(f"{DOCS}/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json")
        if registry["voting_plane"]["exists"] is not False:
            problems.append("this stage declares a voting plane")
        if not registry["voting_plane"].get("reason"):
            problems.append("the absence of a voting plane is not reasoned")
        for topic in registry["topics"]:
            if any(token in topic["topic_id"] for token in ("vote", "ballot", "tally")):
                problems.append(f"a voting topic exists: {topic['topic_id']}")
        environment = dict(os.environ)
        environment["HOME"] = "/var/lib/rabbitmq"
        node = environment.get("RABBITMQ_NODENAME", "epd2api04@localhost")
        process = subprocess.run(
            ["rabbitmqctl", "-n", node, "list_vhosts", "name"],
            capture_output=True, text=True, env=environment, timeout=120,
        )
        if process.returncode != 0:
            raise EnvironmentBlocked("missing input: the live broker could not be queried")
        vhosts = [line.strip() for line in process.stdout.splitlines() if line.strip()]
        for vhost in vhosts:
            if any(token in vhost.lower() for token in ("vote", "ballot", "tally")):
                problems.append(f"a voting virtual host exists: {vhost}")
        covered = self.matching_tests("voting")
        if len(covered) < 2:
            problems.append(f"voting isolation under-tested: {covered}")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {"vhosts": vhosts, "tests": covered}

    # ==================================================================
    # G19  retention and legal hold
    # ==================================================================
    def g19_retention(self):
        problems: list[str] = []
        registry = self.read_json(f"{DOCS}/API04_TOPIC_AND_SUBSCRIPTION_REGISTER.json")
        for topic in registry["topics"]:
            if not topic.get("retention_schedule"):
                problems.append(f"no retention schedule on {topic['topic_id']}")
            if not topic["dead_letter_policy"].get("retention_schedule"):
                problems.append(f"no quarantine retention schedule on {topic['topic_id']}")
        migrations = "\n".join(
            p.read_text(encoding="utf-8")
            for p in sorted(self.path(f"{SRC}/persistence/migrations/postgresql").glob("*.sql"))
        )
        for table in ("api04_gov.legal_hold", "api04_gov.disposition_record"):
            if table not in migrations:
                problems.append(f"no {table}")
        replay = self.read(f"{SRC}/runtime/replay.py")
        if "RECORD_UNDER_LEGAL_HOLD" not in replay:
            problems.append("a legal hold does not block a replay")
        covered = self.matching_tests("legal_hold", "purged", "retention")
        if len(covered) < 3:
            problems.append(f"retention and legal hold under-tested: {covered}")
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {"tests": len(covered)}

    # ==================================================================
    # G20  real broker runtime, exactly pinned
    # ==================================================================
    def g20_real_broker(self):
        problems: list[str] = []
        broker_module = self.read(f"{SRC}/transport/rabbitmq.py")
        if 'BROKER_VERSION = "3.12.1"' not in broker_module:
            problems.append("the broker version is not pinned to 3.12.1")
        if re.search(r'BROKER_VERSION\s*=\s*"[^"]*latest', broker_module):
            problems.append("the broker version is a floating tag")
        probe = self.live_python(
            "import json,sys;"
            "sys.path[:0]=['src','tests','../../packages/python/epd2-core/src',"
            "'../audit-core/src','../data-plane-service/src'];"
            "from support import harness;"
            "rt=harness.make_runtime();info=rt.bootstrap();b=rt.broker_for();"
            "print(json.dumps({'reported': b.reported_version(),"
            "'pinned': b.assert_pinned_version(),"
            "'declared': info['declared'], 'product': info['broker_product']}))"
        )
        if probe["reported"] != "3.12.1":
            problems.append(f"the live broker reports {probe['reported']!r}")
        return (PASS if not problems else FAIL), problems, {"broker": probe}

    # ==================================================================
    # G21  live PostgreSQL runtime
    # ==================================================================
    def g21_live_postgres(self):
        problems: list[str] = []
        if 'REQUIRED_ENGINE_VERSION = "16.15"' not in self.read(f"{SRC}/persistence/db.py"):
            problems.append("the governed engine version is not 16.15")
        probe = self.live_python(
            "import json,sys;"
            "sys.path[:0]=['src','tests','../../packages/python/epd2-core/src',"
            "'../audit-core/src','../data-plane-service/src'];"
            "from support import harness;"
            "from epd2_events_messaging_runtime.persistence import db;"
            "c=db.connect(harness.POSTGRES_DSN);"
            "print(json.dumps({'engine': db.assert_engine(c),"
            "'migrations': db.migration_state(c)}))"
        )
        if probe["engine"] != "16.15":
            problems.append(f"the live engine reports {probe['engine']!r}")
        if not probe["migrations"]["complete"]:
            problems.append(f"migrations incomplete: {probe['migrations']}")
        return (PASS if not problems else FAIL), problems, {"postgresql": probe}

    # ==================================================================
    # G22  inherited API-chain non-regression
    # ==================================================================
    def g22_api_chain_non_regression(self):
        raise EnvironmentBlocked(
            "missing input: the exact independently accepted API-01, API-02 and API-03 "
            "archives are not present in this environment. The inherited API-chain "
            "non-regression phase runs against those exact bytes and against nothing "
            "else; API-03 R13 is a working integration predecessor and is not a "
            "substitute for them."
        )

    # ==================================================================
    # G23  DATA no-new-regression
    # ==================================================================
    def g23_data_non_regression(self):
        raise EnvironmentBlocked(
            "missing input: the accepted DATA baseline archive and its validator are "
            "not present in this environment, so the DATA no-new-regression phase "
            "cannot be executed here."
        )

    # ==================================================================
    # G24  cross-service failure fixtures
    # ==================================================================
    def g24_failure_fixtures(self):
        problems: list[str] = []
        names = self.suite_names()
        for fixture in MANDATED_FIXTURES:
            if not any(f"test_{fixture}_" in name for name in names):
                problems.append(f"mandated failure fixture {fixture.upper()} is absent")
        self.require_suite_green(problems)
        executed = [n for n in names if re.match(r"test_f\d\d", n)]
        return (PASS if not problems else FAIL), problems, {
            "mandated": len(MANDATED_FIXTURES), "executed": len(executed),
        }

    # ==================================================================
    # G25  secret and evidence sanitation
    # ==================================================================
    def g25_secret_sanitation(self):
        problems: list[str] = []
        for path in self.api04_text_files():
            relative = self.relative(path)
            if relative in SECRET_SCAN_ALLOWLIST:
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            for pattern in SECRET_PATTERNS:
                if pattern.search(text):
                    problems.append(f"secret-shaped value in {relative}")
                    break
        # The allowlist must still be earning its place.
        for relative, reason in SECRET_SCAN_ALLOWLIST.items():
            target = self.path(relative)
            if not target.exists():
                problems.append(f"allowlisted file no longer exists: {relative} ({reason})")
                continue
            text = target.read_text(encoding="utf-8", errors="replace")
            if not any(p.search(text) for p in SECRET_PATTERNS):
                problems.append(
                    f"allowlisted file no longer contains what it was allowlisted for: {relative}"
                )
        return (PASS if not problems else FAIL), problems, {
            "allowlist": SECRET_SCAN_ALLOWLIST,
        }

    # ==================================================================
    # G26  mutation self-test
    # ==================================================================
    def g26_mutation_selftest(self):
        problems: list[str] = []
        sys.path.insert(0, str(self.path(f"{SERVICE}/tests")))
        try:
            from mutation.mutations import MUTATIONS  # type: ignore[import-not-found]
        finally:
            sys.path.pop(0)
        if len(MUTATIONS) < 42:
            problems.append(f"the mandate is at least 42 mutations; the catalogue has {len(MUTATIONS)}")
        names = self.suite_names()
        detected = [n for n in names if n.startswith("test_the_mutation_is_detected")]
        if len(detected) != len(MUTATIONS):
            problems.append(
                f"{len(detected)} mutations were run against {len(MUTATIONS)} in the catalogue"
            )
        self.require_suite_green(problems)
        return (PASS if not problems else FAIL), problems, {
            "catalogue": len(MUTATIONS),
            "executed": len(detected),
            "areas": sorted({m.area for m in MUTATIONS}),
        }

    # ==================================================================
    # G27  no API-05+ leakage
    # ==================================================================
    def g27_no_forward_scope(self):
        problems: list[str] = []
        markers = ("api-05", "api05", "provider_gateway", "vendor_callback")
        for path in self.api04_text_files():
            relative = self.relative(path)
            if relative in FORWARD_SCOPE_EXEMPT:
                continue
            for number, line in enumerate(
                path.read_text(encoding="utf-8", errors="replace").splitlines(), start=1
            ):
                lowered = line.lower()
                # A sentence that names the boundary in order to refuse it is not
                # a leak across it — the same negation rule G2 uses.
                if any(negation in lowered for negation in CLAIM_NEGATIONS):
                    continue
                for marker in markers:
                    if marker in lowered:
                        problems.append(
                            f"forward-scope marker {marker!r} in {relative}:{number}"
                        )
        return (PASS if not problems else FAIL), problems[:30], {"markers": list(markers)}

    # -- run ----------------------------------------------------------------
    GATES: tuple[tuple[int, str, str], ...] = (
        (0, "archive / root / hygiene", "g0_hygiene"),
        (1, "canonical governance and carried closure", "g1_canonical_governance"),
        (2, "PRESEAL status correctness", "g2_preseal_status"),
        (3, "API-03 R13 recorded only as working predecessor", "g3_api03_working_predecessor"),
        (4, "inventory / accounting", "g4_inventory"),
        (5, "canonical envelope uniqueness and no parallel port", "g5_envelope_and_ports"),
        (6, "runtime topic / subscription registry", "g6_topic_registry"),
        (7, "service identity + ACL", "g7_identity_and_acl"),
        (8, "transactional outbox", "g8_outbox"),
        (9, "durable inbox / deduplication", "g9_inbox"),
        (10, "acknowledgement / crash / redelivery", "g10_ack_crash_redelivery"),
        (11, "ordering / versioning", "g11_ordering"),
        (12, "schema compatibility", "g12_schema_compatibility"),
        (13, "retry / dead-letter / quarantine", "g13_retry_dlq"),
        (14, "replay / re-drive governance", "g14_replay_redrive"),
        (15, "asynchronous FIR-AUTH-001", "g15_async_reauthorization"),
        (16, "readiness / lag", "g16_readiness"),
        (17, "identifier / privacy governance", "g17_identifier_privacy"),
        (18, "voting isolation", "g18_voting_isolation"),
        (19, "retention / legal hold", "g19_retention"),
        (20, "real broker runtime", "g20_real_broker"),
        (21, "live PostgreSQL runtime", "g21_live_postgres"),
        (22, "inherited API-chain non-regression", "g22_api_chain_non_regression"),
        (23, "DATA no-new-regression", "g23_data_non_regression"),
        (24, "cross-service failure fixtures", "g24_failure_fixtures"),
        (25, "secret / evidence sanitation", "g25_secret_sanitation"),
        (26, "mutation self-test", "g26_mutation_selftest"),
        (27, "no API-05+ leakage", "g27_no_forward_scope"),
    )

    def run(self, only: set[int] | None = None) -> dict[str, Any]:
        if self.run_suite and only is None:
            self.execute_suite()
        elif not self.run_suite:
            self.suite.update(self.parse_junit(self.root / "validation/api04/junit.xml"))
        for number, title, method in self.GATES:
            if only is not None and number not in only:
                continue
            self.gate(number, title, getattr(self, method))
        failed = [r.number for r in self.results if r.result == FAIL]
        blocked = [r.number for r in self.results if r.result == BLOCKED]
        return {
            "validator": VALIDATOR_VERSION,
            "root": str(self.root),
            "status": "PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED",
            "result": PASS if not failed else FAIL,
            "failed_gates": failed,
            "environment_blocked_gates": blocked,
            "gate_count": len(self.results),
            "suite": {k: v for k, v in self.suite.items() if k != "names"},
            "gates": [
                {
                    "gate": r.number,
                    "title": r.title,
                    "result": r.result,
                    "problems": r.problems,
                    "evidence": r.evidence,
                }
                for r in self.results
            ],
            "self_acceptance_claim": "NONE",
            "authoritative_verification":
                "NOT PERFORMED. Authoritative acceptance is independent and is not "
                "claimed, performed or implied here.",
        }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="EPD2 API-04 validator")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--no-suite", action="store_true")
    parser.add_argument("--gates", default="")
    parser.add_argument("--out", default="validation/api04/validator_result.json")
    arguments = parser.parse_args(argv)

    root = Path(arguments.root).resolve()
    only = {int(x) for x in arguments.gates.split(",") if x.strip()} or None

    if only is None:
        target = root / "validation/api04"
        if target.exists():
            for stale in target.iterdir():
                stale.unlink()

    validator = Validator(root, run_suite=not arguments.no_suite)
    document = validator.run(only)

    out = root / arguments.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")

    for gate in document["gates"]:
        marker = {PASS: "PASS", FAIL: "FAIL", BLOCKED: "BLOCKED"}[gate["result"]]
        print(f"G{gate['gate']:<2} {marker:<7} {gate['title']}")
        for problem in gate["problems"]:
            print(f"        - {problem}")

    print(f"API04_PRESEAL_RESULT:{document['result']}:{arguments.out}")
    return 0 if document["result"] == PASS else 2


if __name__ == "__main__":
    raise SystemExit(main())
