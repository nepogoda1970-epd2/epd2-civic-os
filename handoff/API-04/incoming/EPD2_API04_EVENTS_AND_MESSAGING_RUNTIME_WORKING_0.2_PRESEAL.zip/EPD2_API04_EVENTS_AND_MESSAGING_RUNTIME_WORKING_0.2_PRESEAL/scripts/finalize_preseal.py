#!/usr/bin/env python3
"""Seal the API-04 working preseal, in a fixed order.

The order matters and is enforced rather than documented:

    1  clean every build artefact the tooling can leave behind
    2  regenerate the derived registers until they stop changing
    3  run the validator, which runs the whole suite itself
    4  require the terminal line to be PASS
    5  regenerate the file manifest over the sealed content
    6  write SHA256SUMS over every file in the archive
    7  package the archive and write its SHA-256 sidecar
    8  extract the archive fresh and verify every digest again

Step 8 is the one that matters. An archive whose digests are only checked
in the directory it was built from is an archive whose digests were never
independently checked.

Usage:  finalize_preseal.py [--root TREE] [--out DIR] [--skip-validator]
"""

from __future__ import annotations

import sys

sys.dont_write_bytecode = True

import argparse
import hashlib
import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

ARCHIVE = "EPD2_API04_EVENTS_AND_MESSAGING_RUNTIME_WORKING_0.2_PRESEAL"
TERMINAL = "API04_PRESEAL_RESULT:PASS:validation/api04/validator_result.json"
ARTEFACTS = ("__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache")


def clean(root: Path) -> int:
    removed = 0
    for name in ARTEFACTS:
        for path in root.rglob(name):
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
                removed += 1
    for path in root.rglob("*.pyc"):
        path.unlink(missing_ok=True)
        removed += 1
    return removed


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def sealed_files(root: Path, *, exclude: set[str]) -> list[Path]:
    return sorted(
        p for p in root.rglob("*")
        if p.is_file()
        and not any(part in ARTEFACTS for part in p.parts)
        and str(p.relative_to(root)) not in exclude
    )


def build_registers(root: Path) -> None:
    """Run the generator until the tree stops changing.

    The inventory counts the registers, and the manifest covers them, so one
    pass leaves both one step behind. Converging is the honest fix; hand-editing
    the count would be the dishonest one.
    """
    previous = None
    for attempt in range(5):
        subprocess.run(
            [sys.executable, "scripts/build_registers.py"],
            cwd=root, check=True, capture_output=True, text=True,
        )
        current = {
            str(p.relative_to(root)): digest(p)
            for p in sorted((root / "docs/api/API-04").glob("*.json"))
        }
        if current == previous:
            print(f"registers converged after {attempt} additional pass(es)")
            return
        previous = current
    raise SystemExit("the derived registers did not converge")


def run_validator(root: Path) -> None:
    process = subprocess.run(
        [sys.executable, "scripts/validate_api04.py"],
        cwd=root, capture_output=True, text=True, timeout=7200,
    )
    print(process.stdout[-4000:])
    if TERMINAL not in process.stdout:
        raise SystemExit(
            "the validator did not report the working-preseal PASS terminal line; "
            "the archive is not sealed"
        )


def write_sha256sums(root: Path, exclude: set[str]) -> Path:
    target = root / "SHA256SUMS.txt"
    lines = [
        "# Every file in this working preseal archive.",
        "#",
        "# Status: PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED. These digests record what",
        "# the archive contains. They are not an acceptance and not a lineage.",
        "#",
    ]
    files = sealed_files(root, exclude=exclude | {"SHA256SUMS.txt"})
    lines.append(f"# files: {len(files)}")
    lines.append("")
    for path in files:
        lines.append(f"{digest(path)}  {path.relative_to(root)}")
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target


def package(root: Path, out: Path) -> tuple[Path, Path]:
    out.mkdir(parents=True, exist_ok=True)
    archive = out / f"{ARCHIVE}.zip"
    if archive.exists():
        archive.unlink()
    files = sealed_files(root, exclude=set())
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in files:
            bundle.write(path, f"{ARCHIVE}/{path.relative_to(root)}")
    sidecar = out / f"{ARCHIVE}.zip.sha256"
    sidecar.write_text(f"{digest(archive)}  {archive.name}\n", encoding="utf-8")
    return archive, sidecar


def verify_fresh_extract(archive: Path) -> dict:
    with tempfile.TemporaryDirectory() as scratch:
        target = Path(scratch)
        with zipfile.ZipFile(archive) as bundle:
            bundle.extractall(target)
        root = target / ARCHIVE
        problems: list[str] = []

        sums = root / "SHA256SUMS.txt"
        checked = 0
        for line in sums.read_text(encoding="utf-8").splitlines():
            if not line.strip() or line.startswith("#"):
                continue
            expected, relative = line.split(maxsplit=1)
            path = root / relative.strip()
            if not path.exists():
                problems.append(f"missing from the extract: {relative.strip()}")
                continue
            if digest(path) != expected:
                problems.append(f"digest mismatch after extraction: {relative.strip()}")
            checked += 1

        listed = {
            line.split(maxsplit=1)[1].strip()
            for line in sums.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.startswith("#")
        }
        for path in sealed_files(root, exclude={"SHA256SUMS.txt"}):
            if str(path.relative_to(root)) not in listed:
                problems.append(f"present in the extract but unlisted: {path.relative_to(root)}")

        for artefact in ARTEFACTS:
            if list(root.rglob(artefact)):
                problems.append(f"build artefact survived into the archive: {artefact}")

        status = (root / "docs/api/API-04/API04_STATUS.txt").read_text(encoding="utf-8").strip()
        if status != "PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED":
            problems.append(f"the extracted archive's status is {status!r}")

        lineage = json.loads(
            (root / "docs/api/API-04/API04_LINEAGE.json").read_text(encoding="utf-8")
        )
        if lineage["accepted_predecessor_sha256"] is not None:
            problems.append("the extracted archive freezes a predecessor SHA-256")
        if lineage["self_acceptance_claim"] != "NONE":
            problems.append("the extracted archive makes a self-acceptance claim")

        return {"files_checked": checked, "problems": problems}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="seal the API-04 working preseal")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--out", default=None)
    parser.add_argument("--skip-validator", action="store_true")
    arguments = parser.parse_args(argv)

    root = Path(arguments.root).resolve()
    out = Path(arguments.out).resolve() if arguments.out else root.parent / "out"

    print(f"1  cleaned {clean(root)} build artefact(s)")
    print("2  regenerating the derived registers")
    build_registers(root)

    if arguments.skip_validator:
        print("3  validator SKIPPED by request — this run does not seal anything")
    else:
        print("3  running the validator (it runs the whole suite)")
        run_validator(root)
        print("4  terminal line confirmed")

    print(f"5  cleaned {clean(root)} artefact(s) left by the validator run")
    subprocess.run(
        [sys.executable, "scripts/build_registers.py", "--manifest-only"],
        cwd=root, check=True, capture_output=True, text=True,
    )
    sums = write_sha256sums(root, exclude=set())
    print(f"6  wrote {sums.relative_to(root)}")

    archive, sidecar = package(root, out)
    print(f"7  packaged {archive.name} ({archive.stat().st_size:,} bytes)")
    print(f"   sidecar  {sidecar.read_text().strip()}")

    report = verify_fresh_extract(archive)
    print(f"8  fresh extract: {report['files_checked']} digests verified")
    for problem in report["problems"]:
        print(f"   PROBLEM {problem}")
    if report["problems"]:
        return 2
    print("   fresh extract verified")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
