#!/usr/bin/env python3
"""Provision the API-04 reference broker from the governed registers.

An operator step, not a runtime step, and it uses a **separate** credential from
every producer and consumer. Two properties matter and both are asserted by the
validator:

* every service principal is created with ``configure=^$`` — it may declare
  nothing, so a protected topic cannot be brought into existence by a producer or
  a consumer that simply uses it;
* one plane. There is no voting virtual host, because API-04 carries no voting
  material at all: PACK-13 refuses it at every payload boundary
  (``P13-VOTE-002``, ``P13-VOTE-006``) and ``P13-VOTE-008`` leaves the voting
  data plane's topology to PACK-15/16.

Passwords are generated here and written to a file **outside** the package tree
with mode 0600. The validator fails if a credential file appears in the archive.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

RABBITMQCTL = os.environ.get("RABBITMQCTL", "rabbitmqctl")
NODENAME = os.environ.get("RABBITMQ_NODENAME", "epd2api04@localhost")


def ctl(*args: str) -> str:
    env = dict(os.environ)
    env["HOME"] = env.get("RABBITMQ_HOME", "/var/lib/rabbitmq")
    env["RABBITMQ_NODENAME"] = NODENAME
    result = subprocess.run(
        [RABBITMQCTL, "-n", NODENAME, *args], capture_output=True, text=True, env=env
    )
    tolerated = ("already_exists", "already exists")
    if result.returncode != 0 and not any(t in result.stderr for t in tolerated):
        raise SystemExit(f"rabbitmqctl {' '.join(args)} failed:\n{result.stderr}")
    return result.stdout


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--register", required=True)
    parser.add_argument("--acl", required=True)
    parser.add_argument("--secrets-out", required=True)
    args = parser.parse_args()

    register = json.loads(Path(args.register).read_text())
    acl = json.loads(Path(args.acl).read_text())
    if register["voting_plane"]["exists"]:
        raise SystemExit("this provisioner declares no voting plane; the register says one exists")

    planes = list(register["planes"])
    if len(planes) != 1:
        raise SystemExit(f"expected exactly one plane, the register declares {planes}")
    plane = planes[0]

    secrets: dict[str, str] = {}
    ctl("add_vhost", plane)

    provisioner = f"api04-provisioner-{plane}"
    password = "prov-" + os.urandom(16).hex()
    ctl("add_user", provisioner, password)
    ctl("change_password", provisioner, password)
    ctl("set_permissions", "-p", plane, provisioner, ".*", ".*", ".*")
    secrets[provisioner] = password

    subscriptions = register["subscriptions"]
    topics = {t["topic_id"]: t for t in register["topics"]}

    for service in sorted(acl["service_principals"]):
        user = f"svc-{service}"
        password = "svc-" + os.urandom(16).hex()
        ctl("add_user", user, password)
        ctl("change_password", user, password)
        secrets[user] = password

        writable = sorted(
            {t["destination_name"] for t in topics.values() if service in t["producer_services"]}
        )
        readable = sorted(
            {s["queue"] for s in subscriptions if s["consumer_service"] == service}
            | {s["dead_letter_queue"] for s in subscriptions if s["consumer_service"] == service}
        )
        if readable:
            # a consumer publishes its own retry and quarantine copies explicitly,
            # so a disposition is an auditable act rather than a broker side effect
            writable = writable + [f"dlx.retry.{plane}", f"dlx.quarantine.{plane}"]
        write_pattern = "^(" + "|".join(re.escape(x) for x in writable) + ")$" if writable else "^$"
        read_pattern = (
            "^(" + "|".join(re.escape(q) + r"(\.p\d+)?" for q in readable) + ")$" if readable else "^$"
        )
        ctl("set_permissions", "-p", plane, user, "^$", write_pattern, read_pattern)

    out = Path(args.secrets_out)
    out.write_text(json.dumps(secrets, indent=2) + "\n")
    os.chmod(out, 0o600)
    print(f"provisioned plane {plane!r} with {len(acl['service_principals'])} service principals")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
