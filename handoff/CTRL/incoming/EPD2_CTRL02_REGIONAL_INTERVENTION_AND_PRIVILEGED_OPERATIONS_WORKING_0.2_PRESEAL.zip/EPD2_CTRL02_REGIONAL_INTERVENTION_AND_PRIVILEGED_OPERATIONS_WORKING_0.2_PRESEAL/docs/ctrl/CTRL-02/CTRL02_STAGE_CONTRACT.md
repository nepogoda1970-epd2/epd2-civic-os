# CTRL-02 — Regional Intervention and Privileged Operations

Mode: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`

CTRL-02 implements bounded, auditable regional intervention and privileged
operations on the CTRL-01 authority foundation. CTRL-01 is consumed only as an
exact working predecessor and is not represented as accepted.

## Runtime boundary

The runtime provides four distinct intervention levels:

1. exact session or subject quarantine;
2. exact authority-grant suspension;
3. exact regional action restriction;
4. narrow, time-bounded temporary supervision.

Requests, approval, activation/execution, revocation/restoration and post-use
review are separate governed operations. Every consequential action is
commit-time reauthorized against exact actor, authority version, scope and
target version.

## Non-negotiable exclusions

- no universal administrator or wildcard action scope;
- no hierarchy-derived Bund competence or implicit takeover;
- no coarse `region_disabled` control;
- no self-approval or duplicate-person quorum;
- no approval-as-execution shortcut;
- no indefinite or silently renewed JIT/break-glass grant;
- no raw secret visibility implied by control authority;
- no provider/key custody inside CTRL;
- no voting administration, voter lookup, ballot access or identity linkage;
- no historical evidence rewrite or direct-DB action equivalence.

## Evidence and API contract

The control-console contract is server-backed and every mutation route maps to
a stable action ID, required capability, commit-time reauthorization and an
evidence output. The evidence journal is append-only and hash-linked.

## Seal rule

Development verification may pass while G04 remains
`BLOCKED_FOR_FINAL_SEAL`. Final seal additionally requires authoritative
CTRL-01 acceptance, exact accepted candidate identity and reconciliation of all
consumed CTRL-01 contracts, followed by fresh reruns of affected gates.

