# PACK-16D — External Conformance Report

**Round:** PACK-16D — Network-Enabled Finalization: Lockfile Regeneration,
Immutable ElectionGuard Provenance and Final Acceptance Alignment.
**Reference implementation. Not production code. Not certified. Not a PASS.**
**Repository version:** unchanged at `0.16.0` · **Canon version:** unchanged at `0.8.0`
**ADR:** `ADR-102`, status `proposed`
**NOT PRODUCTION READY. NOT LEGALLY ACTIVATED. PUBLIC-ELECTION ACTIVATION PROHIBITED BY DEFAULT.**

---

## 1. Scope

This document reports what external conformance evidence exists for the
PACK-16D reference implementation, what each piece of it proves, and —
at least as important — what it does not.

The audit finding `EXTERNAL CONFORMANCE: FAIL` was raised because the
first PACK-16D candidate shipped one class of evidence, self-generated
stability vectors, and called it conformance. It is not. `§8` of this
document is the strongest single argument that the audit was right.

A later audit found the correction's own weak spot: `CROSS-IMPLEMENTATION ON
TARGET PROFILE: PARTIAL`. Most of what the independent oracle checked ran on
the 1024-bit test group, and a single `cross-implementation` label made that
invisible. `§2` and `§5` are the answer to that finding — five evidence
classes instead of three, and all twelve core operations cross-checked on
`EPD2-CRYPTO-1` itself.

**The sources this document's comparisons rest on are defined in
`PACK-16D-PROTOCOL-EVIDENCE-MATRIX.md`** (`H-01` … `H-10`), which is the
single canonical PACK-16D Evidence Registry. This document carries the
`EC-*` rules and the comparison narrative; it defines no source of its own,
and where the two disagree about a source, the registry is right.

Artefacts:

| ID | Artefact | Role |
| -- | -------- | ---- |
| `EC-01` | `reference/testing/conformance.py` | `EvidenceClass`, `EXTERNAL_EVIDENCE_CLASSES`, `TARGET_PROFILE_CORE_OPERATIONS`, `ConformanceVector`, `PRIMARY_SOURCE_UNAVAILABLE`, `serialize()` |
| `EC-02` | `tests/reference/vectors/PACK-16D-CONFORMANCE-EVIDENCE.json` | The committed evidence catalogue, `catalog_version EPD2-CONFORMANCE-2`: **26 entries — 1 primary-source, 1 rfc-conformance, 8 cross-implementation-test-profile, 16 cross-implementation-target-profile, 0 internal-stability** |
| `EC-03` | `tests/reference/crossimpl/openssl_cli_ed25519_oracle.py` | Independent oracle 1: the OpenSSL **command-line tool**, out-of-process. Replaces the deleted in-process `openssl_ed25519_oracle.py` — see `§6` |
| `EC-04` | `tests/reference/crossimpl/independent_verifier.mjs` | Independent oracle 2: a Node.js verifier written from the documented grammar, `oracle_version = epd2-independent-verifier-2` |
| `EC-05` | `tests/reference/test_conformance.py` | Runs both oracles and enforces the catalogue's shape |
| `EC-06` | `tests/reference/vectors/PACK-16D-TEST-VECTORS.json` | The 23 internal stability vectors — **deliberately not part of `EC-02`** |
| `EC-90` | `tests/reference/test_target_conformance.py` | **15 tests, marked `slow_conformance`**: the twelve core operations plus two invalid fixtures, all on `EPD2-CRYPTO-1` |
| `EC-91` | `tests/reference/vectors/PACK-16D-TARGET-PROFILE-FIXTURES.json` | The exported deterministic fixtures, `catalog_version EPD2-TARGET-FIXTURES-1`, **12 cases**, `contains_secret_material: false` |
| `EC-92` | `tests/reference/vectors/PACK-16D-TARGET-PROFILE-TIMINGS.json` | The measured cost of running the core on 4096-bit parameters, written next to the fixtures rather than argued about |

## 2. Five evidence classes

`EvidenceClass` names exactly five, and every datum is labelled with the one
it belongs to, so that the weakest can never be mistaken for the strongest
and so that a cross-check on a group the election will never use cannot hide
behind one on the group it will.

| ID | Class | What it proves | What it does **not** prove |
| -- | ----- | -------------- | -------------------------- |
| `EC-07` | `internal-stability` | The canonical forms have not drifted between runs or releases. Produced by this implementation, consumed by this implementation | Anything about correctness. **An error made consistently is invisible to its own oracle** |
| `EC-08` | `primary-source` | An external party published a value and stated it is the right answer, and this implementation reproduces it | Coverage. It is evidence only for the operations for which such a value exists — see `§9` |
| `EC-93` | `rfc-conformance` | A **published RFC test vector** is reproduced by the primitive. The strongest evidence a cryptographic primitive can have, and the only Ed25519 evidence in this round that does not share an upstream with the provider | Anything about the protocol built on the primitive, and nothing about timing |
| `EC-94` | `cross-implementation-test-profile` | Software sharing no code with the producer computed the same answer, **on `EPD2-TESTONLY-NOTCONFORMANT-P1024-Q160`** | That the same holds in the group the election uses. It is evidence the *code paths* agree, not that the numbers are right in `EPD2-CRYPTO-1` |
| `EC-95` | `cross-implementation-target-profile` | The same, **on `EPD2-CRYPTO-1` itself**. The class the audit's `PARTIAL` finding existed to force into being | That either implementation matches a third party, a standards body's reference, or a complete independent ElectionGuard |

| ID | Rule |
| -- | ---- |
| `EC-09` | **The former single `cross-implementation` class was split, and nothing was reclassified upward by the split.** Every datum that ran on the test profile is now labelled `cross-implementation-test-profile` and stays there. The target-profile entries are new work in `EC-90`, not relabelled old work. A split that promoted existing evidence would be the audit finding restated as a fix |
| `EC-10` | The classes are ordered by strength and are never merged in reporting. `test_evidence_classes_are_distinct_and_labelled` asserts the enum is exactly these five |
| `EC-96` | Two derived constants make the classification enforceable rather than editorial. `EXTERNAL_EVIDENCE_CLASSES` holds **four** members — `internal-stability` is deliberately excluded, because it is the class that cannot detect a consistent error, which is the reason the others exist. `TARGET_PROFILE_CORE_OPERATIONS` names the **twelve** operations `§5` requires, so a catalogue missing one fails a test instead of leaving a reader to count |
| `EC-11` | Every catalogue entry carries `source_title`, `source_version`, `source_location`, `source_digest`, `retrieved`, `licence`, `canonical_input`, `expected_output`, `comparison_result` and `limitations`. **`limitations` is a required field, and `test_conformance_evidence_catalogue_is_committed_and_classified` asserts it is non-empty for every entry.** A datum with no stated limitation is not admissible here |
| `EC-12` | The same test asserts that a cross-implementation entry does not name the producer (`epd2_voting_service`) in its `source_location`. An oracle that lives inside the producer is not an oracle |

## 3. Why the self-generated stability vectors are not conformance evidence

| ID | Rule |
| -- | ---- |
| `EC-13` | `PACK-16D-TEST-VECTORS.json` holds **23** vectors. Its catalogue-level `provenance` reads *self-generated by the PACK-16D reference implementation on a TEST profile; NOT an external conformance vector*, and every vector repeats that string in its own `source` field |
| `EC-14` | Every vector's `status` is `stability-only (interoperability NOT established)` |
| `EC-15` | `test_self_generated_vectors_are_never_called_conformance` enforces both strings — the catalogue-level provenance and, per vector, the status and the source. The label cannot be quietly removed in a later edit |
| `EC-16` | **These vectors are useful and they are not conformance.** They detect drift: a change to the encoder, a domain label or a parameter changes a digest and the vector fails. They cannot detect an error the implementation makes consistently, because the implementation is its own oracle. `§8` is a worked example of exactly such an error |
| `EC-17` | The stability vectors were produced on a TEST profile, which is now named `EPD2-TESTONLY-NOTCONFORMANT-P1024-Q160`. The name itself carries the disclaimer |
| `EC-18` | They are kept in a **separate artefact** from `EC-02`, and the evidence catalogue contains **zero** `internal-stability` entries. The separation is structural, not editorial |

## 4. Primary-source and RFC-conformance evidence

Two entries, one in each class. Provenance below is quoted from the
committed artefacts.

### 4.1 `CV-01` — ElectionGuard 2.1 standard baseline parameters

The provenance of this entry was **restructured** by this correction. The
audit found `PARAMETER SOURCE REPRODUCIBILITY: PARTIAL — MUTABLE URL /
DIGEST NOT IN ARTIFACT`, and it was right: the round was resting a parameter
set on a `/main/` branch URL.

| ID | Field | Value |
| -- | ----- | ----- |
| `EC-19` | Operation | `parameter_set`, profile `EPD2-CRYPTO-1`, class `primary-source` |
| `EC-20` | **Authoritative** source (`H-08`) | *ElectionGuard Design Specification* **2.1.0**, §3.1.1 page 14, "Standard Baseline Cryptographic Parameters" — the specification, not an implementation of it |
| `EC-21` | Authoritative location | `https://github.com/microsoft/electionguard/releases/download/v2.1/EG_Spec_2_1.pdf` — a **versioned release asset under the tag `v2.1`**, recorded in the artefact with `document_url_immutability: "versioned release asset under the tag v2.1; not a branch reference"` |
| `EC-22` | Authoritative digest | SHA-256 `a263ab3cd2cf28f05de324ecd2d9752ffed45f814709582b4c2bb23d1826b936` — **INHERITED from PACK-16B evidence `F-01`, recorded first-hand there and NOT re-verified this round.** The document could not be retrieved in this environment |
| `EC-23` | **Corroborating** source (`H-01`) | `microsoft/electionguard-rust` — `src/eg/src/standard_parameters.rs` at commit `520651138110a13f777409e96606454df928ceac`, raw-byte SHA-256 `ad38bfa6…5770`, `provenance_status: "SATISFIED"`. The `/main/` location survives as a navigation URL with `human_readable_url_is_authoritative: false`. Licence: MIT (upstream repository) |
| `EC-24` | Withdrawn digest | The previous round's `3afa2962…` for that file is **WITHDRAWN, not relabelled**: it was computed over a markdown rendering rather than over the raw bytes. No `H-*` entry records a `source_sha256` for it |
| `EC-25` | Expected output | `parameter_digest = f0af5b71412ccf93a1eaf93364c223f5339cdb2815a2efcfa1bd775cd2bf17fb` — unchanged by the restructuring |
| `EC-26` | Comparison result | MATCH, verified locally by arithmetic: `q = 2²⁵⁶ − 189`, `q \| p−1`, `p = q·r + 1`, `1 < g < p`, `g^q = 1 mod p`, `p`, `q` and `r/2` probable prime, `p`'s leading and trailing 256 bits all ones, 3306 of 3584 middle bits equal `ln 2` |
| `EC-27` | Limitations | The constants were transcribed by automated fetch and **not re-read by a second human**. The corroborating file's commit pin and byte-exact digest were obtained on a network-enabled host; the build session verified the pin's internal consistency and re-derived every parameter offline, but did not re-fetch the bytes |

| ID | Rule |
| -- | ---- |
| `EC-28` | **The transcription is verified by mathematics, not by trusting the fetch.** Every relation in `EC-26` is one a single wrong hex digit anywhere would break |
| `EC-97` | **And now by reconstruction, which is stronger than either (`H-09`).** The artefact's new `derivation` block rebuilds the whole parameter set from the published rule with no file and no network: `p = ONES(256) \|\| M(3584) \|\| ONES(256)`, `M = (first 3305 fractional bits of ln 2) << 279 \| delta_low` with `delta_low` a recorded 279-bit constant, `q = 2**256 - 189`, `r = (p-1)//q`, `g = pow(2, r, p)`. `ln 2` is computed locally as `2*atanh(1/3)`, not tabulated. All four constants reconstruct exactly. **A URL says where bytes came from; this says the bytes are the ones the rule produces** — which is why a missing commit pin weakens the provenance trail without weakening the values |
| `EC-29` | The `r/2`-prime property and the `ln 2` derivation are the published family's documented structure. The first candidate's same-size test profile had **neither**, which is exactly why it was never a substitute for the real profile |
| `EC-30` | `parameter_digest` is pinned in code as `EPD2_CRYPTO_1_PARAMETER_DIGEST`, so an edit to the artefact is detected on load. The artefact's `digests` block now separates it from a `source_sha256` — one is over the local canonical parameter tuple, the other would be over an upstream file's exact bytes — each with its own definition, so the two can no longer be confused |
| `EC-31` | The actual values of `p`, `q`, `g` and `r` are in the profile artefact and are deliberately not reproduced in any document. A document is not a place where a parameter can be checked |

### 4.2 `CV-02` — RFC 8032 §7.1 Ed25519 vectors

**This is now the primary conformance evidence for the signature
primitive**, and it is in its own class (`rfc-conformance`) for that reason.

| ID | Field | Value |
| -- | ----- | ----- |
| `EC-32` | Operation | `checkpoint_signature`, profile `Ed25519 (RFC 8032)`, class `rfc-conformance` |
| `EC-33` | Source | RFC 8032, *Edwards-Curve Digital Signature Algorithm (EdDSA)*, §7.1 (January 2017) |
| `EC-34` | Source location | `https://www.rfc-editor.org/rfc/rfc8032` · Licence: IETF Trust Legal Provisions |
| `EC-35` | Source digest | n/a — the vectors are reproduced verbatim in `test_checkpoint_signatures.py` as `RFC_8032_VECTORS` |
| `EC-36` | Canonical input | **Three** vectors: TEST 1 (empty message), TEST 2 (one byte), TEST 3 (two bytes), each with its secret key, public key, message and signature |
| `EC-37` | Expected output | The RFC's published public key and signature for each, compared in full |
| `EC-38` | Comparison result | MATCH — all three pass against `CryptographyEd25519Provider` |
| `EC-39` | Limitations | **Three of the RFC's vectors are reproduced, not all of them.** The longer messages, the 1024-byte vector and the Ed25519ph variant are not covered. RFC 8032 specifies correctness, **not** side-channel resistance |

## 5. The target-profile core

The audit's second `PARTIAL` was about coverage, not about correctness. The
oracle existed and was useful; most of what it checked ran on a group the
election will never use. `tests/reference/test_target_conformance.py`
closes that.

| ID | Rule |
| -- | ---- |
| `EC-98` | **All twelve core operations are cross-checked on `EPD2-CRYPTO-1` itself.** `TARGET_PROFILE_CORE_OPERATIONS` names them: `parameter_digest`, `group_element_encoding`, `scalar_encoding`, `selection_encryption`, `selection_proof`, `ballot_hash`, `confirmation_code`, `accumulation`, `guardian_public_commitment`, `decryption_share`, `threshold_combination_3_of_5`, `aggregate_tally_recovery` |
| `EC-99` | **One documented command**, because evidence nobody can re-run is not evidence: `pytest -m slow_conformance services/voting-service/tests/reference/`. It selects **15 tests** and deselects 484 |
| `EC-100` | **Every nonce, scalar, plaintext, election context, manifest and guardian polynomial is fixed** by a seeded deterministic source. This is the property that makes the comparison mean anything: comparing two independently randomised ciphertexts proves nothing, because they were never supposed to be equal |
| `EC-101` | **The fixtures are exported, not merely computed.** `PACK-16D-TARGET-PROFILE-FIXTURES.json` (`EPD2-TARGET-FIXTURES-1`) holds **12 cases**, with `contains_secret_material: false` and the profile's `parameter_digest` recorded alongside them. A third party can take the file and run their own comparison without running EPD²'s test suite |
| `EC-102` | **The oracle's verdict is machine-readable.** Version 2 wraps every result in an envelope carrying `vector_id`, `operation`, `profile_id`, `expected`, `actual`, `match` and `oracle_version` (`epd2-independent-verifier-2`). A re-audit diffs a structure rather than interpreting prose |
| `EC-103` | **`ballot_structural` is the handler that matters.** The oracle is handed the ballot's **fields** and rebuilds the canonical bytes itself before hashing them. Handing it the producer's canonical encoding would test the hash function and not the encoding — and the encoding is precisely where the previous round's real defect was (`§8`) |
| `EC-104` | **Two invalid fixtures, and both stay INSIDE the subgroup.** `target-3-of-5-tally-invalid-share` and `target-decryption-share-invalid` are each tampered by multiplying by `g`, so the corrupted value is still a valid group element of order `q`. The oracle refuses them **by the mathematics** — the Chaum–Pedersen equation and the Lagrange recombination fail — rather than by a cheap structural check that a random 4096-bit integer would also have failed. A negative control that any nonsense would trip is not a control |
| `EC-105` | The catalogue entry for those two, `CV-26`, states the limit of what they show: they demonstrate the oracle **can** fail. They do not bound how many other defect classes would slip past it |

### 5.1 Measured cost

The point of the target profile is that it is expensive, so the cost is
published rather than used as a reason to substitute a smaller group. A
4096-bit modular exponentiation costs roughly forty times a 1024-bit one.

```text
selection_encryption            0.043 s
selection_proof_generation      0.086 s
ballot_ciphertexts              0.164 s
accumulation                    0.112 s
ballot_encryption               0.562 s
ballot_hash                     0.000 s
confirmation_code               0.000 s
ceremony_3_of_5                 2.074 s
threshold_shares                0.213 s
independent_oracle_full_run     0.858 s
full target suite (15 tests)    8.06  s
```

| ID | Rule |
| -- | ---- |
| `EC-106` | These are the figures measured for this round. `PACK-16D-TARGET-PROFILE-TIMINGS.json` is **regenerated by each run**, so the committed artefact records the numbers from the run that produced it and will differ from these on any other host. It is a benchmark, not a capacity statement, and its own `note` says so |

## 6. Independent oracle 1 — the OpenSSL command-line tool

**The character of this evidence changed, and the change is a weakening that
is stated rather than absorbed.**

| ID | Rule |
| -- | ---- |
| `EC-107` | **When the primitive was hand-written, comparing it against OpenSSL was strong evidence.** A from-scratch Ed25519 agreeing with libcrypto on every case put to it ruled out a whole family of implementation errors, and the previous round was right to lean on it |
| `EC-108` | **It is no longer that.** The active provider *is* OpenSSL, through `cryptography` 46.0.7 linked against OpenSSL 3.5.6. The CLI binary (**OpenSSL 3.0.13, 30 January 2024** here) is libcrypto with a command-line front end. **The oracle and the thing it checks share an upstream project**, so a defect in OpenSSL's Ed25519 present in both builds would be invisible to this comparison. This is the honest weak point of the round's signature evidence, and it is why `§4.2` and not this section is the primary claim |
| `EC-109` | **The old in-process oracle was deleted for exactly that reason.** `tests/reference/crossimpl/openssl_ed25519_oracle.py` called OpenSSL *through `python-cryptography`*. Once `cryptography` became the provider, that script was comparing one library against itself inside one process — agreement by construction, which is the failure mode `EC-12` and `§8` exist to prevent. It was deleted rather than kept and re-labelled: a cross-check that cannot disagree with the thing it checks is not a weaker oracle, it is not an oracle |
| `EC-40` | `CV-03`: the replacement shells out to the `openssl` **binary**, a separately built and separately versioned artefact, and speaks to it only through files and exit codes. Result: **6 cases — the three RFC 8032 §7.1 vectors accepted, and three mutated-message variants of them rejected** |
| `EC-41` | **What independence it does have.** A separate process, a separate binary, a different version, and a script that imports **no cryptographic Python library at all**: a raw 32-byte public key is wrapped by hand in its twelve fixed RFC 8410 §4 SubjectPublicKeyInfo DER prefix bytes and handed to the tool. It is an independent *execution path* and an independent *version*. It is not an independent *lineage* |
| `EC-42` | `cryptography` **is** a declared repository dependency now — `cryptography>=46.0.7,<47` in `services/voting-service/pyproject.toml`, resolved in `uv.lock` as 46.0.7 — which is the whole reason `EC-109` had to happen. The oracle deliberately does not use it; see `PACK-16D-LANGUAGE-AND-DEPENDENCY-ASSESSMENT.md` §4.1 |
| `EC-43` | **Empty messages are reported `skipped`, never passed.** `openssl pkeyutl -rawin` refuses a zero-length input file — a tool limitation, not a verification result. Reporting it as a pass would be a lie. TEST 1 is covered directly by `§4.2` instead, and the oracle emits the reason with the skip |
| `EC-44` | **The oracle is proved capable of rejecting.** Three of its six cases are mutated messages that must be refused, and the test asserts they were. An oracle observed only to agree is not evidence |
| `EC-45` | Stated limitation, from the catalogue: *the CLI binary and the library the active provider links share an upstream project, so a defect present in both would be invisible here. The evidence that does not share a lineage is the RFC 8032 published vectors.* Agreement also rules out an implementation error against the RFC; it does not rule out a defect in the RFC |
| `EC-110` | **The net position, stated without softening.** Moving from a hand-written primitive to a vetted one materially reduced custom-cryptography risk and simultaneously reduced the independence of this oracle. Both halves are real. The round does not claim the second did not happen |

## 7. Independent oracle 2 — the Node.js verifier

`tests/reference/crossimpl/independent_verifier.mjs`. It reads a JSON case
file named on argv and writes a JSON verdict on stdout. It never sees a
private key, a nonce or any voter data.

| ID | What makes it independent |
| -- | ------------------------- |
| `EC-46` | **It imports only `node:` builtins** — `node:crypto` and `node:fs`, and nothing else. `test_the_oracle_is_not_the_producer` asserts every `import` line contains `node:` |
| `EC-47` | **It contains no reference to the producer.** The same test asserts the string `epd2_voting_service` does not appear in it, and that `child_process` does not either — so it cannot call back into Python for an answer |
| `EC-48` | **It re-derives the canonical encoding from the written grammar**, not from the Python encoder: `UINT(n,width)`, `BYTES(b) = UINT(len,4) \|\| b`, `TEXT(s) = BYTES(utf8(NFC(s)))`, `SEQ(xs) = UINT(len,4) \|\| BYTES(x0) \|\| BYTES(x1) ...`, `STRUCT(fs) = UINT(len,4) \|\| (TEXT(name) \|\| BYTES(value))...`, `h(key,label,parts) = HMAC-SHA256(key, TEXT(label) \|\| SEQ(parts))`. The test asserts `function encodeSeq` and `createHmac` are present |
| `EC-49` | **It writes its own modular exponentiation.** `function modPow` is square-and-multiply over `BigInt`, not a call to Python's `pow(a,b,m)`, so even the arithmetic is an independent path. The test asserts `function modPow` is present |
| `EC-50` | **It recomputes the Fiat–Shamir challenge itself** for the selection proof — rebuilding the challenge payload from the grammar and comparing `c0 + c1 mod q` against it — rather than accepting the challenge in the transcript |
| `EC-51` | **It is proved to be capable of failing.** `test_the_oracle_detects_a_wrong_answer` feeds it a deliberately wrong expected ciphertext and asserts the verdict is `matches: false`; `§5`'s two subgroup-preserving invalid fixtures do the same on the target profile. A cross-check that cannot fail proves nothing |

### 7.1 What was cross-checked

| ID | Vector | Operation | Profile | Result |
| -- | ------ | --------- | ------- | ------ |
| `EC-52` | `CV-04` | `parameter_set` — bit lengths, `q = 2^256 - 189`, `q \| p-1`, `p = q*r + 1`, `1 < g < p`, `g^q = 1`, and an independently recomputed `parameter_digest` | `EPD2-CRYPTO-1` | MATCH |
| `EC-53` | `CV-05` | `selection_encryption` — `alpha = g^r`, `beta = K^r * g^m`, on an identical fixed nonce | `EPD2-TESTONLY-NOTCONFORMANT-P1024-Q160` | MATCH |
| `EC-54` | `CV-06` | `selection_proof` — full disjunctive Chaum–Pedersen verification plus challenge recomputation | test profile | MATCH |
| `EC-55` | `CV-07` | `ballot_hash` — the domain-separated digest over the envelope's canonical bytes | test profile | MATCH |
| `EC-56` | `CV-08` | `confirmation_code` — digest, base conversion over the declared alphabet, grouping | test profile | MATCH |
| `EC-57` | `CV-09` | `accumulation` — componentwise multiplication of four ciphertexts | test profile | MATCH |
| `EC-58` | `CV-10` | `decryption_share` — both Chaum–Pedersen equations for a guardian share | test profile | MATCH |
| `EC-59` | `CV-11` | `threshold_tally` — **a full 3-of-5 threshold tally**: Lagrange coefficients at zero, combination, `g^m` recovery and bounded decode | test profile | MATCH, plaintext equal |
| `EC-60` | `CV-12` … `CV-26` | group encoding, target arithmetic, and the **twelve core operations plus the two invalid fixtures** of `§5` | `EPD2-CRYPTO-1` | MATCH, and REJECTED where required |

| ID | Rule |
| -- | ---- |
| `EC-61` | **`EC-61` used to say that only `CV-01` and `CV-04` ran on the real parameters. That is no longer true, and the entry is corrected rather than deleted**, because a reader who remembers the old claim should be able to find what replaced it. The catalogue now holds **16 `cross-implementation-target-profile` entries against 8 `cross-implementation-test-profile` ones**. The test-profile comparisons were kept, not discarded: they are cheap regression evidence, and they are counted in their own class so they can never be read as target-profile agreement |
| `EC-62` | The oracle's group-encoding check (`checkEncoding`) **is** exercised this round, on the target profile, as `CV-12` and `CV-15`. Scalar encoding (`checkScalarEncoding`) and guardian commitments (`checkGuardianCommitment`) are new handlers in version 2 and are likewise exercised on `EPD2-CRYPTO-1` |
| `EC-63` | The Node.js verifier is used **only** by out-of-process test oracles, imports only `node:` builtins, and is not a repository dependency. No npm package is involved and `package-lock.json` is untouched. The OpenSSL **binary** is likewise a tool, not a dependency; the OpenSSL **library** now is one, through `cryptography`, and `§6` says what that costs |

## 8. The defect the independent oracle found

This is why the audit was right to fail `EXTERNAL CONFORMANCE`.

| ID | Finding |
| -- | ------- |
| `EC-64` | **`encode_seq` was ambiguous.** It emitted a 4-byte item count and then concatenated the items **raw**. So `SEQ([b"ab", b"c"])` and `SEQ([b"a", b"bc"])` produced identical bytes: two different sequences with the same encoding and therefore the same digest |
| `EC-65` | `encode_struct` had the same defect for a different reason: field values were appended raw, so the boundary between one field's value and the next field's name depended on the reader's schema rather than on the bytes |
| `EC-66` | **How a collision worked.** Any structure containing a sequence of variable-length items could be rewritten into a different structure with the same canonical bytes, by moving a byte from the end of one item to the start of the next. Everything downstream — ballot digests, confirmation codes, checkpoint roots, signatures — is computed over those bytes, so two distinct artefacts could share a digest and a signature |
| `EC-67` | **How it was found.** The Node.js oracle was written from the **documented grammar**, in which `SEQ = UINT(len,4) \|\| BYTES(item)...` — every item length-prefixed. The implementation did not do that. The oracle disagreed with the code, and the disagreement is how the defect surfaced |
| `EC-68` | **Why the producer's own vectors could never have caught it.** A stability vector records what this implementation produces and checks that it keeps producing it. The ambiguous encoder was perfectly stable: it produced the same wrong bytes every time, and every self-generated vector agreed with it. The oracle for the vectors *was* the defect |
| `EC-69` | **What changed.** Both functions now length-prefix — `encode_seq` emits `UINT(len,4) \|\| BYTES(item)...` and `encode_struct` emits `TEXT(name) \|\| BYTES(value)` per field. The collision is gone, Python and the oracle agree byte-for-byte, and **every digest in the round changed as a result** — which the stability vectors duly caught, which is what stability vectors are for |
| `EC-70` | The defect is pinned as a negative-corpus case, `ambiguous_sequence_encoding` (reason code `INVALID_CANONICAL_ENCODING`), which asserts the two sequences now differ, that the same holds for struct field values, and that the documented form is the one produced. The negative corpus is **39** cases (41 tests) |
| `EC-71` | The general lesson, stated plainly: **a specification and an implementation that disagree are only discoverable by someone reading the specification instead of the implementation.** That is the whole argument for an independently written verifier, it is why `EC-103` hands the oracle fields rather than bytes, and it is why `OD-P16D-02` stays open even after this round |

## 9. Where no primary source exists

`PRIMARY_SOURCE_UNAVAILABLE` names six operations for which no published
external vector was located. **No self-generated value was relabelled to
fill a gap.** The reasons below are the dictionary's own text, condensed.

| ID | Operation | Declared reason |
| -- | --------- | --------------- |
| `EC-72` | `selection_encryption` | ElectionGuard 2.1 publishes the parameter constants but no worked encryption vector with a fixed nonce that could be reproduced byte-for-byte; the specification gives the equations, not examples |
| `EC-73` | `selection_proof` | No published disjunctive Chaum–Pedersen transcript with fixed randomness; and EPD2's Fiat–Shamir context is EPD2-specific, so an ElectionGuard transcript would not apply unchanged in any case |
| `EC-74` | `ballot_hash` | EPD2 uses its own canonical encoding (`EPD2-ENC-1`) and domain-separation registry, so a ballot digest is by construction an EPD2 value with no external counterpart |
| `EC-75` | `confirmation_code` | The confirmation-code alphabet and grouping are EPD2 decisions from PACK-16C, not ElectionGuard ones |
| `EC-76` | `accumulation` | Componentwise multiplication has no published vector; it is checked cross-implementation instead |
| `EC-77` | `threshold_tally` | No published end-to-end threshold tally vector on the standard parameters was located |

| ID | Rule |
| -- | ---- |
| `EC-78` | Three of the six (`EC-74`, `EC-75`, and in part `EC-73`) are unavailable **by construction**: they are EPD2 decisions, and no external party has ever had reason to publish a value for them. That is a design consequence, not a search failure |
| `EC-79` | The other three are search failures as of 2026-08-02. A published vector may exist and not have been found; nothing here claims the search was exhaustive |
| `EC-80` | Each of the six is covered by cross-implementation comparison instead, **now on the target profile as well as the test profile**, and the substitution is named rather than hidden. `test_primary_source_unavailability_is_declared_not_hidden` asserts the dictionary is non-empty, that every reason is substantive, and that the four EPD2-specific operations are listed |
| `EC-81` | Because of this list, `primary-source conformance vectors` remains **PARTIALLY SATISFIED** in the Acceptance Matrix and not `SATISFIED`. Widening a substitute does not turn it into a primary source. `target-profile cross-implementation core` is `SATISFIED` |

## 10. What this evidence still is not

| ID | Limitation |
| -- | ---------- |
| `EC-82` | **This is not a comparison against a complete independent ElectionGuard implementation.** Two oracles is not one. The Node.js verifier checks named operations, not an election; the OpenSSL CLI checks a signature scheme, not a protocol. **`OD-P16D-02` remains open**, narrowed but not closed, and a fully independent verifier is `DEFERRED` to PACK-17 |
| `EC-83` | **Full interoperability with ElectionGuard is not claimed.** No EPD2 artefact has been consumed by an ElectionGuard implementation, and no ElectionGuard artefact has been consumed here. The one thing shared with ElectionGuard and verified is the parameter set |
| `EC-84` | The Node.js oracle was written for this round, in this repository, from the same specification documents. Same specification, different language, different author path; it shares no code, no parser and no arithmetic with the producer. **A specification error would be reproduced by both**, and `§8` happened only because the specification and the code disagreed |
| `EC-85` | **The Ed25519 CLI oracle shares an upstream with the provider (`§6`).** That is the sharpest single limitation in this document's evidence, and no amount of case count fixes it: 6 cases or 600, the two sides are libcrypto. The claim that survives is `§4.2` |
| `EC-86` | No external cryptographic review has taken place. **No BSI conformity is claimed. `VO-08` is OPEN** and is not addressed by any evidence in this document |
| `EC-87` | Nothing here is evidence about timing. The signature surface moved to a library that pursues side-channel resistance as a design goal, which is a real risk reduction and **is not an assurance**: EPD² measured nothing. Guardian secret operations and the group arithmetic remain pure Python and are **not constant-time** (`OD-P16D-05`, production blocker, narrowed but open) |
| `EC-88` | The whole npm side was not executed (registry HTTP 403). `uv lock` and `uv lock --check` were **not executed** — both need the index, and `uv lock --offline` fails on `hypothesis`. `uv sync --all-groups --frozen` **was** run: it built every workspace member and then failed downloading `virtualenv==21.7.0` with HTTP 403, which is a network failure rather than a lock inconsistency and is **not** claimed as a pass. Branch coverage was **not** measured — no tool for it is installable here. The line-coverage figure this round reports is recorded in `PACK-16D-LANGUAGE-AND-DEPENDENCY-ASSESSMENT.md` §5 and is not restated here |
| `EC-111` | **The frozen install was not performed in the session that produced this candidate.** `uv lock` and `uv sync --all-groups --frozen` ran on a network-enabled host; this session verified the lock's parsed contents and asserted the imported library's version equal to the locked one, but has no package index and did not re-run the install |
| `EC-112` | **The corroborating upstream source's digest was computed elsewhere.** The commit pin and raw-byte digest are recorded in the artefact along with a verification scope stating that this session did not re-fetch the bytes. The parameter values do not depend on the file at all — `EC-97` is why — so this is a limit on the trail, not on the values |
| `EC-89` | Evidence of the kind in this document supports a claim about implemented behaviour. It supports no claim about production readiness, certification or legal activation, and none is made |

## 11. What this document does not decide

```text
Comparison against a complete ElectionGuard implementation → OD-P16D-02, PACK-17, external party
Independent verifier written by another party              → OD-P16D-02, PACK-17, external party
An Ed25519 oracle that shares no upstream with the provider → PACK-17, external party
Published external vectors for the six missing operations  → PACK-17, external party
External cryptographic review                              → VO-08, PACK-16B external review
Parameter appropriateness and BSI assessment               → VO-08, GOVERNANCE
Constant-time assurance                                    → OD-P16D-05, PACK-17, FIR
Re-fetching the upstream file's bytes in this session      → one `curl | sha256sum`
Re-verifying the specification PDF digest first-hand       → PACK-16B `F-01`, inherited
Branch-coverage measurement                                → PACK-17, toolchain
```

**REFERENCE IMPLEMENTATION. REQUIRES EXTERNAL REVIEW. NOT PRODUCTION READY.
NOT LEGALLY ACTIVATED.**
