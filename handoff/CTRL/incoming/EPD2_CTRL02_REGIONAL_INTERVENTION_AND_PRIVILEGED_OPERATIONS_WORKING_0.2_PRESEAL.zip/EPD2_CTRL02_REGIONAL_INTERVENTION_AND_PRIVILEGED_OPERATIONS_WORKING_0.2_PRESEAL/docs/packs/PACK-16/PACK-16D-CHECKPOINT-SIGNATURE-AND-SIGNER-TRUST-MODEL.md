# PACK-16D — Checkpoint Signature and Signer Trust Model

**Round:** PACK-16D — Network-Enabled Finalization: Lockfile Regeneration,
Immutable ElectionGuard Provenance and Final Acceptance Alignment.
**Reference implementation. Not production code. Not certified. Not a PASS.**
**Repository version:** unchanged at `0.16.0` · **Canon version:** unchanged at `0.8.0`
**ADR:** `ADR-102`, status `proposed`
**NOT PRODUCTION READY. NOT LEGALLY ACTIVATED. PUBLIC-ELECTION ACTIVATION PROHIBITED BY DEFAULT.**

---

## 1. Scope

This document describes
`services/voting-service/src/epd2_voting_service/reference/publication/checkpoint_signing.py`
and `.../crypto/signature_provider.py`: the signature profile, the
canonical payload, the signer trust anchor, key rotation, the outcome
codes, and — the part that matters most — the boundary between what a valid
signature proves and what it does not.

The audit finding `CHECKPOINT AUTHENTICITY: FAIL` was raised because the
first PACK-16D candidate signed checkpoints with a symmetric HMAC key and
the verifier never checked the result, since a third party does not hold
that key. **A signature nobody can verify is not authenticity; it is
decoration.** That was replaced by an Ed25519 implementation written in
this repository.

**What changed in this correction, and what did not.** A later audit passed
`CHECKPOINT SIGNATURE SEMANTICS` and failed
`CHECKPOINT SIGNATURE PRIMITIVE POLICY: HANDWRITTEN ED25519`. Only the
primitive moved. The canonical checkpoint payload (§3), the signer trust
anchor (§4), the rotation windows (§5) and the five failure outcomes (§6)
are **unchanged** — same fields in the same order, same registry semantics,
same outcome codes, same exit codes. This is stated explicitly at the head
of each of those sections, because a reader of a corrected document is
entitled to know which parts they do not need to re-review.

| ID | Symbol | Role |
| -- | ------ | ---- |
| `CS-01` | `crypto.signature_provider` | The port over a **vetted library**: Ed25519 (RFC 8032, PureEdDSA over edwards25519, SHA-512), supplied by `cryptography` (OpenSSL Ed25519). Not implemented here |
| `CS-02` | `CheckpointPayload` | Exactly what a signature covers. Nothing outside it is bound |
| `CS-03` | `SignerRecord`, `SignerRegistry` | The declared authorised signer set — the trust anchor |
| `CS-04` | `sign_checkpoint(payload, seed)` | Produces a signature over the domain-separated signing input |
| `CS-05` | `verify_checkpoint(payload, signature, registry)` | Returns `(CheckpointSignatureOutcome, detail)`, fail-closed |
| `CS-06` | `CHECKPOINT_SCHEMA_VERSION` | `"EPD2-CHECKPOINT-2"`, bound into every signed payload |

## 2. The Ed25519 profile, now supplied rather than implemented

**This section is the one that changed.** The scheme, the wire formats and
the profile string are the same as before; what moved is who computes them.

| ID | Rule |
| -- | ---- |
| `CS-07` | **Profile:** Ed25519, RFC 8032 PureEdDSA over edwards25519 with SHA-512. Public keys are the standard 32-byte raw encoding, signatures the standard 64 bytes, private keys 32 bytes. The profile string recorded wherever a signature is published is `SIGNATURE_PROFILE = "Ed25519 (RFC 8032, PureEdDSA, SHA-512)"`, and `publication/checkpoint_signing.py` takes it from the provider rather than restating it |
| `CS-08` | **The primitive is supplied by a vetted library and is not implemented in this repository.** `crypto/signature_provider.py` is a port: `CheckpointSignatureProvider` is a `@runtime_checkable` Protocol with six operations — `generate_test_keypair`, `load_public_key`, `sign_checkpoint`, `verify_checkpoint`, `public_key_bytes`, `signature_bytes` — and `CryptographyEd25519Provider` is the single active implementation, `backend = "cryptography (OpenSSL Ed25519)"`, exposed as the module-level singleton `PROVIDER`. Every method of it is argument validation and canonical encoding around a library call |
| `CS-09` | **Why the previous implementation was removed rather than improved.** It followed RFC 8032, it agreed with OpenSSL on every vector it was given, and an audit failed it — correctly. Agreement on the vectors an author thought to write is not the property that matters for a low-level primitive. What matters is the vulnerability class nobody thought of: a missing subgroup check, a branch that leaks a key bit, a malleable encoding accepted on some input nobody tried. Those are found by years of adversarial attention paid to one widely deployed implementation, not by the author of a fresh one. `crypto/ed25519.py` is **deleted** — not moved, not deprecated |
| `CS-74` | **There is no fallback.** `cryptography` is imported at module scope; if it is missing the import raises `SignatureProviderUnavailableError` (`SIGNATURE_PROVIDER_UNAVAILABLE`) and the process does not start. A `try/except` fallback to hand-written curve code would reinstate exactly what the audit removed, on whichever machine happened to lack the dependency — the machine you would least want running it. `test_missing_provider_fails_closed` runs the import in a subprocess with `cryptography` blocked, with a control run first so the assertion cannot pass for the wrong reason, and asserts the import fails rather than succeeding by a fallback |
| `CS-75` | **The dependency is declared and locked.** `cryptography>=46.0.7,<47` is in `services/voting-service/pyproject.toml` and resolves in `uv.lock` as 46.0.7, linked against OpenSSL 3.5.6, licensed Apache-2.0/BSD-3. `uv lock` and `uv sync --all-groups --frozen` were run on a network-enabled host; §4.1 of `PACK-16D-LANGUAGE-AND-DEPENDENCY-ASSESSMENT.md` records both, and records that the build session verified the lock's contents rather than re-running the install |
| `CS-76` | **No other module imports `cryptography`.** `test_handwritten_ed25519_not_imported` parses every `*.py` under `reference/` with `ast` and fails if any module other than `signature_provider.py` names it, or if any module imports or defines curve arithmetic under any filename. The check is structural rather than a grep, because the failure it guards against is somebody re-adding the implementation under a different name |

### 2.1 How conformance is proved rather than assumed

The evidence changed shape with the primitive. There is no longer an
implementation of ours to compare against an oracle; what there is, is a
published answer and an independent execution path.

| ID | Evidence | What it shows |
| -- | -------- | ------------- |
| `CS-10` | **Three RFC 8032 §7.1 vectors, checked against the provider** — TEST 1 (empty message), TEST 2 (one byte) and TEST 3 (two bytes) — each reproduced in `test_checkpoint_signatures.py` with its secret key, public key, message and signature | For each vector the provider derives the published public key, produces the published signature and verifies it. This is an external primary source stating what the right answer is. The RFC publishes more vectors; three are reproduced with their provenance rather than the corpus copied in bulk |
| `CS-11` | **The independent oracle is now the OpenSSL command-line tool**, `tests/reference/crossimpl/openssl_cli_ed25519_oracle.py`, reporting `OpenSSL 3.0.13`, run out-of-process through files and exit codes | Six cases: the three RFC vectors accepted, and the same three signatures under a mutated message rejected. The script imports nothing from EPD², nothing from `cryptography`, and no Python cryptographic library at all — it wraps a raw public key in its twelve fixed DER prefix bytes (RFC 8410 §4) and hands it to the tool |
| `CS-12` | **The previous in-process oracle was deleted.** `openssl_ed25519_oracle.py` called the same library the provider now uses, so it was no longer independent of the thing it was checking | An oracle that shares its implementation with the producer measures nothing. Removing it is the honest response, not renaming it |
| `CS-13` | If the `openssl` binary is absent, `test_openssl_cli_independently_verifies_rfc_vectors` **fails loudly** rather than skipping, and the test additionally asserts that at least four comparisons genuinely executed | A silently skipped oracle is exactly how a round ends up claiming conformance it never measured |

| ID | Rule |
| -- | ---- |
| `CS-14` | **The oracle's limitation is stated with the evidence, because it is the weak point.** The `openssl` CLI and the library the provider links **share an upstream project**. A defect in OpenSSL's Ed25519 that survived across both builds would be invisible to this comparison. The oracle adds an independent execution path and a different version, not a different lineage. **The evidence that does not share a lineage is the RFC 8032 §7.1 published vectors**, which are checked directly against the provider. The oracle script says this in its own module docstring |
| `CS-77` | **Empty messages are reported as skipped, not as passed.** `openssl pkeyutl -rawin` refuses a zero-length input file, which is a tool limitation and not a verification result. The empty-message vector is covered by the RFC vector test instead |

### 2.2 Encoding strictness and refusals

| ID | Rule |
| -- | ---- |
| `CS-15` | **Only strict raw canonical encodings are accepted: no PEM, no DER, no base64.** A public key is exactly 32 raw bytes and a signature exactly 64; a length that is not exactly right is a malformed input rather than an alternative encoding. Accepting several encodings would let two byte strings name one key, and a registry keyed on bytes would then hold two entries for one signer |
| `CS-16` | `verify_checkpoint` on the provider returns `False` on **every** defect — wrong signature length, wrong public-key length, a non-bytes argument, a key the library will not parse, a genuine mismatch — and never raises on bad input. A verifier always gets an answer, and the answer at this layer says nothing about *which* defect it was: that distinction is drawn one layer up, by `verify_checkpoint` in `publication/checkpoint_signing.py`, which holds the registry to draw it with |
| `CS-17` | The refusals are pinned by test: `test_invalid_signature_rejected` (one flipped signature bit), `test_wrong_public_key_rejected`, `test_wrong_message_rejected`, `test_noncanonical_key_length_rejected` (31 bytes, 33 bytes, empty, 64 bytes) and `test_noncanonical_signature_length_rejected` (63 bytes, 65 bytes, empty, truncated to 32). `load_public_key`, `signature_bytes` and `public_key_bytes` raise `SignatureFormatError` on the same inputs rather than returning a value |
| `CS-18` | A key or seed of the wrong length raises `SignatureFormatError` (reason code `BOARD_SIGNATURE_INVALID`); `sign_checkpoint` in the publication layer raises `CheckpointSigningError` before the provider is reached at all |
| `CS-78` | **What this round does *not* pin by test is the `S >= L` rule.** The previous candidate implemented and tested that refusal because it owned the verification path. It no longer does, and the check now lives inside the vetted library. `checkpoint_signing.py` records that the provider rejects a non-canonical scalar; **this repository publishes no test of its own asserting it this round**, and that gap is named here rather than left for a reader to discover |

## 3. The canonical payload — UNCHANGED

**Nothing in this section changed in this correction.** The audit passed
`CHECKPOINT SIGNATURE SEMANTICS`, and the payload is exactly what it was:
the same ten fields, in the same declaration order, under the same
`EPD2-CHECKPOINT-2` schema version, digested under the same
`BOARD_CHECKPOINT` label. Only the bytes that consume `signing_input()`
are produced by different code.

`CheckpointPayload.canonical_bytes()` is an `encode_struct` over exactly
these fields, in this declaration order:

| ID | Field | Why it is bound |
| -- | ----- | --------------- |
| `CS-19` | `schema_version` | A signature made under one checkpoint schema cannot be replayed as one made under another |
| `CS-20` | `protocol_profile_id` | Ties the checkpoint to the cryptographic profile in force |
| `CS-21` | `election_context_id` | A signature from another election does not transfer |
| `CS-22` | `board_id` | A signature from another board does not transfer |
| `CS-23` | `checkpoint_sequence` | A signature lifted from checkpoint 0 does not validate checkpoint 1 |
| `CS-24` | `tree_size` | The claimed number of entries cannot be restated |
| `CS-25` | `root` | The Merkle root is what the checkpoint is *for* |
| `CS-26` | `previous_checkpoint_hash` | The chain link, so a checkpoint cannot be re-parented |
| `CS-27` | `publication_phase` | An `open` checkpoint cannot be presented as a `closed` one |
| `CS-28` | `signing_key_id` | The signature names its own key, so a signature cannot be re-attributed to another authorised signer |

| ID | Rule |
| -- | ---- |
| `CS-29` | **The encoding is canonical binary tuples and never JSON.** Ordinary JSON is not canonical: key order, integer/float ambiguity, unicode escaping and whitespace are all under-specified, so two conforming encoders can produce different bytes for the same value. A signature is over *these* bytes and over nothing else. `test_the_payload_binds_every_field_the_specification_lists` asserts each field name appears in the encoding and that the result does not begin with `{` |
| `CS-30` | **The signature is not over the canonical bytes directly.** `signing_input()` is `h(ZERO_KEY, DomainLabel.BOARD_CHECKPOINT, [canonical_bytes()])` — a domain-separated digest. The label prevents a signature over some other EPD2 structure from ever being presented as a checkpoint signature. The same test asserts `signing_input() != canonical_bytes()` |
| `CS-31` | **`CheckpointPayload` has no `public_key` field at all** — see `CS-35` |
| `CS-32` | Altering any bound field and re-presenting the original signature yields `BOARD_SIGNATURE_INVALID`. This is exercised for `root`, `checkpoint_sequence`, `tree_size`, `previous_checkpoint_hash` and `publication_phase` |

## 4. The signer trust anchor — UNCHANGED

**Nothing in this section changed in this correction.** `SignerRegistry`,
`SignerRecord`, the rule that a key is never read out of the artefact it
signs, and the separation of `signer_registry` from `signed_checkpoints` in
`BoardExport` are all as they were. The provider deliberately has no
opinion on *whose* key it is holding (`CS-08`); trust is decided here and
nowhere else.

| ID | Rule |
| -- | ---- |
| `CS-33` | **A verifier must not accept a key that arrives inside the artefact it is checking, because then anyone can mint their own board.** The authorised signer set is therefore part of the **election context**, fixed before the first checkpoint, and supplied to the verifier *alongside* the export |
| `CS-34` | `SignerRegistry` is that set: `election_context_id`, `board_id` and a tuple of `SignerRecord`. It has `resolve(signing_key_id)`, `canonical_bytes()` and `digest()` (domain-separated under `DomainLabel.BOARD_SIGNATURE`). **No method on it can add a signer** |
| `CS-35` | **No path reads a key out of the checkpoint being verified.** The checkpoint carries only a *key identifier*, which must resolve inside the registry. `test_a_signer_registry_is_never_read_from_the_checkpoint` asserts structurally that `verify_checkpoint`'s source contains `registry.resolve`, does not contain `payload.public_key`, and that `CheckpointPayload` has no `public_key` attribute and no such slot |
| `CS-36` | An identifier that does not resolve is `BOARD_SIGNER_UNKNOWN`, with the detail stating *a key carried by the artefact it signs is never a trust anchor* |
| `CS-37` | A key that resolves but whose record names a different election or board is `BOARD_SIGNER_UNAUTHORIZED` — resolution is not authorisation |
| `CS-38` | `BoardExport` carries `signer_registry` as a separate field from `signed_checkpoints`. The two arrive together but are never derived from each other |

## 5. Key lifecycle and rotation — UNCHANGED

**Nothing in this section changed in this correction.** The rotation
windows are the same inclusive `active_from_sequence` /
`active_to_sequence` pair, declared in advance in the registry, with
`superseded_by` naming the replacement. The only wording that moved is in
`CS-44`, where the fixture key derivation is now described in the
provider's terms.

| ID | Rule |
| -- | ---- |
| `CS-39` | `SignerRecord` carries `signing_key_id`, `public_key`, `board_id`, `election_context_id`, `key_version`, `active_from_sequence`, `active_to_sequence` and `superseded_by` |
| `CS-40` | **Activation windows are declared in advance, not announced by the key itself.** `is_active_at(sequence)` is an inclusive window: below `active_from_sequence` is inactive; `active_to_sequence` of `None` means open-ended; otherwise the sequence must not exceed it |
| `CS-41` | **A rotation is expressed by ending one window and beginning the next**, both inside the registry. `superseded_by` names the replacement so a reader can follow the chain |
| `CS-42` | A key used outside its declared window is `BOARD_SIGNER_UNAUTHORIZED`, with the detail naming the checkpoint sequence. `test_signer_outside_its_activation_window_rejected` publishes two checkpoints, declares the key active only for sequence 0, and asserts the first is `VALID` and the second `SIGNER_UNAUTHORIZED` |
| `CS-43` | Every field of a `SignerRecord` is inside its `canonical_bytes()`, including the window and `superseded_by`, so the registry digest changes if any of them is edited |
| `CS-44` | **Key custody is not modelled.** The reference board holds its signing key as a field and derives a 32-byte **TEST-ONLY** Ed25519 private key from it (a value of the right length is used directly; anything else is hashed with SHA-256, so a short fixture string cannot become a short key). The provider's method is named `generate_test_keypair` rather than carrying the warning in a comment, because deterministic key generation is exactly what a production key must never be. A production board would hold its key in a key store this reference implementation does not model (`OD-P16D-11`) |

## 6. Outcomes and exit codes — UNCHANGED

**Nothing in this section changed in this correction.** The five failure
outcomes, their result codes and their exit codes 45–49 are exactly as they
were, and were not renumbered.

`CheckpointSignatureOutcome` has six members. Five map one-to-one onto
verification result codes; `VALID` is the case in which verification
continues.

| ID | Outcome | Result code | Exit | Condition as implemented |
| -- | ------- | ----------- | ---- | ------------------------ |
| `CS-45` | `BOARD_SIGNATURE_VALID` | — | — | Every check passed. Verification continues; this is not a verdict on the board |
| `CS-46` | `BOARD_SIGNATURE_MISSING` | `BOARD_SIGNATURE_MISSING` | 45 | The checkpoint carries no signature at all |
| `CS-47` | `BOARD_SIGNER_UNKNOWN` | `BOARD_SIGNER_UNKNOWN` | 46 | `signing_key_id` does not resolve in the declared signer set |
| `CS-48` | `BOARD_SIGNER_UNAUTHORIZED` | `BOARD_SIGNER_UNAUTHORIZED` | 47 | The key resolves but names another election or board, or is outside its activation window |
| `CS-49` | `BOARD_SIGNATURE_INVALID` | `BOARD_SIGNATURE_INVALID` | 48 | The provider's Ed25519 verification returned `False` — altered bytes, a replayed signature, a malformed key or signature, a forgery |
| `CS-50` | `BOARD_SIGNATURE_CONTEXT_MISMATCH` | `BOARD_SIGNATURE_CONTEXT_MISMATCH` | 49 | The schema version is not `EPD2-CHECKPOINT-2`, or the checkpoint names a different election or board than the registry |

| ID | Rule |
| -- | ---- |
| `CS-51` | **The distinctions are the point.** A reader of an exit code can tell "nobody signed this" (45) from "the wrong person signed it" (46/47) from "the bytes were altered" (48) from "this is not the artefact you think it is" (49). Collapsing them into one failure would lose the information an operator needs |
| `CS-52` | The checks run in a fixed order: signature present, schema version, election, board, key resolution, key authorisation, window, then the signature verification itself. Cheap structural refusals precede the expensive one |
| `CS-53` | Exit codes are stable and never renumbered. The round's verification result set is 26 codes with 26 distinct exit codes; 45–49 are new this round |
| `CS-54` | **An export with checkpoint tuples but no signed checkpoints returns `INCOMPLETE_RECORD`, not a weaker pass.** The checkpoint chain is computed over the whole signed payload, so an export carrying only the legacy five-tuple view cannot be chain-checked at all. Falling back to a narrower digest would be a downgrade the verifier could not see |
| `CS-55` | `board_export_from(board)` is the one place a complete export is built — entries, checkpoints, signed checkpoints and registry together. Callers assembling a `BoardExport` by hand were the reason the signed view and the tuple view could drift apart |
| `CS-56` | When the registry and the signed checkpoints are both present and every signature verifies, `verify_board` appends `board.checkpoint_signatures` to `checks_run`. When they are not, the check is absent from the list rather than reported as passed |

## 7. Authenticity is not consistency

This is the section the rest of the document exists to support.

| ID | Rule |
| -- | ---- |
| `CS-57` | **What a valid signature proves:** the named signer, authorised in the declared registry for this election and board and active at this sequence, issued *this* checkpoint — this root, this tree size, this chain link, this phase — and the bytes have not been altered since |
| `CS-58` | **What it does not prove:** that the board showed the same checkpoint to everyone. A signature is a statement by one party about one artefact. It carries no information about what any other party was shown |
| `CS-59` | **Two validly signed checkpoints at one sequence with different roots is equivocation by an authorised signer.** That is worse than a forgery — the trust anchor itself misbehaved — and it must never be reported as a signature success |
| `CS-60` | `verify_board` detects it: signatures are verified first, and a second checkpoint at a sequence already seen with a different root returns `BOARD_INCONSISTENCY` (exit code 40) with the detail *an authorised signer equivocated* |
| `CS-61` | `test_conflicting_signed_checkpoints_detected` constructs exactly that case. The same authorised signer signs a different root at the same sequence, **and the test asserts both signatures are genuinely `VALID` before checking for the inconsistency** — the comment in the test is explicit that both signatures must be genuine for the test to mean anything |
| `CS-62` | **Detection remains bounded to a single exported view.** Equivocation is caught when both conflicting checkpoints appear in one export. A board that shows one view to one mirror and another view to another mirror is *not* detected, because cross-mirror comparison and gossip are unimplemented. This is **`OD-P16D-06`**, open |
| `CS-63` | The claim is attached to every verification result rather than left in a document. `NOT_CHECKED` states, on every result including `VERIFIED`, *that the board showed the same checkpoints to everyone — a valid signature proves who issued a checkpoint, never that no other view exists; cross-mirror comparison remains unimplemented.* `test_a_valid_signature_is_not_evidence_of_a_single_view` asserts that entry is present |

### 7.1 The registry's own authorisation is outside the verifier's reach

| ID | Rule |
| -- | ---- |
| `CS-64` | **`OD-P16D-12`, new this round:** the verifier checks a checkpoint against the signer registry it was given. **It cannot tell you that registry was authorised by the Election Board.** Given a registry containing an attacker's key and checkpoints signed by that key, `verify_checkpoint` returns `VALID`, correctly, and says nothing about where the registry came from |
| `CS-65` | This too is a `NOT_CHECKED` entry printed with every result: *that the authorised signer set itself is the right one*. The corresponding test asserts its presence |
| `CS-66` | Closing it requires publication and governance of the signer registry — how it is announced, by whom, and how a verifier obtains it over an independent path. That is a governance obligation, not a code change here |
| `CS-67` | `NOT_CHECKED` has **9** entries this round. The previous entry stating that checkpoint signatures are never verified was **removed because it is no longer true**, and replaced by these two narrower ones. An honest non-coverage list gets shorter only when the coverage is real |

## 8. Limitations of this implementation

Stated here, in the body, because they qualify every claim above.

| ID | Limitation |
| -- | ---------- |
| `CS-68` | **No constant-time or side-channel assurance is claimed.** The signing surface moved into OpenSSL, a project that pursues side-channel resistance — but **EPD² has measured nothing**, and measuring nothing is not evidence. `OD-P16D-05` is therefore **narrowed, not closed**: the signature primitive is no longer ours, while the group arithmetic everywhere else in `crypto/` remains pure Python with no timing guarantee. This is still a production blocker |
| `CS-69` | **The four-way split still governs.** Public verification, guardian secret operations, secret nonce generation and private-key signing are treated separately in `PACK-16D-SECURITY-AND-SIDE-CHANNEL-LIMITATIONS.md`, with a FIR obligation for production. What this correction changed is which code performs the signing half, not what has been measured about it |
| `CS-70` | No external cryptographic review of this repository has taken place. No BSI conformity is claimed and `VO-08` is **OPEN** |
| `CS-71` | Three RFC 8032 vectors and an out-of-process OpenSSL CLI comparison are not interoperability with everything, and the CLI shares an upstream with the linked library (`CS-14`). `OD-P16D-02` remains open |
| `CS-72` | The reference board is a single in-process board. Multi-signer registries, threshold board signatures, and operational separation between the board operator and the signing key holder are not implemented |
| `CS-73` | **44 tests** in `services/voting-service/tests/reference/test_checkpoint_signatures.py`, all passing (up from 29; the suite gained the provider-wiring, no-fallback, RFC-vector and encoding-strictness tests, and lost the tests that probed curve arithmetic this repository no longer owns). Plus the negative-corpus case `unauthorized_board_signer` (`BOARD_SIGNER_UNKNOWN`) and scenario E2E-13 (a checkpoint from an unauthorised signer fails verification). Passing tests are evidence about the implemented behaviour and about nothing else |
| `CS-79` | **A reviewer reproducing this round installs from the lock** (`CS-75`), which resolves `cryptography` 46.0.7 with artefact hashes. The suite additionally asserts that the imported library's version equals the locked one, so a run against some other build cannot be mistaken for evidence about this one |

## 9. What this document does not decide

```text
Signer registry publication and governance             → OD-P16D-12, GOVERNANCE
Cross-mirror split-view detection and gossip           → OD-P16D-06, PACK-17
Constant-time assurance for any part of the stack      → OD-P16D-05, PACK-17, FIR
Supply-chain policy for the locked native provider     → SL-54, SL-56,
                                                         release engineering
Production key storage, HSM, operator custody          → PACK-16B, GOVERNANCE
Multi-signer or threshold board signatures             → PACK-17
Independent verifier by another party                  → OD-P16D-02, PACK-17, external party
Parameter and profile appropriateness                  → VO-08, PACK-16B external review
```

**REFERENCE IMPLEMENTATION. REQUIRES EXTERNAL REVIEW. NOT PRODUCTION READY.
NOT LEGALLY ACTIVATED.**
