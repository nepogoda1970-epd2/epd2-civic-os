# PACK-16C — FIR Coverage Matrix

**Round:** PACK-16C — Casting, Receipt, Verification Client, Bulletin Board and Election Record. **Specification and ADR only. No code. No cryptographic implementation. Not implemented. Not a PASS.**
**Repository version:** unchanged at `0.15.0` · **Canon version:** unchanged at `0.8.0`
**ADR:** `ADR-101`, status `proposed`
**NOT PRODUCTION READY. NOT LEGALLY ACTIVATED. PUBLIC-ELECTION ACTIVATION PROHIBITED BY DEFAULT.**

Assessed against the **cumulative Master Future Implementation Register**
carried in this archive at its canonical path
`docs/roadmap/EPD2_MASTER_FUTURE_IMPLEMENTATION_REGISTER.md`, which is the
only authoritative register. **No standalone register version is used and
no second register is created.**

**No FIR entry is marked `implemented` by this round, and none may be.**

Treatment values permitted for a specification stage:

```text
specified                        assessed
selected for architectural review
deferred to PACK-16D / PACK-17
blocked pending cryptographic review
blocked pending legal assessment
unchanged
```

Treatment values **prohibited** for this round:

```text
implemented · externally verified · production ready · legally activated
```

**New FIR identifiers created by this round: none.**
**FIR identifiers removed, renamed or downgraded: none.**
**Statuses changed in the register: none.**

---

## 1. Roadmap

| FIR | Status before | Treatment | References | Obligation that remains |
| --- | ------------- | --------- | ---------- | ----------------------- |
| `FIR-ROADMAP-005` | `approved` | **unchanged** | — | Untouched |
| `FIR-ROADMAP-006` | `approved` | **selected for architectural review** | whole pack; `ADR-101` | **Status stays `approved`, target version stays `0.16.0`.** PACK-16C performs the casting, receipt, verification, board and record specification stage only. Nothing is built, and vote casting remains unimplemented |
| `FIR-ROADMAP-007` | `approved` | **deferred to PACK-17** | `AO-*`, `IV-*`, `ER-24` | Independent-verification operations, board resilience, archive re-verification and witness ecosystem work |
| `FIR-ROADMAP-008` | `approved` | **unchanged** | — | Untouched |
| `FIR-ROADMAP-009` | `approved` | **unchanged** | — | Untouched |

**`FIR-ROADMAP-006` MUST NOT move to `implemented`, `scheduled` or any
status implying delivery on the strength of this round.**

---

## 2. Hard invariants

| FIR | Status before | Treatment | References | Obligation that remains |
| --- | ------------- | --------- | ---------- | ----------------------- |
| `FIR-INV-001` No global user ID | `approved` | **specified** for the casting domain | `API-01`, `PM-*`, `DM-01` | The casting service takes **no identity input at all**; `ballot_id` is client-random with no structure |
| `FIR-INV-002` Identity/ballot unlinkability | `approved` | **specified — the ballot side, not closed** | `CN-*`, `DM-10`, `EV-05`, `EV-06`, `PM-03` | §2.1 |
| `FIR-INV-003` Voting Client isolation | `approved` | **specified — extended** | `VC-*`, `BP-17`, `XA-21` | The Verification Client runs on a **separate published origin**; verification must be possible off the voting device and offline |
| `FIR-INV-004` Eligibility/credential separation | `approved` | **specified** at the consumption boundary | `CN-*`, `SB-*`, `DM-03`, `DM-04` | The capability store and the ballot store share **no key, no surrogate key and no correlation column** |
| `FIR-INV-005` No intermediate tally | `approved` | **specified — extended to publication** | `TC-01`…`TC-09`, `TC-22`…`TC-57`, `API-03`, `API-32`, `EV-61` | **Extended from "no endpoint" to "no derivable figure", and corrected.** The first candidate's padding model left the figure derivable by counting ciphertext-bearing entries; the sealed-batch model publishes one constant-size commitment per fixed window and nothing else (`TC-21`, `TC-29`) |
| `FIR-INV-006` Safe feature flags | `approved` | **specified — strengthened** | `VP-00`, `VP-07`, `VP-15`, `API-35`, `CH-37`, `CH-38`, `TC-24`, `TC-69` | No flag, mode or configuration may reorder the pipeline, skip a subgroup check, enable provisional acceptance or expose plaintext — **there is no plaintext to expose**. **`K` and `A` are protocol-profile constants and must not be implemented as feature flags**; batch cadence, capacity and `R` may not be changed during an election |
| `FIR-INV-007` DLP and controlled export | `approved` | **specified — strengthened** | `PM-*` §3, `EV-*` §5, `API-34`, `EV-71`, `EV-74`, `EV-75` | No secret, nonce, capability or exact timestamp in logs, events, exports, URLs or error text; **no export may join gateway metadata to ballot fields**. **No continuation capability or capability reference appears in any event payload**, and the capability-side half of each atomic boundary is an internal transactional state change whose technical evidence is non-exportable, bounded-context-local and short-retention |
| `FIR-INV-008` Security/System Admin separation | `approved` | **specified — structurally** | `DP-15`, `API-04`, `PM-05` | **No operator at any permission level can act on an individual ballot**, because no such operation exists |
| `FIR-INV-009` JIT and break-glass governance | `approved` | **specified — categorically** | `API-34`, `DP-01`, `BL-04`, `ER-21` | **No break-glass path into a ballot, a tally or a pre-closure decryption.** A proposal to add one is a design-review rejection |
| `FIR-INV-010` Document version integrity | `approved` | **specified** | `VP-*` stage 5, `ER-02`, `ER-11` | The pinned specification digest is checked **bit for bit** on every ballot; the record states the schema version it is written against |
| `FIR-INV-011` Statistical Disclosure Control | `approved` | **specified — this round's central application** | `TC-16`…`TC-19`, `TC-29`, `PM-*` #22 #26 #38, `DP-12` | Minimum electorate size gates electronic activation; aggregates suppressed below a published threshold; **before closure there are no aggregates at all**; suppression is stated, never silent |
| `FIR-INV-012` Accessibility as Definition of Done | `approved` | **specified — as an activation gate** | `XA-01`…`XA-32` | A context whose flow has not been tested with assistive technology **is not activated**; known unresolved barriers are published before opening |
| `FIR-INV-013` Bund/Land/Kreis isolation | `approved` | **specified** | `BP-*`, `T-P16C-07` | No value is carried between contexts; a board, a manifest and a key belong to exactly one context |
| `FIR-INV-014` No universal administration | `approved` | **specified — extended to the record** | `API-04`, `API-35`, `DP-15`, `BL-02`…`BL-04` | No party can delete, modify, replace or silently exclude a published entry — **the operation does not exist at any level** |
| `FIR-INV-015` No false production claims | `approved` | **specified and enforced** | `PB-12`…`PB-21`, `CB-04`, `ER-18`, `IV-11`, every header | The prohibited-claims list is **scannable over published participant-facing text**; a verifier result that omits what it did not check is prohibited |

### 2.1 `FIR-INV-002` — what this round adds, and what it still cannot close

PACK-15 closed `identity → credential`. PACK-16A specified the architecture
of `credential → ballot`. **PACK-16C specifies the ballot side of that
second half in full** — where the capability is consumed, what is written,
what is never written together, and what is published.

```text
What this round adds:      the atomic boundary's two halves live in
                           separate stores with no join key (DM-10);
                           no trace spans the boundary (EV-06);
                           the retry token is stripped before publication
                           (BP-16); nothing published carries a
                           correlating field (ER-* §2)

What this round does not:  demonstrate the "cannot be paired" property

What this round cannot:    close an invariant that needs a built system,
                           and an operator with database access to both
                           stores plus precise timing remains a stated
                           residual (T-P16C-28)
```

`FIR-INV-002` stays **partially addressed and future**, exactly as PACK-15,
PACK-16A and PACK-16B left it. **This round advances the specification and
does not close the invariant.**

---

## 3. Roles

| FIR | Status before | Treatment | References | Obligation that remains |
| --- | ------------- | --------- | ---------- | ----------------------- |
| `FIR-ROLE-001` DPO | `approved` | **specified** | `PM-*`, `DP-13` | The DPO owns retention of anything in the metadata matrix; no ballot-level capability |
| `FIR-ROLE-002` Election board/officer | `approved` | **specified — bounded** | `BL-04`, `DP-*` §5, `FMR-10` | The Board decides at context level and **possesses nothing**; no officer can reach a ballot |
| `FIR-ROLE-003` Independent auditor | `approved` | **specified — strengthened** | `DP-16`, `DP-17`, `FMR-10`, `IV-14` | Auditor concurrence is required for every remedy that changes the tallied set, and for `D-02`, `D-03`, `D-04`, `D-08` |
| `FIR-ROLE-004` Finance auditor | `approved` | **unchanged** | — | Untouched |
| `FIR-ROLE-005` Election Administration Separation Matrix | `approved` | **specified — applied, not extended** | `DP-*` §5, `PM-05` | No role is added by this round; the gateway/casting-service separation is applied within the existing matrix |
| `FIR-ROLE-006` Finance separation | `approved` | **unchanged** | — | Untouched |

---

## 4. Entries this round engages without closing

| FIR | Treatment | Why it is engaged |
| --- | --------- | ----------------- |
| `FIR-ASM-006` Advance voting | **specified, partially — deferred to PACK-16D** | **Deferred to PACK-16C by PACK-16B and taken up here.** The lifecycle, the window fixed by signed checkpoints, `no intermediate tally` and the result-publication rule are specified (`BL-*`, `TC-*`, `ER-*` §5). The **Ja/Nein/Enthaltung ballot style, the majority rule and the binding/advisory flag are manifest content**, not casting mechanics, and remain PACK-16D's and governance's. `BL-07` fixes changeability: **there is no revoting** |
| `FIR-ASM-007` Closed confidential poll | **specified, partially — deferred to PACK-16D** | **Deferred to PACK-16C by PACK-16B and taken up here.** One response per participant is the capability's exactly-once property (`CN-*`); no intermediate distribution is `TC-07`; aggregated result after closure is `ER-*` §5; **"no ordinary UI mapping person to answer" is architectural here, not a UI convention** (`API-04`, `DP-01`). The entry's own requirement of **no claim of cryptographic anonymity** is honoured: `TC-16` refuses electronic activation below a minimum electorate size rather than claiming anonymity a small cohort cannot have |
| `FIR-TRUST-001` Signature, seal and timestamp framework | **specified, partially — deferred to PACK-16D** | This round fixes **what must be signed** — checkpoints, publication commitments, the manifest, exclusion decisions — and **what a signature does not establish**: `ER-09` and `DM-12` forbid an exact timestamp anywhere, so no signed artefact carries one. The framework remains PACK-16D's |
| `FIR-SEC-001` Security incident and breach response | **specified, partially — deferred to PACK-17** | `FM-16C-*`, `EV-*` §2 and `DP-*` §2 fix **34 failure modes, eleven dispute classes** and the events that must be published as they occur, including the **capacity incident** and its governed pause/extension/abort path (`FM-16C-29`). Runbooks, rehearsal and **capacity stress testing** (`OD-P16C-18`) remain PACK-17's |
| `FIR-SEC-002` Backup verification and recovery testing | **assessed** | The record is append-only and mirrored; **restoring a backup over a published board is not a recovery operation that exists** (`BL-03`, `ER-17`). Archive integrity checking is `IV-*` check 16; rehearsal is PACK-17's |
| `FIR-OSS-006` Open verification, reproducible builds | **specified — criteria fixed, delivery deferred to PACK-16D** | `IV-07`…`IV-10`, `VC-*` and `API-27` make reproducible builds, signed releases, published digests, cross-language test vectors and archived source **mandatory pass/fail criteria** for both clients. Delivery is PACK-16D's |
| `FIR-CONFIG-001` Governed operational configuration | **specified — strengthened twice** | Batch interval, `C_primary`, `C_reserve`, `R`, interval count, the **capacity partition**, the **safety reserve**, first and last publication times, late-batch and empty-batch rules, checkpoint interval, suppression thresholds, minimum electorate size and escalation window are **governed configuration, frozen before `voting_open` and published with the manifest** (`TC-22`, `TC-66`, `TC-74`, `OD-P16C-10`). **Adaptive change during an election is prohibited** (`TC-24`, `TC-69`). `K` and `A` are **not** configuration at all — they are protocol-profile constants (`CH-37`) |
| `FIR-COMM-002` Neutral sensitive notifications | **specified** | `RN-16C-20` — `verification.code_not_found` never implies voter error; `DP-*` §6 states the irreversibility plainly without alarming framing; `FMR-05` forbids presenting a rollback as a loss |
| `FIR-DELIVERY-001` Official delivery and receipt | **specified, partially** | The receipt is **not a delivery artefact**: it is re-derivable from public data, is not a bearer token, and nothing depends on retaining it (`RE-04`). Publication, not receipt, is the delivery event, and it has a deadline and a public failure path (`PA-*`) |
| `FIR-QUALITY-001` Data quality and discrepancy handling | **specified, partially** | `EV-26` board inconsistency, `FM-16C-16` publication failure, `FM-16C-18`…`FM-16C-28` sealed-batch failures, `IV-*`'s `TALLY_MISMATCH` and `ARCHIVE_CORRUPTION` — each published, **none quietly repaired** (`ER-17`, `TC-54`, `FMR-15`) |
| `FIR-DATA-003` Legal Hold | **assessed** | A legal hold may not compel disclosure of a ballot's content or of who cast it, **because neither is held** (`DP-01`). It may not extend retention of anything in the metadata matrix beyond its named purpose (`ER-25`) |
| `FIR-GOV-001` Emergency governance | **specified — bounded** | `FMR-10`: no failure mode has "governance decides" as its outcome. Election-level outcomes are enumerated in `FM-16C-*` §4 with named deciders and named concurrence |
| `FIR-INCLUSION-001` Assisted and alternative channels | **specified** | `XA-23`…`XA-25`, `CB-07`: assistance under PACK-15's boundary unchanged; **an alternative channel is required wherever coercion risk is material**, and a context with none is not activated electronically |
| `FIR-METRIC-002` Count, facet and small-cohort controls | **specified — this round's other central application** | `TC-16`…`TC-19`, `TC-25`, `TC-29`, `TC-33`, `PM-*` #26 #38, `EV-60`, `EV-68`, `DP-12`. **Batch size is no longer a count**: one constant-size commitment per fixed window, published even when the window is empty. Suppression below a published threshold applies to every post-closure aggregate including dispute classes |
| `FIR-CAND-001` Candidacy & Nomination | **unchanged** | Untouched; candidate and option content is manifest content |
| `FIR-PROG-001` Program formation lifecycle | **unchanged** | Untouched |
| `FIR-UX-011` Page specification and screen content governance | **specified** | Every participant-facing string in this round is governed-catalogue content (`XA-14`, `VP-12`, `DP-18`), and the prohibited-claims list is enforced over it mechanically (`CB-04`) |

---

## 5. Entries preserved and explicitly untouched

**Verified present and unmodified in the register carried in this archive.**

| FIR | Title | State |
| --- | ----- | ----- |
| `FIR-OSS-001` | EUPL-1.2 Project Licensing Baseline | **preserved, unchanged** |
| `FIR-OSS-002` | Source Availability for Network-Provided Modified Versions | **preserved, unchanged** |
| `FIR-OSS-003` | Third-Party Licence and Dependency Compliance | **preserved, unchanged** |
| `FIR-OSS-004` | Contribution, Copyright and Provenance Governance | **preserved, unchanged** |
| `FIR-OSS-005` | Trademark, Name and Official Instance Separation | **preserved, unchanged** |
| `FIR-OSS-006` | Open Verification, Reproducible Builds | **preserved, unchanged** — engaged in §4, not modified |
| `FIR-ASM-008` | Prototype video meetings | **preserved, unchanged** |
| `FIR-INV-002` | Identity/ballot unlinkability | **preserved, unchanged** |
| `FIR-INV-015` | No false production claims | **preserved, unchanged** |
| `FIR-ROADMAP-006` | Voting and Elections | **preserved, unchanged** |

### 5.1 A licensing note that is not a change

This round creates **no code and no dependency of any licence**.
`OD-P16A-08` is unchanged and unanswered, and no `FIR-OSS-*` compliance is
claimed.

---

## 6. Obligations that are `blocked`, and why that is the honest value

| Obligation | Blocked value | Blocking artefact |
| ---------- | ------------- | ----------------- |
| `OD-P16A-06` / `TV-08` | **blocked pending cryptographic review** | No external review of the composed EPD² profile has been obtained. **Unchanged by this round** |
| `VO-08` | **blocked pending independent cryptographic review** | Owner: **PACK-16B external cryptographic review**, confirmed by PACK-17 — **not PACK-16C**. Blocks production and legal activation. **PACK-16C neither closes, narrows nor re-owns it** |
| `BM-28` / `OD-P16C-08` | **blocked pending independent verifier engagement** | No party outside EPD² has been engaged. Blocks **binding use of any context** |
| `OD-P16C-01` | **blocked pending demonstration** | The atomic boundary's exactly-once guarantee is specified and **not demonstrated**. If PACK-16D cannot demonstrate it, this becomes an `ARCHITECTURAL BLOCKER` |
| `OD-P16C-12` | **blocked pending an ecosystem that does not yet exist** | `G-03`, `G-05`: split-view detection is unstandardised. Until witnesses exist, split-view resistance rests on **organisational** mirror independence |
| `OD-P16C-16` | **blocked pending a serialization decision** | Checks 17–21 cannot be executed by an independent verifier until the opening and reconciliation formats are pinned. Blocks **binding use of a context**, not this round |
| `OD-P16C-19` | **blocked pending a construction this round could not specify** | The **per-capability** bound — at most one cast artefact and one public challenge artefact per anonymous continuation — needs privacy-preserving evidence that does not publish a capability-to-artefact mapping. **Public totals are checkable now; the per-capability statement is not.** Owner: PACK-16D specification, independent cryptographic review by PACK-17. **`ARCHITECTURAL BLOCKER` for certification if no sufficient evidence boundary can be constructed** |
| `OD-P16A-11` | **blocked pending legal assessment** | § 15 Abs. 2a PartG mapping. **Unchanged by this round** |

**Eight blocked obligations, none of them dressed as progress.** Four are
new to PACK-16C — one added by the turnout correction and one by the
capacity correction — and four are inherited unchanged.

---

## 7. Summary

| Measure | Value |
| ------- | ----- |
| FIR entries assessed | all entries in the canonical register |
| FIR entries **specified** or **specified, partially** by this round | 32 — §2 15 · §3 4 · §4 13 |
| FIR entries whose treatment was **strengthened by the turnout correction** | 5 — `FIR-INV-005`, `FIR-INV-011`, `FIR-CONFIG-001`, `FIR-METRIC-002`, `FIR-QUALITY-001` |
| FIR entries whose treatment was **strengthened by the capacity correction** | 4 — `FIR-CONFIG-001`, `FIR-SEC-001`, `FIR-GOV-001`, `FIR-INV-006` |
| FIR entries whose treatment was **strengthened by the event-privacy correction** | 1 — `FIR-INV-007` |
| **Future implementation obligations named by the capacity correction** | 5 — anonymous public-challenge entitlement enforcement; atomic leaf reservation; predeclared reserve batch capacity; privacy-preserving per-capability reconciliation; capacity-incident governance. **All are carried as `OD-P16C-17`…`OD-P16C-19` and existing FIR entries; no new FIR identifier is created** |
| of those, entries whose remainder is **deferred** with a named owner | 5 — `FIR-ASM-006`, `FIR-ASM-007`, `FIR-TRUST-001`, `FIR-SEC-001`, `FIR-OSS-006` |
| FIR entries **deferred** in whole | 1 — `FIR-ROADMAP-007` |
| FIR entries **assessed** without specification | 2 — `FIR-SEC-002`, `FIR-DATA-003` |
| FIR entries **selected for architectural review** | 1 — `FIR-ROADMAP-006` |
| FIR entries **blocked** | 0 entries; 6 obligations (§6) |
| FIR entries **unchanged** | all others |
| FIR entries marked `implemented` | **0** |
| FIR entries created | **0** |
| FIR entries removed, renamed or downgraded | **0** |
| FIR **statuses changed** in the register | **0** |
| Register copies in the archive | **1**, at the canonical path |
| `FIR-INV-002` closed | **no — and it cannot be, by this round** |
| Entries deferred to PACK-16C by earlier rounds and taken up | **2** — `FIR-ASM-006`, `FIR-ASM-007` |

**SPECIFIED. REQUIRES EXTERNAL REVIEW. NOT PRODUCTION READY. NOT LEGALLY
ACTIVATED.**
