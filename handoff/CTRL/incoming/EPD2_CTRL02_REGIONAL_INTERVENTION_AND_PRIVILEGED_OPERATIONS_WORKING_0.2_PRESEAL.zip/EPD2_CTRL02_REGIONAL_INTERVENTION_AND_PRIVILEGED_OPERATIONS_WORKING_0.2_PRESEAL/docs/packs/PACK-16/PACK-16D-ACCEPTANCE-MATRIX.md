# PACK-16D — Acceptance Matrix

**Round:** PACK-16D — Network-Enabled Finalization: Lockfile Regeneration,
Immutable ElectionGuard Provenance and Final Acceptance Alignment. A correction
of the PACK-16D reference-implementation candidate, not a new round.
**Reference implementation. Not production code. Not certified. Not a PASS.**
**Repository version:** unchanged at `0.16.0` · **Canon version:** unchanged at `0.8.0`
**ADR:** `ADR-102`, status `proposed`
**NOT PRODUCTION READY. NOT LEGALLY ACTIVATED. PUBLIC-ELECTION ACTIVATION PROHIBITED BY DEFAULT.**

---

## 1. How to read this matrix

Ten columns, as §56 requires. `Status` takes one of five values and nothing
else:

```text
SATISFIED            implemented in reference form and covered by a test
PARTIALLY SATISFIED  implemented, with a named gap in the same row
DEFERRED             deliberately not done this round; owner named
BLOCKED              cannot be done without an external party
NOT APPLICABLE       out of this round's scope
```

`SATISFIED` means *satisfied for a reference implementation*. It never means
production-ready, externally reviewed, certified or legally activated. Every
row's residual risk column says what remains true anyway.

`CORRECTED` is **not** a status and appears nowhere in the `Status` column.
The correction changed the *facts* behind several rows; it did not invent a
sixth classification to describe them.

`External evidence` names a first-hand external source or says `none`.
**Most rows still say `none`**, because most of this round's work is
implementation of decisions three earlier rounds made — and pretending
otherwise would be the easiest way to make this matrix worthless. The rows
that now name an external source do so because a primary source or an
independent oracle was actually consulted, not because the topic sounds
external.

Test evidence names a test file, and where one test carries a row's whole
weight, that test by name.

### 1.0 What *this* finalization changed in this matrix

Two rows were `PARTIALLY SATISFIED` because the build environment could reach
neither a package index nor GitHub. Both blockers have been cleared on a
network-enabled host, and both rows now read `SATISFIED` **on evidence**:

| Row | Was | Is | Why |
| -- | --- | --- | --- |
| 79 `AM-79` | `PARTIALLY SATISFIED` | **`SATISFIED`** | The corroborating implementation source is commit-pinned at `520651138110a13f777409e96606454df928ceac` with its raw-byte digest recorded in the artefact, alongside the normative specification provenance that was already pinned |
| 89 `AM-89` | `PARTIALLY SATISFIED` | **`SATISFIED`** | `cryptography 46.0.7` resolves in `uv.lock` inside the `epd2-voting-service` graph, from a registry, with hashes on all 43 artefacts and both transitives locked |

**Neither promotion was granted for the disappearance of a blocker.** A row is
`SATISFIED` here because the five things §10 of the finalization task requires
are each present and each checked by a test, not because the obstacle that
prevented them went away. The distinction matters: the previous round's defect
was a status drifting ahead of its evidence, and the same error in the opposite
direction would be no better.

One residual limit is recorded rather than absorbed into the promotion: the
`uv sync --all-groups --frozen` run and the upstream byte fetch both happened on
the network-enabled host, not in the build session. The session verified the
lock's contents, tied the running library version to the locked one, and checked
the pin's internal consistency — it did not re-run the install or re-fetch the
bytes, and rows 79 and 89 say so in their residual-risk columns.

### 1.1 What the third audit's correction changed in this matrix

The third audit passed everything cryptographic and raised one matrix
defect, which was real and is the reason this section exists:

> `AM-79` claimed the parameter set was **immutably provenanced** with
> status `SATISFIED`, while its own evidence column admitted that
> `upstream_commit`, `commit_pinned_source_url` and `source_sha256` were
> absent.

A row cannot assert a property and document its absence in the same
sentence. **`AM-79` is now `PARTIALLY SATISFIED`.**

| Row | Was | Is | Why |
| -- | --- | --- | --- |
| 79 `AM-79` | `SATISFIED` | **`PARTIALLY SATISFIED`** — *since promoted, see §1.0* | Normative provenance is pinned; the corroborating implementation source is not, and the row may not average the two into a pass |
| 89 `AM-89` | `PARTIALLY SATISFIED` | **unchanged** — *since promoted, see §1.0* | Still declared and not locked. The status was already right; only the evidence column is sharper |

**Neither downgrade was forced by new information.** Both facts were
already recorded in the artefact and in the previous handover; what was
wrong was the *status* placed on top of them. That is the failure mode this
matrix is most prone to — the evidence stays honest while the summary
drifts optimistic — and it is worth naming rather than quietly fixing.

### 1.2 What the second audit's correction changed in this matrix

The second audit passed the parameter profile, the target-profile crypto
tests, both guardian paths, checkpoint signature *semantics* and archive
hygiene. It failed one thing and half-passed two:

| Row | Was | Is | Why |
| -- | --- | --- | --- |
| 41 `AM-41` | `SATISFIED`, citing a hand-written primitive | **SATISFIED**, citing a vetted provider | The semantics were never the problem; the primitive was |
| 79 `AM-79` | `SATISFIED` on a mutable `/main/` URL | **SATISFIED** on a versioned document plus offline reconstruction — **corrected down to `PARTIALLY SATISFIED` (§1.1), then promoted on a commit pin (§1.0)** | A branch reference is not provenance |
| 55 `AM-55` | `SATISFIED` — "two independent oracles" | **split into rows 55 and 86** | One label covered both profiles and hid that most checks ran on the fast group |
| — | — | new rows **86–90** | The provider, the absence of hand-written crypto, the target-profile core, the dependency lock, and full ecosystem interoperability |

The lock row (89) was for two rounds the only row in this matrix that was
`PARTIALLY SATISFIED` because of something a round could not finish rather than
something it deliberately deferred. It is `SATISFIED` as of §1.0, and no row is
in that category any more.

### 1.3 What the first audit's correction changed in this matrix

The first independent audit failed four areas. Each had a row here that
described a *central implementation gap* as though it were an external-party
blocker. That was the matrix's own defect, and it was corrected:

| Row | Was | Is | Why |
| -- | --- | --- | --- |
| 2 `AM-02` | `BLOCKED` — "the real family is absent" | **SATISFIED** | The real parameters are present and load |
| 41 `AM-41` | `BLOCKED` — "a verifier cannot confirm the operator published a checkpoint" | **SATISFIED** | Ed25519 signatures are generated and verified against a declared signer set |
| 55 `AM-55` | `BLOCKED` — "nothing has been checked against any other implementation" | **SATISFIED** | Two independent oracles now check it, and one of them found a real defect |
| 65 `AM-65` | `DEFERRED` — "the tally rests on one guardian" | **SATISFIED** (split into rows 65, 79, 80) | Feldman-VSS DKG with 3-of-5 and 4-of-7 quorums |
| 77 `AM-77` | `BLOCKED` | **DEFERRED** to PACK-17 | Not an external party's inaction: nobody has yet written a *complete* second implementation, and that is PACK-17's scope |

A `BLOCKED` row must name a party that has not acted. A row that names a
task this round could have done and did not is `DEFERRED`, and a row that
names a task this round *should* have done is a defect, not a status.

## 2. The matrix

| # | Requirement ID | Requirement | Inherited source | External evidence | Implementation artifact | Test evidence | Status | Residual risk | Next stage |
| -- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | `AM-01` | Parameter validation fails closed on every structural defect | PACK-16B `EPD2-CRYPTO-1` | ElectionGuard 2.1 §3.1.1 constants, read first-hand | `crypto/parameters.py` `validate_parameter_set` | `test_crypto_units.py::test_parameter_validation_fails_closed`, `test_epd2_crypto_1.py::test_epd2_crypto_1_invalid_constant_rejected`, `test_negative_corpus.py` | **SATISFIED** | The mechanism *and* the constants are now validated; whether the constants are the right ones for a German public election is `VO-08` and remains unanswered | PACK-16B review |
| 2 | `AM-02` | `EPD2-CRYPTO-1` is never silently substituted | PACK-16B | none | `load_profile` — no `except`, no default, no test-profile reference; `require_target_profile`, `ProfileSubstitutionError`, `TEST_ONLY_MARKER` | `test_epd2_crypto_1.py::test_epd2_crypto_1_no_fallback`, `::test_epd2_crypto_1_no_environment_or_flag_can_substitute`, `::test_loader_source_names_no_fallback_branch`, `::test_the_test_profile_is_not_the_target` | **SATISFIED** | A structural test can prove no substitution path exists in *this* loader; it cannot prove a future caller will not add one | PACK-17 |
| 3 | `AM-03` | Expected bit lengths come from code, not from the profile file | this round | none | `PROFILE_BIT_LENGTHS` | `test_verifier_branches.py::test_profile_bit_lengths_come_from_code_not_from_the_file` | **SATISFIED** | none | — |
| 4 | `AM-04` | `q = 2²⁵⁶ − 189`, 256 bits, probable-prime | PACK-16B | ElectionGuard 2.1 `standard_parameters.rs`, read first-hand | `Q_ELECTIONGUARD_2_1` | `test_crypto_units.py::test_q_is_the_electionguard_small_prime` | **SATISFIED** | Miller–Rabin is not a proof of primality | formal verification, deferred |
| 5 | `AM-05` | Canonical encoding is unambiguous and fixed-width | PACK-16C `OD-P16C-04` | none | `crypto/encoding.py` (`EPD2-ENC-1`) | `test_crypto_units.py`, `test_property.py::test_p04`, `test_p05b` | **SATISFIED** | Non-ambiguity of caller-supplied field names is a caller obligation, met by inspection | PACK-17 |
| 6 | `AM-06` | Field order is normative; maps prohibited; duplicates rejected | PACK-16C | none | `encode_struct` | `test_crypto_units.py::test_canonical_struct_field_order_is_normative`, `::test_canonical_struct_rejects_duplicate_fields` | **SATISFIED** | none | — |
| 7 | `AM-07` | Domain separation is centralised and fails closed | PACK-16B Fiat–Shamir doc | none | `crypto/domain_separation.py` (`EPD2-DS-1`, 27 labels) | `test_crypto_units.py::test_domain_labels_are_unique_and_registered` | **SATISFIED** | Three hash sites bypass the registry; none computes a protocol digest, and all three are named | PACK-17 |
| 8 | `AM-08` | A registered label with no call site is declared, not hidden | this round | none | `RESERVED_WITHOUT_CALL_SITE` | `test_verifier_branches.py::test_reserved_domain_labels_are_declared_accurately` | **SATISFIED** | none | — |
| 9 | `AM-09` | Production and deterministic randomness are separated | PACK-16D §15 | none | `crypto/randomness.py` | `test_crypto_units.py::test_select_source_can_never_return_a_deterministic_source`, `::test_deterministic_source_requires_both_guards` | **SATISFIED** | none | — |
| 10 | `AM-10` | Randomness failure fails closed rather than degrading | PACK-16D §60 | none | `ProductionRandomSource` | `test_verifier_branches.py::test_production_random_source_reports_failure_rather_than_degrading` | **SATISFIED** | none | — |
| 11 | `AM-11` | Ballot encryption follows `EPD2-HOM-1` | PACK-16A | none | `crypto/elgamal.py`, `casting/ballot.py` | `test_property.py::test_p01`, `test_casting_units.py`, `test_epd2_crypto_1.py::test_epd2_crypto_1_encrypt_verify`, `::test_epd2_crypto_1_homomorphic_tally` | **SATISFIED** | Now exercised on `EPD2-CRYPTO-1` itself as well as on the fast test profiles. Ballot *styles* remain single-contest in the reference tally | `OD-P16D-10` |
| 12 | `AM-12` | Plaintext outside the domain is rejected, never clamped | PACK-16A | none | `encrypt(..., max_message)` | `test_negative_corpus.py::test_neg_invalid_scalar` | **SATISFIED** | No nonce-reuse detector exists | PACK-17 |
| 13 | `AM-13` | Undervote and blank contest are structurally indistinguishable from a full one | PACK-16A ballot model | none | placeholder selections in `encrypt_ballot` | `test_casting_units.py::test_undervote_is_absorbed_by_placeholders`, `::test_a_blank_contest_still_produces_a_valid_ballot` | **SATISFIED** | none | — |
| 14 | `AM-14` | The ballot envelope carries no identity | PACK-16A `NO IDENTITY IN BALLOT` | none | `BallotEnvelope`, six fields | `test_casting_units.py::test_ballot_envelope_carries_no_identity_field` | **SATISFIED** | none | — |
| 15 | `AM-15` | Proof generation and verification implemented for all three kinds | PACK-16A NIZK family | none | `crypto/proofs.py` | `test_property.py::test_p02`, `test_p03`, `test_e2e.py` | **SATISFIED** | Not constant-time | `OD-P16D-05` |
| 16 | `AM-16` | Invalid subgroup elements are rejected before any equation | PACK-16B | none | `is_in_subgroup`, checks in every verifier | `test_negative_corpus.py::test_neg_invalid_subgroup_element`, `::test_neg_zero_element`, `::test_neg_element_ge_p` | **SATISFIED** | none | — |
| 17 | `AM-17` | A proof does not transfer between selections, ballots or contexts | PACK-16A | none | Fiat–Shamir context binding | `test_property.py::test_p03_modified_proof_fails`, `test_negative_corpus.py::test_neg_reused_nonce` | **SATISFIED** | none | — |
| 18 | `AM-18` | Decryption-share proofs are bound to the contest and option they decrypt | this round | none | `decryption_share_context()` | `test_verifier_branches.py::test_decryption_share_proof_is_bound_to_its_contest_and_option` | **SATISFIED** | none | — |
| 19 | `AM-19` | Challenge opening re-encrypts to the published envelope | PACK-16C `CH-*` | none | `verify_challenge_opening` | `test_negative_corpus.py::test_neg_cast_nonce_revealed`, `test_verifier_branches.py::test_invalid_challenge_opening_branch` | **SATISFIED** | none | — |
| 20 | `AM-20` | Continuation state is three booleans; `K = 1`, `A = 1` | PACK-16C | none | `casting/continuation.py`, `publication/capacity.py` | `test_property.py::test_p10`, `test_casting_units.py` | **SATISFIED** | none | — |
| 21 | `AM-21` | A public challenge does not consume the cast entitlement | PACK-16C | none | `spend_public_challenge()` | `test_e2e.py::test_e2e_02_public_challenge_then_cast` | **SATISFIED** | none | — |
| 22 | `AM-22` | A second public challenge is impossible | PACK-16C | none | entitlement check inside the transaction | `test_e2e.py::test_e2e_03`, `test_property.py::test_p09` | **SATISFIED** | none | — |
| 23 | `AM-23` | A second cast is impossible | PACK-16C | none | `consume_for_cast()` | `test_e2e.py::test_e2e_04`, `test_property.py::test_p08` | **SATISFIED** | none | — |
| 24 | `AM-24` | The public-challenge transaction is atomic | PACK-16C | none | `submit_public_challenge` | `test_fault_injection.py::test_public_challenge_rolls_back_completely` (6 points) | **SATISFIED** | Atomicity proven against an in-memory store | `OD-P16D-04` |
| 25 | `AM-25` | The cast-acceptance transaction is atomic | PACK-16C | none | `submit_cast_ballot` | `test_fault_injection.py::test_cast_rolls_back_completely_at_every_transactional_point` | **SATISFIED** | same | `OD-P16D-04` |
| 26 | `AM-26` | A capability is never consumed by a rollback | PACK-16C | none | snapshot restore in `store.transaction()` | `test_e2e.py::test_e2e_05_crash_before_commit` | **SATISFIED** | none | — |
| 27 | `AM-27` | Idempotent replay is stable; a conflict fails closed | PACK-16C | none | `_replay()`, inside the transaction | `test_property.py::test_p06`, `test_p07`, `test_concurrency.py::test_c04` | **SATISFIED** | none | — |
| 28 | `AM-28` | Nine named concurrency races produce no double acceptance | PACK-16D §42 | none | store lock + compare-and-set | `test_concurrency.py` (87 tests) | **PARTIALLY SATISFIED** | Evidence covers the reference store's re-entrant lock only, not a production isolation level | `OD-P16D-04`, PACK-17 |
| 29 | `AM-29` | Leaf reservation is atomic and precedes acceptance | PACK-16C | none | `reserve_leaf` compare-and-set | `test_concurrency.py::test_c05`, `test_property.py::test_p12` | **SATISFIED** | none | — |
| 30 | `AM-30` | A public challenge never occupies a cast-reserved slot | PACK-16C `TC-75` | none | `_candidate_slots` | `test_negative_corpus.py::test_neg_wrong_slot_type`, `test_concurrency.py::test_c03` | **SATISFIED** | none | — |
| 31 | `AM-31` | Adaptive overflow is impossible | PACK-16C | none | declared partition; `CapacityPlan.validate()` | `test_negative_corpus.py::test_neg_adaptive_overflow_attempt` | **SATISFIED** | Found as a real defect this round and fixed | — |
| 32 | `AM-32` | Capacity exhaustion fails closed with no hidden queue | PACK-16C | none | `CastCapacityUnavailableError`, `CapacityExhaustedError` | `test_e2e.py::test_e2e_07_capacity_exhaustion`, `test_verifier_branches.py::test_capacity_exhaustion_is_caught_at_sealing_time` | **SATISFIED** | none | — |
| 33 | `AM-33` | Sealed batch size is independent of occupancy | PACK-16C `TC-33` | none | `seal_batch` cover-leaf fill | `test_casting_units.py::test_sealed_batch_size_is_independent_of_occupancy` | **SATISFIED** | Constant *size* is measured; timing side channels are not | `OD-P16D-05` |
| 34 | `AM-34` | Batch roots recompute deterministically | PACK-16C | none | `crypto/merkle.py` | `test_property.py::test_p14`, `test_negative_corpus.py::test_neg_batch_root_mismatch` | **SATISFIED** | none | — |
| 35 | `AM-35` | Cover leaves never become tally-eligible | PACK-16C | none | `reconcile()` | `test_property.py::test_p13`, `test_negative_corpus.py::test_neg_cover_leaf_in_tally` | **SATISFIED** | none | — |
| 36 | `AM-36` | Spoiled ballots never enter the tally | PACK-16A, PACK-16C | none | `verify_record` spoiled/accepted disjointness | `test_negative_corpus.py::test_neg_spoiled_ballot_in_tally` | **SATISFIED** | none | — |
| 37 | `AM-37` | Bulletin-board inclusion proofs work | PACK-16C | RFC 6962 §2.1, read first-hand in PACK-16C | `crypto/merkle.py`, `verify_leaf_inclusion` | `test_property.py::test_p14`, `test_verifier_branches.py::test_batch_inclusion_failed_branch` | **SATISFIED** | none | — |
| 38 | `AM-38` | Consistency proofs work | PACK-16C | RFC 6962 §2.1.2 | `consistency_proof`, `verify_consistency` | `test_casting_units.py::test_inclusion_and_consistency_hold_for_odd_sizes`, `test_negative_corpus.py::test_neg_invalid_consistency_proof` | **SATISFIED** | none | — |
| 39 | `AM-39` | Rollback and equivocation are detected | PACK-16C | none | `verify_board` | `test_e2e.py::test_e2e_08`, `::test_e2e_08b`, `test_negative_corpus.py` | **PARTIALLY SATISFIED** | Detected **within one exported view**. Split view across mirrors is not detected | `OD-P16D-06`, PACK-17 |
| 40 | `AM-40` | Checkpoint roots re-derive from the exported entries | this round | none | `verify_board` root recomputation | `test_verifier_branches.py::test_checkpoint_roots_are_re_derived_from_the_exported_entries` | **SATISFIED** | none | — |
| 41 | `AM-41` | Checkpoint operator signatures are verified | PACK-16C | RFC 8032 §7.1 vectors; OpenSSL cross-check | `publication/checkpoint_signing.py`, `crypto/signature_provider.py`, `SignerRegistry` as the trust anchor | `test_checkpoint_signatures.py::test_valid_checkpoint_signature`, `::test_verifier_checks_signatures_and_says_so`, `::test_verifier_reports_a_forged_signature_distinctly`, `::test_a_signer_registry_is_never_read_from_the_checkpoint` (44 tests) | **SATISFIED** | A valid signature proves *who issued* a checkpoint. It does not prove the registry itself was authorised (`OD-P16D-12`), nor that the board showed one view to everyone (row 39) | `OD-P16D-12`, PACK-17 |
| 42 | `AM-42` | No tally artefact exists before closure | PACK-16A `NO INTERMEDIATE TALLY` | none | `open_tally(board_closed)` | `test_e2e.py::test_e2e_10`, `test_invariants.py` (§44 block) | **SATISFIED** | none | — |
| 43 | `AM-43` | No feature flag can disable an invariant | PACK-16D §45 | none | `invariants.py` | `test_invariants.py::test_unsafe_flag_override_fails_startup` (10 invariants × 4 shapes) | **SATISFIED** | A name guard cannot prove the code behind the name is correct; that is what the other rows are for | — |
| 44 | `AM-44` | The election record is deterministic and covers every artefact | PACK-16C | none | `ElectionRecord.canonical_bytes()` | `test_casting_units.py::test_election_record_digest_is_deterministic`, `test_verifier_branches.py::test_record_digest_covers_the_openings_and_the_shares` | **SATISFIED** | none | — |
| 45 | `AM-45` | Reconciliation is one-to-one and bounded by `E` and `E × K` | PACK-16C | none | `reconcile()` | `test_casting_units.py::test_reconciliation_reports_every_class`, `test_negative_corpus.py` | **SATISFIED** | none | — |
| 46 | `AM-46` | The verifier runs without identity, credential or capability state | PACK-16C `IV-*` | none | `verification/` package | `test_invariants.py::test_verifier_imports_no_identity_credential_or_capability_module`, `::test_verifier_names_no_capability_or_identity_symbol` | **SATISFIED** | Independent of the *publisher*, within one codebase. Not an independent *implementation* | `OD-P16D-02` |
| 47 | `AM-47` | A valid election passes end-to-end verification | PACK-16C | none | `verify_record` | `test_e2e.py::test_e2e_01`, `::test_e2e_multi_contest_election_verifies` | **SATISFIED** | Single ballot style only | `OD-P16D-10` |
| 48 | `AM-48` | A `VERIFIED` result always prints what it did not check | PACK-16C `IV-11` | none | `NOT_CHECKED`, **9** entries | `test_verifier_branches.py::test_not_checked_is_never_empty_and_names_vo_08` | **SATISFIED** | The entry claiming checkpoint signatures are never verified was **removed because it became false**, and replaced by two narrower and still-true ones | — |
| 49 | `AM-49` | An invalid-proof corpus is rejected | PACK-16D §40 | none | **39** cases | `test_negative_corpus.py` (41 tests, incl. two index guards) | **SATISFIED** | none | — |
| 50 | `AM-50` | Every negative case asserts its declared reason code | this round | none | `EXPECTED_REASON_CODES` | `test_negative_corpus.py::test_every_case_asserts_its_declared_reason_code` | **SATISFIED** | Four declared codes were wrong and were corrected | — |
| 51 | `AM-51` | Fault injection confirms rollback and recovery at 11 points | PACK-16D §43 | none | `hooks.py`, `testing/faults.py` | `test_fault_injection.py` (22 tests) | **SATISFIED** | none | — |
| 52 | `AM-52` | Fault injection is test-only and cannot reach production | PACK-16D §43 | none | `FaultHook` protocol; hooks passed explicitly | `test_fault_injection.py::test_production_modules_do_not_import_the_injector` (`ast`) | **SATISFIED** | none | — |
| 53 | `AM-53` | Test vectors are deterministic and documented | PACK-16D §38 | none | `testing/vectors.py`, 23 vectors | `test_vectors.py` (31 tests) | **SATISFIED** | **Stability only.** These 23 vectors are `internal-stability` evidence and are not conformance evidence; they keep the `interoperability NOT established` status | rows 55, 82 |
| 54 | `AM-54` | No vector claims interoperability or a production profile | this round | none | `SELF_GENERATED`, `STATUS_STABILITY`, `EvidenceClass` | `test_vectors.py::test_no_vector_claims_interoperability`, `::test_no_vector_uses_a_production_profile`, `test_conformance.py::test_self_generated_vectors_are_never_called_conformance` | **SATISFIED** | none | — |
| 55 | `AM-55` | Cross-implementation conformance on the **fast test profile** | PACK-16A | an independent Node.js verifier written from the written grammar | `reference/testing/conformance.py`, `crossimpl/independent_verifier.mjs`, `PACK-16D-CONFORMANCE-EVIDENCE.json` (8 `cross-implementation-test-profile` entries) | `test_conformance.py::test_the_oracle_is_not_the_producer`, `::test_cross_impl_*`, `::test_the_oracle_detects_a_wrong_answer` | **SATISFIED** | Evidence about the 1024-bit group. It says the *code paths* agree; it says nothing about the numbers in the group an election would use. That is row 86, and splitting the two is what the second audit's `PARTIAL` forced | row 86 |
| 56 | `AM-56` | Forbidden data does not reach events | PACK-16C event privacy | none | `FORBIDDEN_OUTBOX_FIELDS` | `test_invariants.py::test_event_payloads_carry_no_forbidden_field`, `test_concurrency.py::test_no_capability_to_ballot_leakage_in_any_persisted_row` | **SATISFIED** | none | — |
| 57 | `AM-57` | Forbidden data does not reach logs | PACK-16D §46 | none | `logging_boundary.py`, 23 forbidden fields | `test_invariants.py::test_forbidden_log_field_fails_the_test_sink` (all 23) | **SATISFIED** | A field-name boundary cannot detect a value smuggled into an allowed field; there is no free-text field | PACK-17 |
| 58 | `AM-58` | The test RNG cannot be enabled in a production profile | PACK-16D §38 (criterion) | none | `select_source()` | `test_invariants.py::test_test_rng_cannot_be_selected_in_production_profile` | **SATISFIED** | none | — |
| 59 | `AM-59` | Turnout is not derivable before closure | PACK-16C `TC-29`, `BA-07` | none | pre-closure entry allow-list; constant batch size | `test_invariants.py::test_turnout_and_accepted_enumeration_are_not_exported_pre_closure` | **SATISFIED** | Structural only; timing and traffic analysis are out of scope | PACK-17 |
| 60 | `AM-60` | Audit evidence is tamper-evident and privacy-minimised | PACK-16D §47 | none | `audit.py` | `test_invariants.py::test_audit_log_is_tamper_evident`, `::test_audit_records_reject_extra_fields` | **PARTIALLY SATISFIED** | Role restriction and retention are governance properties, **not implemented** | PACK-17 |
| 61 | `AM-61` | Every artefact schema is versioned and rejects unknown fields | PACK-16D §50 | none | `schemas.py`, 13 schemas | `test_invariants.py` (§50 block), `test_negative_corpus.py::test_neg_unknown_critical_field` | **SATISFIED** | The registry gates one production path (record export); other artefacts are not yet validated through it | PACK-17 |
| 62 | `AM-62` | All twelve §48 reason codes exist as typed results | PACK-16C catalogue | none | 48 typed error classes; **26** result codes with 26 distinct exit codes | `PACK-16D-REASON-CODE-COVERAGE.md`, `test_negative_corpus.py`, `test_guardians.py::test_error_codes_are_the_declared_ones` | **SATISFIED** | none | — |
| 63 | `AM-63` | Constant-time / side-channel resistance | PACK-16B | none | none | none | **BLOCKED** | Python integers are not constant-time. Four surfaces are distinguished rather than blanketed: public verification carries no secret; **guardian secret operations and secret-nonce use remain pure Python and are not constant-time**. Ed25519 signing moved to OpenSSL, which pursues side-channel resistance as a design goal — a real reduction in risk and **not an assurance**, because EPD² measured nothing. `OD-P16D-05` is narrowed, not closed | `OD-P16D-05`, **production blocker** |
| 64 | `AM-64` | Secret-material zeroization | PACK-16D §60 | none | none | none | **BLOCKED** | Python cannot reliably zeroize an immutable `int` or `bytes` | PACK-17 |
| 65 | `AM-65` | Threshold DKG and the 3-of-5 default guardian quorum | PACK-16B | none | `guardians/ceremony.py` (Feldman VSS, Schnorr proof of possession), `guardians/threshold.py` (Lagrange at zero) | `test_guardians.py::test_3_of_5_joint_key_derivation`, `::test_3_of_5_quorum_decryption`, `::test_2_of_5_rejected`, `test_e2e.py::test_e2e_11`, `test_epd2_crypto_1.py::test_epd2_crypto_1_guardian_ceremony` | **SATISFIED** | The ceremony runs **in one process with no authenticated channel, no HSM, no air gap and no key custody**. That is a reference path, not a key ceremony | `OD-P16D-11`, PACK-17 |
| 66 | `AM-66` | Production authentication and credential integration | PACK-14, PACK-15 | none | none — test-only capability fixture | `test_casting_units.py::test_reference_api_banner_states_it_is_not_production_authentication` | **DEFERRED** | The API authenticates nothing | `OD-P16D-08` |
| 67 | `AM-67` | Property-based testing across 15 named properties | PACK-16D §41 | none | `test_property.py` | 17 tests, 40 cases each | **PARTIALLY SATISFIED** | Deterministic loops, not hypothesis: no shrinking, no adversarial search | `OD-P16D-03` |
| 68 | `AM-68` | `VO-08` assessed | PACK-16B | none | none | named in `NOT_CHECKED` | **BLOCKED** | No BSI conformity claimed | PACK-16B review, PACK-17 |
| 69 | `AM-69` | Canon assessed | PACK-16D §54 | none | `PACK-16D-CANON-ASSESSMENT.md` | `scripts/check_canon_0_8_0.py` — 18 checks pass | **SATISFIED** | `NO CANON CHANGE REQUIRED` | — |
| 70 | `AM-70` | FIR assessed, nothing improperly closed | PACK-16D §55 | none | `PACK-16D-FIR-COVERAGE-MATRIX.md`, register §1.23 | matrix arithmetic in §5 of that document | **SATISFIED** | 0 of the 8 unclosable items closed | PACK-17 |
| 71 | `AM-71` | Dependencies unchanged; lock files untouched | PACK-16D §63 | none | zero new dependencies | `uv.lock` and `package-lock.json` byte-identical | **SATISFIED** | `uv sync --frozen` could not be executed to confirm the lock still resolves | PACK-17 |
| 72 | `AM-72` | Repository version assessed and bumped correctly | PACK-16D §62 | none | 8 files | `scripts/verify_versions.py` — `OK`; `packages/python/epd2-core/tests/test_version.py` | **SATISFIED** | none | — |
| 73 | `AM-73` | Archive hygiene: one root, one lock, no nested ZIPs, no secrets | PACK-16D §64, §65 | none | packaging exclusions | `scripts/check_forbidden_files.py` — `OK`; `tests/repository/test_forbidden_paths.py` | **SATISFIED** | none | — |
| 74 | `AM-74` | Every executed command's output is recorded; unexecuted ones named | PACK-16D §57 | none | `PACK-16D-IMPLEMENTATION-REPORT.md` §commands | the report itself | **SATISFIED** | `uv sync --frozen`, the entire npm side, hypothesis and branch coverage **were not executed** and are named as such | PACK-17 |
| 75 | `AM-75` | Coverage reported across the six §59 dimensions | PACK-16D §59 | none | `trace`-based measurement | report §coverage | **PARTIALLY SATISFIED** | **Branch coverage was not measured** — no tool is installable here | PACK-17 |
| 76 | `AM-76` | External cryptographic review | PACK-16B | none | none | none | **BLOCKED** | No external party reviewed anything | PACK-16B, PACK-17 |
| 77 | `AM-77` | A fully independent verifier — a complete second implementation | PACK-16A | none | none | none | **DEFERRED** | Two single-purpose oracles (row 55) are not a complete implementation, and verifier independence inside one codebase is not implementation independence. This is nobody else's inaction; it is work this round did not undertake | PACK-17 |
| 78 | `AM-78` | Production deployment, HSM, key ceremony, legal activation | PACK-16A/16B | none | none | none | **NOT APPLICABLE** | Out of this round's scope by §-out-of-scope | later rounds |
| 79 | `AM-79` | The real `EPD2-CRYPTO-1` parameter set loads, validates and is **immutably provenanced** | PACK-16B | **Normative:** ElectionGuard 2.1 §3.1.1 p.14 at a versioned release asset, digest recorded in the artefact. **Corroborating implementation source:** `microsoft/electionguard-rust` at commit `520651138110a13f777409e96606454df928ceac` (2025-02-02), `src/eg/src/standard_parameters.rs`, SHA-256 `ad38bfa6…5770`, retrieved 2026-08-03 | `crypto/profiles/EPD2-CRYPTO-1.json` — `source.authoritative`, `source.corroborating`, `source.hierarchy`, `digests`, `derivation`; `parameter_digest` pinned in code | `test_epd2_crypto_1.py::test_epd2_crypto_1_parameters_reconstruct_offline`, `::test_epd2_crypto_1_upstream_commit_nonempty`, `::test_epd2_crypto_1_upstream_commit_is_full_sha`, `::test_epd2_crypto_1_source_url_contains_exact_commit`, `::test_epd2_crypto_1_source_file_path_present`, `::test_epd2_crypto_1_source_sha256_present`, `::test_epd2_crypto_1_source_sha256_format`, `::test_epd2_crypto_1_parameter_digest_recomputes`, `::test_epd2_crypto_1_normative_and_corroborating_sources_distinct`, `::test_epd2_crypto_1_mutable_branch_not_authoritative` | **SATISFIED** | **Promoted from `PARTIALLY SATISFIED` on evidence, not on the blocker's removal.** All five things §10 requires are present: normative specification provenance, upstream commit, commit-pinned URL, source-file SHA-256, parameter digest — each asserted by a named offline test. Two limits remain and are not absorbed into the status: the source digest was computed on a network-enabled host and this session verified its *consistency* rather than re-fetching the bytes (`source_sha256_verification_scope` records exactly that, and one `curl \| sha256sum` closes it), and the pin makes the implementation source *checkable* without making it *normative* — parameter correctness continues to rest on the specification and on offline reconstruction | `VO-08` |
| 80 | `AM-80` | The whole cryptographic suite runs on `EPD2-CRYPTO-1`, not only on test profiles | this round | none | no profile-conditional code path exists | `test_epd2_crypto_1.py` (18 tests: encryption, proofs, challenge opening, homomorphic tally, key generation, group encoding, a 3-of-5 ceremony) | **SATISFIED** | Runtime is 28.03 s for the suite and 3.984 s for parameter validation alone. **No validation was disabled and no reduced group substituted to make anything faster** | — |
| 81 | `AM-81` | The quorum engine is generic `k`-of-`n`, with 4-of-7 as the declared high-assurance configuration | PACK-16B | none | `QuorumPolicy`, `HIGH_ASSURANCE_QUORUM = (4, 7)` | `test_guardians.py::test_4_of_7_configuration`, `::test_4_of_7_quorum_success`, `::test_3_of_7_rejected`, `::test_invalid_configurations_fail_closed` | **SATISFIED** | `2k <= n` is rejected, so two disjoint sets can never each decrypt. The engine is generic; the two *declared* configurations remain the PACK-16B ones and this round did not add a third | — |
| 82 | `AM-82` | Primary-source conformance vectors | this round | ElectionGuard 2.1 standard baseline parameters; RFC 8032 §7.1 vectors 1, 2 and 3 | `PACK-16D-CONFORMANCE-EVIDENCE.json` — 1 primary-source and 1 rfc-conformance entry; `PRIMARY_SOURCE_UNAVAILABLE` names 6 operations with a reason each | `test_conformance.py::test_primary_source_parameter_vector`, `::test_primary_source_encoding_vector`, `::test_primary_source_unavailability_is_declared_not_hidden`, `test_checkpoint_signatures.py::test_rfc_8032_published_test_vector` | **PARTIALLY SATISFIED** | **Six operations have no published external vector** — EPD2's canonical encoding, domain separation and confirmation-code alphabet are EPD2 decisions with no external counterpart, and no published Chaum–Pedersen or threshold-tally transcript with fixed randomness was located. Those six are covered by cross-implementation comparison instead (row 55). **No self-generated value was relabelled to fill a gap** | PACK-17 |
| 83 | `AM-83` | No threshold reduction and no compensated decryption | PACK-16B baseline | none | quorum read from the ceremony transcript, never from the caller; `compensated_decryption_share()` exists only to raise `CompensatedDecryptionProhibited` | `test_guardians.py::test_threshold_reduction_rejected`, `::test_compensated_decryption_unavailable`, `::test_ceremony_rejects_a_tampered_transcript` | **SATISFIED** | none | — |
| 84 | `AM-84` | No guardian secret and no hidden master key reaches any published artefact | PACK-16B `no hidden master key` | none | shares are never written to the transcript; the joint secret is never assembled by any party | `test_guardians.py::test_no_guardian_secret_leaves_the_transcript`, `::test_shares_verify_against_published_commitments` | **SATISFIED** | The test searches the transcript's canonical bytes for every share and coefficient. In-process memory custody is a separate and unsolved problem | `OD-P16D-11` |
| 85 | `AM-85` | Checkpoint signing keys may rotate under a declared, in-advance schedule | this round | none | `SignerRecord.active_from_sequence` / `active_to_sequence` / `superseded_by` | `test_checkpoint_signatures.py::test_signer_outside_its_activation_window_rejected`, `::test_signer_record_round_trips_through_canonical_bytes` | **SATISFIED** | Windows are declared in the election context, never announced by the key itself | — |
| 86 | `AM-86` | Cross-implementation conformance **core on the `EPD2-CRYPTO-1` target profile** | this round | an independent Node.js verifier (`epd2-independent-verifier-2`), separate process, `node:` builtins only | `crossimpl/independent_verifier.mjs`, `vectors/PACK-16D-TARGET-PROFILE-FIXTURES.json` (12 cases), `PACK-16D-CONFORMANCE-EVIDENCE.json` (16 `cross-implementation-target-profile` entries) | `test_target_conformance.py` — 15 tests covering all twelve core operations plus two invalid fixtures | **SATISFIED** | The twelve core operations agree on the real group. The oracle shares an author with the producer, though it was written from the written grammar; and it is not a complete ElectionGuard implementation (row 90). Six of the twelve run only here and not against any third party | rows 77, 90 |
| 87 | `AM-87` | Checkpoint signatures use a **vetted cryptographic provider**, not an implementation written here | final correction | `cryptography` 46.0.7 over OpenSSL 3.5.6; Apache-2.0/BSD-3 | `crypto/signature_provider.py` — `CheckpointSignatureProvider` Protocol, one `CryptographyEd25519Provider`, six operations, no fallback | `test_checkpoint_signatures.py::test_vetted_ed25519_provider_is_active`, `::test_missing_provider_fails_closed` (with a control run), `::test_rfc8032_vectors` | **SATISFIED** | A vetted provider materially reduces custom-implementation risk. It does **not** by itself establish side-channel assurance, certification or BSI conformity (row 63). It also adds a compiled native artefact to the runtime path | row 63, row 89 |
| 88 | `AM-88` | No hand-written cryptographic primitive remains in the active path | final correction | none | `crypto/ed25519.py` **deleted**; no module outside the provider imports `cryptography` | `test_checkpoint_signatures.py::test_handwritten_ed25519_not_imported` — `ast` over every module in `reference/` | **SATISFIED** | Structural, so a re-addition under another filename fails too. The group arithmetic, the proofs and the Merkle tree remain EPD² code — they are protocol constructions over standard-library primitives, not primitives | — |
| 89 | `AM-89` | The signature provider is a **declared and locked** dependency | final correction | none | declared as `cryptography>=46.0.7,<47` in `services/voting-service/pyproject.toml`; **resolved in `uv.lock` as `cryptography 46.0.7`** from `https://pypi.org/simple`, with `cffi 2.1.0` and `pycparser 3.0`; lock digest `b2d0775458…8066` | `tests/repository/test_pack16d_signature_dependency.py` — 9 tests, parsing `uv.lock` as TOML rather than by string search | **SATISFIED** | **Promoted from `PARTIALLY SATISFIED`.** Locked, hashed on all 43 artefacts, inside the `epd2-voting-service` dependency graph rather than as a stray root entry, with the manifest specifier echoed in `requires-dist`, and the imported library's version asserted equal to the locked one. Two limits: `uv sync --all-groups --frozen` (`Checked 61 packages`) ran on the network-enabled host and not in the build session, which still has no index — "the tests are green" and "the frozen install passes" are separate claims and are recorded separately; and locking a vetted provider is a supply-chain property, not a side-channel one (row 63) | row 63 |
| 90 | `AM-90` | Full ElectionGuard ecosystem interoperability | PACK-16A | none | none | none | **DEFERRED** | Nothing here has been checked against a complete ElectionGuard implementation in either direction. Two single-purpose oracles and a target-profile core are not that, and the distance between them is the point of rows 55 and 86 | PACK-17, `OD-P16D-02` |

## 3. Summary, computed from the rows above

Counted from the table, not asserted alongside it.

| Status | Rows | Row numbers |
| --- | --- | --- |
| `SATISFIED` | **76** | 1–27, 29–38, 40–59, 61, 62, 65, 69–74, 79, 80, 81, 83–89 |
| `PARTIALLY SATISFIED` | **6** | 28, 39, 60, 67, 75, 82 |
| `DEFERRED` | **3** | 66, 77, 90 |
| `BLOCKED` | **4** | 63, 64, 68, 76 |
| `NOT APPLICABLE` | **1** | 78 |
| **Total** | **90** | 76 + 6 + 3 + 4 + 1 = 90 |

Row count 90, requirement IDs `AM-01` … `AM-90`, unique, contiguous. Status
counts sum to the row count. No unsupported status value appears, and
`CORRECTED` appears nowhere in the `Status` column.

`AM-90` — **No row claims production readiness, external review,
certification or legal activation.** The four remaining `BLOCKED` rows each
name a party that has not acted — an external cryptographic reviewer
(row 76), the BSI `VO-08` assessment (row 68), and the constant-time and
zeroization properties Python cannot provide (rows 63, 64). Four is fewer
than the previous eight, and the difference is not leniency: three of the
four rows that left `BLOCKED` did so because the work was **done**, and the
fourth left because calling it blocked was a misclassification of this
round's own omission.

`AM-91` — **One `BLOCKED` row is a production blocker rather than a gap**:
row 63, the absence of any constant-time guarantee. It now bites in three
places rather than one — guardian secret operations, secret-nonce use and
Ed25519 private-key signing — and a deployment that ignored it would be
unsafe, not merely incomplete. Row 41's production blocker is **discharged**:
checkpoint signatures are generated and verified.

`AM-93` — **No row is unfinished any more.** Rows 79 and 89 were, for two
rounds, the only rows naming work that had been attempted and prevented by the
build environment rather than deferred or blocked on another party. Both were
classified `PARTIALLY SATISFIED` rather than `BLOCKED` precisely because no
external party was involved and each closed with a command on a machine that had
network access. Those commands were run; both rows are now `SATISFIED`. Every
remaining non-`SATISFIED` row names either an external party who has not acted
or work a round chose not to do.

`AM-94` — **Neither row was promoted because a blocker went away.** The
previous correction's defect was a status drifting ahead of its evidence, and
promoting these rows on the mere disappearance of an obstacle would be the same
error pointed the other way. Each row was promoted against the five conditions
§10 of the finalization task sets out, each condition is asserted by a named
offline test, and the two things the build session did **not** do — re-run the
frozen install, re-fetch the upstream bytes — are stated in the rows' own
residual-risk columns rather than smoothed over. A reader who wants the
strongest available check on row 79 does not have to take this matrix's word
for it: `curl -sL <pinned-url> | sha256sum` settles it in one command.

`AM-92` — **`SATISFIED` still means satisfied for a reference
implementation.** Row 79 is the sharpest case: the parameters are real,
primary-sourced and mathematically checked, and the row is still not a
statement that they are the right parameters for a binding German election.
That question is `VO-08` and it is open.

## 4. What this matrix does not decide

```text
Whether ADR-102 is accepted            → external review
Whether VO-08 can be closed            → PACK-16B review, PACK-17
Whether FIR-ROADMAP-006 is implemented → PACK-17
Whether the signer registry is the right one → the Election Board, OD-P16D-12
Production readiness of anything here  → not this round, and not by a matrix
```

**REFERENCE IMPLEMENTATION. REQUIRES EXTERNAL REVIEW. NOT PRODUCTION READY.
NOT LEGALLY ACTIVATED.**
