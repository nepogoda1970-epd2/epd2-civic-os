# PACK-16D — Schema Registry

**Round:** PACK-16D — Cryptographic Implementation Architecture, Reference
Components, Atomic Persistence, Test Vectors and Verification Harness.
**Reference implementation. Not production code. Not certified. Not a PASS.**
**Repository version:** unchanged at `0.16.0` · **Canon version:** unchanged at `0.8.0`
**ADR:** `ADR-102`, status `proposed`
**NOT PRODUCTION READY. NOT LEGALLY ACTIVATED. PUBLIC-ELECTION ACTIVATION PROHIBITED BY DEFAULT.**

---

## 1. Scope

This document describes
`services/voting-service/src/epd2_voting_service/reference/schemas.py`:
the 13 versioned schemas for artefacts that cross a trust boundary, what
the registry checks, what it deliberately does not do, and why there is no
migration machinery in it.

| ID | Symbol | Role |
| -- | ------ | ---- |
| `SR-01` | `REGISTRY_VERSION = "EPD2-SCHEMA-1"` | The registry's own version. Asserted by `test_every_required_schema_is_registered` |
| `SR-02` | `SchemaDescriptor` | Name, version, critical fields, optional fields, backward-compatible versions, pinned encoding version |
| `SR-03` | `SCHEMA_REGISTRY` | 13 descriptors, keyed by name |
| `SR-04` | `get_schema(name, version)` | Resolves a name and a version, or raises `UnknownSchemaError` |
| `SR-05` | `validate_document(name, document, version)` | Resolves, then validates the document's field names |
| `SR-06` | `SchemaError` / `UnknownSchemaError` / `UnknownCriticalFieldError` / `MissingCriticalFieldError` | The four typed errors |

## 2. The 13 schemas

Every descriptor in this round carries `version = "1.0.0"`,
`backward_compatible_with = ()` and
`encoding_version = "EPD2-ENC-1"`. `test_every_schema_is_versioned_and_pins_its_encoding`
asserts all three properties over every entry.

| ID | Schema | Critical fields | Optional fields |
| -- | ------ | --------------- | --------------- |
| `SR-07` | `parameter_set` | `parameter_set_id`, `profile_version`, `p`, `q`, `g` | `provenance`, `production_use_permitted` |
| `SR-08` | `election_context` | `election_context_id`, `manifest_digest`, `parameter_set_id`, `base_hash` | — |
| `SR-09` | `manifest` | `election_context_id`, `ballot_styles` | — |
| `SR-10` | `encrypted_ballot` | `ballot_id`, `election_context_id`, `ballot_style_id`, `parameter_set_id`, `manifest_digest`, `contests` | — |
| `SR-11` | `spoiled_ballot` | `ballot_id`, `nonces`, `plaintexts` | — |
| `SR-12` | `receipt` | `ballot_id`, `confirmation_code`, `batch_window_id`, `counted` | `publication_obligation_id` |
| `SR-13` | `batch_commitment` | `election_context_id`, `batch_sequence`, `batch_window_id`, `fixed_capacity_profile_id`, `capacity`, `commitment_root` | — |
| `SR-14` | `batch_opening` | `batch_sequence`, `leaves`, `openings` | — |
| `SR-15` | `reconciliation_record` | `accepted_cast`, `public_challenged_spoiled`, `cover`, `E`, `K`, `A` | — |
| `SR-16` | `board_entry` | `sequence`, `entry_type`, `payload` | — |
| `SR-17` | `checkpoint` | `checkpoint_sequence`, `tree_size`, `root`, `previous_checkpoint_hash`, `signature` | — |
| `SR-18` | `election_record` | `manifest`, `params`, `joint_public_key`, `base_hash`, `sealed_batches`, `batch_openings`, `accepted_ballots`, `spoiled_ballots`, `reconciliation`, `tallies` | `shares`, `ceremony`, `threshold_shares` |
| `SR-19` | `verification_result` | `code`, `exit_code`, `checks_run`, `not_checked` | `detail`, `warnings` |

| ID | Observation on the field lists |
| -- | ------------------------------ |
| `SR-20` | **`encrypted_ballot` declares no identity field of any kind** — the six critical fields are exactly the six fields of `BallotEnvelope`. There is no optional slot in which one could be added without changing this table |
| `SR-21` | **`receipt` declares `counted` as critical.** A receipt states whether the ballot is counted; it is not a proof of content and carries no plaintext field |
| `SR-22` | **`board_entry` has three fields and `payload` is opaque bytes.** The registry says nothing about what a payload contains; the pre-closure entry-type rules in `publication/bulletin_board.py` govern that, not this table |
| `SR-23` | **`verification_result` declares `not_checked` critical.** A result document that omits its non-coverage statements is not a valid verification result |
| `SR-43` | **`election_record` gained two optional fields this round: `ceremony` and `threshold_shares`.** They are optional at the registry level because a record built without a guardian ceremony still validates, not because the verifier treats them lightly — `verify_record` runs the ceremony check immediately after the joint-key subgroup check and before anything that uses the key, and the joint public key is **derived** from the ceremony roster rather than accepted standalone. Both fields are inside `ElectionRecord.canonical_bytes()`, so a record that carries them binds them into its digest |

`test_every_required_schema_is_registered` asserts that all 13 names are
present and that `REGISTRY_VERSION == "EPD2-SCHEMA-1"`.

### 2.1 The `checkpoint` schema carries two versions, and they are different things

| ID | Statement |
| -- | --------- |
| `SR-44` | **The registry descriptor `checkpoint` (`SR-17`) is at `version = "1.0.0"` like every other descriptor.** That version governs the *document field list* the registry validates, and it did not change this round |
| `SR-45` | **The signed payload's own schema version is `CHECKPOINT_SCHEMA_VERSION = "EPD2-CHECKPOINT-2"`**, declared in `publication/checkpoint_signing.py`. It is a **separate** identifier from the descriptor's version and lives inside the bytes the signature covers. `verify_checkpoint` refuses a payload whose `schema_version` is not exactly `EPD2-CHECKPOINT-2`, returning `BOARD_SIGNATURE_CONTEXT_MISMATCH` (exit 49). `test_checkpoint_signatures::test_schema_version_is_bound` pins this |
| `SR-46` | **What `EPD2-CHECKPOINT-2` binds.** `CheckpointPayload.canonical_bytes()` is a canonical binary struct — never JSON — over ten fields in declaration order: `schema_version`, `protocol_profile_id`, `election_context_id`, `board_id`, `checkpoint_sequence`, `tree_size`, `root`, `previous_checkpoint_hash`, `publication_phase` and `signing_key_id`. `signing_input()` hashes that struct under the `BOARD_CHECKPOINT` domain label, so a signature over some other EPD2 structure can never be presented as a checkpoint signature |
| `SR-47` | **What it deliberately does not bind: a public key.** `CheckpointPayload` has **no** `public_key` field, only a `signing_key_id` that must resolve inside a `SignerRegistry` supplied alongside the export. A key carried by the artefact it signs is not a trust anchor, and the absence of the field is what makes that structural rather than procedural |
| `SR-48` | **Why the `-2`.** The version number is bound into the signed payload precisely so that a signature made under one payload schema cannot be replayed as one made under another. Incrementing it is therefore a signature-compatibility break by construction, which is the same discipline `SR-28` applies to the registry: a version the verifier does not know is an error, never an attempt |

## 3. The five §50 rules, as implemented

| ID | Rule | Implementation |
| -- | ---- | -------------- |
| `SR-24` | **No silent field reinterpretation.** A field means one thing under one schema version and is never quietly re-read as something else | The registry resolves a `(name, version)` pair to exactly one descriptor with one field list. There is no coercion step, no alias table and no "if this version, read field X as field Y" branch anywhere in the module |
| `SR-25` | **An unknown critical field is rejected, never ignored.** A receiver that ignores a field it does not understand is a receiver that can be told something it will not act on | `SchemaDescriptor.validate()` computes `present - (critical ∪ optional)` and raises `UnknownCriticalFieldError` (reason code `INVALID_SCHEMA`) naming every unknown field, with the message *"an unknown field is rejected, never ignored"*. There is no "ignore the rest" mode. A missing critical field raises `MissingCriticalFieldError`, also `INVALID_SCHEMA` |
| `SR-26` | **Backward compatibility is explicit.** A consumer reads an older version only where a human declared that it may | `backward_compatible_with` is a tuple on the descriptor. `get_schema()` accepts a version only if it equals `descriptor.version` or appears in that tuple. **In this round every descriptor declares `backward_compatible_with = ()`,** so `1.0.0` is the only readable version of every schema — there is no compatibility yet to be compatible with, and none is asserted |
| `SR-27` | **The canonical encoding version is pinned.** A schema names the byte-level encoding its documents are written in | `SchemaDescriptor.encoding_version` defaults to `ENCODING_VERSION`, imported from `crypto/encoding.py`, and is `"EPD2-ENC-1"` on all 13. Pinning is per schema, so a future schema could name a different encoding without silently changing the others |
| `SR-28` | **Schema migration is never silent.** A version the registry does not know is an error, not an attempt | `get_schema()` raises `UnknownSchemaError` with the message *"migration is never silent"* for an unknown version, and for an unknown schema name. `test_migration_is_never_silent` asserts both, matching on that phrase |

### 3.1 One consequence of `SR-28` worth naming

`UnknownSchemaError.reason_code` is **`UNSUPPORTED_PROFILE`**, not
`INVALID_SCHEMA`. A version the registry cannot read therefore surfaces
under exit code 11, while a malformed document of a known version
surfaces under exit code 12. That is deliberate — the two conditions have
different remedies, one being "this consumer is too old" and the other
"this document is wrong" — but a reader mapping reason codes to exit codes
should not expect all four schema errors to share one code.

## 4. What `validate()` actually checks

The registry is a **field-name** validator. Stating its limits precisely
matters more than the mechanism does.

| ID | Statement |
| -- | --------- |
| `SR-29` | **It checks field names only.** `validate()` builds `set(document)` and compares it against the declared names. It never inspects a value |
| `SR-30` | **There is no type checking.** `{"ballot_id": 17}` passes the `receipt` schema exactly as `{"ballot_id": "b"}` does, provided the other critical names are present |
| `SR-31` | **There is no value or range checking.** A `capacity` of `-1`, a `tree_size` that decreased, an empty `commitment_root` — none of these are the registry's concern. Those properties are enforced by `CapacityPlan.validate()`, by `verify_board()` and by the batch verifier, each of which is documented elsewhere in this round |
| `SR-32` | **Field order is declared normative but is not enforced by `validate()`.** The module docstring states that field order matches the canonical encoding and that changing an order is a breaking change, not a formatting change — and that is true of the *encoding*, where `encode_struct` never sorts. `validate()` itself compares sets, so it cannot detect a reordered document. Order is enforced by `crypto/encoding.py`, not here |
| `SR-33` | **`validate()` never returns a value.** It raises or it returns `None`. There is no partial result, no warning list and no "valid except" outcome |

## 5. There is deliberately no migration machinery

| ID | Statement |
| -- | --------- |
| `SR-34` | **The module contains no upgrade function, no downgrade function, no field-mapping table and no version-negotiation step.** The whole of its version handling is the equality-or-declared-list test in `get_schema()` |
| `SR-35` | **Why.** A migration function is a place where a document written under one set of rules is rewritten to satisfy another, by code, without a human deciding that the rewrite preserves meaning. In an election system the document in question is evidence. A migration that quietly reinterprets a ballot, a batch commitment or a reconciliation record produces evidence that no longer says what its author said, and the failure is invisible because migration succeeded |
| `SR-36` | **What is offered instead.** The registry can answer exactly one question: does this document match a version someone declared readable? A schema change is then a decision with a diff — a new version, an explicit `backward_compatible_with` entry, and a review of both — rather than a code path that runs at load time |
| `SR-37` | **The cost is accepted.** Every schema change is a breaking change until someone declares otherwise, and old documents are unreadable rather than upgraded. For evidence artefacts that is the correct trade; for a general-purpose data format it would not be. This registry is only for artefacts that cross a trust boundary |

## 6. Where the registry is, and is not, wired in

This section exists because the previous ones describe a mechanism, and a
mechanism that is not called checks nothing.

| ID | Statement |
| -- | --------- |
| `SR-38` | **The registry has one production call site: `ReferenceApi.export_election_record()` validates the record against `election_record@1.0.0` before any bytes leave.** It used to have none outside its own tests, which made it a declaration rather than a check. It is still not routed through the casting, publication or verification paths: a ballot, a batch commitment or a checkpoint is not validated against its descriptor anywhere in production code. `test_verifier_branches::test_export_validates_the_record_against_its_registered_schema` pins the export path and asserts the descriptor's field set equals the record's exactly |
| `SR-39` | **`INVALID_SCHEMA` is therefore not reachable through `verify_record`.** It is declared in `test_verifier_branches.UNREACHABLE_IN_REFERENCE_VERIFIER` with the reason that it is reached by the schema registry, and is exercised by the negative-corpus cases `unknown_critical_field` and `missing_critical_field`. **`UNSUPPORTED_PROFILE` is no longer in the same position.** It used to be declared unreachable alongside `INVALID_SCHEMA` and reached only through `test_migration_is_never_silent`; `verify_record` now returns it for a parameter set with no entry in `PROFILE_BIT_LENGTHS`, before any other check, and the entry was removed from the unreachable dict. `UnknownSchemaError` still carries the same code from the registry side (`SR-06`, `SR-28`), so exit code 11 now has two producers — the registry and the verifier — and `SR-41.1` records why that is acceptable |
| `SR-49` | **Two producers, one remedy.** Both conditions mean the same thing to a caller: *this consumer cannot read what it was given*. A registry version it does not know and a parameter profile it has no declared bit lengths for are the same class of refusal, and the shared exit code says so. The verifier's message names the profile; the registry's names the schema and version |
| `SR-40` | **The `election_record` descriptor now matches the record's own field set.** It previously declared no `batch_openings` field and named `parameter_set` where the record's attribute is `params`, so a real record validated against its own descriptor would have been rejected for an unknown field — and nothing caught it, because no production path validated a record. Both were corrected, and the export test asserts `critical ∪ optional == ElectionRecord.__slots__`. **One difference remains and is not a validation failure:** `canonical_bytes()` emits the parameter set under the wire name `parameter_set` and places `batch_openings` after `spoiled_ballots`, while the descriptor lists the attribute name `params` and places `batch_openings` after `sealed_batches`. `validate()` compares sets (`SR-32`), so neither the naming nor the ordering difference is caught by it; the encoding's order is the normative one |
| `SR-41` | **All three optional fields are declared optional but are always emitted.** `canonical_bytes()` writes `shares` and `threshold_shares` as sequences unconditionally, empty when there are none, and writes `ceremony` unconditionally too — as the empty text encoding when the record carries no transcript. "Optional" in this registry means "may be absent from a document", not "may be absent from the encoding". The encoding's field order is `ceremony`, `threshold_shares`, `shares`; the descriptor's optional tuple is `shares`, `ceremony`, `threshold_shares`. That is a third ordering difference of the kind `SR-40` describes, and `validate()` compares sets so it does not see it — the encoding's order is the normative one |
| `SR-42` | **Consequence, stated plainly.** The registry in this round is an accurate statement of intent for all 13 schemas and a checked mechanism for exactly one of them — `election_record`, on the export path. Wiring the remaining twelve into the artefact paths is a PACK-17 item and is not claimed as done |

## 7. What this document does not decide

```text
Wiring the registry into the casting paths              → PACK-17, see SR-38
Reconciling `election_record` with the builder encoding → done this round, see SR-40
Type and value validation of document fields            → out of scope, see SR-30, SR-31
A second declared schema version, and its compatibility → future decision, see SR-26
Whether a checkpoint document should be registry-validated → PACK-17, see SR-38, SR-44
Wire-format re-parsing in the verifier                  → PACK-17
Cross-implementation agreement on any schema            → OD-P16D-02, unestablished
```

**REFERENCE IMPLEMENTATION. REQUIRES EXTERNAL REVIEW. NOT PRODUCTION READY.
NOT LEGALLY ACTIVATED.**
