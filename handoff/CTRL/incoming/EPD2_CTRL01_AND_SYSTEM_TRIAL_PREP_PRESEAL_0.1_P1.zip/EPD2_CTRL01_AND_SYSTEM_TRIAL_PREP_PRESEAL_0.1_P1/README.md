# EPD² CTRL-01 + SYSTEM TRIAL PREVIEW — PRESEAL PACKAGE 0.1 P1

**Self-state:** `CTRL01_IMPLEMENTATION_COMPLETE / LOCAL_VERIFICATION_PASS / PRESEAL_READY / NOT_ACCEPTED`
**Stage mode:** `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`
**System Trial Preview:** `PREPARATION_ONLY / CHECKPOINT_NOT_OPEN`

This package claims no CTRL acceptance, no CTRL closure, no production
readiness, no final security acceptance, no BSI or Common Criteria
certification and no legal activation.

## Entering baseline

- repository: `nepogoda1970-epd2/epd2-civic-os`
- branch: `main`
- commit: `cb02b231e701d0b4f12db89c86bc56a9fe11f71a`
- tree: `1ea6161335044dc4d1e50a6b1588bad6627f7af5`
- bootstrap: `PASS`

## Read first

1. `docs/ctrl/CTRL-01/CTRL-01-DEVELOPER-REPORT.md`
2. `docs/ctrl/CTRL-01/CTRL-01-SPECIFICATION.md`
3. `validation/ctrl01/ctrl01_preseal_result.json`
4. `validation/ctrl01/dependency_reconciliation.json`

## Reproducing the result

From a checkout of the canonical repository at the baseline above, with these
files applied:

```sh
uv sync --all-groups
uv run python scripts/ctrl01_registry_export.py
uv run python scripts/system_trial_preview_prepare.py
uv run pytest services/control-plane-service/tests -q
uv run python scripts/ctrl01_validator.py
```

Terminal marker: `CTRL01_RESULT:<PASS|FAIL>:<path>`; exit code 0 only when all
twenty-two mandatory gates pass.

## Open dependencies

`API-05`, `API-06`, `INFRA-02` and `OPS-02` are not accepted. Before any future
seal, re-fetch current `main`, reconcile every accepted predecessor delta, and
re-run every affected gate. See `validation/ctrl01/dependency_reconciliation.json`.
