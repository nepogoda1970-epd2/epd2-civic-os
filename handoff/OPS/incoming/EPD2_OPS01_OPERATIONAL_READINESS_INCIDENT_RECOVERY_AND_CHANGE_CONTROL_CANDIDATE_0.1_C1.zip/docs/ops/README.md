# EPD² Operations

Stage: **OPS-01 — Operational Readiness, Incident, Recovery & Change Control
Foundation**
Mode: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`

OPS-01 is the first executable operational-control layer for EPD². It is not a
folder of procedures: every control here is exercised by a canonical harness
against real processes, real sockets and a real PostgreSQL server, and every
gate is decided by a re-derivation of the property from recorded observations
rather than by a boolean the exercise set for itself.

Nothing in this directory accepts anything. The OPS layer's status in the
Program Control Register is unchanged by OPS-01, and stays so until an
independent governed verification says otherwise.

## Where things live

| Path                                      | What it is                                                                |
| ----------------------------------------- | ------------------------------------------------------------------------- |
| `ops/catalog/services.yaml`               | The service operational catalog — no service is anonymous                 |
| `ops/slo/profiles.yaml`                   | Engineering SLI/SLO profiles (not service-level agreements)               |
| `ops/telemetry/fields.yaml`               | The canonical telemetry field registry                                    |
| `ops/incident/severity.yaml`              | Deterministic severity criteria, including the mandatory SEV-1 set        |
| `ops/sod/matrix.yaml`                     | Operational roles, duties and incompatible duty pairs                     |
| `ops/recovery/classes.yaml`               | Recovery classes R0–R4 and the per-datastore recovery model               |
| `ops/disposition/operational_copies.yaml` | What happens to logs, traces, backups, exports and snapshots              |
| `ops/release/secret_scan_allowlist.yaml`  | The secret gate's declared, reasoned exceptions                           |
| `docs/ops/runbooks/`                      | OPS-RB-001 … OPS-RB-020                                                   |
| `docs/ops/OPS-01/`                        | Stage artefacts: baseline, developer report, FIR disposition, limitations |
| `packages/python/epd2-ops/`               | The executable controls                                                   |
| `scripts/validation/validate_ops01.py`    | The canonical acceptance harness                                          |
| `scripts/ops01/seal_candidate.py`         | Freeze and package the candidate                                          |

## Running the gates

```bash
make verify-ops01
```

or, equivalently, the canonical entry point on its own:

```bash
uv run python scripts/validation/validate_ops01.py
```

The harness needs a reachable PostgreSQL 16 server. It reads:

| Variable              | Default      |
| --------------------- | ------------ |
| `EPD2_OPS_PGHOST`     | `127.0.0.1`  |
| `EPD2_OPS_PGPORT`     | `5432`       |
| `EPD2_OPS_PGUSER`     | `postgres`   |
| `EPD2_OPS_PGDATABASE` | `epd2_ops01` |

There is no password variable, and that is deliberate: the exercises run against
a throwaway instance holding only generated fixture data, so the local and CI
setups both use trust authentication on loopback and no credential exists to
leak. The database is created and dropped by the harness.

If PostgreSQL is unreachable, the recovery gates **fail**. They do not skip.
A mandatory gate that can be skipped is a mandatory gate that will be.

## Evidence

Machine-readable results are written to `validation/ops01/`, which is
git-ignored on purpose: producing evidence must not change the tree the evidence
certifies. Each file records the candidate identity, the environment, the tool
version, the verdict and its own digest; `ops01_acceptance_result.json`
aggregates them and carries the digest of every other file.

The run ends with a terminal marker:

```text
OPS01_RESULT:PASS:validation/ops01/ops01_acceptance_result.json
```

## Local and CI parity

`.github/workflows/ops01-verify.yml` calls the same harness with the same
arguments. It does not re-implement a single check in YAML, so a gate cannot
pass in one place and fail in the other because two descriptions of it drifted.

## What a PASS means, and what it does not

A PASS means: the implementation is complete, local verification passed, and a
preseal candidate can be built. It does not mean OPS-01 is accepted, that the
OPS layer is closed, that anything is production-ready, or that any security or
certification claim holds. Those transitions are made elsewhere, by someone
else, against exact bytes.
