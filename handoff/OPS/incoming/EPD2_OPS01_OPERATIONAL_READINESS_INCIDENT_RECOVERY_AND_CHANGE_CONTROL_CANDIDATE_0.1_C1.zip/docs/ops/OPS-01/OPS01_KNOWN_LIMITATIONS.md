# OPS-01 — Known limitations

Stage: `OPS-01` · Mode: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`

Classification, per the stage contract:

| Class                        | Meaning                                                              |
| ---------------------------- | -------------------------------------------------------------------- |
| `BLOCKER`                    | Prevents a local PASS, or prevents the stage contract from being met |
| `NON_BLOCKING`               | Real, recorded, does not prevent the current stage's verdict         |
| `DEFERRED_BY_STAGE_BOUNDARY` | Owned by another layer or a later stage by design                    |
| `EXTERNAL_DEPENDENCY`        | Waiting on something outside this stage's control                    |
| `PRODUCTION_ONLY_VALIDATION` | Cannot be proven anywhere but a real deployment                      |

One item is a `BLOCKER`, and it is a blocker on the **final seal**, not on the
local verification: L-01. The stage contract explicitly permits development and
local verification to continue while it stands, and explicitly forbids sealing
against an unaccepted INFRA-01. It is therefore recorded as a blocker that is
excluded from the current stage verdict by the stage contract itself, which is
the only circumstance in which a blocker may coexist with a local PASS.

---

## L-01 — INFRA-01 is not accepted, so OPS-01 cannot be sealed

**Class:** `BLOCKER` (on final seal only; explicitly excluded from the local
verification verdict by the OPS-01 stage contract)
**Owner:** INFRA-01 verification

`OPS01_FINAL_SEAL = BLOCKED`. There is no authoritative accepted INFRA-01
candidate identity to bind to. OPS-01 consumed no INFRA-01 interface and did not
read the `EPD2_INFRA01_BRANCH_infra01ciacceptanceharness.bundle` present in the
repository — that is implementation lineage, not acceptance, and treating it as a
predecessor is the silent assumption the contract forbids. The reconciliation
procedure and the twelve gates to rerun are recorded in
`INFRA01_RECONCILIATION_RESULT.json`.

## L-02 — Three pre-existing defects on the entering tree

**Class:** `NON_BLOCKING`
**Owner:** the stages that own those files

Recorded in `OPS01_ENTERING_BASELINE_IDENTITY.json` as PRE-01, PRE-02, PRE-03
and reproduced here so they are not discovered as OPS-01 regressions:

1. `scripts/check_pilot_roadmap.py` produces two `RUF100` errors under the ruff
   version resolved by `uv.lock`, so a repository-wide `ruff check .` is red on
   the entering tree and remains red. OPS-01 did not repair it: editing a
   governed file outside this stage's scope to make an unrelated command green
   is precisely the kind of quiet fix that makes a lineage untrustworthy.
2. `services/voting-service/tests/reference/test_property.py::test_property_limitation_is_recorded`
   fails whenever `hypothesis` is installed, because it asserts that importing
   it raises `ImportError`. `uv sync --all-groups` installs it.
3. Running the repository-wide `pytest` **rewrites a tracked file**
   (`services/voting-service/tests/reference/vectors/PACK-16D-TARGET-PROFILE-TIMINGS.json`).
   Any same-bytes invariant taken around a full test run is therefore
   unsatisfiable on this tree. The OPS-01 freeze protocol does not invoke that
   suite; the OPS-01 test suites are confined to `tests/ops01` and
   `packages/python/epd2-ops/tests`, and the harness takes its manifest around
   itself only.

## L-03 — `uv.lock` was regenerated to add the `epd2-ops` workspace member

**Class:** `NON_BLOCKING`
**Owner:** OPS-01

Adding a workspace package necessarily changes `uv.lock`; CI verifies that
`uv sync --frozen` does not modify it further, and it does not. The diff is 18
added lines describing `epd2-ops` and its two existing dependencies
(`epd2-core`, `pyyaml`). No third-party dependency was added to the repository.

## L-04 — The secret gate scans the working set, not the git history

**Class:** `NON_BLOCKING`
**Owner:** SEC / FIR-SEC-SECRET-001

`scan_repository_secrets` covers every file that would be committed. A secret
that existed in an earlier commit and was later removed is not detected. History
scanning and public-release sanitization are FIR-SEC-SECRET-001 work owned
elsewhere.

## L-05 — Recovery is exercised against one PostgreSQL instance and a small dataset

**Class:** `PRODUCTION_ONLY_VALIDATION`
**Owner:** OPS (later stages) / INFRA

The backup–destroy–restore round trip is real: a real `pg_dump`, a real
`DROP SCHEMA CASCADE`, a real `pg_restore`, and a digest comparison of
authoritative rows, grants and audit-chain continuity. It runs on a single node
with 500 deterministic rows. The measured restore time is therefore an
environment measurement and is labelled
`PROVISIONAL_ENGINEERING_TARGET` alongside it. Nothing here demonstrates
production restore duration, cross-region retrieval, or behaviour at real data
volume.

## L-06 — Rollback is exercised against a purpose-built deployment target

**Class:** `DEFERRED_BY_STAGE_BOUNDARY`
**Owner:** INFRA-01 / OPS (later stages)

The rollback gate is genuine — real release directories, a real `current`
symlink, real OS processes, and the served identity read back over HTTP from the
process that is actually answering — but the thing being deployed is the OPS-01
health runtime, not an EPD² application service. The accepted API service
runtime is not on `main`, and OPS-01 declined to fabricate one. Exercising
rollback against the real runtime belongs to the INFRA/OPS preview-readiness
work.

## L-07 — Observability is governed, not deployed

**Class:** `DEFERRED_BY_STAGE_BOUNDARY`
**Owner:** OPS (later stages) / INFRA

There is no metrics backend, no tracing backend, no log aggregation, no alert
routing and no on-call rota. OPS-01 defines what may be emitted, proves the
emitter refuses everything else, and defines the SLI/SLO and escalation
thresholds. Whether an alert reaches a human at 03:00 is not demonstrated.

## L-08 — Voting isolation is proven at the application and telemetry layer only

**Class:** `DEFERRED_BY_STAGE_BOUNDARY`
**Owner:** INFRA / SEC (FIR-VOTE-NET-001)

```text
application-layer unlinkability != infrastructure-layer unlinkability
```

The linkage probe finds no join candidate between member-domain and voting
telemetry, and its positive control proves the probe can detect a planted one.
Client IP, TLS session metadata, reverse-proxy and CDN/WAF identifiers, request
timing and request sizes are infrastructure-layer surfaces OPS-01 does not
control and does not claim.

## L-09 — Operational copy disposition is modelled, not wired

**Class:** `DEFERRED_BY_STAGE_BOUNDARY`
**Owner:** DATA / OPS (later stages)

The policy governs all seven copy kinds and the propagation is exercised, but no
real log store, trace store, backup store or export destination is connected to
it. Legal-hold registration and release mechanics do not exist yet.

## L-10 — The decommission and incident workflows have never run against a real subject

**Class:** `NON_BLOCKING`
**Owner:** OPS (later stages)

Both are exercised end to end, including the refusals, against synthetic
subjects. Neither has retired a real service nor driven a real incident, so the
usual gap between a workflow that is correct and a workflow that is usable under
pressure is untested.

## L-11 — Provider failures are exercised against a failing local dependency

**Class:** `NON_BLOCKING`
**Owner:** OPS (later stages)

Four provider-failure paths are driven against a dependency that genuinely
fails, and the guard opens and refuses without substituting a value. They are
not driven against the actual mail, object-storage or trust providers, which
have their own failure modes (partial success, slow success, wrong success).

## L-12 — `make verify` remains red on this tree

**Class:** `NON_BLOCKING`
**Owner:** the stages that own the affected files

Because of L-02(1) and L-02(2), the repository-wide `make verify` does not pass
on the entering tree and does not pass now. `make verify-ops01` — the canonical
OPS-01 entry point — passes. The OPS-01 scope is lint-clean, format-clean,
type-clean and green: `ruff format --check`, `ruff check`, `mypy` and `pytest`
over `packages/python/epd2-ops`, `tests/ops01`, `scripts/validation` and
`scripts/ops01`.

## L-13 — Local trust authentication for PostgreSQL

**Class:** `NON_BLOCKING`
**Owner:** OPS-01

The exercises connect to a throwaway PostgreSQL instance over loopback with
trust authentication, locally and in CI. This is a deliberate choice: it means
no credential exists in the repository, in the workflow, or in any evidence
file, and the instance holds only generated fixture data. It is not a statement
about how a real deployment authenticates.
