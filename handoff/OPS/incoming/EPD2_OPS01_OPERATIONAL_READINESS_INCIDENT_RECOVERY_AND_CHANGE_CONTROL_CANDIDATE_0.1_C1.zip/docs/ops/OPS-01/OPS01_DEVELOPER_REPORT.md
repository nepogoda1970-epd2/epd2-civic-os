# OPS-01 — Developer Report

**Stage:** `OPS-01` — Operational Readiness, Incident, Recovery & Change Control
Foundation
**Mode:** `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`
**Candidate self-state:** `CANDIDATE_NOT_ACCEPTED`

---

## 1. Entering baseline

Recorded in full in `OPS01_ENTERING_BASELINE_IDENTITY.json`.

|                                     |                                                                    |
| ----------------------------------- | ------------------------------------------------------------------ |
| Repository                          | `nepogoda1970-epd2/epd2-civic-os`                                  |
| Base commit                         | `3d0b2fec5f86c491f36de1041caa66d983727480`                         |
| Base tree                           | `684a5777cee8ef608716d12514e9b7dc673048d5`                         |
| Commit subject                      | `gov(api03): close C5 and advance primary API-04`                  |
| API-02 accepted (C13)               | `9363561271f0f92d2afc42ccbb0d792cb5461c97c19a5f46a6fa51408bdfc6a9` |
| API-03 accepted (C5)                | `5fb769cd387c7bcf10b9783d05fce44066985c7408a015cb4c670419ce316b55` |
| API-04                              | ACTIVE / IN DEVELOPMENT / NOT ACCEPTED                             |
| INFRA-01                            | IMPLEMENTED / UNDER GOVERNED VERIFICATION / **NOT ACCEPTED**       |
| OPS in the Program Control Register | `NOT_STARTED` — unchanged by this stage                            |

The Program Control Register permits parallel preparation of OPS
incident/recovery/change/election runbooks and SoD models while API-04 is the
active primary API stage. That permission is what OPS-01 works under, and gate
G02 re-reads the register on every run to confirm it still says so.

Three defects were present on the entering tree **before** any OPS-01 change and
are recorded rather than repaired (PRE-01…PRE-03; see §16). The third matters
structurally: running the repository-wide `pytest` rewrites a tracked fixture
file, so any same-bytes invariant taken around a full test run is unsatisfiable
on this tree. The OPS-01 freeze protocol is scoped accordingly.

## 2. Implementation summary

OPS-01 is a working operational-control layer, not a documentation bundle. It
answers the stage's thirteen questions with mechanisms:

- **How is the system observed?** A telemetry field registry the emitter
  enforces (`ops/telemetry/fields.yaml`), with purpose, classification,
  retention, access role, allowed and prohibited contexts and a redaction rule
  per field. An undeclared field is refused.
- **How is an incident detected?** Distinct liveness / readiness / dependency
  health / degraded / unavailable probes on a real HTTP surface, plus SLI/SLO
  profiles with alert and escalation thresholds.
- **Who may act, and who may not?** A duty matrix with eight incompatible pairs,
  evaluated over every role and every actor at load time.
- **How is escalation controlled?** Deterministic severity from declared
  criteria, with a mandatory floor that cannot be argued down.
- **How is a failed service recovered? How is data restored?** A real
  backup → destroy → restore round trip with digest comparison of authoritative
  rows, permission grants and audit-chain continuity.
- **How is a bad release rolled back?** A real deployment with real processes,
  where the served identity is read back over HTTP from the process that is
  actually answering.
- **How are emergency privileges controlled?** Break-glass with an independent
  approver, a bounded scope from a closed list, automatic expiry on a monotonic
  high-water mark, and a third-party post-event review.
- **How is operational evidence preserved?** Hash-chained append-only ledgers,
  and evidence files bound to the exact tree they were produced against.
- **How is a voting incident handled without breaking isolation?** A separate,
  allow-listed voting observability profile and a linkage probe with a positive
  control.
- **How is an outage distinguished from a security incident?** Severity criteria
  and separate runbooks, with security and privacy relevance recorded explicitly
  on every incident — including when false.
- **How do we prove the runbooks work?** Twelve of the twenty are bound to a
  governed gate that exercises their path.

## 3. Files added and changed

**Added — 68 files.**

| Area                                    | Count                                       | Contents                                                                                      |
| --------------------------------------- | ------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `packages/python/epd2-ops/`             | 20 src modules + 2 test modules + packaging | 8 070 lines of control code                                                                   |
| `ops/`                                  | 8 policy files                              | 1 526 lines: catalog, SLO, telemetry, severity, SoD, recovery, disposition, secret allow-list |
| `docs/ops/runbooks/`                    | 20 runbooks                                 | 1 400 lines                                                                                   |
| `docs/ops/`                             | README + 5 stage artefacts                  | baseline, this report, FIR disposition, limitations, INFRA-01 reconciliation                  |
| `scripts/validation/`, `scripts/ops01/` | 2 scripts                                   | 1 056 lines: the harness and the sealer                                                       |
| `tests/ops01/`                          | 3 suites                                    | 897 lines with the package tests                                                              |
| `.github/workflows/`                    | 1 workflow                                  | `ops01-verify.yml`                                                                            |

**Changed — 5 files, each minimally and for a stated reason.**

| File                          | Change                                                                                                           | Why                                                                                                                  |
| ----------------------------- | ---------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| `pyproject.toml`              | `epd2-ops` added as a workspace member, dependency, ruff `src`, isort first-party, mypy path and pytest testpath | A new package has to be declared in all six places or the toolchain silently ignores it                              |
| `uv.lock`                     | 18 lines describing `epd2-ops`                                                                                   | Regenerated by `uv lock`; CI verifies `uv sync --frozen` does not modify it further. No third-party dependency added |
| `Makefile`                    | `verify-ops01`, `seal-ops01`, OPS-01 mypy groups                                                                 | One canonical command, per §37                                                                                       |
| `scripts/check_repository.py` | 41 OPS-01 required paths appended                                                                                | If a policy file is missing the harness cannot run; that belongs in the structure check, not in a late failure       |
| `.gitignore`                  | `/validation/`                                                                                                   | Producing evidence must not change the tree the evidence certifies                                                   |

No service under `services/`, no contract, no canonical document and no other
stage's artefact was modified.

## 4. Service catalog coverage

21 services discovered in the repository; 21 catalogued; 0 drift in either
direction (G05 fails on drift in **both** directions, because a catalog that
names a service which no longer exists is as misleading as one that omits a
running service).

|                                     |                                             |
| ----------------------------------- | ------------------------------------------- |
| CRITICAL / HIGH / MEDIUM            | 10 / 10 / 1                                 |
| Stateful services                   | 21                                          |
| Voting-isolated (`VOTING_ISOLATED`) | `voting-service`, `tally-service`           |
| Voting-adjacent                     | `eligibility-service`, `credential-service` |
| Declared external dependencies      | 7                                           |

Each entry carries all 21 required fields, including the two most often left
out: `expected_degraded_behaviour` in prose (the checker requires substance, not
a word) and `voting_boundary`, which decides which observability profile the
service is allowed to use at all.

## 5. FIR disposition

Full matrix in `OPS01_FIR_DISPOSITION.json`. Sixteen FIRs classified:

| Disposition               | Count |
| ------------------------- | ----- |
| `IMPLEMENTED_BY_OPS01`    | **0** |
| `PARTIALLY_ADVANCED`      | 12    |
| `DEPENDENCY_ONLY`         | 3     |
| `INTENTIONALLY_UNCHANGED` | 1     |
| Status changes requested  | **0** |

Not one FIR is claimed as implemented. This is the honest result for a
foundation stage that owns the operational half of requirements whose other
halves belong to INFRA, SEC and the trust authority — and the temptation to
promote `FIR-OPS-001` in particular, because so much of it is now real, is
exactly what the no-silent-promotion rule exists to resist.

## 6. Observability implementation

28 telemetry fields governed: 10 `OPERATIONAL`, 2 `PSEUDONYMOUS_SCOPED`, 2
`RESTRICTED`, and 14 `FORBIDDEN`. The forbidden entries are declared rather than
omitted, so the registry can name and refuse them instead of merely not knowing
about them.

The emitter is the only sanctioned path, and it fails closed four ways: an
undeclared field is refused; a `FORBIDDEN` field is refused; a field outside its
allowed context is refused; and — the one that catches the real bug — after
redaction the serialized record is scanned for the shapes secrets actually take,
and a record that still contains one is **not emitted at all**. Dropping a log
line is an inconvenience; logging a private key is a trust incident.

Four SLO profiles cover all ten required indicators, with alert and escalation
thresholds whose ordering is enforced (an alert with nothing behind it is a
dashboard) and a mandatory `known_limitation` on every indicator.

## 7. Privacy controls

Correlation identifiers are minted from a per-process, per-domain ephemeral HMAC
key over a purpose and a request nonce. The mint call **has no parameter for a
subject**, so there is nowhere to put a member identifier. The exercise mints 25
identifiers and finds 25 distinct values, confirms the same nonce yields
unrelated values in two domains, and the registry audit reports no value
spanning either requests or domains.

Health surfaces are built from a key allow-list and then scanned; a body
carrying a connection string is refused before it can be rendered.

## 8. Voting isolation controls

`VotingObservabilityProfile` is a separate type with an allow-list, not a
stricter flag on the ordinary emitter — one boolean is too short a distance
between a shared emitter and a leak. Fifteen member-domain field names are
refused by name; anything not on the ten-field allow-list is refused for being
unlisted.

The linkage probe intersects member-domain, voting-ingress and ballot event
values and reports every join candidate. It found none. Its positive control
runs first and detects a deliberately planted linkage, because "no linkage
found" and "the probe does nothing" are otherwise indistinguishable.

What this does **not** claim is stated plainly in `OPS01_KNOWN_LIMITATIONS.md`
L-08: application-layer unlinkability is not infrastructure-layer unlinkability,
and client IP, TLS metadata, proxy and CDN identifiers and request timing belong
to INFRA under FIR-VOTE-NET-001.

## 9. Incident model

Nine states with a real transition table. The exercise drives an incident from
`DETECTED` to `CLOSED` and records the refusals along the way: triage cannot be
skipped, containment requires a containment action, and closure requires a
post-incident review. The review itself requires all fourteen fields, and a
corrective action whose verification is the word "done" is refused.

Severity comes from 19 declared criteria, 8 of them mandatory SEV-1 —
key compromise, voting isolation breach, unauthorized privileged action, audit
integrity loss, authentication outage, destructive corruption, restore integrity
failure and telemetry secret leak. An incident cannot be constructed below a
mandatory floor, and cannot be argued down while the criterion holds.

Every transition, action and emergency use appends to a hash-chained ledger. The
exercise rewrites one entry and confirms the chain detects it.

## 10. Recovery and backup implementation

Against **PostgreSQL 16.13**, not a mock:

| Step                                                                               | Result                                                                            |
| ---------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| Seed 500 deterministic rows, a 64-link audit chain, two roles with distinct grants | done                                                                              |
| `pg_dump` custom format + manifest (digest, size, tool version, server version)    | done                                                                              |
| Restore a byte-modified copy of the dump                                           | **refused** on the digest mismatch                                                |
| `DROP SCHEMA ops_pilot CASCADE`, then assert emptiness                             | destroyed                                                                         |
| `pg_restore`                                                                       | completed                                                                         |
| Authoritative-row digest before vs after                                           | **equal**                                                                         |
| Permission-grant digest before vs after                                            | **equal**                                                                         |
| Audit chain continuity                                                             | **intact**                                                                        |
| Measured restore time                                                              | recorded, with environment and limitations, as a `PROVISIONAL_ENGINEERING_TARGET` |

Seven datastores are classified R0–R4. Voting and tally stores are R4 on an
isolated trust path with separate authority, and OPS-01 refuses to fold them
into the ordinary restore sequence.

## 11. Rollback and change management

Nine change states with approval separated from execution: a change without a
rollback plan is not proposable, a proposer cannot review their own change, and
an approver cannot execute it.

The rollback gate is physical. Release A (known-good) and release B (which
cannot become ready) are real directories; `current` is a real symlink; each
release runs as its own OS process. Observed:

- A deployed, `/health/identity` reads back `rel-A-known-good`, ready `true`;
- B deployed, readiness never reached within the deadline, **promotion refused**,
  and `/health/identity` read back `rel-B-candidate` from the failing process
  before it was stopped — so the refusal is attributable rather than assumed;
- rollback to A, `/health/identity` reads back `rel-A-known-good`, ready `true`,
  and `current` points at A.

## 12. Separation of duties and break-glass

16 roles, 12 duties, 8 incompatible pairs. Every duty is held by at least one
role (a model describing work nobody can do is not a model), and no role — and
no exercised actor — unions an incompatible pair. All six forbidden unions the
stage names were attempted and refused.

Break-glass: six scopes are refused **by name** (`BALLOT_CONTENT_READ`,
`VOTING_CRYPTO_BYPASS`, `VOTING_ISOLATION_BYPASS`, `AUDIT_LOG_REWRITE`,
`EVIDENCE_DELETION`, `PERMANENT_ROLE_GRANT`), self-approval does not exist as an
operation, duration is capped at four hours, an activated grant whose expiry is
removed is revoked on sight, and the post-event review may not be performed by
the requester or the approver.

The expiry proof is the one worth reading: the grant expires at +31 minutes,
then the wall clock is moved to **six hours before the grant was issued**, and
the grant stays expired, because expiry is evaluated against a monotonic
high-water mark. The clock state becomes `UNTRUSTED` and no new authority can be
granted while it is.

## 13. Failure injection

| Injection                       | How                                                            | Where    |
| ------------------------------- | -------------------------------------------------------------- | -------- |
| Process kill                    | `SIGKILL` on a live listener, then observe liveness gone       | G06      |
| Mandatory dependency loss       | real TCP probe against a closed port                           | G07      |
| Bad configuration               | 10 cases; none opens a socket; exit 78 / 69                    | G07      |
| Provider failure                | 4 providers, guard opens, no fabricated success                | G24      |
| Overload                        | 500 offers into a 64-deep queue; 337 shed explicitly           | G25      |
| Clock rollback and forward jump | steppable clock; expiry re-checked across both                 | G26      |
| Backup destruction              | real `DROP SCHEMA CASCADE`                                     | G20      |
| Restore from tampered bytes     | digest mismatch, refused                                       | G20      |
| Deployment failure              | real process that never becomes ready                          | G22, G23 |
| Forbidden telemetry             | 14 injections including a smuggled DSN and an undeclared field | G10      |

## 14. Mutation suite

**26 mutations, 26 rejected, 0 accepted**, across 19 gates. They attack three
surfaces, and the third is the important one: as well as mutating the policy
files and the behavioural controls, several mutations feed crafted result
documents to the gate assertion functions the harness actually uses to decide a
verdict — a fake successful backup, a restore claiming a match while its digests
differ, a rollback with no observed identity, a promoted release that never
became ready, a provider failure reported as success. A verifier that has never
been attacked is a verifier with no reason to be trusted.

Two mutations were found by the gates during development rather than by
inspection, and both were real: the self-acceptance detector flagged its own
vocabulary, and the secret scanner flagged its own patterns. Both were fixed by
assembling the literals from fragments so the detector no longer contains what
it hunts for — not by adding an exemption.

## 15. Test results

| Suite                                   | Result                                       |
| --------------------------------------- | -------------------------------------------- |
| `packages/python/epd2-ops/tests`        | 33 passed                                    |
| `tests/ops01`                           | 55 passed                                    |
| **Total**                               | **88 passed, 0 failed, 0 skipped**           |
| `ruff format --check` (OPS-01 scope)    | 32 files clean                               |
| `ruff check` (OPS-01 scope)             | clean                                        |
| `mypy` (src, scripts, both test suites) | clean under the repository's strict settings |
| `scripts/check_repository.py`           | all 1 023 required paths present             |
| `scripts/check_forbidden_files.py`      | no forbidden paths                           |
| Canonical harness                       | **32 / 32 gates PASS**                       |

No mandatory gate reports `SKIPPED`, `ENVIRONMENT_BLOCKED`, `NOT_RUN` or
`MANUAL_ASSUME_PASS`; those lists are emitted empty in
`ops01_acceptance_result.json` so their emptiness is itself evidence.

## 16. Known limitations

Thirteen recorded in `OPS01_KNOWN_LIMITATIONS.md`. The one blocker is L-01
(INFRA-01 not accepted, so the final seal is blocked), and it is excluded from
the local verification verdict by the stage contract itself — the only
circumstance in which a blocker may coexist with a local PASS.

The three pre-existing entering-tree defects (L-02) are reproduced there in
full. They are recorded, not repaired: editing a governed file outside this
stage's scope to make an unrelated command green is the kind of quiet fix that
makes a lineage untrustworthy.

## 17. Dependency reconciliation

**INFRA-01** — `OPS01_FINAL_SEAL = BLOCKED`. Full record in
`INFRA01_RECONCILIATION_RESULT.json`, including the three INFRA-01 interfaces
OPS-01 deliberately did **not** consume and why, and the twelve gates to rerun
once an accepted identity exists. The
`EPD2_INFRA01_BRANCH_infra01ciacceptanceharness.bundle` present in the
repository was neither read nor imported: it is implementation lineage, and
treating it as an accepted predecessor is precisely the silent assumption the
stage contract forbids.

**API** — OPS-01 consumes no unaccepted API interface. Because the operational
catalog is reconciled against the repository's live service topology at gate
time, a service added by a later API stage surfaces as a catalog gap rather than
being quietly absent. At final reconciliation the accepted API baseline actually
consumed must be named, new services must appear with telemetry and SLO
coverage, and the affected failure and recovery gates must be rerun.

## 18. Exact candidate identity

Produced by `scripts/ops01/seal_candidate.py`, which refuses a dirty tree,
re-runs the canonical harness as a child process, and refuses to package if the
tree changed while it ran. The identity — filename, byte size, SHA-256, member
count, tree digest, base commit and tree, creation timestamp — is written to
`OPS01_CANDIDATE_IDENTITY.json` beside the archive and must be fixed before any
external acceptance.

The archive contains `CANDIDATE_NOT_ACCEPTED`, `OPS01_FREEZE_MANIFEST.json` and
`OPS01_CANDIDATE_SELF_STATE.json` in addition to the frozen tree. Every member is
verified against the manifest after packaging.

## 19. Local verdict

```text
OPS01_RESULT:
IMPLEMENTATION_COMPLETE
LOCAL_VERIFICATION_PASS
PRESEAL_READY
NOT_ACCEPTED
```

## 20. Explicit non-acceptance

This stage is **not accepted**. The OPS layer is **not closed**. Nothing here is
production-ready, security-certified, BSI- or Common-Criteria-certified, or
legally activated. The candidate does not accept itself, and gate G02 scans every
OPS-01 artefact for a self-acceptance claim on every run — including this
document.

Only an independent governed verification, receiving the exact candidate bytes,
may move OPS-01 from `PRESEAL / NOT ACCEPTED` to `ACCEPTED`. Even then,
`OPS-01 ACCEPTED` would not mean the OPS layer is closed: the Program Control
Register orders OPS runtime closure after INFRA, and no developer or workflow
may invent that transition.
