# EPD² Operations

Stages: **OPS-01 — Operational Readiness, Incident, Recovery & Change Control
Foundation** (accepted at C2) and **OPS-02 — Preview Operations, Deployment,
Observability & Recovery Readiness**
Mode: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`

OPS-01 is the first executable operational-control layer for EPD². OPS-02 builds
a deployable preview environment on top of it. Neither is a folder of procedures:
every control here is exercised by a canonical harness against real processes,
real sockets and a real PostgreSQL server, and every gate is decided by a
re-derivation of the property from recorded observations rather than by a boolean
the exercise set for itself.

Nothing in this directory accepts anything. OPS-01 is accepted and closed at its
exact C2 bytes by an authoritative run recorded in the Program Control Register;
the OPS layer itself remains open, and OPS-02 does not change that, does not open
the System Trial Preview and does not accept itself.

## Where things live

| Path                                      | What it is                                                                                              |
| ----------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| `ops/catalog/services.yaml`               | The service operational catalog — no service is anonymous                                               |
| `ops/slo/profiles.yaml`                   | Engineering SLI/SLO profiles (not service-level agreements)                                             |
| `ops/telemetry/fields.yaml`               | The canonical telemetry field registry                                                                  |
| `ops/incident/severity.yaml`              | Deterministic severity criteria, including the mandatory SEV-1 set                                      |
| `ops/sod/matrix.yaml`                     | Operational roles, duties and incompatible duty pairs                                                   |
| `ops/recovery/classes.yaml`               | Recovery classes R0–R4 and the per-datastore recovery model                                             |
| `ops/disposition/operational_copies.yaml` | What happens to logs, traces, backups, exports and snapshots                                            |
| `ops/release/secret_scan_allowlist.yaml`  | The secret gate's declared, reasoned exceptions                                                         |
| `docs/ops/runbooks/`                      | OPS-RB-001 … OPS-RB-020                                                                                 |
| `docs/ops/OPS-01/`                        | Stage artefacts: baseline, developer report, FIR disposition, limitations                               |
| `packages/python/epd2-ops/`               | The executable controls                                                                                 |
| `scripts/validation/validate_ops01.py`    | The canonical acceptance harness                                                                        |
| `scripts/ops01/seal_candidate.py`         | Freeze and package the candidate                                                                        |
| `ops/preview/`                            | OPS-02 preview data: config profiles, secret declarations, SLOs, telemetry fields, migrations           |
| `docs/ops/OPS-02/`                        | OPS-02 stage artefacts: baseline, OPS-01 reconciliation, developer report, FIR disposition, limitations |
| `packages/python/epd2-preview/`           | The executable preview-environment controls                                                             |
| `scripts/validation/validate_ops02.py`    | The canonical OPS-02 harness (42 gates)                                                                 |
| `scripts/ops02/seal_candidate.py`         | Freeze and package the OPS-02 candidate                                                                 |

## Running the gates

```bash
make verify-ops01   # 32 gates
make verify-ops02   # 42 gates
```

or, equivalently, the canonical entry points on their own:

```bash
uv run python scripts/validation/validate_ops01.py
uv run python scripts/validation/validate_ops02.py
```

Both harnesses need a reachable PostgreSQL 16 server; OPS-02 was verified
against 16.15 exactly, matching the accepted OPS-01 C2 authoritative
environment. They read:

| Variable              | Default                                       |
| --------------------- | --------------------------------------------- |
| `EPD2_OPS_PGHOST`     | `127.0.0.1`                                   |
| `EPD2_OPS_PGPORT`     | `5432`                                        |
| `EPD2_OPS_PGUSER`     | `postgres`                                    |
| `EPD2_OPS_PGDATABASE` | `epd2_ops01` (OPS-01) / `epd2_ops02` (OPS-02) |

There is no password variable, and that is deliberate: the exercises run against
a throwaway instance holding only generated fixture data, so the local and CI
setups both use trust authentication on loopback and no credential exists to
leak. The database is created and dropped by the harness.

If PostgreSQL is unreachable, the recovery gates **fail**. They do not skip.
A mandatory gate that can be skipped is a mandatory gate that will be. Where an
external dependency genuinely prevents execution, OPS-02 records `BLOCKED`; a run
containing one cannot reach a `PASS` verdict.

## Evidence

Machine-readable results are written to `validation/ops01/` and
`validation/ops02/`, which are git-ignored on purpose: producing evidence must not change the tree the evidence
certifies. Each file records the candidate identity, the environment, the tool
version, the verdict and its own digest; `ops01_acceptance_result.json` and
`ops02_acceptance_result.json` aggregate them and carry the digest of every other
file in their own directory.

The run ends with a terminal marker:

```text
OPS01_RESULT:PASS:validation/ops01/ops01_acceptance_result.json
OPS02_RESULT:PASS:validation/ops02/ops02_acceptance_result.json
```

The OPS-02 harness refuses a `PASS` verdict unless executed equals total, passed
equals total, and every one of `failed`, `missing`, `skipped`,
`environment_blocked`, `not_run` and `manual_assume_pass` is empty.

## Local and CI parity

`.github/workflows/ops01-verify.yml` and `.github/workflows/ops02-verify.yml`
call the same harnesses with the same arguments. Neither re-implements a single
check in YAML, so a gate cannot pass in one place and fail in the other because
two descriptions of it drifted.

## What a PASS means, and what it does not

A PASS means: the implementation is complete, local verification passed, and a
preseal candidate can be built. It does not mean the stage is accepted, that the
OPS layer is closed, that the System Trial Preview is open or openable, that
anything is production-ready, or that any security, BSI, Common Criteria or EAL4
claim holds. Those transitions are made elsewhere, by someone else, against exact
bytes.

OPS-01 is accepted and closed at its exact C2 bytes. The OPS layer remains open.
OPS-02 is a parallel working stage and accepts nothing, including itself.
