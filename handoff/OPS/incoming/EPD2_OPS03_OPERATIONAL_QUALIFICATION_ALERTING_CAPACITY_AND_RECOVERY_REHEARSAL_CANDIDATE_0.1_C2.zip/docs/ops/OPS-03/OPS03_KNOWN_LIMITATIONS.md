# OPS-03 C2 Known Limitations

C2 resolves the former G05 governance blocker by binding qualification to exact independently accepted API-06 C1.

Remaining non-claims are intentional:

- OPS-03 does not accept itself.
- OPS layer closure requires a later governance decision.
- System Trial Preview requires a separate checkpoint-opening decision.
- Capacity/RTO/RPO measurements are qualification evidence, not production commitments.
- No BSI, Common Criteria, EAL4, legal-activation, or final-security claim is made.

Local container note: the ChatGPT artifact-build container used for this corrective reseal does not provide the PostgreSQL 16 client/server toolchain. The canonical GitHub workflow does provide PostgreSQL 16.15 and remains the required environment for the full 50-gate runtime replay. This is an environment limitation of the artifact builder, not a declared OPS-03 stage blocker.
