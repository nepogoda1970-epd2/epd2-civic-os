---
runbook_id: OPS-RB-017
title: Provider / External Dependency Failure
owner: role:platform-operations
exercised_by: G24
---

# OPS-RB-017 — Provider / External Dependency Failure

## Trigger

An external dependency in the catalog fails: mail, object storage, the identity
trust provider, the message queue, a database, or DNS resolution.

## Preconditions

The dependency's declared failure behaviour is in
`ops/catalog/services.yaml` under `external_dependencies`.

## Required authority

`DIAGNOSTIC_ACCESS`; `CHANGE_EXECUTION` to shed or reroute.

## Forbidden authority

No fabricated success. A send that failed is not recorded as sent, an upload
that failed is not recorded as stored, and a verification that could not be
performed is not recorded as verified. No hard-coded fallback endpoint when
resolution fails.

## Steps

1. Confirm the failure is the provider's and not the network path or the
   credential (a credential failure is OPS-RB-006).
2. Confirm the dependency guard has opened and is refusing fast rather than
   queueing. Fast refusal is correct behaviour.
3. Confirm retries are bounded and jittered; measure total downstream attempts,
   not per-caller attempts.
4. Confirm the system's observable state matches reality: nothing is marked
   complete that the provider did not complete.
5. Apply the declared failure behaviour — shed, queue within bounds, or refuse —
   and confirm it matches the catalog rather than improvising.
6. On recovery, let the guard half-open and probe; do not force it closed.

## Verification

The guard state transitions are recorded; total attempts are within the retry
budget; no operation is marked successful that the provider did not perform.

## Rollback

Any temporary reroute is reverted once the provider recovers, under a change
record.

## Evidence generated

`validation/ops01/dependency_failure_result.json` with guard state, attempt
records and the fabricated-success check.

## Exit criteria

Provider healthy or the declared degraded behaviour is stable and correct, with
no fabricated success anywhere in the record.

## Escalation

A CRITICAL external dependency down beyond its escalation threshold goes to the
service owner; the identity trust provider additionally goes to the trust
authority.
