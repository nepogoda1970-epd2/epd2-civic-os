---
runbook_id: OPS-RB-009
title: Break-Glass Closure & Review
owner: role:security-reviewer
exercised_by: G18
---

# OPS-RB-009 — Break-Glass Closure & Review

## Trigger

A break-glass grant expired, was revoked, or its work is complete.

## Preconditions

The grant ledger is available and verifies. The reviewer is neither the
requester nor the approver.

## Required authority

`SECURITY_REVIEW`.

## Forbidden authority

The requester and the approver may not close the grant. `SECRET_KEY_ACCESS` and
`SECURITY_REVIEW` are incompatible duties, so the key custodian does not review
emergency key use either.

## Steps

1. Confirm the grant is no longer active. An expired grant confers nothing; an
   active grant with no expiry is revoked on sight rather than trusted.
2. Read every recorded use and confirm each was inside the granted scope.
3. Confirm no permanent role assignment appeared as a side effect: compare
   effective privileges before and after.
4. Confirm the clock: if an anomaly was recorded during the grant window,
   re-derive expiry against the authority high-water mark rather than the wall
   reading.
5. Record whether the emergency was avoidable, and what standing control would
   have made it unnecessary.
6. Close the grant with a review reference.

## Verification

Grant state is `CLOSED` with a review reference by a third actor. Effective
privileges after closure equal those before activation. The ledger verifies.

## Rollback

None. A review is not reversible; a disputed finding is recorded alongside, not
overwritten.

## Evidence generated

`validation/ops01/break_glass_result.json` including the expiry proof and the
privilege comparison.

## Exit criteria

Closed, reviewed by a third actor, no residual privilege, and a corrective
action recorded if the emergency was avoidable.

## Escalation

Any use outside scope, any missing expiry, or any residual privilege is
`SEV1-UNAUTHORIZED-PRIVILEGED-ACTION`.
