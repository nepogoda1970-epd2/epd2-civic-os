---
runbook_id: OPS-RB-019
title: Disaster Recovery
owner: role:restore-approver
exercised_by: G21
---

# OPS-RB-019 — Disaster Recovery

## Trigger

Loss of an environment, a datastore cluster, or enough of the platform that
individual service recovery is not the right unit of work.

## Preconditions

Backups and their manifests are reachable from outside the lost environment.
The dependency ordering in `ops/recovery/classes.yaml` is available.

## Required authority

`RESTORE_APPROVAL` and `RESTORE_EXECUTION`, held by different actors.
Voting-isolated stores (R4) require voting authority and are recovered on their
own path.

## Forbidden authority

Ordinary restore authority does not extend to the voting path. No restore is
promoted before its integrity comparison passes. No environment is declared
recovered on the basis of processes being up.

## Steps

1. Declare the disaster and establish a single incident record for it.
2. Rebuild R0 and R1 components from source; they are not restored.
3. Restore R2 and R3 stores in the declared dependency order, audit store first
   or alongside, following OPS-RB-004 for each.
4. For each store, compare the authoritative digest, the grant digest and the
   audit chain before promoting it.
5. Recover R4 voting stores separately, under voting authority, with their own
   verification. Do not fold them into the general sequence.
6. Bring services up in dependency order and confirm readiness from each
   service's own endpoint.
7. Measure and record elapsed time per store and for the whole environment
   against the provisional targets.
8. Reconcile: state the data-loss boundary actually incurred, per store.

## Verification

Every restored store passed its comparison before promotion; every service
reports ready; the measured timings are recorded with environment and
limitations; the incurred data-loss boundary is stated per store.

## Rollback

A store that fails comparison is not promoted; the environment stays partially
recovered rather than wholly wrong.

## Evidence generated

`validation/ops01/backup_restore_result.json` per store; the measured recovery
objectives; the disaster incident ledger.

## Exit criteria

All stores restored and verified, services ready, timings and data-loss
boundaries recorded, and a post-incident review opened under OPS-RB-020.

## Escalation

Any store that cannot be restored, or whose comparison fails twice, escalates to
the service owner and `role:security-reviewer` before further attempts.
