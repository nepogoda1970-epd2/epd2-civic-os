---
runbook_id: OPS-RB-010
title: Capacity / Overload
owner: role:platform-operations
exercised_by: G25
---

# OPS-RB-010 — Capacity / Overload

## Trigger

Queue age or depth crosses its escalation threshold; latency rises with error
rate; connection pools are exhausted; workers are starved.

## Preconditions

The affected service's SLO profile and declared degraded behaviour are known.

## Required authority

`DIAGNOSTIC_ACCESS`; `CHANGE_EXECUTION` for shedding and limit changes.

## Forbidden authority

No raising of a queue bound to "let it catch up" without a change record — an
unbounded queue converts overload into memory exhaustion and then into an
outage with worse telemetry. No disabling of retry limits.

## Steps

1. Identify the saturated resource: queue, connection pool, worker slots,
   downstream dependency.
2. Confirm shedding is explicit. Work refused with a reason class is correct
   behaviour; work silently dropped is a defect.
3. Check for a retry storm: compare total downstream attempts with distinct
   requests. Bounded per-caller retries still amplify in aggregate.
4. Shed deliberately at the ingress rather than letting the backlog grow.
5. If a dependency is the constraint, follow OPS-RB-017.
6. Only then consider capacity changes, as a recorded change.

## Verification

Observed queue depth stays at or below its declared capacity; shed counts are
non-zero and attributed to a reason; memory does not grow monotonically; total
downstream attempts stay within the retry budget.

## Rollback

Temporary limit increases are reverted once the backlog clears; they are changes
and are closed like changes.

## Evidence generated

`validation/ops01/overload_result.json` with offered, accepted, shed, shed
reasons and maximum observed depth.

## Exit criteria

Backlog age is inside its objective, shedding has stopped, no limit was left
raised without a change record.

## Escalation

Repeated overload at the same point is a capacity finding, not an incident to
re-run: raise it to the service owner with the measured numbers.
