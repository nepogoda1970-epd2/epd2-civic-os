---
runbook_id: OPS-RB-005
title: Failed Deployment & Rollback
owner: role:release-engineer
exercised_by: G22
---

# OPS-RB-005 — Failed Deployment & Rollback

## Trigger

A candidate release fails to reach readiness within its deadline, or a
post-deployment verification fails.

## Preconditions

The previous known-good release is identifiable and still deployable. The change
record exists with a rollback plan — a change without one is not approvable, so
its absence is itself the finding.

## Required authority

`CHANGE_EXECUTION` to deploy and to roll back. `CHANGE_APPROVAL` from a
different actor for the original change.

## Forbidden authority

The approver of a change may not execute it. Rollback does not require a new
approval — the rollback plan was approved with the change — but it does require
a recorded execution.

## Steps

1. Confirm the failure by observing the running process, not the deployer's
   intent: read the release identity and readiness from the serving endpoint.
2. Do not promote. A release that has not become ready is not promoted to
   `current` under any circumstance.
3. Stop the candidate.
4. Redeploy the known-good release.
5. Read the release identity back from the running process and confirm it is the
   known-good one and that it reports ready.
6. Transition the change to `ROLLED_BACK` with the reason recorded.

## Verification

`/health/identity` reports the known-good release; `/health/ready` reports
ready; the deployment ledger shows promotion refused for the candidate and
restoration of the known-good release.

## Rollback

This runbook is the rollback. If the known-good release also fails to become
ready, the fault is not in the candidate: escalate to OPS-RB-002 or OPS-RB-003
before deploying anything further.

## Evidence generated

`validation/ops01/rollback_result.json` and the deployment ledger.

## Exit criteria

The observed serving identity is the known-good release, readiness is sustained,
and the change record states what failed and what was restored.

## Escalation

A second failed rollback, or any rollback during an election window, escalates
to `role:incident-commander` and the service owner immediately.
