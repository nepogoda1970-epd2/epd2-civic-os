---
runbook_id: OPS-RB-011
title: Queue / Worker Failure
owner: role:platform-operations
exercised_by: G25
---

# OPS-RB-011 — Queue / Worker Failure

## Trigger

Consumers stop making progress; the oldest unprocessed item ages past its
threshold; jobs fail repeatedly; or the queue broker is unavailable.

## Preconditions

The queue and its owning service are in the operational catalog. Idempotency
expectations for the job class are known.

## Required authority

`DIAGNOSTIC_ACCESS`; `CHANGE_EXECUTION` to restart consumers or drain.

## Forbidden authority

No inspection of message payloads that carry domain content. No replay of jobs
whose handler is not idempotent. Draining a queue is a destructive act and needs
a change record, not an on-call decision.

## Steps

1. Distinguish broker unavailable, consumers dead, consumers alive but stuck,
   and poison message.
2. If consumers are dead, restart and confirm progress resumes by falling
   backlog age, not by process count.
3. If a poison message is blocking, move it aside with its identifier recorded;
   do not delete it.
4. If the broker is down, confirm producers are shedding explicitly rather than
   buffering without durability, then follow OPS-RB-017.
5. Before any replay, confirm idempotency for that job class. Where it does not
   hold, the work is not replayed.

## Verification

Backlog age falls; job completion recovers; no job was processed twice where
idempotency does not hold; any set-aside message is recorded.

## Rollback

Set-aside messages are restored to the queue once the handler defect is fixed,
under a change record.

## Evidence generated

Queue depth and age snapshots on the incident ledger;
`validation/ops01/overload_result.json` where shedding occurred.

## Exit criteria

Consumers are progressing, the backlog is inside its objective, and no
non-idempotent replay occurred.

## Escalation

Suspected duplicate processing of a member-visible action escalates to the
service owner immediately.
