---
runbook_id: OPS-RB-020
title: Post-Incident Review
owner: role:incident-commander
exercised_by: G15
---

# OPS-RB-020 — Post-Incident Review

## Trigger

An incident reached `RESOLVED`. Every incident gets a review; SEV-1 and SEV-2
reviews are written, SEV-3 and SEV-4 may be brief, but none is skipped.

## Preconditions

The incident ledger verifies. Participants are available. The review is
blame-neutral and evidence-driven: what the system allowed, not who typed what.

## Required authority

`INCIDENT_DECLARATION` to run the review; `SECURITY_REVIEW` for any incident
with security or privacy relevance.

## Forbidden authority

No editing of the incident record to make the timeline tidier. Corrective
actions may not be closed by writing "done" — the model refuses it — and a
corrective action without an owner and a deadline is not a corrective action.

## Steps

1. Reconstruct the timeline from the ledger, marking any segment that crosses a
   recorded clock anomaly as wall-reading only.
2. State impact in member terms, not in service terms.
3. Separate detection from cause: how long until anyone knew, and what would
   have shortened that.
4. Identify root cause and contributing factors. Where several conditions had to
   coincide, say so rather than choosing one.
5. Record containment and recovery as they happened, including what was tried
   and did not work.
6. Record what worked. A review that only lists failures teaches nothing about
   what to keep.
7. Identify control gaps — the controls that should have prevented, detected or
   bounded this and did not.
8. Write corrective actions, each with an owner, a deadline and a statement of
   how completion will be verified.
9. Move the incident to `CLOSED` only once the review is recorded.

## Verification

All fourteen required review fields are present and non-empty; every corrective
action has an owner, a deadline and a verification statement; the incident
cannot be closed without the review reference.

## Rollback

None. A review is amended by appending, never by rewriting.

## Evidence generated

The post-incident review document, referenced from the incident record;
`validation/ops01/incident_simulation_result.json` for the exercised path.

## Exit criteria

Review complete, corrective actions owned and dated with verification stated,
incident `CLOSED`.

## Escalation

A corrective action that misses its deadline is raised to the service owner. A
control gap that recurs across reviews is raised as a systemic finding rather
than re-recorded per incident.
