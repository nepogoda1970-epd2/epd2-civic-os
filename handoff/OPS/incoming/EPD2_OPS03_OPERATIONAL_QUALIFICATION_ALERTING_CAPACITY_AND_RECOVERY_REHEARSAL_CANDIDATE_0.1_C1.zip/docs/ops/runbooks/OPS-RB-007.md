---
runbook_id: OPS-RB-007
title: Certificate / Trust Failure
owner: role:trust-authority
exercised_by: G27
---

# OPS-RB-007 — Certificate / Trust Failure

## Trigger

A certificate expired or is about to; a chain fails validation; a trust anchor
is withdrawn; or mutual TLS between services begins failing.

## Preconditions

The affected trust relationships are identified from the operational catalog's
`secret_classes_used` and dependency edges.

## Required authority

`SECRET_KEY_ACCESS` for replacement material. Revocation and any change to the
accepted trust set belong to the trust authority (FIR-TRUST-002/003).

## Forbidden authority

No disabling of certificate validation to restore availability. "Turn off
verification until we fix it" converts a trust failure into a trust compromise
and is refused. No ordinary break-glass scope grants this.

## Steps

1. Determine whether the failure is expiry, misissuance, chain incompleteness or
   revocation. Only the first is a routine operational event.
2. For expiry: replace the certificate, restart or reload the workloads, and
   confirm the chain validates end to end.
3. For anything else: contain first. Stop the affected path rather than relaxing
   validation.
4. Confirm the trust set is unchanged, or route the change to the trust
   authority with the evidence for it.
5. Record which artefacts and sessions were established under the failed
   material.

## Verification

Chain validation succeeds from a clean client. No validation setting was
relaxed. The trust set matches the governed record.

## Rollback

Replacement material that fails validation is withdrawn and the previous state
restored only if it is still valid; an expired certificate is never reinstated.

## Evidence generated

`validation/ops01/secret_incident_result.json`; the trust-set comparison.

## Exit criteria

Validation succeeds, no verification control was weakened, and the trust set is
in the governed state.

## Escalation

Suspected misissuance or a compromised anchor is SEV-1 and escalates to the
trust authority and `role:security-reviewer` before any replacement is deployed.
