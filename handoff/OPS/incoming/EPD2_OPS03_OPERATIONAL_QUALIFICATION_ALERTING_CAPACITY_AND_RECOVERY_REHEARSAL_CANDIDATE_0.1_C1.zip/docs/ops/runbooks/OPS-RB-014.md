---
runbook_id: OPS-RB-014
title: Privacy / Telemetry Leakage Incident
owner: role:security-reviewer
exercised_by: G10
---

# OPS-RB-014 — Privacy / Telemetry Leakage Incident

## Trigger

A forbidden value is found in logs, metrics, traces, a debug bundle or an
export: a credential, a token, a key, a member identifier, a message or document
body, protected identity evidence, detailed finance data, or anything
ballot-shaped.

## Preconditions

The telemetry field registry is available. The emitting service and the field
are identified.

## Required authority

`SECURITY_REVIEW`; `DIAGNOSTIC_ACCESS` to locate the emission.

## Forbidden authority

Investigating a leak does not authorize reading the leaked content beyond what
is needed to classify it. No copying of the leaked values into an incident
record — reference the location, never the value.

## Steps

1. Classify what leaked, using the registry's classification, and set severity.
   Credentials, keys and protected content are `SEV1-TELEMETRY-SECRET-LEAK`.
2. Stop the emission at the source. The emitter refuses undeclared fields, so a
   leak means either a declared field carried an unexpected value or an emission
   path bypassed the emitter — establish which.
3. Determine reach: which sinks, which retentions, which copies
   (`ops/disposition/operational_copies.yaml`).
4. Purge the copies within their propagation rules; debug bundles and exports go
   first because they have the widest access.
5. If credentials or keys leaked, open OPS-RB-006 immediately — exposure in a
   log is exposure.
6. Add the missed value shape to the redaction patterns and prove the addition
   with a test that fails without it.

## Verification

The forbidden value no longer appears in any sink; the leak scan is re-run and
returns nothing; a regression test exists for the specific shape.

## Rollback

None. A leak cannot be un-emitted; the response is containment and rotation.

## Evidence generated

`validation/ops01/telemetry_redaction_result.json`; the purge record per sink.

## Exit criteria

Emission stopped, copies purged, credentials rotated if involved, and a
regression test added.

## Escalation

Any voting-domain or ballot-shaped value escalates to OPS-RB-016 as well, and
is treated as a suspected isolation breach until shown otherwise.
