---
runbook_id: OPS-RB-012
title: Clock / Time Anomaly
owner: role:platform-operations
exercised_by: G26
---

# OPS-RB-012 — Clock / Time Anomaly

## Trigger

`CLOCK_ROLLBACK` or `CLOCK_FORWARD_JUMP` is recorded by the authoritative clock;
time synchronization is lost; or event chronology stops making sense.

## Preconditions

The authoritative-time state (`TRUSTED`, `DEGRADED`, `UNTRUSTED`) is readable.

## Required authority

`DIAGNOSTIC_ACCESS`; `CHANGE_EXECUTION` to correct synchronization.

## Forbidden authority

Nobody may move a host clock to make an expired authority usable again. The
model does not permit it — expiry is evaluated on a monotonic high-water mark —
and attempting it is `SEV1-UNAUTHORIZED-PRIVILEGED-ACTION`.

## Steps

1. Read the anomaly record: kind, observed reading, previous high-water mark,
   delta.
2. In `UNTRUSTED`, no new authority is granted. Break-glass requests are refused
   until trusted time returns. This is the intended behaviour, not an outage to
   work around.
3. Re-establish synchronization from the authoritative source.
4. Re-derive every expiry decision taken during the anomaly window against the
   high-water mark, not the wall reading.
5. Confirm no session, grant or assertion was extended by the anomaly.
6. Record the chronology caveat on any incident whose timeline crosses the
   window: those timestamps are wall readings and may not represent elapsed
   time.

## Verification

Time state returns to `TRUSTED`; the anomaly record is retained; no expired
authority became usable; affected incident timelines carry the caveat.

## Rollback

None. A clock is corrected forward; it is not corrected by reverting the
recorded anomaly.

## Evidence generated

`validation/ops01/clock_failure_result.json` with the rollback and forward-jump
cases and the expiry decisions taken across them.

## Exit criteria

Synchronization restored, authority decisions re-derived, and the evidence shows
no resurrection of expired authority.

## Escalation

A rollback large enough to cross an expiry boundary is escalated to
`role:security-reviewer` regardless of whether authority was actually revived.
