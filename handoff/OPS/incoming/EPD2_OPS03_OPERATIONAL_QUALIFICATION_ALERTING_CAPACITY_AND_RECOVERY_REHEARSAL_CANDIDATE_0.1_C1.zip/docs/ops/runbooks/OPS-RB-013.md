---
runbook_id: OPS-RB-013
title: Audit / Evidence Integrity Incident
owner: role:audit-reviewer
exercised_by: G15
---

# OPS-RB-013 — Audit / Evidence Integrity Incident

## Trigger

A hash chain fails verification; an evidence file no longer matches its recorded
digest; an audit gap is found; or an append fails and the originating operation
was not refused.

## Preconditions

The chain head and the recorded digests are available. The reviewer holds no
key-custody duty.

## Required authority

`AUDIT_REVIEW`.

## Forbidden authority

No repair of a chain in place. No re-generation of evidence to make a digest
match. `AUDIT_REVIEW` and `SECRET_KEY_ACCESS` are incompatible duties precisely
so nobody can both sign and bless.

## Steps

1. Freeze the affected evidence: further appends continue, but nothing is
   rewritten.
2. Identify the first entry whose recomputed hash differs, and the last entry
   that verified. The defect lies between them.
3. Determine whether the cause is alteration, reordering, truncation, or a write
   that never happened.
4. If any writer continued serving while unable to append, that is a second and
   more serious finding: the refuse-on-audit-failure contract was not honoured.
5. Preserve everything, including the invalid state. Reconstructing a "correct"
   chain destroys the evidence of what happened.
6. Raise `SEV1-AUDIT-INTEGRITY-LOSS`.

## Verification

The break point is identified precisely, the preserved artefacts are digested,
and no chain was rewritten.

## Rollback

None. Evidence is append-only; a correction is a new entry describing the
finding.

## Evidence generated

The preserved chain with the identified break; the digest comparison record.

## Exit criteria

Cause identified, scope of unverifiable evidence stated, nothing rewritten, and
a corrective action with a verification requirement recorded.

## Escalation

Immediate SEV-1 escalation to `role:security-reviewer` and the service owner.
Any suspicion that signing material is involved opens OPS-RB-006 in parallel.
