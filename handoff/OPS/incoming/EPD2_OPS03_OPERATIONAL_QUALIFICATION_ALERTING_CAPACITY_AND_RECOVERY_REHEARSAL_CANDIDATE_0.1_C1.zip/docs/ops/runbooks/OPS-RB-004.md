---
runbook_id: OPS-RB-004
title: Backup & Restore
owner: role:restore-operator
exercised_by: G20
---

# OPS-RB-004 — Backup & Restore

## Trigger

Data loss or corruption confirmed; a store must be rebuilt; or the scheduled
restore exercise is due. A backup that has not been restored is not evidence of
recoverability, so the exercise is not optional.

## Preconditions

A backup exists with a manifest recording its SHA-256, size, tool version and
server version. The target datastore's recovery class is known. For R3 and R4,
independent verification is arranged before the restore is trusted.

## Required authority

`BACKUP_ACCESS` to read the artefact; `RESTORE_APPROVAL` from a different actor;
`RESTORE_EXECUTION` to perform it. R4 (voting) restores require voting
authority and are out of scope for ordinary restore duty.

## Forbidden authority

The restore operator must not approve their own restore. No restore into a live
environment without an approval record. No restore from an artefact whose bytes
do not match its manifest — that check is not advisory.

## Steps

1. Record the pre-restore state: authoritative-row digest, grant digest, audit
   chain continuity.
2. Verify the backup bytes against the manifest digest. A mismatch stops here
   and becomes `SEV1-RESTORE-INTEGRITY-FAILURE`.
3. Obtain restore approval from `role:restore-approver`.
4. Restore in the declared dependency order.
5. Recompute the authoritative-row digest and compare it with the source value.
6. Recompute the grant digest: a restore that loses permissions has restored
   data into an unprotected store.
7. Re-verify the audit chain across the restored range.
8. Measure and record the elapsed restore time against the provisional RTO.

## Verification

Authoritative digest equal; grant digest equal; audit chain intact; measured
restore time recorded with its environment and limitations stated.

## Rollback

If the comparison fails, the restored store is not promoted. The pre-restore
artefacts are retained and the incident severity is raised rather than the
comparison being repeated until it passes.

## Evidence generated

`validation/ops01/backup_restore_result.json`, the backup manifest, and the
measured recovery objective record.

## Exit criteria

Restored authoritative data, permissions and audit continuity all match, and the
comparison is recorded — not asserted.

## Escalation

Any digest mismatch is SEV-1 and escalates to the service owner and
`role:security-reviewer` before any further restore attempt.
