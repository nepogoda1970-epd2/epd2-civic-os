---
runbook_id: OPS-RB-016
title: Voting Isolation / Linkability Incident
owner: role:security-reviewer
exercised_by: G12
---

# OPS-RB-016 — Voting Isolation / Linkability Incident

## Trigger

A correlation identifier is observed on both sides of WS-03; a member-domain
field appears in voting telemetry; a shared trace spans Member Core and the
Voting Client; or any operational path is found that could join an
authentication event to a ballot event.

## Preconditions

The telemetry samples are available. The linkage probe and its positive control
are available.

## Required authority

`SECURITY_REVIEW`. Voting-side actions are executed by `role:voting-operations`.

## Forbidden authority

The investigation must not itself construct the linkage it is investigating. Do
not join the streams to "confirm" the finding beyond establishing that a join
key exists; record the key's shape and location, not the joined records. No
ballot content is read at any point.

## Steps

1. Raise `SEV1-VOTING-ISOLATION-BREACH` on suspicion. Confirmation comes later.
2. Run the linkage probe over the ordinary and voting streams, and run its
   positive control first — a probe that cannot detect a planted linkage cannot
   clear a real one.
3. Identify the join key: which field, which emitter, which sink, over what
   period.
4. Stop the emission and remove the field from the voting path. If a correlation
   value crossed the boundary, treat every value minted in that window as
   compromised and rotate the minting key.
5. Determine reach across the retention of every sink that held both streams,
   including debug bundles and backups.
6. Purge under `ops/disposition/operational_copies.yaml`, widest access first.
7. Assess whether an actual identity-to-vote inference was possible, separately
   from whether a join key existed. Record both answers.

## Verification

The probe finds no join candidate after the fix, with the positive control still
detecting a planted one. No member-domain field remains in the voting allow
list. The reach assessment covers every sink.

## Rollback

None. Isolation is restored forward; the historical exposure is recorded.

## Evidence generated

`validation/ops01/voting_ops_isolation_result.json` including the positive
control and the post-fix probe.

## Exit criteria

Join key removed, reach assessed and purged, inference question answered in
writing, and the probe clean with its control still working.

## Escalation

Immediate SEV-1 to the service owner, `role:voting-operations` and
`role:security-reviewer`. If an election is open, the decision to continue or
suspend it is a governance decision and is not taken by operations.
