---
runbook_id: OPS-RB-001
title: Incident Declaration & Triage
owner: role:incident-commander
exercised_by: G13
---

# OPS-RB-001 — Incident Declaration & Triage

## Trigger

An alert crosses its escalation threshold; a readiness probe reports
`UNAVAILABLE` for a CRITICAL service; a member-visible failure is reported; or
any operator suspects one of the mandatory SEV-1 criteria in
`ops/incident/severity.yaml`.

## Preconditions

The declaring operator holds `INCIDENT_DECLARATION`. The severity criteria file
is readable. An incident identifier is allocated before any diagnostic action,
so that every subsequent action has something to attach to.

## Required authority

`INCIDENT_DECLARATION` to declare. `DIAGNOSTIC_ACCESS` to triage.

## Forbidden authority

Declaring an incident confers nothing else. It does not grant secret or key
access, it does not authorize a production change, and it does not authorize
break-glass — the SoD matrix keeps `INCIDENT_DECLARATION` and
`BREAK_GLASS_APPROVAL` apart precisely so an incident cannot self-authorize
emergency power.

## Steps

1. Record the incident in state `DETECTED` with detection time and detector.
2. Name the severity criteria that hold. Do not type a severity; derive it.
3. Move to `TRIAGED`. If a mandatory criterion holds, the severity floor it sets
   cannot be lowered while it holds.
4. Assign an owner. Record affected services from the operational catalog, and
   set the security, privacy and voting relevance flags explicitly — including
   when they are false.
5. Move to `DECLARED` and open the incident evidence ledger.
6. Route to the specific runbook: outage → OPS-RB-002, store → OPS-RB-003,
   release → OPS-RB-005, secret → OPS-RB-006, telemetry leak → OPS-RB-014,
   voting → OPS-RB-015 / OPS-RB-016.

## Verification

The incident record carries a derived severity, at least one criterion, an
owner, and a hash-chained ledger whose first entry is the detection. The ledger
verifies.

## Rollback

An incident declared in error is moved `TRIAGED → RESOLVED` with a recorded
justification. The record is never deleted: a withdrawn declaration is part of
the operational history.

## Evidence generated

`validation/ops01/incident_simulation_result.json`; the incident ledger.

## Exit criteria

The incident is owned, classified from declared criteria, routed to a specific
runbook, and its evidence chain is open and verifying.

## Escalation

SEV-1 escalates immediately to `role:security-reviewer` and the service owner.
Any suspicion of voting isolation loss escalates to `role:voting-operations` and
follows OPS-RB-016 in parallel, not afterwards.
