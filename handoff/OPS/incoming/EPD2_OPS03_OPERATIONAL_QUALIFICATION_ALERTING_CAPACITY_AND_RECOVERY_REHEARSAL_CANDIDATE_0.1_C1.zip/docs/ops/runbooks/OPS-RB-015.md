---
runbook_id: OPS-RB-015
title: Voting Availability Incident
owner: role:voting-operations
exercised_by: G28
---

# OPS-RB-015 — Voting Availability Incident

## Trigger

Voting ingress is unavailable; the voting service fails readiness; the guardian
or key service is unreachable; a network partition separates the voting path;
or evidence and results are only partially available.

## Preconditions

The election window state is known. The voting observability profile — and only
that profile — is available for diagnosis.

## Required authority

`INCIDENT_DECLARATION` and `CHANGE_EXECUTION` held by `role:voting-operations`.

## Forbidden authority

No operator may inspect ballot content for debugging, under any severity. No
member, person, account or session identifier may be introduced into voting
telemetry to aid diagnosis. No fallback to a non-isolated path to restore
availability: an unavailable voting service is a better outcome than a
correlatable one. Ordinary break-glass grants none of these.

## Steps

1. Establish which component: ingress, voting service, guardian/key service,
   store, or the network between them.
2. Diagnose from the minimized profile only — allow-listed fields, bucketed
   values, no identifiers. If that is not enough to diagnose, the answer is to
   improve the profile through governance, not to widen it during an incident.
3. If the trust or key service is the cause, treat suspected trust-material
   compromise as OPS-RB-006 with voting authority, and stop ballot acceptance.
4. On a partition, confirm that no side accepted ballots it cannot prove: ballot
   acceptance stops rather than continuing optimistically.
5. If evidence or results are partially available, publish nothing. A partial
   tally is not published, ever.
6. Recover the component, then confirm acceptance resumes only with the isolated
   trust material intact.

## Verification

Voting readiness is green on the voting path; no member-domain field appears in
any voting telemetry record; no partial result was published; the isolation
probe finds no join candidate.

## Rollback

If a change made during the incident touched the isolation boundary in any way,
it is reverted first and reviewed before availability work continues.

## Evidence generated

`validation/ops01/voting_ops_isolation_result.json`; the voting incident record.

## Exit criteria

Voting availability restored on the isolated path, isolation re-proven after
recovery, and nothing partial published.

## Escalation

Any suspicion of linkage escalates immediately to OPS-RB-016 and SEV-1; an
incident inside an election window escalates to the service owner and
`role:security-reviewer` on declaration, not on resolution.
