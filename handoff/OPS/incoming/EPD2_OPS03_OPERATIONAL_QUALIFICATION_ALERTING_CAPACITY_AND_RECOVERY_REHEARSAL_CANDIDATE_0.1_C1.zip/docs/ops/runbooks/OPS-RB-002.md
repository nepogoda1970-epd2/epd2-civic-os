---
runbook_id: OPS-RB-002
title: Major Service Outage
owner: role:platform-operations
exercised_by: G07
---

# OPS-RB-002 — Major Service Outage

## Trigger

A service reports `UNAVAILABLE`, or its readiness endpoint returns 503 for
longer than the escalation window in its SLO profile.

## Preconditions

An incident exists (OPS-RB-001). The service's catalog entry is at hand: it
names the dependencies, the expected degraded behaviour and the incident class.

## Required authority

`DIAGNOSTIC_ACCESS`; `CHANGE_EXECUTION` for restarts and traffic changes.

## Forbidden authority

No domain-content access. Reading member records "to see whether it works" is
not a diagnostic step. No secret or key access — an outage is not a key-custody
event unless OPS-RB-006 says so.

## Steps

1. Separate the four questions: is the process alive (`/health/live`), is it
   ready (`/health/ready`), which dependency is failing
   (`/health/dependencies`), and is the business function degraded or absent.
2. If liveness fails, the process is gone: restart, and record the restart as an
   operational event.
3. If liveness passes and readiness fails, do not restart. A restart loop
   against a dependency outage amplifies the outage. Go to the dependency.
4. If a mandatory dependency is DOWN, follow OPS-RB-003 (store) or OPS-RB-017
   (provider).
5. If the outage began within one release of a deployment, treat OPS-RB-005 as
   the more likely path before deeper diagnosis.
6. Confirm the degraded behaviour matches what the catalog says it should be. A
   service degrading differently from its declared contract is a second finding,
   recorded separately.

## Verification

`/health/ready` returns `ready: true` and the dependency report shows every
mandatory dependency UP. The observed release identity matches the intended one.

## Rollback

If a change made during triage did not help, revert it before trying the next
one. Two simultaneous untracked changes make the cause unrecoverable.

## Evidence generated

Readiness and dependency snapshots attached to the incident ledger;
`validation/ops01/dependency_failure_result.json` for the exercised path.

## Exit criteria

Readiness is green from the process that is actually serving, sustained across
the monitoring window, with no manual intervention holding it up.

## Escalation

Two failed recovery attempts, or any CRITICAL service down beyond its
escalation threshold, escalates to the service owner and
`role:incident-commander`.
