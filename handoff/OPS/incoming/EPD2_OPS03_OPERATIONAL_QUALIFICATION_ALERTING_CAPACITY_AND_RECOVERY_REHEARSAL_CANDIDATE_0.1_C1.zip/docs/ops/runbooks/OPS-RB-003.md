---
runbook_id: OPS-RB-003
title: Database Failure
owner: role:platform-operations
exercised_by: G07
---

# OPS-RB-003 — Database Failure

## Trigger

`database_availability` breaches its escalation threshold, or a readiness probe
reports the primary store DOWN.

## Preconditions

An incident exists. The datastore's entry in `ops/recovery/classes.yaml` is at
hand: it names the recovery class, the dependency ordering and the expected
data-loss boundary.

## Required authority

`DIAGNOSTIC_ACCESS`. `RESTORE_APPROVAL` and `RESTORE_EXECUTION` are separate
duties and are not needed unless the incident becomes a restore.

## Forbidden authority

No reading of domain tables for diagnosis. Connectivity, replication state,
locks and disk are operational facts; row contents are not. A single operator
must not both approve and execute a restore.

## Steps

1. Establish whether the store is unreachable, reachable but refusing
   connections, or reachable and slow. These have different causes and different
   recoveries.
2. Confirm dependent services are failing readiness rather than serving stale
   data. A service that is green while its mandatory store is down is a defect
   to raise even mid-incident.
3. Attempt connectivity recovery: connection limits, exhausted pools, disk
   pressure, a stuck migration lock.
4. If the data is intact, recovery ends here. Do not restore a healthy store.
5. If data loss or corruption is suspected, raise severity to
   `SEV1-DESTRUCTIVE-DATA-CORRUPTION` and go to OPS-RB-004.
6. Restore only in the declared dependency order; the audit store is restored
   before or with the store whose events it records.

## Verification

Dependent services report ready. The authoritative-row digest matches the
pre-incident value where one exists. The audit chain verifies with no gap.

## Rollback

Connection-level changes are reverted once the store is healthy. Emergency
limit increases are logged as a change and reverted, not left in place.

## Evidence generated

Dependency and readiness snapshots; if a restore occurred,
`validation/ops01/backup_restore_result.json`.

## Exit criteria

The store serves, dependents are ready, the audit chain verifies, and the
expected data-loss boundary has been stated explicitly — including "none".

## Escalation

Suspected corruption is SEV-1 and escalates to the service owner,
`role:security-reviewer` and `role:restore-approver` together.
