---
runbook_id: OPS-RB-008
title: Break-Glass Activation
owner: role:break-glass-actor
exercised_by: G17
---

# OPS-RB-008 — Break-Glass Activation

## Trigger

An incident requires an action no standing role permits, and waiting for a
normal change would extend member-visible harm.

## Preconditions

An incident exists. The needed scope is one of the declared emergency scopes. An
approver holding `BREAK_GLASS_APPROVAL` — who is not the requester — is
available. Trusted time is `TRUSTED`; when it is not, no new authority is
granted at all.

## Required authority

`BREAK_GLASS_ACTIVATION` to request and activate; `BREAK_GLASS_APPROVAL`, held
by a different actor, to approve.

## Forbidden authority

Self-approval does not exist as an operation. Break-glass never grants
`BALLOT_CONTENT_READ`, `VOTING_CRYPTO_BYPASS`, `VOTING_ISOLATION_BYPASS`,
`AUDIT_LOG_REWRITE`, `EVIDENCE_DELETION` or `PERMANENT_ROLE_GRANT` — these are
refused by name, not by judgement. An incident commander may not approve
emergency access for an incident they declared.

## Steps

1. State the reason in specific terms: what will be done, to what, and why now.
2. Choose the narrowest scope that can work, and a duration no longer than
   needed — never more than four hours.
3. Request the grant. Obtain approval from a different actor.
4. Activate. Activation starts the expiry clock; expiry is evaluated against the
   authoritative time high-water mark, so moving the host clock backwards does
   not extend it.
5. Perform only actions within the granted scope. Each use is recorded.
6. Stop when the action is done; do not hold the grant open for convenience.

## Verification

The grant record carries reason, scope, requester, a different approver,
activation time and expiry. Every use is inside the scope and before expiry.

## Rollback

Actions taken under a grant are reverted by their own runbook, not by revoking
the grant. Revocation stops further use; it does not undo what was done.

## Evidence generated

`validation/ops01/break_glass_result.json`; the break-glass ledger; entries on
the incident record.

## Exit criteria

The action is complete, the grant is expired or revoked, and OPS-RB-009 is open.

## Escalation

A refused scope request is itself a finding: escalate to
`role:security-reviewer` rather than looking for another route to the same
capability.
