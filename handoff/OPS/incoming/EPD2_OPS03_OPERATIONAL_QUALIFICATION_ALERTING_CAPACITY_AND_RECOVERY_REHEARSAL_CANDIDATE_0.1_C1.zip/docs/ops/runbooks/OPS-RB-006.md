---
runbook_id: OPS-RB-006
title: Credential / Secret Compromise
owner: role:security-reviewer
exercised_by: G27
---

# OPS-RB-006 — Credential / Secret Compromise

## Trigger

A credential or secret is suspected exposed: found in a log or export, reported
by a third party, observed in anomalous authorization failures, or exposed by a
repository or artefact leak.

## Preconditions

The secret class is identified. These are not equivalent: a human password, a
service credential, a certificate, an API secret, a signing key and an
encryption key have different response plans and different authority
requirements (`epd2_ops.secret_incident`).

## Required authority

`SECURITY_REVIEW` to classify and drive. `SECRET_KEY_ACCESS` for rotation of
operational credentials. Signing- and encryption-key actions require the
governed key authority under FIR-SEC-004 / FIR-CRYPTO-001 — OPS may contain and
preserve evidence, and may not decide what remains trusted.

## Forbidden authority

Diagnostic access does not become key access during an incident. Break-glass
does not confer signing-key authority. The actor who holds the key material does
not review their own incident.

## Steps

1. Classify the secret. Record the mandatory severity: signing and encryption
   keys are SEV-1, the rest SEV-2.
2. Contain: revoke sessions, isolate the workload, block the exposed path.
3. For operational credentials and API secrets: rotate, restart the workloads
   that hold them, and confirm the old value no longer authenticates.
4. For certificates: replace operationally; revocation and any trust-set change
   go to the trust authority.
5. For signing keys: stop issuing, preserve everything, and hand the trust-set
   question to the key authority. Every artefact the key ever signed is in
   question, including evidence.
6. For encryption keys: rotation does not undo disclosure. Record the
   confidentiality question explicitly and route it to security authority.
7. Review access evidence for the exposure window.

## Verification

The old credential no longer authenticates. Workloads are healthy on the new
material. The response actions taken match the declared plan for that class, and
any action requiring key authority carries that authority's record.

## Rollback

There is no rollback for a rotation. If the new material is faulty, issue new
material again; never restore the compromised value.

## Evidence generated

`validation/ops01/secret_incident_result.json`; the access-evidence review.

## Exit criteria

Contained, rotated or replaced within the authority that owns it, evidence
reviewed, and the residual question — what the holder could have done with it —
answered in writing.

## Escalation

Signing- or encryption-key compromise escalates immediately to the trust
authority and `role:security-reviewer`, and OPS-RB-007 runs alongside if any
certificate or trust anchor is involved.
