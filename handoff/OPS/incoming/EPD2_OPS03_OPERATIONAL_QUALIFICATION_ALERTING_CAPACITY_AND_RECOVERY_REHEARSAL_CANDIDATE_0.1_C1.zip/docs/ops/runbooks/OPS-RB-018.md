---
runbook_id: OPS-RB-018
title: Service Decommissioning
owner: role:service-owner
exercised_by: G30
---

# OPS-RB-018 — Service Decommissioning

## Trigger

A service, provider or version is to be retired.

## Preconditions

A decommission plan exists naming the target, its kind and the reason. The
target's catalog entry, datastores and secret classes are known.

## Required authority

`CHANGE_APPROVAL` for the plan; `CHANGE_EXECUTION` for the steps;
`SECRET_KEY_ACCESS` for secret destruction, held by a different actor.

## Forbidden authority

Deleting code does not decommission a service. No step may be skipped as
"obviously done", and evidence retention — the one step that produces nothing
visible — is mandatory.

## Steps

1. Remove traffic. Confirm from the ingress, not from intent.
2. Stop scheduled jobs and consumers.
3. Revoke credentials. This comes after traffic and jobs, or it causes the
   outage it was meant to avoid.
4. Destroy secrets. Only after revocation, or un-revocable credentials remain.
5. Complete data disposition, including every derived operational copy.
6. Remove monitoring and alerting so the retired service stops generating
   noise — and so a later alert from it is a real finding.
7. Remove dependency edges from the catalog and from dependent services.
8. Remove routes and DNS entries; retire certificates.
9. Update documentation and the operational catalog.
10. Retain the evidence of all of the above.

## Verification

Every mandatory step is recorded with an actor and an evidence reference, in an
order that satisfies the declared prerequisites. The workflow refuses to report
`DECOMMISSIONED` while any step is outstanding.

## Rollback

Before secret destruction, a decommission can be abandoned and the service
restored. After it, restoration is a new provisioning, not a rollback.

## Evidence generated

`validation/ops01/decommission_result.json` and the decommission ledger.

## Exit criteria

All eleven steps complete in a valid order, catalog and documentation updated,
evidence retained.

## Escalation

A step that cannot be completed blocks the decommission. The service stays in
`IN_PROGRESS` and the blocker is raised to the service owner; it is not recorded
as done.
