# OPS-03 DEVELOPER REPORT

Stage: **OPS-03 — Operational Qualification, Alerting, Capacity & Recovery Rehearsal**
Stage mode: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`
Candidate self-state: `CANDIDATE_NOT_ACCEPTED`
Recorded: 2026-09-02

## 1. Result, stated plainly

**49 of 50 gates PASS. 0 FAIL. 1 BLOCKED. Harness verdict: `BLOCKED`.**

G05 is blocked because the accepted final API runtime does not exist: API-06 is
`NEXT` and the API layer is open. §3 forbids treating unaccepted API-06 bytes as
an accepted dependency, and §7 requires the final PASS-target to bind the exact
accepted API identity at seal time. So this is a working/preseal result, and per
§7 it **must not be labelled PASS-ready**. It is not.

Everything else executed and passed against real processes, real HTTP and a real
PostgreSQL 16.15 server.

## 2. Candidate identity

- Filename: `EPD2_OPS03_OPERATIONAL_QUALIFICATION_ALERTING_CAPACITY_AND_RECOVERY_REHEARSAL_CANDIDATE_0.1_C1.zip`
- SHA-256, size, member count: written to `OPS03_C1_CANDIDATE_IDENTITY.json` and the `.sha256` file beside the archive at seal time
- Handoff state recorded in the candidate: `WORKING_PRESEAL_SNAPSHOT_WITH_DECLARED_BLOCKER`
- Candidate self-state: `CANDIDATE_NOT_ACCEPTED`

The candidate's own digest is written outside the archive it describes, never
inside it. The sealer refuses a dirty tree, re-runs the canonical harness as a
child process, refuses to package if the tree changed while it ran, verifies
every packaged member against the freeze manifest, and re-opens and re-hashes the
archive before reporting success. A `FAIL` harness is refused outright; a
`BLOCKED` one seals a working snapshot that carries its blockers in its own
identity document.

## 3. Source identity

- Entering canonical `main`: `217559b7f21c338d6fe8d4e4676082cd3840251c`, tree `eb8a3254c2b8a30feff71318d4377eff2435605c`
- Commit subject: `governance(ops02): accept and close bounded OPS-02 C3`
- Working branch: `ops03-operational-qualification`
- Freeze tree digest, governed file count, final source commit and tree: recorded in `OPS03_C1_CANDIDATE_IDENTITY.json`

Read live from the canonical tree in the mandated order, not from the snapshot
shipped with the assignment package. The snapshot agreed with it, which is worth
recording and is not what makes the baseline valid.

## 4. Accepted predecessor binding

- **OPS-02 C3**: `ac3b543b0cb3a8e45f7d973c841769d0b4c6e7af649a54aee034f3e0b6afc125`, 16,632,939 bytes, freeze digest `91f5b78d…`, source commit `bf33855a…`, authoritative run `33610516469`
- **OPS-01 C2**: `39a6b02af03269a8ebf61216503fa03df2abf4e5194aa3c45c6f4bb176f2ad27`
- **INFRA-01 C3**: `5cd90da141056badc38ee3fb34f2d648002ace5b87c6a0cce1d331431364b131`
- **INFRA-02**: `d91fa6db81126765c0e26bf285fff2f974464544b7fa6299b6d069a25d1ff72c`
- **API-05 C1**: `38bab7663b54f9f81538666315ee16195b0aa086e5b5c50c2b87acc3f4f03a70`
- **API-06**: `NEXT` — not accepted, not bound, not substituted

The OPS-02 C3 archive was verified before any of its bytes were used: the
supplied file hashed to the accepted digest exactly, all 1,536 freeze-manifest
entries matched their extracted files with zero mismatches, and the freeze tree
digest recomputed to `91f5b78d…`.

Of those 1,536 governed files, **1,528 are carried unchanged**. The eight that
differ are recorded individually with both digests and a reason in
`docs/ops/OPS-03/OPS03_PREDECESSOR_RECONCILIATION.json`:

| File                                            | Classification                    | Why                                                                                                                                                                     |
| ----------------------------------------------- | --------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `docs/roadmap/EPD2_PROGRAM_CONTROL_REGISTER.md` | `CANONICAL_GOVERNANCE_NEWER`      | The register on `main@217559b7` records the OPS-02 C3 acceptance that the C3 archive predates. Newer canonical governance is **not** overwritten from a working branch. |
| `scripts/validation/validate_ops01.py`          | `GOVERNANCE_ASSERTION_RECONCILED` | One further narrow reconciliation — see §5.                                                                                                                             |
| `pyproject.toml`                                | `WORKSPACE_REGISTRATION`          | Registers `epd2-qualification` and `tests/ops03`. No OPS-01 or OPS-02 setting changed.                                                                                  |
| `uv.lock`                                       | `WORKSPACE_REGISTRATION`          | Regenerated for the new member. **No third-party dependency added.**                                                                                                    |
| `Makefile`                                      | `WORKSPACE_REGISTRATION`          | Adds `verify-ops03` and `seal-ops03`. No existing target changed.                                                                                                       |
| `scripts/check_repository.py`                   | `WORKSPACE_REGISTRATION`          | Registers the OPS-03 required paths. No existing path removed.                                                                                                          |

No accepted control is reimplemented, weakened or bypassed. No competing
release-integrity model is created: the accepted OPS-01 freeze implementation is
imported, and the accepted INFRA digests are bound as constants the harness
refuses to proceed without.

## 5. The third reconciliation of the accepted OPS-01 harness

The accepted OPS-01 harness returned **27/32** on this base before any OPS-03
work touched it. The cause is worth stating because it is now a pattern.

OPS-01's G02 treated all of `docs/ops/` as OPS-01-owned and scanned it for
self-acceptance claims. That was correct when OPS-01 was the only stage writing
there. Canonical governance now writes acceptance records under sibling
directories — `docs/ops/OPS-02/OPS02_C3_AUTHORITATIVE_ACCEPTANCE_RESULT.json`
among them — and one of those records states that OPS-01 is accepted. Which it
is. An independent authority saying so is the _opposite_ of a self-acceptance
claim, but the scan could not tell the difference.

OPS-01's ownership is now scoped to `docs/ops/OPS-01/`, `docs/ops/runbooks/` and
`docs/ops/README.md`. Each stage scans its own artefacts. The change narrows what
OPS-01 claims to speak for rather than weakening what it checks, and the accepted
harness returns 32/32 on this tree with its suites still at 88/88.

The accepted **OPS-02** harness needed the matching generalisation, and this one
was found by running the extraction test rather than by reading the code. Its G01
recognised a sealed candidate only by the filename
`OPS02_CANDIDATE_SELF_STATE.json`, so an extracted OPS-03 candidate carrying the
accepted OPS-02 bytes read as having no identity at all, and the accepted harness
returned 40/42 from the sealed bytes. It now recognises a later-stage carrier and
requires **more** of it than of an OPS-02 candidate — stage, mode,
`CANDIDATE_NOT_ACCEPTED`, and the exact accepted OPS-02 candidate and freeze tree
digests it carries. Without it, no later OPS stage could demonstrate OPS-02
non-regression from its own sealed bytes, which §12 requires. The OPS-03 sealer
was correspondingly extended to declare the accepted OPS-01 freeze tree digest,
because OPS-01's carrier check demands it and is right to.

That is four such reconciliations across three stages. Each time, a stage's own
acceptance — or the mere existence of a stage after it — invalidated an assertion
that was correct when written. The OPS-03 harness is built not to add a fifth: it
reads governance state as data, assembles its own forbidden phrases from
fragments so it does not trip on its own pattern list, and never asserts a
literal status string.

## 6. Runtime environment

- OS: Ubuntu 24.04.4 LTS, Linux 6.18.44 x86_64
- Python 3.12.11 · uv 0.8.17 · Node 22.22.2 / npm 10.9.7
- **PostgreSQL 16.15**, client and server — the project-controlled line, matching the accepted OPS-01 C2 and OPS-02 C3 authoritative environments
- Database access via `psql`, `pg_dump`, `pg_restore`; **no new third-party Python dependency was added**
- Collector: a standard-library `ThreadingHTTPServer` in its own OS process on a real port

## 7. Verification results

- **OPS-03 gates: 50 executed, 49 passed, 0 failed, 0 missing, 0 skipped, 0 not-run, 0 manual-assume-pass, 1 blocked**
- **OPS-03 tests: 66 passed** (30 in `packages/python/epd2-qualification/tests`, 36 in `tests/ops03`)
- **Mutations: 24 defined, 24 detected**, across **21 distinct gates**
- **Predecessor non-regression: OPS-01 32/32 and OPS-02 42/42 on this tree, and again from the extracted candidate bytes with no git history present; 88/88 and 57/57 tests**
- `same_governed_source_bytes_after_execution`: **true**
- Lint, format and strict type checking clean over the whole OPS-03 surface

Terminal marker:
`OPS03_RESULT:BLOCKED:validation/ops03/ops03_acceptance_result.json`

A `PASS` verdict requires `executed == total`, `passed == total` and every one of
`failed`, `missing`, `skipped`, `environment_blocked`, `not_run` and
`manual_assume_pass` empty. `environment_blocked` holds `["G05"]`, so the verdict
is `BLOCKED`, and the harness's own self-check refuses to write `PASS` alongside
a non-empty array.

## 8. Runtime evidence

**Telemetry path (G10–G16).** A collector in its own process (`distinct_process:
true`) on a real socket, answering `/health` with _two_ separate facts — the
collector is alive, and the store is writable — because a collector reporting
healthy over a read-only store is the fabricated-success failure this stage
exists to catch. Records were written, the collector was then killed, and all
three signals were read back from the store: persistence, not memory. Fifty-one
composed telemetry fields across the three accepted registries. Reads are
role-bounded with **no universal reader**; unknown role, undeclared purpose,
out-of-role signal, expired elevation and elevation-after-clock-rollback were all
refused, and self-approval of an elevation was refused. Ten audit rows were
written, covering granted and refused reads and naming the elevation used.
Retention deleted the expired record, kept the fresh one, and re-counted zero
surviving expired rows.

**Privacy and voting isolation (G17, G18).** Nine injections refused — bearer
token, connection credentials, and member, account, person, voter, ballot-content
and session identifiers in both the voting and member domains — each with a
stated reason; an undeclared but harmless field was dropped rather than refused,
with the drop recorded. A deliberately conflicting field redeclaration was
refused by the composition guard. Over 24 distinct correlation values, **no value
spanned isolated domains**, and the planted positive control **was** detected, so
the negative result means something.

**Objectives and budgets (G19–G21).** Ten objectives, each naming an owner in the
accepted duty matrix, an existing OPS-RB runbook, a known severity and an action;
an unknown owner and an unknown runbook were both refused at load time.
Evaluation read the store through the audited path — ten audit rows attributed to
`SLO_EVALUATION` are the proof. Budget accounting was byte-identical across two
runs of the same window, and a deliberately breached objective exhausted its
budget.

**Alerting (G22–G26).** Breach → alert → route → acknowledge, and separately
breach → no acknowledgement → escalation to a _different_ target. With the sink
failing, the router recorded `FAILED`; with `fabricate_success` enabled it
claimed `DELIVERED` while the sink received nothing, which is exactly what MUT-13
exists to catch. Routing to an unknown role was refused. No actor is primary for
every role.

**Capacity (G29–G35).** Baseline: 2,000 requests, ~1,867/s, p50 0.32 ms, p95 0.96
ms, p99 1.63 ms. Overload: 4,000 offered against a queue of 32 — 2,831 admitted,
**1,169 shed** with reason `QUEUE_FULL`, max depth exactly 32, no unbounded
growth. Retry amplification 1.10× against a cap of 150, with 152 retries refused.
Soak: 12,000 requests, queue growth trend 0.0, drained to 0, no evidence lost. An
unbounded-queue control, an uncapped-retry control and a broken-idempotency
control were each run so the gates are tested against the failure and not only
against the fix.

**Recovery (G36–G41).** A deterministic dataset — `ops03-trial-20260903-4000x20000`,
24,000 rows, 4.86 MB, content digest `6184c07c…` — generated from a seed so a
reviewer can regenerate it exactly. A real `pg_dump` (1,230,385 bytes, digest
`73894b6a…`, bound to the dataset digest), a tampered copy **refused before the
restore ran**, the schema then actually destroyed, restored, and reconciled from
**data content**: expected and observed digests and row counts identical. The
activation gate refused at every stage before reconciliation and readiness, naming
which condition it was refusing on, and admitted only when all three held.

**Incident drills (G42).** All twelve executed and complete, each with an entry
condition, observable evidence, an owner, a runbook, a safe state, a recovery
condition and a post-recovery check. The five degradation drills all refused
consequential traffic while degraded — `degraded mode != weakened invariant`
enforced, not asserted. D12 closed a voting-sensitive incident end to end with no
identifier reaching the store.

**Drift and duties (G43–G45).** Four drift dimensions, each compared by digest;
a self-approved change refused; unrecorded drift reported fail-closed and cleared
only once a change record accounted for it. Sixteen roles, eight incompatible
pairs, **no universal operator, no universal reader, no universal responder**,
and a destructive restore approved by someone other than its executor.

**Freeze (G49).** 1,567 governed files; tree digest identical before and after the
whole gate suite; the clean extract, with no `.git` present, reproduced the freeze
tree digest exactly with no missing, changed or unaccounted member.

## 9. Preview-minimum evidence

**15 of 15 OPS-owned prerequisites `PASS_EVIDENCED`.** Five further
prerequisites are listed and blocked elsewhere — `BLOCKED_BY_API` (the accepted
final API runtime), `BLOCKED_BY_INFRA` (a deployed observability stack; a trusted
time source), `BLOCKED_BY_SEC` (real authenticated principals) and
`BLOCKED_BY_GOVERNANCE` (the recorded INFRA/OPS minimum itself).

`system_trial_preview_opened` is hard-wired `false` and
`governance_decision_recorded` is hard-wired `false`; no code path sets either
otherwise, and the builder refuses a `PASS_EVIDENCED` classification whose
supporting gates did not pass.

## 10. BSI readiness

Result `PASS_WITH_EXPLICIT_EXISTING_DEFERRED_GAPS`, certification claim **`NONE`**.

Ten rows reassessed. **Nine partially improved** — M-03, M-11, M-16, M-17, M-19,
M-20, M-25, M-27, M-30 — with M-11 recorded as
`PRESERVED_AND_OPERATIONALLY_STRENGTHENED`. **M-02 `UNCHANGED`, still RED / P0.**
All nine inherited deferred bindings preserved; **zero closed, zero new
blockers**. The builder refuses an improvement whose gates did not pass, refuses
`CLOSED` as an effect, refuses a document that drops a binding, and refuses the
wordings "BSI compliant", "CC compliant" and "EAL4 certified" anywhere in its
output.

## 11. FIR disposition

Ten FIRs reassessed. **0 implemented, 9 partially advanced, 1 intentionally
unchanged, 0 deferred, 0 new FIRs, 0 status changes requested.** No disposition
moved relative to OPS-02: this stage deepens what those dispositions already
described rather than crossing a threshold, and claiming otherwise would be the
easiest and least honest thing in the document.

## 12. Known limitations

See `docs/ops/OPS-03/OPS03_KNOWN_LIMITATIONS.md` — twenty-one entries with owner,
reason, closure stage, required evidence and blocking class. The ones that matter
most: G05 is blocked on the accepted API runtime; capacity and recovery figures
are trial measurements on one host; there is no observability product, no paging
transport, no identity provider, no key lifecycle and no trusted time source; the
audit trail is not independently protected; and the mutation suite is assurance
of the verifier, not of the platform.

## 13. Final developer handoff state

```text
OPS03_RESULT:
IMPLEMENTATION_COMPLETE
LOCAL_VERIFICATION_BLOCKED_ON_ACCEPTED_API_RUNTIME
49_OF_50_GATES_PASS
NOT_PASS_READY
NOT_ACCEPTED
```

State: `IMPLEMENTED + PRESEAL VERIFIED + SEALED AS A WORKING SNAPSHOT WITH ONE
DECLARED BLOCKER`. It is deliberately **not**
`READY_FOR_INDEPENDENT_GOVERNED_REVIEW`: §7 reserves that for a candidate with no
blocked gate, and this one has G05.

## 14. Explicit non-acceptance

OPS-03 is **not accepted**. The OPS layer is **not closed**. The API layer is
**not closed**. The System Trial Preview is **not open** and is not declared
openable. Nothing here is production-ready; no measurement here is a production
capacity figure, RTO, RPO, objective, guarantee or commitment. Nothing is BSI-,
Common-Criteria- or EAL4-certified, and no certification is claimed or sought. No
real vote, no real personal data and no legal effect is authorised.

The candidate does not accept itself. Gate G09 scans every OPS-03 artefact for a
self-acceptance claim on every run — including this document — and the archive
carries `CANDIDATE_NOT_ACCEPTED` as a member file.

Only an independent governed verification, receiving the exact candidate bytes
and running the canonical harness on them, may change OPS-03's state. Even then,
OPS-03 acceptance would not close the OPS layer, would not close the API layer
and would not open the System Trial Preview: the Program Control Register orders
those after API-06 acceptance, and no developer, workflow or document may invent
that transition.
