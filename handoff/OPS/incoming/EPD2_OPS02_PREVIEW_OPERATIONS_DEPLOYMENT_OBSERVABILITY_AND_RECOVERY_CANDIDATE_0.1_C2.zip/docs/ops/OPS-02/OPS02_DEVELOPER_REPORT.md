# OPS-02 DEVELOPER REPORT

Stage: **OPS-02 — Preview Operations, Deployment, Observability & Recovery Readiness**
Stage mode: `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`
Candidate self-state: `CANDIDATE_NOT_ACCEPTED`
Recorded: 2026-09-01

## 1. Candidate identity

- Filename: `EPD2_OPS02_PREVIEW_OPERATIONS_DEPLOYMENT_OBSERVABILITY_AND_RECOVERY_CANDIDATE_0.1_C1.zip`
- SHA-256: written to `OPS02_C1_CANDIDATE_IDENTITY.json` and to the `.sha256` file beside the archive at seal time
- Size: recorded in the same identity document
- ZIP member count: frozen tree plus `CANDIDATE_NOT_ACCEPTED`, `OPS02_FREEZE_MANIFEST.json`, `OPS02_CANDIDATE_SELF_STATE.json`, `OPS02_PREVIEW_READINESS_PREREQUISITES.json` and `OPS02_BSI_READINESS_DISPOSITION.json`
- Candidate self-state: `CANDIDATE_NOT_ACCEPTED`

The candidate digest cannot appear inside the candidate it describes. It is
produced by `scripts/ops02/seal_candidate.py`, which refuses a dirty tree,
re-runs the canonical harness as a child process, and refuses to package if the
tree changed while it ran. Every packaged member is verified against the freeze
manifest after packaging, and the archive is re-opened and re-hashed before the
sealer reports success.

## 2. Source identity

- Entering canonical `main` commit: `2878c3bbfeb11328adf294a2b59d631b851b43dd`
- Entering canonical `main` tree: `15ef1e8044fd8875caf10ed480e33b787d2675f5`
- Working branch: `ops02-preview-operations`
- Final source commit and tree: recorded in `OPS02_C1_CANDIDATE_IDENTITY.json`
- Freeze tree digest and governed file count: recorded in `OPS02_C1_CANDIDATE_IDENTITY.json` and in the `OPS02_FREEZE_MANIFEST.json` shipped inside the archive
- Assignment reference commit: `43a0b083116f6fd94e6718b08a6f04ebb08767f0`

The candidate was extracted to a clean location and independently re-verified
from those bytes alone: the archive digest matched its `.sha256`, every manifest
entry matched its file, the recomputed tree digest matched the manifest, and both the
OPS-02 harness (42/42) and the accepted OPS-01 harness (32/32) passed against
the extracted tree with no git repository present.

The freeze tree digest is a SHA-256 over the canonical JSON encoding of
`{path: sha256}` for every governed file. Gate G41 recomputes it after the whole
gate suite has run and fails on any added, removed or changed file, which is how
the same-bytes invariant — tested tree equals verified tree equals frozen tree
equals packaged tree — is enforced rather than asserted.

## 3. Accepted predecessor binding

- OPS-01 C2 SHA-256: `39a6b02af03269a8ebf61216503fa03df2abf4e5194aa3c45c6f4bb176f2ad27`
  (authoritative run `33564968274`, source commit `a12d990d76fc4ebf7d0d08634b4cad0fbc5862cc`,
  freeze tree digest `e08ef203c096e17779592407d7b48c843c84f4f27d99e6e7514ddb7491a11613`)
- INFRA-01 C3 SHA-256: `5cd90da141056badc38ee3fb34f2d648002ace5b87c6a0cce1d331431364b131`
  (authoritative run `33556094346`, source commit `38f7d13c8badf911e61d659adb2905d1089a64a5`)
- Accepted API baselines at entry: API-01, API-02 and API-03 ACCEPTED / CLOSED;
  API-03 at accepted C5 `5fb769cd387c7bcf10b9783d05fce44066985c7408a015cb4c670419ce316b55`
- API-04: ACTIVE / IN DEVELOPMENT / NOT ACCEPTED
- Final accepted API-06 binding: **not available.** API-06 is not accepted and
  the API layer is open. OPS-02 records this as a dependency block, not a pass.

The accepted OPS-01 C2 archive was verified byte for byte before anything was
built on it: 1,486 of 1,486 members matched and the candidate digest was
recomputed from the archive rather than trusted from a document. Of the 1,486
governed files, 1,482 were carried unchanged. The four that differ are recorded
individually, with both digests and a reason, in
`docs/ops/OPS-02/OPS02_OPS01_RECONCILIATION.json`:

| File                                            | Classification                    | Reason                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| ----------------------------------------------- | --------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `docs/roadmap/EPD2_PROGRAM_CONTROL_REGISTER.md` | `CANONICAL_GOVERNANCE_NEWER`      | The canonical copy on `main` records the OPS-01 C2 acceptance and is newer than the copy inside the C2 archive. It was **not** overwritten from the working branch.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| `pyproject.toml`                                | `WORKSPACE_EXTENSION`             | Registers the new `epd2-preview` package in six places: dependency, workspace member, uv source, ruff src and isort first-party, mypy path and pytest testpaths.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| `uv.lock`                                       | `WORKSPACE_EXTENSION`             | Regenerated for the new workspace member. No third-party dependency was added.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| `scripts/validation/validate_ops01.py`          | `GOVERNANCE_ASSERTION_RECONCILED` | Two checks, narrowly reconciled. **G02** previously required the literal register text `OPS NOT_STARTED`, which no longer exists now that OPS-01 is accepted; it now requires the OPS layer to be recorded as **open** and still fails if it is recorded as closed. **G01** previously recognised a sealed candidate only by the filename `OPS01_CANDIDATE_SELF_STATE.json`, so an extracted OPS-02 candidate carrying the accepted OPS-01 bytes was reported as having no establishable identity; it now recognises a later-stage carrier and requires **more** of it — stage, stage mode, `CANDIDATE_NOT_ACCEPTED`, and the exact accepted OPS-01 candidate and freeze tree digests it carries. The accepted `epd2-ops` package is byte-identical to C2. |

No accepted OPS-01 control is reimplemented, weakened or bypassed. No competing
release-integrity model is created: the accepted INFRA-01 freeze implementation
is reused, and the accepted digests are bound as constants that the harness
refuses to proceed without.

## 4. Runtime environment

- OS: Ubuntu 24.04.4 LTS, Linux 6.18.44 x86_64
- Python: 3.12.11
- uv: 0.8.17
- PostgreSQL: 16.15 (client and server), matching the accepted OPS-01 C2 authoritative environment exactly
- Node / npm: 22.22.2 / 10.9.7
- Database access: `psql`, `pg_dump` and `pg_restore` command-line tools; no new
  third-party Python dependency was introduced for database work
- Service processes: standard-library `ThreadingHTTPServer`, real OS processes
  bound to real ports and reached over real HTTP

Mock-only evidence would not satisfy this stage, so none of the runtime gates
use a mock. The database is a real PostgreSQL 16.15 instance, the service is a
real process, and the recovery gates destroy and restore a real database.

## 5. Verification results

- OPS-02 gates: **42 executed, 42 passed, 0 failed, 0 missing, 0 skipped, 0 environment-blocked, 0 not-run, 0 manual-assume-pass**
- OPS-02 tests: 57 passed, 0 failed, 0 skipped (37 in `packages/python/epd2-preview/tests`, 20 in `tests/ops02`)
- OPS-01 non-regression: 32 of 32 gates pass and 88 of 88 tests pass on the same
  tree, and 32 of 32 again when the accepted OPS-01 harness is run against the
  **extracted OPS-02 candidate bytes** with no git history present
- Mutation cases: **20 defined, 20 detected**, covering 15 distinct gates
- Lint, format and strict type checking: clean over the whole OPS-02 surface

The harness writes `validation/ops02/ops02_acceptance_result.json` and refuses a
`PASS` verdict unless `executed == total`, `passed == total` and every one of
`failed`, `missing`, `skipped`, `environment_blocked`, `not_run` and
`manual_assume_pass` is empty. The terminal marker is
`OPS02_RESULT:PASS:validation/ops02/ops02_acceptance_result.json`.

A gate that cannot execute because an external dependency is unavailable reports
`BLOCKED`. It is never reported as a pass, and a run containing one cannot reach
a `PASS` verdict.

## 6. Runtime evidence

**Deployment identity (G07, G08).** A release manifest carries a self-digest. The
deployed identity is read back from the running process over HTTP at
`/health/identity` rather than restated by the deployer, so the evidence is an
independent observation. The verified release
`0368a2ea2e769ae1ebae…` and the running candidate
`1034186808f13d875a87…` are compared on every verification; a deliberately
mismatched deployment is refused. The provenance chain runs from the accepted
INFRA-01 candidate through the release manifest to the deployed identity, and
the invariant that an accepted artefact is not the same thing as a rebuilt
equivalent artefact is enforced as a gate.

**Readiness (G10, G12, G13).** Eleven authoritative-readiness conditions. The
evaluator raises rather than returning a verdict if the full condition set is
not present, so a dropped condition cannot read as ready. A probe that throws
becomes `UNKNOWN`, and `UNKNOWN` never satisfies a condition. Ten distinct
failure conditions were induced and each removed readiness and named itself.
Schema compatibility is evaluated against real applied migrations with four of
five verdicts observed in the run (`MATCHED`, `STALE`, `AHEAD`, `DIVERGED`), only
one of which permits readiness. Dependency readiness names the failing
dependency rather than reporting a generic failure.

**Traffic activation (G11).** Traffic is an explicit act, not a side effect of a
process starting. Three refusal reasons were exercised —
`NOT_AUTHORITATIVELY_READY`, `TRAFFIC_DISABLED`, `TRAFFIC_SHED` — and each names
which half of the admission decision refused. The four states _process alive_,
_service ready_, _authoritatively ready_ and _traffic-enabled_ are separately
observable on four endpoints.

**Observability (G14, G15, G16).** Thirty-nine telemetry fields composed from the
accepted OPS-01 registry plus the twelve OPS-02 fields, with a composition guard
that refuses a differing redeclaration of an inherited field rather than
silently taking the newer one — a guard that fired during development on
`release_identity` and was resolved by removing the OPS-02 redeclaration, not by
widening the rule. Nine injection attempts against the emitter were refused. The
correlation audit over 40 observations found 40 distinct values, no global person
key, no value spanning domains and no value spanning requests. The voting linkage
probe reports `linkage_possible: false`, with a positive control that the probe
detects.

**Alerts (G17, G18, G19).** Eight service level objectives, seven of them
critical, each bound to an owning role in the accepted OPS-01 separation-of-duties
matrix, an existing OPS-RB runbook, a known severity and a stated operator
action. The loader refuses an unknown owner, an unknown runbook or an unknown
severity at load time. All eight objectives fired against the running environment
across the six required alert classes, and every firing produced an owner, a
runbook and an action. Ownership spans four roles with no universal owner.

**Backup and restore (G20, G21, G22).** A real `pg_dump` against PostgreSQL
16.15 produced a 12,945-byte dump with a recorded SHA-256. The database was then
actually destroyed and actually restored. A tampered backup is refused rather
than restored. A destructive restore requires an approver who is not the
executor. The restored content is verified against what was backed up rather
than success being inferred from a completed command, and the hash-chained
operational evidence ledger still verifies after the restore.

**Rollback (G23, G24).** A failed deployment does not promote its candidate. A
regression discovered after readiness rolls back to a prior release identified by
digest — `rel-A-known-good` — not by version string.

**Reset (G25).** Environment reset is a first-class lifecycle operation with its
own authorization and change record. After reset the service is not running, the
deploy root is absent and the schema is gone; the phase is `RESET` and the
environment cannot be activated from there.

**Failure injection (G26, G27, G29).** Dependency loss moves the environment to
`DEGRADED`, refuses consequential traffic and fabricates no success value.
Authoritative-time loss removes readiness and refuses consequential traffic with
reason `NOT_AUTHORITATIVELY_READY`. Overload offered 400 units against a bounded
queue of capacity 64: 163 accepted, 237 shed explicitly with reason `QUEUE_FULL`,
maximum depth 64, no unbounded growth. Those are exercise numbers, not capacity
measurements.

**Incident and change control (G28, G30, G31, G32, G33).** Nine incident
scenarios executed end to end. A credential incident marks a secret compromised,
which removes readiness, and rotation restores it; no secret value appears in any
evidence document. Every successful consequential transition carries a change
identifier, and an unrecorded mutation is detected. The separation-of-duties
audit covers 16 roles and 8 incompatible pairs, with no role holding an
incompatible pair and no universal operator. A voting-sensitive incident was
closed without introducing any identifier.

**Freeze and packaging (G40, G41, G42).** A freeze manifest over every governed
file; a tree digest identical before and after the whole gate suite, with no file
added, removed or changed; a package dry run whose members all verify against the
manifest; and a scan of every OPS-02 artefact — including this document — for a
self-acceptance claim. The exact file count and digests are in
`OPS02_C1_CANDIDATE_IDENTITY.json`, not restated here, because a document that
restates its own tree's digest is a document that is wrong after the next edit.

## 7. Preview readiness

Overall status: **`TECHNICALLY_READY_BUT_BLOCKED_BY_API`**

Nineteen prerequisites: 15 implementation prerequisites all `PASS`, 0
implementation-blocked, 4 governance-decision prerequisites blocked.

- **API blockers (3):** `PRQ-API-01` (API-06 not accepted), `PRQ-API-02` (API layer
  not closed), `PRQ-GOV-02` (System Trial Preview not open, which depends on the
  first two).
- **INFRA blockers (0).**
- **OPS blockers (1):** `PRQ-GOV-01` — no explicit INFRA/OPS preview-readiness
  minimum has been recorded in canonical governance. A stage cannot write its own
  entry condition, so this is reported as blocked rather than satisfied.

The canonical path remains: API-06 authoritative acceptance → API layer CLOSED →
an explicit recorded INFRA/OPS preview-readiness minimum → SYSTEM TRIAL PREVIEW.
OPS-02 sits before the first step. A dependency block is not a technical failure
and is not reported as one; equally, the technical readiness of the OPS-02
implementation does not shorten that path by one step.

## 8. BSI readiness

Result: `PASS_WITH_EXPLICIT_EXISTING_DEFERRED_GAPS`

- Touched rows (10): M-02, M-03, M-11, M-16, M-17, M-19, M-20, M-25, M-27, M-30
- Improved rows: 8, all `PARTIALLY_IMPROVED` — M-03, M-11, M-16, M-17, M-19,
  M-20, M-25, M-27. M-11 is additionally recorded as
  `PRESERVED_AND_OPERATIONALLY_STRENGTHENED` against OPS-01 C2.
- Unchanged rows: M-02 (`UNCHANGED`, still RED / P0 — operating a preview
  environment does not touch the evaluator question about non-identifying
  election-scoped eligibility representation) and M-30.
- Unchanged deferred gaps: all nine OPS-01 C2 bindings preserved and open —
  `OPS01-BSI-M02-P0`, `OPS01-BSI-M03-PROD-AUTH`, `OPS01-BSI-M16-TIME-AUDIT`,
  `OPS01-BSI-M17-AUDIT-PROTECTION`, `OPS01-BSI-M19-SECURE-STATE`,
  `OPS01-BSI-M20-MGMT`, `OPS01-BSI-M25-CM`, `OPS01-BSI-M27-AGD`,
  `OPS01-BSI-M30-TR03169`.
- New blockers introduced: **none**
- Certification claim: **`NONE`**

The disposition builder refuses to record an improvement against a row whose
supporting gates did not pass, and refuses to record any row as CLOSED. No BSI,
Common Criteria or EAL4 certification is claimed, requested or implied by this
stage, and no stronger EPD² invariant inherited from OPS-01 C2 was relaxed to
match a certification expectation.

## 9. FIR disposition

Ten FIRs reassessed, recorded in `docs/ops/OPS-02/OPS02_FIR_DISPOSITION.json`.

- Implemented by OPS-02: **0**
- Partially advanced: **9** — FIR-OPS-001, FIR-READY-001, FIR-REL-001,
  FIR-TIME-001, FIR-CRYPTO-001, FIR-DATA-004, FIR-RES-001, FIR-LIFE-001,
  FIR-TEST-001
- Deferred to a later stage: **0**
- Intentionally unchanged: **1** — FIR-VOTE-BSI-001
- New FIRs discovered: **0**
- Status changes requested: **0**

The only movement between the OPS-01 and OPS-02 dispositions is FIR-CRYPTO-001,
from `DEPENDENCY_ONLY` to `PARTIALLY_ADVANCED`, and only on the operational half:
a preview environment now has a governed way to declare, require, redact and
invalidate a secret without ever holding one. FIR-READY-001 is the FIR this stage
advanced furthest, because readiness moved from a modelled state machine to a
property of a running environment read back over HTTP. No FIR status is promoted
and the Master Future Implementation Register is not edited by this stage.

## 10. Known limitations

See `docs/ops/OPS-02/OPS02_KNOWN_LIMITATIONS.md` — twenty limitations with owner,
reason, required closure stage, required evidence and blocking class. The
significant ones: the System Trial Preview cannot be opened while API-06 is
unaccepted; no preview-readiness minimum is recorded in governance; the topology
is a single host, so capacity and recovery-time figures are exercise numbers and
not objectives; no secret store, key lifecycle or trusted time source exists; and
the mutation suite is assurance of the OPS-02 verifier, not of the platform.

## 11. Final developer handoff state

```text
OPS02_RESULT:
IMPLEMENTATION_COMPLETE
LOCAL_VERIFICATION_PASS
PRESEAL_READY
NOT_ACCEPTED
```

State: `IMPLEMENTED + PRESEAL VERIFIED + SEALED + READY FOR INDEPENDENT GOVERNED REVIEW`

## 12. Explicit non-acceptance

This stage is **not accepted**. The OPS layer is **not closed**. The System Trial
Preview is **not open** and is not declared openable. Nothing here is
production-ready, security-certified, BSI-, Common-Criteria- or EAL4-certified,
or legally activated. No real vote, no real personal data and no legal effect is
authorised by anything in this candidate.

The candidate does not accept itself. Gate G42 scans every OPS-02 artefact for a
self-acceptance claim on every run, including this document, and the archive
carries `CANDIDATE_NOT_ACCEPTED` as a member file.

Only an independent governed verification, receiving the exact candidate bytes
and running the canonical harness on them, may move OPS-02 from
`PRESEAL / NOT ACCEPTED` to `ACCEPTED`. Even then, OPS-02 acceptance would not
close the OPS layer and would not open the System Trial Preview: the Program
Control Register orders those after API-06 acceptance and API layer closure, and
no developer, workflow or document may invent that transition.


## C2 canonical-freshness reconciliation

C2 changes no OPS-02 runtime control. The exact C1 implementation delta was replayed without overlap onto canonical main `2b840017e8cdabcb9af78e3ae25f79e7e75c73f8`. API-05 is active; API-06 and API-layer closure remain governance prerequisites for opening the System Trial Preview.
