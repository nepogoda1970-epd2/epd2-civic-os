# INFRA-02 — Acceptance Matrix

Every governed check of the canonical acceptance path, its authority and its
evidence. The canonical command is `uv run python -m scripts.acceptance run`;
registry version `2.0.0` (`scripts/acceptance/check_registry.json`). The 43
accepted INFRA-01 checks are preserved unchanged; INFRA-02 adds the 8-check
mandatory `release-supply-chain` stage for 51 total. A mandatory check can
never silently disappear: the execution manifest must account for every
registry entry, and `verify_mandatory_gates` additionally refuses a registry
from which any INFRA-02 gate has been removed or demoted (M18).

## 1. Inherited INFRA-01 checks (43, preserved)

| Stage                                                                          | Checks                                                                                                                           | Status in INFRA-02                                                                         |
| ------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| bootstrap                                                                      | identity, tools, registry-integrity, frozen-pre-test                                                                             | preserved                                                                                  |
| verify-governance                                                              | canonical-registers, freshness-reconciliation, pilot-roadmap-lock                                                                | preserved (reconciliation regenerated against the current target with truthful timestamps) |
| verify-repository                                                              | required-paths, forbidden-paths, version-consistency, canon-0-8-0                                                                | preserved (required paths extended with every INFRA-02 file)                               |
| verify-dependencies                                                            | uv-sync-frozen, npm-ci, locks-unchanged                                                                                          | preserved                                                                                  |
| verify-backend                                                                 | ruff-format, ruff-lint, mypy, pytest, security-suites                                                                            | preserved                                                                                  |
| verify-frontend                                                                | prettier, typecheck ×2, eslint, tests ×2                                                                                         | preserved                                                                                  |
| verify-build / verify-browser / verify-accessibility / verify-visual           | next-build, playwright, a11y, visual                                                                                             | preserved                                                                                  |
| verify-secrets / verify-frozen-artifacts / verify-boundaries / verify-evidence | tree-scan, frozen post-test, non-ownership, evidence reconciliation                                                              | preserved                                                                                  |
| freeze / package / verify-package                                              | preconditions, inventory, frozen-pre-package, build, byte-identity, hygiene, frozen-in-archive, secret-scan, evidence-sanitation | preserved                                                                                  |
| emit-manifest                                                                  | manifest.emit                                                                                                                    | preserved                                                                                  |

## 2. INFRA-02 release-supply-chain stage (8, new, all mandatory)

| Check                             | Hard invariants                                                      | Detector authority                                                                                                                                                                                                                                                                                                                                 | Evidence                                                                                                                                         |
| --------------------------------- | -------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| `supplychain.ci-policy`           | HI-01, HI-02, M04/M05/M16/M17/M18                                    | `scripts/infra02/ci_policy.py`, `supply_chain_policy.json` (schema-validated), `verify_mandatory_gates`                                                                                                                                                                                                                                            | check log                                                                                                                                        |
| `supplychain.dependency-sources`  | HI-07, M03 support                                                   | `scripts/infra02/dependencies.py` over exact `uv.lock` / `package-lock.json`                                                                                                                                                                                                                                                                       | check log                                                                                                                                        |
| `supplychain.vulnerability-gate`  | HI-08, M12/M13/M21                                                   | `scripts/infra02/vulnerability.py`: pip-audit + npm audit over the exact frozen locks; governed exceptions file (schema-validated); scan evidence bound to exact lock digests; scanner unavailability → BLOCKED, never PASS                                                                                                                        | `RELEASE/VULNERABILITY-SCAN-EVIDENCE.json`, check log                                                                                            |
| `supplychain.history-secret-scan` | HI-09, M14                                                           | `scripts/infra02/history_scan.py`: every blob reachable from governed publishable refs plus the candidate HEAD, INFRA-01 detector set + line-pinned allowlist                                                                                                                                                                                      | `RELEASE/HISTORY-SECRET-SCAN.json`, check log                                                                                                    |
| `release.identity`                | HI-03/HI-04/HI-05/HI-06/HI-07/HI-13, M01/M02/M06/M07/M08/M09/M19/M22 | `scripts/infra02/{release,sbom,provenance,stage}.py`: content-addressed store, CycloneDX 1.5 SBOM verified in reverse, sealed in-toto/SLSA provenance verified against trusted builders, sealed deployment manifest, sealed release manifest fully cross-verified; includes a live build-once negative control                                     | `RELEASE/SBOM.cdx.json`, `RELEASE/PROVENANCE.intoto.json`, `RELEASE/DEPLOYMENT-MANIFEST.json`, `RELEASE/RELEASE-MANIFEST.json`, `RELEASE/store/` |
| `release.promotion-by-digest`     | HI-10/HI-12, M10/M11/M20                                             | `scripts/infra02/promotion.py`: development → test → staging promoted by digest with re-verification; production attempt without an independent governance acceptance record must be REFUSED (the refusal is the PASS condition); rollback to a previously verified environment succeeds, rollback to a never-promoted environment must be refused | `RELEASE/PROMOTION-DRILL.json`, sealed promotion records in `RELEASE/store/promotions/`                                                          |
| `release.drift-detection`         | HI-11                                                                | `scripts/infra02/promotion.py::detect_drift`: truthful environment fixture must be drift-free AND a tampered fixture must be detected — a dead detector fails the check                                                                                                                                                                            | `RELEASE/DRIFT-CHECK.json`                                                                                                                       |
| `release.evidence-sanitation`     | M15 boundary                                                         | INFRA-01 sanitation detectors over everything the stage wrote, logs included                                                                                                                                                                                                                                                                       | check log                                                                                                                                        |

## 3. Result-state semantics

Fail-closed inherited from INFRA-01 and extended: `PASS` only for executed,
evidence-backed success; `FAIL` for any substantive finding; `BLOCKED` when
a required tool/network dependency is unavailable (e.g. vulnerability
scanners) — never PASS, and distinct from FAIL; `NOT_APPLICABLE_GOVERNED`
only by governed declaration. `PASS WITH ENVIRONMENT LIMITATION` does not
exist. Exit code 0 is issued only for a complete fail-closed PASS, and the
result always carries: LOCAL CANONICAL HARNESS RESULT ONLY — EXTERNAL
GOVERNED ACCEPTANCE NOT PERFORMED — NOT PRODUCTION READY — NOT LEGALLY
ACTIVATED.

## 4. Mutation coverage (M01–M22)

`tests/repository/test_infra02_mutation_suite.py` corrupts a representative
input for every class M01–M22 and asserts the exact detector code; a closing
test proves the twenty-two classes map onto twenty-two distinct `I02_*`
detectors — no shared poison marker. `tests/repository/test_infra02_units.py`
covers every remaining detector, refusal path and governed document.
INFRA-01's suites (63 tests) are preserved unchanged.
