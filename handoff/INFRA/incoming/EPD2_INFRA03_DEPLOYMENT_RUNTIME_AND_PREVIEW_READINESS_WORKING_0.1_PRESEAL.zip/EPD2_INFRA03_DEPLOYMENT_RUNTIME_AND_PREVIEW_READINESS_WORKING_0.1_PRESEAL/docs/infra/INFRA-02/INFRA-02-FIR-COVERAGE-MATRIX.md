# INFRA-02 — FIR Coverage Matrix

Conservative dispositions per assignment §14. No FIR status is promoted by
assertion; "implemented" is claimed only where the requirement is genuinely
proven inside INFRA-02's bounded scope.

## FIR IDs advanced (substantial implementation/foundation, NOT fully implemented)

| FIR                                                                                       | INFRA-02 contribution                                                                                                                                                                                                                                                                                                                                                                | Why not "fully implemented"                                                                                                                                                                      |
| ----------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `FIR-REL-001` — Release, Deployment & Environment Integrity                               | Sealed release manifest binding source/builder/locks/toolchain/artifacts/SBOM/provenance and the INFRA-01 deployment-manifest identity; content-addressed build-once store; promotion-by-digest with ordered environments and production unreachable from CI-green; drift detection; rollback-to-verified-artifact evidence; emergency promotion requires the mandatory audit record | Source-to-running-instance provenance on real production infrastructure, provider selection, and production acceptance criteria are not provable before INFRA-03..07; no environment is deployed |
| `FIR-SEC-SECRET-001` — Repository Secret Leakage Prevention & Public-Release Sanitization | History/ref release gate: every blob reachable from the governed publishable refs scanned with the accepted detector set and line-pinned allowlist; evidence records exact refs/commits/blobs; rotation-not-rewrite remediation doctrine; release-stage evidence sanitation added                                                                                                    | The complete public-release boundary (all future publication channels, org-wide scope beyond this repository) is not proven by one repository's CI enforcement                                   |

## FIR IDs reused/integrated only

| FIR                                                                         | Treatment                                                                                                                                                                                                                                                                 |
| --------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `FIR-READY-001` — Runtime Readiness, Compatibility & Stale-State Protection | Reused as accepted from INFRA-01 (readiness contract evaluator, compatibility rules); the release manifest binds compatibility results and the drift detector enforces the mixed-version matrix rule. Production launch and live readiness probes remain outside INFRA-02 |

## FIR IDs preserved / intentionally unchanged

| FIR                              | Treatment                                                                                                                                                                                     |
| -------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `FIR-INFRA-SOV-001`              | Preserved provider-neutral; the deployment manifest carries the sovereignty profile unchanged; no hosting-provider decision is made                                                           |
| `FIR-SEC-004`                    | Preserved; CI least-privilege permissions enforced per workflow class, but production operator access model remains later governed work                                                       |
| `FIR-TRUST-002`, `FIR-TRUST-003` | Preserved; production credential/key custody authority remains INFRA-03/later governed work — INFRA-02 ships only the content-integrity seal and an explicitly TEST-ONLY ephemeral-key signer |
| `FIR-VOTE-BSI-001`               | Preserved exactly; no certification claim; PACK-16 frozen artifacts untouched (verified by the inherited frozen-artifact gates at five points)                                                |
| `FIR-OSS-001` / `FIR-OSS-007`    | Untouched: the SBOM declares no license compliance; OSS/legal review boundaries stay where governance put them                                                                                |

## FIR IDs deferred

| FIR / concern                                                                 | Deferred to                                                                                                                  |
| ----------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| Production signing keys, HSM/KMS, PKI lifecycle                               | INFRA-03                                                                                                                     |
| Origin/network segmentation, ingress/egress isolation, voting-origin topology | INFRA-04                                                                                                                     |
| Observability/SLO/alerting                                                    | INFRA-05                                                                                                                     |
| Backup/recovery infrastructure                                                | INFRA-06                                                                                                                     |
| Production Infrastructure Baseline declaration                                | INFRA-07                                                                                                                     |
| PACK-16 ceremony-artifact reproducibility proof (IM-33)                       | explicitly left open; declared `NOT_BUILT_BY_INFRA02_IM33_LEFT_EXPLICITLY_OPEN` in the governed reproducibility declarations |

## New FIR IDs created by implementation discovery

None. Implementation discoveries were resolvable inside the existing
governed requirements; the honest gaps are recorded in
`INFRA-02-KNOWN-LIMITATIONS.md` rather than promoted into new FIR IDs the
governance owner has not reviewed.

## PACK-16 supply-chain requirements (assignment §5.5)

The stricter existing PACK-16 requirements (IM-33..IM-38) are neither
relaxed nor re-implemented here: frozen reference artifacts remain byte-pinned
by the inherited INFRA-01 gates, and the INFRA-02 reproducibility
declarations explicitly refuse to claim ceremony-artifact reproducibility
(IM-33 open). Voting-critical dependency handling keeps its existing
stronger constraints; the 5 Python vulnerability exceptions covering the
frozen `cryptography`/`pytest` pins are time-bounded to 2026-11-30 and
justified per advisory in `scripts/infra02/vulnerability_exceptions.json`.
