# INFRA-02 — File Inventory

Every file added or modified by INFRA-02 relative to the exact accepted
INFRA-01 C3 predecessor (ZIP SHA-256
`5cd90da141056badc38ee3fb34f2d648002ace5b87c6a0cce1d331431364b131`), with
its purpose. The byte-exact machine-readable delta, including generated
sealing metadata, is `INFRA01_C3_TO_INFRA02_EXACT_INVENTORY.json` in this
directory and is verifiable with `scripts.acceptance verify-delta`.

## Added — supply-chain implementation (`scripts/infra02/`)

| File                                                           | Purpose                                                                                                                                                                                                                                |
| -------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `scripts/infra02/__init__.py`                                  | package identity (`EPD2-INFRA02-SUPPLY-CHAIN`, version)                                                                                                                                                                                |
| `scripts/infra02/codes.py`                                     | the `I02_*` detector-code namespace (39 distinct fail-closed codes)                                                                                                                                                                    |
| `scripts/infra02/supply_chain_policy.json`                     | the single governed supply-chain policy: workflow trust classes/rules, action pin map, trusted builders, toolchain series, base-image policy, dependency sources, publishable refs, vulnerability policy, reproducibility declarations |
| `scripts/infra02/ci_policy.py`                                 | HI-01/HI-02 workflow validation against the policy                                                                                                                                                                                     |
| `scripts/infra02/sbom.py`                                      | HI-05 CycloneDX 1.5 SBOM generation from the frozen locks + reverse completeness/subject verification                                                                                                                                  |
| `scripts/infra02/provenance.py`                                | HI-06 in-toto/SLSA provenance build + fail-closed verification; TEST-ONLY signer                                                                                                                                                       |
| `scripts/infra02/dependencies.py`                              | HI-07 dependency source/integrity governance + SBOM reconciliation                                                                                                                                                                     |
| `scripts/infra02/vulnerability.py`                             | HI-08 scanners, governed exceptions, gate evaluation, scan-evidence lock binding                                                                                                                                                       |
| `scripts/infra02/vulnerability_exceptions.json`                | the 16 governed, narrow, owned, justified, expiring exceptions                                                                                                                                                                         |
| `scripts/infra02/history_scan.py`                              | HI-09 publishable-ref history secret gate                                                                                                                                                                                              |
| `scripts/infra02/release.py`                                   | HI-03/HI-04 content-addressed release store, sealed release manifest build + verification                                                                                                                                              |
| `scripts/infra02/promotion.py`                                 | HI-10/HI-11/HI-12 promotion state machine, drift detection, rollback                                                                                                                                                                   |
| `scripts/infra02/stage.py`                                     | the release-supply-chain pipeline stage: check implementations, evidence writers, mandatory-gate guard, evidence sanitation                                                                                                            |
| `scripts/infra02/schemas/release_manifest.schema.json`         | release-manifest schema (strict, all bindings required)                                                                                                                                                                                |
| `scripts/infra02/schemas/build_provenance.schema.json`         | provenance-statement schema                                                                                                                                                                                                            |
| `scripts/infra02/schemas/promotion_record.schema.json`         | promotion-record schema                                                                                                                                                                                                                |
| `scripts/infra02/schemas/supply_chain_policy.schema.json`      | policy schema                                                                                                                                                                                                                          |
| `scripts/infra02/schemas/vulnerability_exceptions.schema.json` | exceptions schema                                                                                                                                                                                                                      |

## Added — workflow, tests, docs

| File                                                             | Purpose                                                                                                                                                                    |
| ---------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `.github/workflows/infra02-acceptance.yml`                       | authoritative-release workflow invoking the same canonical harness; SHA-pinned actions, least-privilege token, full-history checkout, target-authority reconciliation step |
| `tests/repository/test_infra02_units.py`                         | unit suite for every remaining detector, refusal path and governed document                                                                                                |
| `tests/repository/test_infra02_mutation_suite.py`                | mutation suite M01–M22, each class asserting its own distinct detector, plus positive controls and the distinctness proof                                                  |
| `docs/infra/INFRA-02/INFRA-02-STAGE-CONTRACT.md`                 | stage contract (this directory)                                                                                                                                            |
| `docs/infra/INFRA-02/INFRA-02-ACCEPTANCE-MATRIX.md`              | check/evidence matrix                                                                                                                                                      |
| `docs/infra/INFRA-02/INFRA-02-FIR-COVERAGE-MATRIX.md`            | conservative FIR dispositions                                                                                                                                              |
| `docs/infra/INFRA-02/INFRA-02-IMPLEMENTATION-REPORT.md`          | implementation report                                                                                                                                                      |
| `docs/infra/INFRA-02/INFRA-02-KNOWN-LIMITATIONS.md`              | honest limitations                                                                                                                                                         |
| `docs/infra/INFRA-02/INFRA-02-FILE-INVENTORY.md`                 | this file                                                                                                                                                                  |
| `docs/infra/INFRA-02/INFRA02_GOVERNANCE_RECONCILIATION.json`     | sealed stage-level reconciliation: target authority, controlling-file identities, predecessor binding (non-competing with the harness-checked INFRA-01 record)             |
| `docs/infra/INFRA-02/INFRA01_C3_TO_INFRA02_EXACT_INVENTORY.json` | byte-exact predecessor→candidate delta inventory                                                                                                                           |

## Added — imported governance records (from the target authority overlay)

| File                                                            | Purpose                                                                           |
| --------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| `docs/api/API-04/API04_C1_ACCEPTANCE_RECORD.json`               | API-04 C1 acceptance record referenced by the current register                    |
| `docs/frontend/FRONT-04-C2-ACCEPTANCE-RECORD.json`              | FRONT-04 C2 acceptance record                                                     |
| `docs/infra/INFRA-01/INFRA01_C3_ACCEPTANCE_RECORD.json`         | the predecessor's own acceptance record — the exact identity INFRA-02 builds from |
| `docs/ops/OPS-01/OPS01_C2_ACCEPTANCE_RECORD.json`               | OPS-01 C2 acceptance record                                                       |
| `docs/ops/OPS-01/OPS01_C2_AUTHORITATIVE_ACCEPTANCE_RESULT.json` | OPS-01 C2 authoritative run result                                                |
| `docs/ops/OPS-01/OPS01_C2_BSI_READINESS_DISPOSITION.json`       | OPS-01 C2 BSI readiness disposition                                               |

## Modified

| File                                                         | Change                                                                                                                                                   |
| ------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `scripts/acceptance/check_registry.json`                     | registry `1.1.0` → `2.0.0`: adds the mandatory 8-check `release-supply-chain` stage; all 43 INFRA-01 checks unchanged                                    |
| `scripts/acceptance/__main__.py`                             | candidate name `EPD2_INFRA02_CI_CD_AND_SOFTWARE_SUPPLY_CHAIN_CANDIDATE_0.1`; wires the 8 stage handlers; BLOCKED-code mapping for the vulnerability gate |
| `scripts/acceptance/executor.py`                             | `internal_result` gains `blocked_codes`: findings that all represent inability-to-execute yield BLOCKED — never PASS, distinct from FAIL                 |
| `scripts/check_repository.py`                                | required-path registry extended with every INFRA-02 file (a mandatory piece of the release path cannot silently disappear)                               |
| `.github/workflows/infra01-acceptance.yml`                   | external actions SHA-pinned per the governed pin map; candidate-upload path follows the harness's current candidate name                                 |
| `.github/workflows/pilot-roadmap-guard.yml`                  | explicit least-privilege `permissions: contents: read`                                                                                                   |
| `docs/roadmap/EPD2_PROGRAM_CONTROL_REGISTER.md`              | target register content plus the INFRA-02 parallel working-state transition (INFRA row, transition record, parallel-action paragraph)                    |
| `docs/roadmap/EPD2_MASTER_FUTURE_IMPLEMENTATION_REGISTER.md` | imported from the target authority verbatim in content (frozen-formatter normalized)                                                                     |
| `docs/infra/INFRA-01/INFRA01_GOVERNANCE_RECONCILIATION.json` | regenerated against the seal-time target with truthful timestamps and updated region-anchored current-state facts                                        |

(`docs/roadmap/EPD2_PROJECT_ENTRYPOINT.md` was also reconciled against the
target; after the candidate's frozen-formatter normalization its bytes equal
the accepted C3 predecessor's, so the exact delta correctly counts it as
unchanged.)

Generated sealing metadata inside the candidate archive (`SHA256SUMS.txt`,
`ACCEPTANCE/FREEZE-INVENTORY.json`) is classified as generated metadata in
the exact delta inventory but is never excluded from path or count
accounting.
