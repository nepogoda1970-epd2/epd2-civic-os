# INFRA-02 — Implementation Report

**Stage:** INFRA-02 — CI/CD & Software Supply-Chain Integrity
**Candidate:** `EPD2_INFRA02_CI_CD_AND_SOFTWARE_SUPPLY_CHAIN_CANDIDATE_0.1`
**Self-state:** `LOCAL VERIFICATION ONLY / CANDIDATE_NOT_ACCEPTED / PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`

## 1. Source line

Per the assignment's source-line rule, this candidate was built from the
exact accepted INFRA-01 C3 predecessor — ZIP SHA-256
`5cd90da141056badc38ee3fb34f2d648002ace5b87c6a0cce1d331431364b131`
(15,854,311 bytes), source commit
`38f7d13c8badf911e61d659adb2905d1089a64a5`, tree
`3036aa886ca554607fec67f74ab753d41c7dbd5b` — not from canonical `main`,
which is a governance authority overlay, not the source predecessor. Before
work began, a checkout of the source commit reproduced the recorded source
tree, tracked-file manifest digest and freeze tree digest
`d022822dbf3a127919595848cc7688053b2601210c56fa9d01aed54172fd4db6`
byte-exactly. Governance was read live from `main` at development start and
re-reconciled against the then-current target immediately before final seal;
the sealed proofs are `docs/infra/INFRA-01/INFRA01_GOVERNANCE_RECONCILIATION.json`
(harness-checked) and `docs/infra/INFRA-02/INFRA02_GOVERNANCE_RECONCILIATION.json`
(stage-level, with per-file target/candidate identities).

## 2. What was built

One governed policy file, ten Python modules, five schemas, one workflow,
two test suites and this documentation set — integrated as the mandatory
`release-supply-chain` stage of the _same_ canonical acceptance command
(`uv run python -m scripts.acceptance run`, registry `2.0.0`). No second
acceptance implementation exists; GitHub Actions
(`.github/workflows/infra02-acceptance.yml`) invokes the identical harness.

Per hard invariant: CI trust classes with fail-closed classification and the
`pull_request_target` prohibition in every class (HI-01); a governed action
pin map of immutable 40-hex commit SHAs, toolchain series pins and a
no-container-base-image release-path policy (HI-02); a content-addressed
release store in which a release id is built once and re-registration with
different bytes is refused (HI-03); a sealed release manifest binding
source, builder, lock digests, toolchain, artifact digests, SBOM and
provenance digests, deployment-manifest identity, contract versions,
migration set, configuration identity, INFRA profile, acceptance evidence,
reproducibility declarations and activation state (HI-04); a CycloneDX 1.5
SBOM generated from the exact frozen locks — 604 components with versions,
PURLs, origins and integrity material — and verified in reverse (HI-05); a
sealed in-toto Statement v1 with SLSA provenance verified against the
governed trusted-builder set, with the signing boundary explicitly at
INFRA-03 (HI-06); dependency source/integrity governance over both lock
formats with SBOM reconciliation (HI-07); a vulnerability gate whose rule is
`ANY_FINDING_WITHOUT_GOVERNED_EXCEPTION`, with 16 narrow, owned, justified
exceptions expiring 2026-11-30, and BLOCKED — never PASS — on scanner
unavailability (HI-08); a Git-history secret gate over every blob reachable
from the governed publishable refs, reusing the accepted detector set and
line-pinned allowlist (HI-09); a promotion state machine over
`development → test → staging → production` in which every promotion
re-verifies stored bytes against the attested digest, staging+ requires
bound acceptance evidence and production additionally requires an
independent governance acceptance record (HI-10); deterministic drift
detection with a live tamper negative control (HI-11); rollback that only
selects previously verified immutable artifacts, and emergency promotion
that fails without the mandatory audit/reconciliation record (HI-12);
governed reproducibility declarations that fail closed on overclaiming
(HI-13); and truthful builder identity plus the production-promotion refusal
implementing no-self-acceptance (HI-14).

## 3. Key design decisions

**One policy authority.** Everything the supply chain governs — classes,
pins, builders, toolchain, registries, refs, vulnerability policy,
reproducibility — lives in `scripts/infra02/supply_chain_policy.json`,
schema-validated and required-path-protected. Changing the release policy is
a tracked, hashed, governed change; there is no second place to look.

**Refusals are exercised, not assumed.** The pipeline's promotion drill
attempts the forbidden production promotion and PASSES only if it is
refused; the drift check tampers a digest and PASSES only if the tampering
is detected; the release-identity check attempts a same-id rebuild and
PASSES only if it is refused. A dead detector is itself a FAIL.

**BLOCKED is a first-class state.** `internal_result` now accepts a
blocked-code set: when every finding of a check represents inability to
execute (scanner/network unavailability), the state is BLOCKED — never PASS,
and distinct from a substantive FAIL. This extends the INFRA-01 rule
"test executed and passed ≠ test did not execute" to the supply-chain gates.

**Locks are identity, not churn.** The frozen dependency locks are part of
the accepted predecessor and of the release identity; known advisories
against them are governed by explicit, expiring exceptions instead of a
lock upgrade smuggled into an infrastructure round.

**Truthful time.** Both reconciliation records carry real generation
timestamps and the target commit's committer timestamp;
`reconciled_at >= target_commit_timestamp` is mechanically enforced
(INFRA01-C2-02 inheritance), and the target was re-fetched immediately
before seal.

## 4. Testing

`tests/repository/test_infra02_mutation_suite.py`: 34 tests — every
mutation class M01–M22 corrupted and caught by its own detector, positive
controls (clean release verifies, clean promotion reaches staging, clean
pinned workflow passes, the real registry declares every gate), and the
proof that the 22 classes map onto 22 distinct `I02_*` codes.
`tests/repository/test_infra02_units.py`: 49 tests — every remaining
detector and refusal path, the governed policy/exception documents against
their schemas, the real repository's workflows/dependencies/SBOM, blocked
semantics, and the TEST-ONLY signer boundary. The inherited INFRA-01 suites
(63 tests) pass unchanged; the full backend/frontend/browser registry
checks run in the canonical pipeline as before.

## 5. Evidence

Each canonical run writes, in addition to the INFRA-01 evidence bundle:
`RELEASE/SBOM.cdx.json`, `RELEASE/PROVENANCE.intoto.json`,
`RELEASE/DEPLOYMENT-MANIFEST.json`, `RELEASE/RELEASE-MANIFEST.json`,
`RELEASE/VULNERABILITY-SCAN-EVIDENCE.json` (bound to exact lock digests),
`RELEASE/HISTORY-SECRET-SCAN.json` (exact refs/commits/blobs),
`RELEASE/PROMOTION-DRILL.json`, `RELEASE/DRIFT-CHECK.json`, the
content-addressed `RELEASE/store/` with sealed promotion records, and a
per-check execution log. The sealed execution manifest accounts for all 51
registry checks.

## 6. Honest limitations

See `INFRA-02-KNOWN-LIMITATIONS.md` — in particular: no real deployed
environments (the governed mechanism is proven, production is refused, not
reached); TEST-ONLY signing pending INFRA-03 key custody; candidate-ZIP
byte-reproducibility not yet proven (declared, not overclaimed); the
vulnerability gate's dependence on live advisory data; and the expiry of all
16 governed exceptions on 2026-11-30.

## 7. Result semantics

A PASS of this candidate anywhere is a local/canonical harness execution
result on the exact tested commit. EXTERNAL GOVERNED ACCEPTANCE: NOT
PERFORMED. NOT PRODUCTION READY. NOT LEGALLY ACTIVATED. No developer-created
acceptance record exists; acceptance is exclusively the independent
reviewer's post-run governance decision (assignment §20).
