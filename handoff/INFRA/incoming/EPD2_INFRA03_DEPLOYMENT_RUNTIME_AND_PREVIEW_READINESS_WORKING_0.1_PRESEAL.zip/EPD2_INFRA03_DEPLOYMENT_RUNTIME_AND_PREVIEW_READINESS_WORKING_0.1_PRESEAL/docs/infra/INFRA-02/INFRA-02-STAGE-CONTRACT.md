# INFRA-02 — CI/CD & Software Supply-Chain Integrity — Stage Contract

**Stage state:** `PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`
**Predecessor:** exact accepted INFRA-01 C3 candidate
`EPD2_INFRA01_CI_ACCEPTANCE_HARNESS_CANDIDATE_0.1_C3.zip`, SHA-256
`5cd90da141056badc38ee3fb34f2d648002ace5b87c6a0cce1d331431364b131`
(source commit `38f7d13c8badf911e61d659adb2905d1089a64a5`, tree
`3036aa886ca554607fec67f74ab753d41c7dbd5b`, freeze tree digest
`d022822dbf3a127919595848cc7688053b2601210c56fa9d01aed54172fd4db6`).
**Assignment:** `EPD2_INFRA02_CI_CD_AND_SUPPLY_CHAIN_IMPLEMENTATION_ASSIGNMENT_v1.0.md`.

## 1. What this stage is

INFRA-02 turns the accepted INFRA-01 acceptance harness into a governed
release path: from source identity through build inputs, dependency
inventory, SBOM, provenance, release manifest, promotion-by-digest and drift
detection — every step machine-verified, fail-closed, and executed by the
same single canonical command:

```text
uv run python -m scripts.acceptance run
```

There is no second acceptance implementation. INFRA-02 adds one mandatory
stage, `release-supply-chain`, to the canonical check registry (registry
version `2.0.0`), between archive verification and manifest emission. All 43
INFRA-01 checks are preserved unchanged and additively extended to 51.

## 2. Hard invariants and where each is enforced

| Invariant                                   | Enforcement                                                                                                                                                                                                                             | Canonical check                                      |
| ------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------- |
| HI-01 trusted vs untrusted CI separation    | `scripts/infra02/ci_policy.py` over `supply_chain_policy.json` workflow classes; unclassified workflows fail closed; `pull_request_target` refused in every class                                                                       | `supplychain.ci-policy`                              |
| HI-02 workflow/action/toolchain pinning     | 40-hex SHA pins declared in the governed pin map; digest-pinned base images (none permitted on this release path); toolchain series pinned                                                                                              | `supplychain.ci-policy`, `release.identity`          |
| HI-03 build-once / promote-by-digest        | content-addressed `ReleaseStore`; re-registering a release id with different artifact bytes is refused; every promotion re-verifies stored bytes                                                                                        | `release.identity`, `release.promotion-by-digest`    |
| HI-04 release manifest + deployment binding | sealed `epd2.infra02.release-manifest/1` binding source, builder, locks, toolchain, artifacts, SBOM/provenance digests and the INFRA-01 deployment-manifest identity (FIR-REL-001)                                                      | `release.identity`                                   |
| HI-05 SBOM                                  | CycloneDX 1.5 generated from the exact frozen locks; completeness verified in reverse; subject bound by SHA-256                                                                                                                         | `release.identity`                                   |
| HI-06 provenance                            | in-toto Statement v1 / SLSA provenance v1; subject, source and builder verified against the governed trusted-builder set                                                                                                                | `release.identity`                                   |
| HI-07 dependency provenance                 | registry-origin allowlist, integrity material required, direct URL/Git refused, SBOM/lock inventory reconciliation                                                                                                                      | `supplychain.dependency-sources`, `release.identity` |
| HI-08 vulnerability gate                    | `ANY_FINDING_WITHOUT_GOVERNED_EXCEPTION`; narrow, owned, justified, time-bounded exceptions only; scanner unavailability is BLOCKED                                                                                                     | `supplychain.vulnerability-gate`                     |
| HI-09 history/ref secret gate               | every blob reachable from the governed publishable refs scanned with the accepted INFRA-01 detector set and line-pinned allowlist                                                                                                       | `supplychain.history-secret-scan`                    |
| HI-10 promotion authorization               | ordered environments `development → test → staging → production`; staging+ requires bound acceptance evidence; production additionally requires an independent governance acceptance record — CI-green alone can never reach production | `release.promotion-by-digest`                        |
| HI-11 drift detection                       | deterministic comparison of environment state against the release manifest, with a live tamper negative control                                                                                                                         | `release.drift-detection`                            |
| HI-12 rollback / emergency evidence         | rollback selects only previously verified immutable artifacts; emergency promotion requires the mandatory audit/reconciliation record                                                                                                   | `release.promotion-by-digest` (+ mutation M20)       |
| HI-13 reproducibility declaration           | per-artifact-class governed declarations; overclaiming beyond proven status fails closed                                                                                                                                                | `release.identity`                                   |
| HI-14 no self-acceptance                    | builder identity is recorded truthfully; the harness refuses production promotion without an independent record; every result carries the non-acceptance disclaimer                                                                     | whole pipeline                                       |

Additionally, `release.evidence-sanitation` closes the stage: no secret
material may persist in any release-stage evidence file (mutation M15), and
`verify_mandatory_gates` refuses a registry from which any governed gate has
been removed or demoted (mutation M18).

## 3. Governed policy authority

`scripts/infra02/supply_chain_policy.json` is the single governed
supply-chain policy: workflow trust classes and rules, the immutable action
pin map, trusted builder identities, toolchain series, base-image policy,
dependency source governance, publishable refs, the vulnerability release
policy and the reproducibility declarations. It is schema-validated
(`supply_chain_policy.schema.json`), tracked, hashed into the freeze
inventory and protected by the required-path registry. Vulnerability
exceptions live only in `scripts/infra02/vulnerability_exceptions.json`
(schema-validated, per-advisory, owned, justified, expiring ≤ 120 days).

## 4. Signing boundary

Production key custody, HSM/KMS and PKI lifecycle are INFRA-03. INFRA-02
seals statements with the content-integrity mechanism and ships a pluggable
signature-verification interface whose only signer is an explicitly
TEST-ONLY HMAC signer with ephemeral per-session keys. No production private
key exists in the repository or CI.

## 5. Explicit non-goals

INFRA-02 does not implement production secrets or key custody (INFRA-03),
network topology/segmentation (INFRA-04), observability/SLO (INFRA-05),
backup/recovery (INFRA-06), or the Production Infrastructure Baseline
(INFRA-07); selects no hosting provider; rewrites no API-04 semantics; moves
no domain logic into CI/CD; changes no PACK-16 cryptographic protocol or
frozen reference artifact; weakens no voting unlinkability; and claims no
BSI/CC/EAL4 certification, production readiness or legal activation. It does
not close the INFRA layer.

## 6. Result semantics

A PASS of the canonical harness — locally or in
`.github/workflows/infra02-acceptance.yml` — is a local/canonical execution
result on the exact tested commit. It is not external governed acceptance,
not production readiness and not legal activation. The stage self-state is
`LOCAL VERIFICATION ONLY / CANDIDATE_NOT_ACCEPTED /
PARALLEL_WORKING_PRESEAL_NOT_ACCEPTED`; only the independent reviewer's
post-run governance decision can change it.
