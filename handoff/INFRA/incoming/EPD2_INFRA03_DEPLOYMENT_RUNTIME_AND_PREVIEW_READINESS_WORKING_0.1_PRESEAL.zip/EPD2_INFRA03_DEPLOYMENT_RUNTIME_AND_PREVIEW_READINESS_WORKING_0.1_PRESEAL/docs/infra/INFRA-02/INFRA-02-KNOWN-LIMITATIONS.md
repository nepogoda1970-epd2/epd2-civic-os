# INFRA-02 — Known Limitations

Honest, explicit limitations of the INFRA-02 working candidate. Nothing here
is hidden behind a PASS; where a limitation affects execution the harness
reports BLOCKED or fails closed rather than degrading silently.

## 1. No production environment exists

The promotion state machine, drift detector and rollback path operate on the
content-addressed release store and machine-readable environment state — the
governed mechanism, exercised end-to-end in evidence — but no real
development/test/staging/production infrastructure is deployed. Production
promotion is proven _refusable_ (the harness demonstrates the refusal), not
performed. Source-to-running-instance provenance on real infrastructure
remains INFRA-03..07 work.

## 2. Signing is content-integrity plus a TEST-ONLY signer

Release manifests, provenance statements and promotion records are sealed
with the canonical content-integrity digest (`manifest_sha256`), and the
provenance module exposes a signature-verification interface — but the only
signer shipped is an explicitly TEST-ONLY HMAC signer with ephemeral
per-session keys. Cryptographic attestation with governed key custody is
INFRA-03. No production private key exists in the repository or CI, by
design.

## 3. Byte-reproducibility of the candidate ZIP is not yet proven

The governed declaration for `candidate-archive-zip` is
`DETERMINISTIC_INPUTS_BUT_BYTE_REPRODUCIBILITY_NOT_YET_PROVEN`: archive
member timestamps derive from filesystem state, so two packaging runs of
identical content are content-identical (proven: tested bytes == packaged
bytes, member-hash equality) but not byte-identical as ZIP files. The source
tree is `CONTENT_REPRODUCIBLE_AND_PROVEN` (freeze tree digest is
recomputable by anyone from the file set). PACK-16 ceremony-artifact
reproducibility (IM-33) is explicitly left open. The release manifest cannot
overclaim any of this: `REPRODUCIBILITY_OVERCLAIMED` fails closed.

## 4. Vulnerability gate depends on external advisory services

`pip-audit` and `npm audit` consult live advisory databases; without network
access the check is `BLOCKED` (never PASS). Scan evidence binds the exact
lock digests scanned, so stale evidence can never authorize a release
(`STALE_SCAN_EVIDENCE`), but advisory _content_ is inherently time-varying:
a release that passes today may accumulate findings tomorrow. The 16
governed exceptions (5 Python, 11 npm) expire 2026-11-30 and must be
resolved by lock upgrades in a governed round before that date, or
explicitly re-granted.

## 5. Frozen locks carry the vulnerabilities the exceptions name

The dependency locks are part of the accepted INFRA-01 C3 predecessor;
INFRA-02 deliberately does not churn them (lock digests are release-identity
inputs and the accepted baseline's test evidence binds to them). The known
advisories against `cryptography 46.0.7` (PYSEC-2026-3552/-3553/-3554,
GHSA-537c-gmf6-5ccf), `pytest 8.4.2` (PYSEC-2026-1845) and 11 npm packages
are therefore present, visible in the scan evidence, and governed by narrow,
owned, justified, time-bounded exceptions rather than silenced.

## 6. History scan requires full history at the boundary

The history/ref secret gate scans every blob reachable from the governed
publishable refs; in CI this requires `fetch-depth: 0` (declared in
`.github/workflows/infra02-acceptance.yml`). On a shallow or ref-less
checkout the gate fails closed (unresolvable publishable ref), it does not
skip. The gate covers this repository's refs; other publication channels are
outside its authority.

## 7. GitHub-hosted runner infrastructure is trusted as a platform

Action pinning, trust classes, least-privilege tokens and trusted-builder
verification constrain what runs in CI, but the GitHub Actions platform and
its hosted runners themselves remain outside the candidate's verification
boundary — hermetic/self-hosted build isolation is future INFRA work.

## 8. Workflow-classification is repository-local

`supply_chain_policy.json` classifies every workflow present in the
candidate tree, and unclassified workflows fail closed. Workflows that exist
only on the governance overlay `main` (e.g. historical acceptance workflows
for other stages) are outside the candidate tree and therefore outside this
check's reach; their authority is pinned by their own acceptance records.

## 9. SBOM completeness is lock-derived

The SBOM enumerates exactly what the frozen locks record (604 components)
and is verified in reverse against them; it does not perform binary
composition analysis of built artifacts. For this repository's release path
(no container images, no compiled binaries beyond the frontend build from
locked inputs) the locks are the complete governed dependency authority.
