# I06 PostgreSQL Runtime Evidence

## Required target

PostgreSQL 16.x, fresh database, migrations 001–008, real role logins, real transaction/concurrency/crash/restart/backup-restore execution.

## Implemented harness

- `migrations/postgresql/007_i06_guardian_decryption.sql`
- `migrations/postgresql/008_i06_roles.sql`
- `scripts/run_i06_postgres_validation.sh`
- `tests/i06_postgres_helpers.mjs`
- four I06 PostgreSQL test files containing 22 declared I06 cases: 3 ceremony/decryption, 2 concurrency, CRASH-01..04, 1 hard restart, 1 backup/restore, 10 privileged tamper classes (including the mandatory I05 aggregate-byte corrective scenario), and 1 role-separation case. The harness also runs the accepted I05 PostgreSQL tamper/backup/role file so predecessor storage invariants are exercised in the same real server.
- mandatory I05 byte-only DBA tamper negative is also added to `tests/i05-postgres-tamper-backup-roles.test.mjs`.

## Execution in this candidate build

**NOT EXECUTED.** No PostgreSQL server/client binaries are present in this execution environment. The accepted predecessor contains PostgreSQL 16.10 provenance/evidence, but executable server binaries are not packaged, and this gate cannot claim that new migrations 007/008 or I06 transactions were runtime established from predecessor evidence.

No mock or SQLite result is substituted.

Consequently PostgreSQL test count for I06 acceptance is `0 executed / 22 declared` and Outcome A is prohibited by the assignment. Machine-readable blocker evidence is in `evidence/results/i06/postgresql-runtime.json`.
