# PB01-I06 Acceptance Report

## Mandatory developer report

- Candidate filename: `EPD2_VCRYPTO-PB01-I06_GUARDIAN_CEREMONY_AND_THRESHOLD_DECRYPTION_CANDIDATE_0.1.zip`
- Archive SHA-256: external delivery metadata, reported with the final artifact (not embedded to avoid a circular archive hash)
- File count: **540 regular files**, recorded in `evidence/results/i06/archive-manifest.json`
- `SHA256SUMS.txt`: generated over every listed regular file and verified again after clean extraction
- Base: accepted `EPD2_VCRYPTO-PB01-I05_HOMOMORPHIC_TALLY_AND_EXACT_FINAL_SET_CONSUMPTION_CANDIDATE_0.2_C1.zip`
- I05 corrective: **implemented**; `recompute()` independently hashes persisted aggregate bytes before trusting committed digest/evidence. Local I05 crypto/composition regression passes. The required privileged PostgreSQL byte-only mutation negative is implemented and wired so I06 decryption refuses on `I05_INTEGRITY_FAILURE`, but it is not runtime-executed in this environment.
- Guardian configurations: N=3/T=2; N=5/T=3; empty-tally N=3/T=2. Guardian-side Belenios threshold key-generation reference run N=3/T=2 PASS in an isolated temporary custody directory; generated private files were deleted and are not in the candidate.
- Belenios: pinned 3.3.0; patch count 0.
- PostgreSQL target: 16.x (accepted predecessor provenance records 16.10); new I06 runtime execution: **0/22 declared tests, blocked by unavailable server binaries**.
- Concurrency: local cryptographic subset equivalence PASS; real PostgreSQL concurrency tests implemented, NOT EXECUTED.
- CRASH-01..04: PostgreSQL tests implemented, NOT EXECUTED.
- Tamper: 9/9 frozen mutation vectors REJECT plus local proof/threshold negatives PASS; 10 privileged PostgreSQL tamper classes implemented, NOT EXECUTED.
- Backup/restore: PostgreSQL test implemented, NOT EXECUTED.
- Role separation: SQL migration/harness implemented; real PostgreSQL role execution NOT EXECUTED.
- Verifier A: **PASS**, 4/4 real threshold vectors; 6/6 independent mutation checks rejected.
- Verifier B: **PASS**, Go 1.23.2, 4/4 real threshold vectors; does not import producer code and does not wrap Verifier A. Rust was unavailable in this execution environment and the assignment explicitly permits Go when Rust materially blocks the gate.
- Cross-language byte agreement: **true** for ceremony digest, aggregate reference digest, share digests, plaintext tally digest, and final decryption record digest.
- I01–I05 semantic preservation: 67 protected predecessor files byte-for-byte unchanged; only authorized I05 `recompute()` corrective is applied to predecessor cryptographic code. I05 local tally tests 8/8 PASS and both I05 verifiers PASS. Legacy predecessor “no I06 implementation” security/final-gate assertions necessarily fail once I06 exists and are not represented as regressions.
- Unresolved debts: real I06 PostgreSQL runtime acceptance; Rust lock/provenance and Rust mutation-negative parity remain carried forward to I08.

## Runtime declarations

- Candidate runtime declaration inherited from the accepted chain: Node 24.19.0.
- Non-PostgreSQL execution environment actually available here: Node v22.16.0, Go 1.23.2, Belenios 3.3.0.
- `rustc`/`cargo`: unavailable; carried Rust verifier debts remain open.
- PostgreSQL server/client binaries: unavailable; therefore no I06 PostgreSQL claim is marked PASS.

## Per-class executed results

| Class | Executed result |
|---|---|
| I06 local Node gate (corrective + API/static + vectors + threshold/mutations) | 23/23 PASS |
| Frozen threshold vectors | 4/4 PASS |
| Frozen mutation vectors | 9/9 REJECT as required |
| Belenios threshold subset invariance | PASS (1/2/3, 3/4/5, all five give same plaintext for N=5/T=3) |
| T-1 negative | PASS — no plaintext |
| Invalid proof among T | PASS — rejected |
| Duplicate guardian threshold attempt | PASS — rejected |
| Verifier A | 4/4 PASS + 6/6 mutations rejected |
| Verifier B (Go) | 4/4 PASS |
| Cross-language digest agreement | true |
| I05 local regression | 8/8 PASS; A/B verifiers PASS |
| PostgreSQL I06 | 0/22 executed — environment blocker |
| PostgreSQL CRASH-01..04 | 0/4 executed — environment blocker |
| PostgreSQL backup/restore | 0/1 executed — environment blocker |

## Classification

`Outcome C — BLOCKED`

Reason: the implementation and real Belenios cross-language cryptographic path are established, but the assignment expressly prohibits Outcome A without real PostgreSQL 16.x execution of the new I06 production path. The required PostgreSQL binaries are unavailable in this build environment.
