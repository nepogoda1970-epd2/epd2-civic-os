#!/usr/bin/env bash
# PB01-I06 real PostgreSQL 16.x acceptance harness. No mocks.
# Usage: EPD2_I06_PG_BIN=/path/to/postgresql-16/bin bash scripts/run_i06_postgres_validation.sh
set -euo pipefail
candidate_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
pg_bin="${EPD2_I06_PG_BIN:?set EPD2_I06_PG_BIN to PostgreSQL 16.x bin directory}"
port="${EPD2_I06_PG_TEST_PORT:-55436}"
pg_user="$(id -un)"
if [ "$(id -u)" -eq 0 ]; then echo 'initdb refuses root; run this harness under an unprivileged account' >&2; exit 77; fi
work_root="$(mktemp -d "${TMPDIR:-/tmp}/epd2-i06-postgres.XXXXXX")"; pg_data="$work_root/data"
start_options="-c listen_addresses=127.0.0.1 -c port=$port -c unix_socket_directories='' -c fsync=on -c synchronous_commit=on -c full_page_writes=on"
cleanup(){ "$pg_bin/pg_ctl" -D "$pg_data" -m immediate stop >/dev/null 2>&1 || true; }; trap cleanup EXIT INT TERM
"$pg_bin/initdb" -D "$pg_data" --no-locale --encoding=UTF8 --auth-local=trust --auth-host=trust >"$work_root/initdb.log"
"$pg_bin/pg_ctl" -D "$pg_data" -o "$start_options" -l "$work_root/postgres.log" -w start
"$pg_bin/createdb" -h 127.0.0.1 -p "$port" -U "$pg_user" epd2_i06_test
for m in 001_i03_submission_ledger 002_i03_roles 003_i04_finalization 004_i04_roles 005_i05_tally 006_i05_roles 007_i06_guardian_decryption 008_i06_roles; do "$pg_bin/psql" -X -q -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i06_test -f "$candidate_root/migrations/postgresql/$m.sql" >/dev/null; echo "applied $m.sql"; done
"$pg_bin/psql" -X -q -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i06_test >/dev/null <<'SQL'
CREATE ROLE epd2_i03_runtime_test LOGIN PASSWORD 'runtime-test-only' IN ROLE epd2_pb01_submission_runtime;
CREATE ROLE epd2_i03_evidence_test LOGIN PASSWORD 'evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
CREATE ROLE epd2_i04_finalizer_test LOGIN PASSWORD 'finalizer-test-only' IN ROLE epd2_pb01_finalization_runtime;
CREATE ROLE epd2_i04_evidence_test LOGIN PASSWORD 'i04-evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
CREATE ROLE epd2_i05_tally_test LOGIN PASSWORD 'tally-test-only' IN ROLE epd2_pb01_tally_runtime;
CREATE ROLE epd2_i05_evidence_test LOGIN PASSWORD 'i05-evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
CREATE ROLE epd2_i06_coordinator_test LOGIN PASSWORD 'coordinator-test-only' IN ROLE epd2_pb01_guardian_coordinator;
CREATE ROLE epd2_i06_ingester_test LOGIN PASSWORD 'ingester-test-only' IN ROLE epd2_pb01_guardian_ingester;
CREATE ROLE epd2_i06_finalizer_test LOGIN PASSWORD 'decrypt-finalizer-test-only' IN ROLE epd2_pb01_decryption_finalizer;
CREATE ROLE epd2_i06_reader_test LOGIN PASSWORD 'i06-reader-test-only' IN ROLE epd2_pb01_i06_runtime_reader;
SQL
base="postgresql://127.0.0.1:$port/epd2_i06_test"
export EPD2_I03_PG_ADMIN_URL="postgresql://$pg_user@127.0.0.1:$port/epd2_i06_test"
export EPD2_I03_PG_RUNTIME_URL="postgresql://epd2_i03_runtime_test:runtime-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I03_PG_EVIDENCE_URL="postgresql://epd2_i03_evidence_test:evidence-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I04_PG_FINALIZER_URL="postgresql://epd2_i04_finalizer_test:finalizer-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I04_PG_EVIDENCE_URL="postgresql://epd2_i04_evidence_test:i04-evidence-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I05_PG_TALLY_URL="postgresql://epd2_i05_tally_test:tally-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I05_PG_EVIDENCE_URL="postgresql://epd2_i05_evidence_test:i05-evidence-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I06_PG_COORDINATOR_URL="postgresql://epd2_i06_coordinator_test:coordinator-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I06_PG_INGESTER_URL="postgresql://epd2_i06_ingester_test:ingester-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I06_PG_FINALIZER_URL="postgresql://epd2_i06_finalizer_test:decrypt-finalizer-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I06_PG_READER_URL="postgresql://epd2_i06_reader_test:i06-reader-test-only@127.0.0.1:$port/epd2_i06_test"
export EPD2_I03_PG_PORT="$port" EPD2_I03_PG_DUMP_PATH="$pg_bin/pg_dump" EPD2_I03_PG_RESTORE_PATH="$pg_bin/pg_restore" EPD2_I03_PG_CREATEDB_PATH="$pg_bin/createdb" EPD2_I03_PG_DROPDB_PATH="$pg_bin/dropdb"
export EPD2_I05_PG_CTL_PATH="$pg_bin/pg_ctl" EPD2_I05_PG_DATA_DIR="$pg_data" EPD2_I05_PG_START_OPTIONS="$start_options"
export EPD2_I06_PG_CTL_PATH="$pg_bin/pg_ctl" EPD2_I06_PG_DATA_DIR="$pg_data" EPD2_I06_PG_START_OPTIONS="$start_options"
cd "$candidate_root"
"$pg_bin/psql" -X -At -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i06_test -c 'SHOW server_version;'
node --test --test-concurrency=1 tests/i05-postgres-tamper-backup-roles.test.mjs tests/i06-postgres-ceremony-decryption.test.mjs tests/i06-postgres-concurrency-crash.test.mjs tests/i06-postgres-tamper-roles.test.mjs tests/i06-postgres-restart-backup.test.mjs
