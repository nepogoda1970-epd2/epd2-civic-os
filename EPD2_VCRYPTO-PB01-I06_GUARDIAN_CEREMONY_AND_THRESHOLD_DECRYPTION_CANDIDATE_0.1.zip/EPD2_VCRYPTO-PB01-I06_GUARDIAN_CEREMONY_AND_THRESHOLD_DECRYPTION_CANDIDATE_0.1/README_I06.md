# EPD² PB01-I06 — Guardian Ceremony, Threshold Decryption & Decryption Evidence

Candidate: `EPD2_VCRYPTO-PB01-I06_GUARDIAN_CEREMONY_AND_THRESHOLD_DECRYPTION_CANDIDATE_0.1`

This candidate extends the accepted I05 0.2_C1 implementation with a threshold-guardian decryption layer while preserving protected I01–I05 code byte-for-byte except the explicitly authorized I05 recomputation corrective in `src/i05/tally.mjs` and its PostgreSQL negative test.

## Implemented

- mandatory I05 persisted-aggregate-byte digest recomputation before I06 authorization;
- Belenios 3.3.0 Pedersen threshold ceremony verification and public-key derivation;
- canonical immutable `GuardianCeremonyRecord`;
- election-local guardian identifiers and canonical order;
- public partial-decryption-share artifacts bound to the exact I05 aggregate;
- proof verification through the pinned upstream Belenios `compute-result`/`verify` path before a share becomes accepted;
- threshold completion and immutable `ThresholdDecryptionRecord`;
- no plaintext before threshold;
- deterministic I07 public-evidence handoff contract;
- PostgreSQL schemas, separated roles, append-only/frozen guards, concurrency locks, crash/restart/backup/tamper test harness;
- independent Verifier A and independent Go Verifier B;
- four real public Belenios threshold vectors, including an empty authorized tally.

## Important setup invariant

Threshold election public-key construction necessarily precedes ballot encryption. I06 therefore includes the guardian ceremony implementation and verifies/finalizes its public record, but it does **not** retrofit threshold trustees onto an already encrypted single-trustee election. The full-chain I06 fixture uses a threshold election public key before any I03 ballots are produced. This preserves all frozen I01–I05 semantics.

## Runtime classification

Cryptographic/vector/verifier execution is complete in this build environment. The new I06 PostgreSQL suite is implemented but was not executable here because no PostgreSQL server binaries (`postgres`, `pg_ctl`, `initdb`, `psql`) are available, and external source retrieval from the execution container is unavailable. Per the assignment, no PostgreSQL mock is substituted.

Therefore this candidate is classified:

`Outcome C — BLOCKED`

See `I06_ACCEPTANCE_REPORT.md` and `I06_POSTGRESQL_RUNTIME_EVIDENCE.md`.
