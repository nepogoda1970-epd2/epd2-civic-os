# CORS, origin and TLS security

The submission service reflects only one configured voting origin; wildcard
CORS and `Access-Control-Allow-Credentials` are absent. Allowed headers are
`authorization`, `content-type` and `idempotency-key`. The browser uses
`credentials: omit`, receives no member cookies and loads no analytics.

The scoped capability header plus exact origin handles cross-origin submission;
member application sessions are not reused as CSRF authority. Arbitrary origins
are rejected before parsing.

Production requires HTTPS for both origins. HTTP is accepted only when the
explicit test/development flag is set; TLS termination, HSTS and network
confidentiality belong to the deployment boundary.
