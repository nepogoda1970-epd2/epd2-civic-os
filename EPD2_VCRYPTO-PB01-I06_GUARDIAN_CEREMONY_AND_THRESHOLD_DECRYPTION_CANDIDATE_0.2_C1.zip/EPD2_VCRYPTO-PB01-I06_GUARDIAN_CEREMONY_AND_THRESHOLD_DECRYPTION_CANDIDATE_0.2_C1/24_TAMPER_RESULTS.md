# Tamper Results

I04 finalization tamper is checked by the accepted recompute path before I05. Independent Go verification covers I04 checkpoint, accepted manifest, canonical CSet/root, closure signature/record, envelope and `F_final`. I05 N01–N12 and real alternate-aggregate attacks all reject.

**Privileged PostgreSQL tamper, executed live** (`tests/i05-postgres-tamper-backup-roles.test.mjs`):

- Append-only triggers reject `UPDATE` and `DELETE` on `pb01_i05.tally_records` and `pb01_i05.aggregates` with `TALLY_APPEND_ONLY_VIOLATION` even for the schema owner.
- A DBA-level attack that disables the triggers and mutates `aggregate_ciphertext_bytes` is detected: the stored bytes no longer hash to the committed `aggregate_ciphertext_digest`, and no longer match the aggregate carried inside the digest-sealed evidence bundle, which itself still verifies.
- Forcing a different `tally_record_digest` into a committed row is detected by `TallyEngine.recompute()` with `TALLY_RECOMPUTE_MISMATCH`.
- Tampering the canonical evidence bundle is detected by `verifyTallyEvidence()`.

Known limitation: `recompute()` compares stored digest **columns** and does not itself re-hash `pb01_i05.aggregates.aggregate_ciphertext_bytes`, so the byte-column tamper above is caught by the hash and evidence checks rather than by `recompute()`. Recorded as `PB01-DEBT-I05-RECOMPUTE-AGGREGATE-BYTES-01`.
