# I04 Input Contract

I05 consumes the accepted I04 `AuthorizedFinalBallotSet` exactly as produced by `src/i04/finalization.mjs`: `election_instance_id`, `crypto_profile`, `tally_function_id`, `f_final`, canonical `ordered_ballot_digests`, and `exact_ballot_byte_references`. No parallel caller-supplied ballot array exists. Production resolution is through `PostgresFinalizationStore.authorizedFinalBallotSet()` and `exactFinalBallotBytes()`.
