# Transaction model

The production store uses PostgreSQL `BEGIN` with an election-scoped
`pg_advisory_xact_lock`. The lock serializes the ledger head/idempotency decision
for one election while PostgreSQL unique constraints remain the final arbiter.
Within one transaction it writes:

- immutable encrypted submission and exact bytes;
- private lifecycle binding;
- append-only hash-chain event;
- idempotency mapping and stable response;
- signed receipt embedded with the accepted record.

Any error rolls back the whole unit. Unique election/digest, election/key and
event sequence constraints close retry races. `fsync`, `synchronous_commit` and
`full_page_writes` were enabled in the executed PostgreSQL validation. The
application never auto-creates schema at startup.

Crash tests cover failure after verification/before transaction, after commit/
before response, client disconnect, service restart and retry.

SQLite `BEGIN IMMEDIATE`, WAL and `synchronous=FULL` remain covered only as the
local semantic-regression adapter.
