# Receipt profile

Receipts use built-in mature Ed25519 with profile
`epd2.pb01.submission-receipt.ed25519/1` and domain
`epd2.pb01.submission-receipt.v1`. The signing key is separate from Belenios
election/trustee keys and must be injected from secret management.

Signed fields bind submission/election IDs, `BallotDigest`, accepted time,
ledger event ID/hash and the explicit claim
`ACCEPTED_NOT_FINAL_NOT_COUNTED`. Retry returns the originally persisted receipt.
The package contains verification code and tests, but no production private key.
