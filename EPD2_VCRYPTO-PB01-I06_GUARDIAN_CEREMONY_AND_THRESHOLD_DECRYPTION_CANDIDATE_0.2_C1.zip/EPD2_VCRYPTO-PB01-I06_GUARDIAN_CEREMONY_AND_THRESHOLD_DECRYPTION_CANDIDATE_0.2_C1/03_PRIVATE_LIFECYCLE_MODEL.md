# Private lifecycle model

Grouping uses only I03 `private_submission_lifecycle.lifecycle_handle`, which is election-scoped, opaque and separate from public evidence. Finalization fails on missing/cross-election/inconsistent bindings. Public artifacts contain no handle, member identity, credential or revote-chain map.
