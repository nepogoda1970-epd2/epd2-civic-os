# Accepted evidence export

`AcceptedSubmissionManifest` is generated from ledger state with binary
lexicographic digest order, the last accepted event time, event count/sequence,
event hash and a domain-separated manifest digest. Repeating export over the
same state is byte/semantically deterministic.

The name and `semantic_claim` explicitly distinguish accepted submissions from
the future effective final set and counted ballots. Mutable URLs and private
lifecycle references are excluded. Conflicting manifests expose different
checkpoint/digest values; external non-forkable publication is future work.
