# Acceptance pipeline

The implemented order is:

1. exact-origin, method, content-type and request-size checks;
2. duplicate-aware UTF-8 JSON parsing and closed I02 schema validation;
3. route/election/profile/tally-function validation;
4. exact base64url decoding and bounded upstream-structure inspection;
5. Belenios UUID/fingerprint cross-check;
6. unchanged I01 `BallotDigest` recomputation and comparison;
7. native Belenios 3.3.0 verification of the received exact bytes;
8. election-scoped capability authorization and private lifecycle derivation;
9. race-safe idempotency/duplicate-digest decision;
10. one transactional acceptance commit;
11. Ed25519 receipt and safe audit event.

Cheap failures precede proof verification. Browser claims of verification or
digest correctness are never authoritative. Only committed `ACCEPTED` records
are eligible input to the future I04 process.
