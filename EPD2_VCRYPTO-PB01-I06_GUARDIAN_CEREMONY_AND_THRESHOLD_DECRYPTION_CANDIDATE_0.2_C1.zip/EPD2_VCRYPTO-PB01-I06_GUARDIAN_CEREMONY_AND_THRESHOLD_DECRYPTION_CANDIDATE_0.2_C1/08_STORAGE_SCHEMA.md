# Storage schema

The production executable uses PostgreSQL 16.10 through pinned `pg` 8.16.3.
DDL and least-privilege roles are in `migrations/postgresql/`. Node 24
`node:sqlite` remains an optional local/unit-test adapter and is not the
production acceptance store.

Logical tables:

- `elections`: governed crypto context, not an administration API;
- `encrypted_submissions`: exact ciphertext bytes and technical acceptance data;
- `private_submission_lifecycle`: opaque election-scoped relation;
- `submission_ledger_events`: ordered hash-chain events;
- `idempotency_records`: hashed key, semantic request hash and stable response;
- `security_audit_events`: redacted security events.

Prohibited identity/plaintext/randomness columns do not exist. Critical fields
are `NOT NULL`; identifiers, digests, profiles and uniqueness are constrained.

The production receiver requires `EPD2_I03_POSTGRES_URL`, verifies TLS unless
the explicit local-development exception is set, and fails startup unless its
database role has the exact non-DDL runtime privilege profile.
