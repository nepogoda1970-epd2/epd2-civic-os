# RevoteResolutionRecord

Private records contain schema, election, lifecycle handle, ordered candidate submission IDs, selected submission/digest, ledger position, policy and checkpoint time plus a domain-separated digest. Runtime roles cannot update/delete them.
