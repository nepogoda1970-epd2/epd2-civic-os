# HomomorphicTallyRecord

Schema `epd2.pb01.homomorphic-tally-record/1` records the I04 anchors, tally input digest/count, exact upstream aggregate object and bytes, aggregate digest, upstream sized-tally bytes, producer version, and domain-separated tally record digest. It contains encrypted aggregate only; no plaintext tally or decryption material is introduced.
