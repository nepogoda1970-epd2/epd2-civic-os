# Ledger tamper results

Starting from two real PostgreSQL-accepted ballots and a retained checkpoint,
tests used a superuser transaction with `session_replication_role=replica` to
model privileged storage tampering while rolling every mutation back afterward.

| Attack | Detection |
| --- | --- |
| historical digest changed | row/event mismatch |
| last event deleted | checkpoint conflict |
| two sequence numbers reordered | chain order/link mismatch |
| supplied conflicting checkpoint | checkpoint conflict |

On the normal schema, update and delete attempts fail with
`APPEND_ONLY_VIOLATION`. These results do not claim protection against a database
controller who can also replace every unwitnessed checkpoint.
