# CSet_final construction

One selected digest per eligible lifecycle is passed to the unchanged I01 `epd2.pb01.cset-final/1` builder and sorted by raw digest bytes. Handles, IDs, timestamps and replacement links are excluded. Empty CSet is explicitly allowed and deterministic.
