# Crash Consistency Results

CRASH-01..04 are executed through the production `PostgresTallyStore` transaction against real PostgreSQL 16.14 (`tests/i05-postgres-crash-restart.test.mjs`); the in-memory failpoint harness is retained only as a unit-level companion and carries no acceptance weight.

- **CRASH-01** `after_finalization_verification_before_aggregation` — no rows in `aggregates`, `tally_records` or `tally_audit_events`.
- **CRASH-02** `during_aggregate_construction` — no rows.
- **CRASH-03** `after_aggregate_persistence_before_tally_record_commit` — the load-bearing case: the aggregate `INSERT` is rolled back with the never-reached record commit; `aggregates` is empty and `store.read()` returns null.
- **CRASH-04** `after_commit_before_response` — the transaction had already committed, so the aggregate and record are durable and the retry returns `replay: true`.

Every stage converges on retry to one aggregate row, one tally record, and the authoritative `f_final`; a further retry after recovery stays idempotent.

**Restart persistence:** `pg_ctl -m immediate stop` performs no clean checkpoint, forcing WAL replay on restart. After recovery the committed tally is byte-identical — `aggregate_ciphertext_bytes`, `upstream_sized_tally_bytes`, the canonical record and the evidence bundle all deep-equal their pre-crash values, and all five digests match. Recompute against a freshly connected finalization store returns `PASS`, and re-execution returns `replay: true`.
