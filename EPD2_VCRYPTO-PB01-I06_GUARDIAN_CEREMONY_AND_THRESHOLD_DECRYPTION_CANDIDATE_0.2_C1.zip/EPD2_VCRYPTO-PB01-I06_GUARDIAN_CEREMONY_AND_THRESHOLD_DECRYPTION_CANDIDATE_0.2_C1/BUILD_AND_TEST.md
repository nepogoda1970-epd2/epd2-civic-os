# Build and test

Accepted product test environment: Node 24.19.0 with the pinned offline npm archives, PostgreSQL 16.x for production-storage tests, Go 1.23 for the independent Verifier B.

Install offline dependencies:

```sh
npm install --offline
```

Non-PostgreSQL I05 gates (vectors, API boundary, static security, local crash/concurrency companions, Verifier A, independent Go Verifier B, adversarial composition, final validation):

```sh
npm run validate:i05
```

PostgreSQL production-runtime acceptance — this is the gate that establishes Outcome A. Run it as a **non-root** user, because `initdb` refuses to run as root:

```sh
EPD2_I05_PG_BIN=/path/to/postgresql-16/bin bash scripts/run_i05_postgres_validation.sh
```

The harness runs `initdb`, starts PostgreSQL with `fsync=on synchronous_commit=on full_page_writes=on`, applies migrations `001`–`006`, creates the six least-privilege login roles, and executes:

```
tests/i05-postgres.integration.test.mjs
tests/i05-postgres-runtime.test.mjs
tests/i05-postgres-crash-restart.test.mjs
tests/i05-postgres-tamper-backup-roles.test.mjs
```

covering exact finalized-set consumption, native Belenios re-verification, idempotent retry, concurrent same tally, conflicting `F_final`/tally conflict, CRASH-01..04, immediate-mode restart persistence, recompute, privileged tamper detection, both directions of role separation, the DDL/TEMP floor, and backup/restore byte and digest preservation. It exports `EPD2_I05_PG_CTL_PATH`, `EPD2_I05_PG_DATA_DIR` and `EPD2_I05_PG_START_OPTIONS` so the restart-persistence test can crash and recover the server.

Predecessor suites:

```sh
EPD2_I03_PG_BIN=/path/to/postgresql-16/bin bash scripts/run_postgres_validation.sh
EPD2_I04_PG_BIN=/path/to/postgresql-16/bin bash scripts/run_i04_postgres_validation.sh
npm run validate:i04-c1
```

Where a Rust toolchain is available the Rust verifier extension can also be run:

```sh
cd verifier/rust && cargo run --release -- --vectors ../../test-vectors/i04-verifier-b
```

Finally:

```sh
sha256sum -c SHA256SUMS.txt
```

Known: `npm run test` (the I03-era suite) fails one assertion that predates this candidate — see `PB01-DEBT-I03-SECURITY-TEST-TALLY-ROUTE-01`. No I06 work is present.
