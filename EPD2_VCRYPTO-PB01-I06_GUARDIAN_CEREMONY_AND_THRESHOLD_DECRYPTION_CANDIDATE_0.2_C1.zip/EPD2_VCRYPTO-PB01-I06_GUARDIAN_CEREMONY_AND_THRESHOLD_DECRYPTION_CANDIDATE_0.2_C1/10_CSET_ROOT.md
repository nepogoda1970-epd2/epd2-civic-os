# cset_root

Computed by the accepted I01 domain `epd2.pb01.cset-root.v1`, SHA-256 over tag, NUL and restricted-JCS canonical `CSet_final` bytes. Producer, recomputation verifier and Verifier B agree.
