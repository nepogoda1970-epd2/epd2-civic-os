# Recomputation verifier

`scripts/recompute-final-set.mjs` re-reads immutable I03 rows, verifies the chain and checkpoint, re-resolves lifecycles and byte-compares accepted manifest, private records, CSet, roots, envelope, F_final and public evidence. Any mismatch returns `FINAL_SET_RECOMPUTE_MISMATCH`.
