# Revote-preparation E2E

The real browser accepted ballot A and later independently randomized ballot B
under the same scoped authorization lifecycle. Both exact ciphertexts and both
ledger events remain immutable. The private table returns one shared opaque
lifecycle handle; status and accepted manifest disclose no relation.

The test records `supersession_decided: false`. I03 neither marks A superseded
nor selects B. Closure and deterministic latest-valid resolution are I04 work.
