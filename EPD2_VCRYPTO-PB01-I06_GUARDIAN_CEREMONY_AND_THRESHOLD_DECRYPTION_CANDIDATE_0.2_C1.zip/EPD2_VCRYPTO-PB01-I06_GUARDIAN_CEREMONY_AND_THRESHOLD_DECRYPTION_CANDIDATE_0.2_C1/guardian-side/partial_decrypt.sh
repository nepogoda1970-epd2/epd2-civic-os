#!/usr/bin/env bash
# PB01-I06 guardian-side REFERENCE helper. Private key files stay guardian-side.
set -euo pipefail
if [ "$#" -ne 6 ]; then
  echo "usage: $0 /path/to/belenios-tool /election/archive/dir TRUSTEE_ID /guardian/private.key /guardian/private.dkey /public/share.json" >&2
  exit 64
fi
tool="$1"; election_dir="$2"; trustee_id="$3"; key="$4"; dkey="$5"; out="$6"
[ -f "$key" ] && [ -f "$dkey" ] || { echo 'guardian key/decryption-key file missing' >&2; exit 66; }
umask 077
tmp="$(mktemp "${TMPDIR:-/tmp}/epd2-i06-share.XXXXXX")"; trap 'rm -f "$tmp"' EXIT
"$tool" election decrypt-threshold --dir "$election_dir" --key "$key" --decryption-key "$dkey" --trustee-id "$trustee_id" > "$tmp"
head -n 1 "$tmp" > "$out"
printf 'PUBLIC_PARTIAL_DECRYPTION_WRITTEN=%s\n' "$out"
