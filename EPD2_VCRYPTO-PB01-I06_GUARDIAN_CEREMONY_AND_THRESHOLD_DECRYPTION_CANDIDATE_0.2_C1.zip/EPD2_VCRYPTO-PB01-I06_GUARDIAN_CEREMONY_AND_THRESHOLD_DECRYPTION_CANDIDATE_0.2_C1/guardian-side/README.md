# Guardian-side reference boundary

These helpers are reference wrappers around the pinned Belenios 3.3.0 trustee primitives. They are **not application-runtime tools** and are not to be copied into the production application container image.

`reference_threshold_ceremony.sh` creates guardian private `.key/.dkey` and threshold-protocol intermediates only inside a caller-supplied guardian custody directory. That output is private guardian material and is never an EPD² PostgreSQL/public-evidence input. Only the resulting public threshold contribution/artifacts are supplied to the ceremony coordinator.

`partial_decrypt.sh` reads one guardian's own private files and emits only the public partial-decryption share/proof. The application receives that public share, never the private files.

The candidate archive contains these helper programs but contains **no generated guardian private key/decryption-key material**. Real production custody may use hardened guardian hosts/HSM-backed workflows later; I06 does not claim an HSM deployment.
