#!/usr/bin/env bash
# PB01-I06 guardian-side REFERENCE helper.
# This program intentionally creates private trustee material in the caller-supplied custody directory.
# It MUST NOT run in the EPD2 application/runtime container and its output directory MUST NOT be copied
# into the candidate/public evidence/production application deployment.
set -euo pipefail
if [ "$#" -ne 4 ]; then
  echo "usage: $0 /path/to/belenios-tool GUARDIAN_COUNT THRESHOLD /guardian/custody/dir" >&2
  exit 64
fi
tool="$1"; n="$2"; threshold="$3"; custody="$4"
case "$n:$threshold" in *[!0-9:]*|'') echo 'guardian count/threshold must be decimal integers' >&2; exit 64;; esac
if [ "$threshold" -lt 2 ] || [ "$n" -lt 2 ] || [ "$threshold" -gt "$n" ]; then echo 'require N>=2 and 2<=T<=N' >&2; exit 64; fi
mkdir -p "$custody"
if [ -n "$(find "$custody" -mindepth 1 -maxdepth 1 -print -quit)" ]; then echo 'custody directory must be empty' >&2; exit 65; fi
chmod 700 "$custody"
cd "$custody"
for i in $(seq 1 "$n"); do "$tool" setup generate-trustee-key-threshold --group Ed25519 --threshold-context "$i/$threshold/$n" --step 1 > "$i.trustee"; done
for i in $(seq 1 "$n"); do cat "$(cat "$i.trustee").cert"; done > certs.jsons
"$tool" setup generate-trustee-key-threshold --group Ed25519 --certs certs.jsons --step 2 >/dev/null
for i in $(seq 1 "$n"); do id="$(cat "$i.trustee")"; "$tool" setup generate-trustee-key-threshold --group Ed25519 --threshold-context "$i/$threshold/$n" --certs certs.jsons --key "$id.key" --step 3; done > polynomials.jsons
"$tool" setup generate-trustee-key-threshold --group Ed25519 --certs certs.jsons --step 4 --polynomials polynomials.jsons >/dev/null
for i in $(seq 1 "$n"); do id="$(cat "$i.trustee")"; "$tool" setup generate-trustee-key-threshold --group Ed25519 --certs certs.jsons --key "$id.key" --step 5 < "$id.vinput" > "$id.voutput"; done
for i in $(seq 1 "$n"); do cat "$(cat "$i.trustee").voutput"; done | "$tool" setup generate-trustee-key-threshold --group Ed25519 --certs certs.jsons --step 6 --polynomials polynomials.jsons > threshold.json
chmod 600 ./*.key ./*.dkey 2>/dev/null || true
printf 'GUARDIAN_SIDE_THRESHOLD_CEREMONY_READY N=%s T=%s\n' "$n" "$threshold"
printf 'PUBLIC_OUTPUT=%s\n' "$custody/threshold.json"
printf '%s\n' 'PRIVATE_OUTPUTS_REMAIN_IN_GUARDIAN_CUSTODY=.key/.dkey and protocol intermediate files'
