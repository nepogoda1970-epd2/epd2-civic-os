import { generateAndVerifyInBrowser } from "./belenios-browser.mjs";
import { buildSubmissionArtifact, canonicalize } from "./profile-browser.mjs";

const form = document.querySelector("#ballot-form");
const options = document.querySelector("#contest-options");
const status = document.querySelector("#status");
const prepareButton = document.querySelector("#prepare-ballot");
const submitButton = document.querySelector("#submit-ballot");
let context;
let handoff;
let submissionAuthorization;
let preparedArtifact = null;
let idempotencyKey = null;

function announce(message, isError = false) {
  status.textContent = message;
  status.dataset.kind = isError ? "error" : "success";
}

async function getJson(url) {
  const response = await fetch(url, { credentials: "omit", cache: "no-store" });
  if (!response.ok) throw new Error("INVALID_ELECTION_CONTEXT");
  return response.json();
}

async function initialize() {
  [context, handoff, submissionAuthorization] = await Promise.all([
    getJson("/fixture/context.json"),
    getJson("/fixture/handoff.json"),
    getJson("/fixture/i03-authorization.json"),
  ]);
  for (const option of context.contest_definition.options) {
    const label = document.createElement("label");
    const input = document.createElement("input");
    input.type = "radio";
    input.name = "choice";
    input.value = option.code;
    input.required = true;
    label.append(input, document.createTextNode(option.label));
    options.append(label);
  }
  prepareButton.disabled = false;
  announce("Election crypto context loaded. Select one option.");
}

form.addEventListener("change", () => {
  preparedArtifact = null;
  idempotencyKey = null;
  submitButton.disabled = true;
});

prepareButton.addEventListener("click", async () => {
  prepareButton.disabled = true;
  submitButton.disabled = true;
  preparedArtifact = null;
  idempotencyKey = null;
  try {
    const choice = new FormData(form).get("choice");
    if (typeof choice !== "string") throw new Error("INVALID_BALLOT_ENCODING");
    announce("Encrypting with Belenios in this browser and verifying locally…");
    const local = await generateAndVerifyInBrowser(context, handoff, choice);
    preparedArtifact = await buildSubmissionArtifact(context, local.encrypted_ballot_base64url, local.local_verification);
    idempotencyKey = crypto.randomUUID();
    submitButton.disabled = false;
    announce("Encrypted ballot prepared and locally verified. Ready to submit.");
  } catch (error) {
    announce(`Ballot not prepared: ${error instanceof Error ? error.message : "INTERNAL_CRYPTO_ERROR"}`, true);
  } finally {
    prepareButton.disabled = false;
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  submitButton.disabled = true;
  try {
    if (!preparedArtifact || !idempotencyKey) throw new Error("LOCAL_PROOF_VERIFICATION_FAILED");
    const received = await fetch(context.receiver_url, {
      method: "POST",
      credentials: "omit",
      cache: "no-store",
      headers: {
        "authorization": `EPD2-Scoped ${submissionAuthorization.scoped_credential.secret}`,
        "content-type": "application/json",
        "idempotency-key": idempotencyKey,
      },
      body: canonicalize(preparedArtifact),
    });
    const receipt = await received.json();
    if (!received.ok) throw new Error(receipt.error || "INVALID_ENCRYPTED_BALLOT");
    announce(`Accepted submission; not yet final or counted. Receipt: ${receipt.ballot_digest}`);
    status.dataset.receipt = receipt.ballot_digest;
    preparedArtifact = null;
    idempotencyKey = null;
    form.reset();
  } catch (error) {
    announce(`Ballot not submitted: ${error instanceof Error ? error.message : "SUBMISSION_STORAGE_FAILED"}`, true);
    submitButton.disabled = preparedArtifact === null;
  }
});

initialize().catch((error) => {
  announce(`Client initialization failed: ${error instanceof Error ? error.message : "INVALID_ELECTION_CONTEXT"}`, true);
});
