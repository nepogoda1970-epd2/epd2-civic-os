"use strict";
globalThis.belenios = {};
