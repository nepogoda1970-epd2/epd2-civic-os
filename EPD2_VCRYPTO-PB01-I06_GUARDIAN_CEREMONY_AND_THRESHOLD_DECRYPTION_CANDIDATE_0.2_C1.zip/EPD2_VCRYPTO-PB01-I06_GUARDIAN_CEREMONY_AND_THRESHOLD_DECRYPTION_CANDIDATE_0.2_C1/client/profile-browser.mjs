export const CRYPTO_PROFILE = "epd2.belenios-homomorphic/1";
export const TALLY_FUNCTION = "epd2.pb01.tally.single-choice.v1";
export const DOMAIN_BALLOT_DIGEST = "epd2.pb01.ballot-digest.v1";
export const SUBMISSION_SCHEMA = "epd2.pb01.encrypted-submission-artifact/1";
export const UPSTREAM_BALLOT_FORMAT = "belenios.ballot/3.3.0-protocol-v1";
export const CLIENT_BUILD_ID = "epd2.pb01.i02.native-helper/0.1+belenios-3.3.0";

const encoder = new TextEncoder();

export function canonicalize(value) {
  if (value === null) return "null";
  if (value === true) return "true";
  if (value === false) return "false";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") throw new Error("numbers prohibited by PB01 restricted JCS profile");
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(",")}]`;
  if (typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype) {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalize(value[key])}`).join(",")}}`;
  }
  throw new Error("unsupported JSON value");
}

function base64urlToBytes(value) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
  const binary = atob(base64);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

export async function ballotDigest(context, encryptedBallotBase64url) {
  if (context.crypto_profile !== CRYPTO_PROFILE) throw new Error("UNSUPPORTED_CRYPTO_PROFILE");
  if (context.tally_function_id !== TALLY_FUNCTION) throw new Error("UNSUPPORTED_TALLY_FUNCTION");
  const ballotBytes = base64urlToBytes(encryptedBallotBase64url);
  JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(ballotBytes));
  const input = {
    schema_version: "epd2.pb01.ballot-digest-input/1",
    election_instance_id: context.election_instance_id,
    crypto_profile: context.crypto_profile,
    belenios_election_uuid: context.belenios_election_uuid,
    belenios_election_fingerprint: context.belenios_election_fingerprint,
    belenios_ballot_base64url: encryptedBallotBase64url,
  };
  const tag = encoder.encode(DOMAIN_BALLOT_DIGEST);
  const body = encoder.encode(canonicalize(input));
  const message = new Uint8Array(tag.length + 1 + body.length);
  message.set(tag, 0);
  message[tag.length] = 0;
  message.set(body, tag.length + 1);
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", message));
  return [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function buildSubmissionArtifact(context, encryptedBallotBase64url, localVerification) {
  if (localVerification !== "PASS") throw new Error("LOCAL_PROOF_VERIFICATION_FAILED");
  return {
    schema_version: SUBMISSION_SCHEMA,
    election_instance_id: context.election_instance_id,
    crypto_profile: context.crypto_profile,
    tally_function_id: context.tally_function_id,
    ballot_digest: await ballotDigest(context, encryptedBallotBase64url),
    encrypted_ballot: encryptedBallotBase64url,
    upstream_ballot_format_version: UPSTREAM_BALLOT_FORMAT,
    client_crypto_build_id: CLIENT_BUILD_ID,
  };
}
