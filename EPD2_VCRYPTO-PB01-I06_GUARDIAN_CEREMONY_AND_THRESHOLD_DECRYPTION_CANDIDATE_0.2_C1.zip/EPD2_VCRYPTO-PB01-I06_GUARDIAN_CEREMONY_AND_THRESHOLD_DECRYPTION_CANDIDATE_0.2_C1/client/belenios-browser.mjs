function requireBrowserCrypto() {
  if (!globalThis.isSecureContext || !globalThis.crypto?.getRandomValues || !globalThis.crypto?.subtle) {
    throw new Error("SECURE_RNG_UNAVAILABLE");
  }
  if (!globalThis.belenios || !globalThis.epd2BeleniosVerify) {
    throw new Error("BROWSER_CRYPTO_UNAVAILABLE");
  }
}

function decodeBase64urlUtf8(value) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
  const binary = atob(base64);
  return new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(binary, (character) => character.charCodeAt(0)));
}

function encodeBase64urlUtf8(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/u, "");
}

function encodeSelection(choice) {
  const selections = {
    yes: [[1, 0, 0]],
    no: [[0, 1, 0]],
    abstain: [[0, 0, 1]],
  };
  if (!(choice in selections)) throw new Error("INVALID_BALLOT_ENCODING");
  return selections[choice];
}

function deriveCredential(rawElection, privateCredential) {
  const parameters = JSON.parse(rawElection);
  return new Promise((resolve, reject) => {
    globalThis.belenios.checkCredential(parameters, privateCredential, {
      success: resolve,
      failure: (code) => reject(new Error(String(code || "INVALID_SCOPED_CREDENTIAL"))),
    });
  });
}

function encryptBallot(electionWithSecret, plaintext) {
  return new Promise((resolve, reject) => {
    globalThis.belenios.encryptBallot(electionWithSecret, plaintext, {
      success: (rawBallot, tracker) => resolve({ rawBallot: String(rawBallot), tracker: String(tracker) }),
      failure: () => reject(new Error("ENCRYPTION_FAILED")),
    });
  });
}

function verifyBallot(rawElection, rawBallot) {
  return new Promise((resolve, reject) => {
    globalThis.epd2BeleniosVerify.verifyBallot(rawElection, rawBallot, {
      success: (credential) => resolve(String(credential)),
      failure: () => reject(new Error("LOCAL_PROOF_VERIFICATION_FAILED")),
    });
  });
}

export async function generateAndVerifyInBrowser(context, handoff, choice) {
  requireBrowserCrypto();
  if (handoff.election_instance_id !== context.election_instance_id || handoff.crypto_profile !== context.crypto_profile) {
    throw new Error("INVALID_ELECTION_CONTEXT");
  }
  const rawElection = decodeBase64urlUtf8(context.upstream_election_json_base64url);
  const electionWithSecret = await deriveCredential(rawElection, handoff.scoped_credential.secret);
  const { rawBallot, tracker } = await encryptBallot(electionWithSecret, encodeSelection(choice));
  await verifyBallot(rawElection, rawBallot);
  return {
    encrypted_ballot_base64url: encodeBase64urlUtf8(rawBallot),
    local_verification: "PASS",
    tracker,
  };
}
