# Browser-to-ledger E2E

Actual Chromium 151.0.7922.34 with pinned Playwright 1.62.1 executed:

isolated WS-03 page → Belenios browser encrypt/prove → local verify → I03 POST →
native Belenios 3.3.0 verify → transactional persistence → signed receipt →
public status lookup.

The executed persistence backend was PostgreSQL 16.10, not SQLite.

The captured request object contained exactly the eight accepted I02 encrypted
artifact fields: no choice, lifecycle handle or scoped credential in the body.
Only the two permitted origins appeared; local/session storage and cookies were
zero. Exact stored bytes and unchanged I01 digest matched. Evidence is in
`evidence/results/browser-to-ledger-e2e.json`.
