# Performance Results

`evidence/results/i05/performance.json` contains executed 100/1,000/10,000-item exact-byte decode, PB01 ballot-digest recomputation and manifest/evidence-digest timings, plus real native Belenios re-verification and upstream aggregation timing for the three-ballot vector. Production-scale native re-verification/aggregation and PostgreSQL retrieval at 100/1,000/10,000 remain environment-bounded and are not claimed. Memory in the current engine is O(n) because exact final rows/bytes are materialized; a later optimization may stream without changing canonical traversal.
