import { CANONICALIZATION_POLICY, CRYPTO_PROFILE } from "../i01_reference/pb01_profile.mjs";
import { aggregateCiphertextDigest } from "../i05/hashes.mjs";
import { CEREMONY_SCHEMA, COMPLETE_STATE, DECRYPTION_RECORD_SCHEMA, I07_HANDOFF_SCHEMA, SHARE_SCHEMA } from "./constants.mjs";
import { failI06 } from "./errors.mjs";
import { guardianCeremonyDigest, guardianPublicKeyDigest, guardianSetDigest, i07HandoffDigest, partialDecryptionShareDigest, plaintextTallyDigest, thresholdDecryptionRecordDigest } from "./hashes.mjs";
const HEX=/^[0-9a-f]{64}$/u;
function reqHex(x,code="I06_SCHEMA_INVALID"){if(!HEX.test(x??""))failI06(code);}
function decimal(n){return String(n);}
export function normalizeBeleniosShareBytes(bytes){
  let b=Buffer.from(bytes);
  if(b.length&&b[b.length-1]===0x0a)b=b.subarray(0,b.length-1);
  if(b.length&&b[b.length-1]===0x0d)b=b.subarray(0,b.length-1);
  return Buffer.from(b);
}

export function buildGuardianCeremonyRecord({electionInstanceId,beleniosElectionUuid,guardianPublicKeys,threshold,electionPublicKey,trusteesBytes,electionBytes}){
  const n=guardianPublicKeys.length;
  if(!/^ei1_[0-9a-f]{32}$/u.test(electionInstanceId)||!Number.isInteger(threshold)||threshold<2||threshold>n)failI06("CEREMONY_POLICY_INVALID");
  const orderedGuardians=guardianPublicKeys.map((publicKey,i)=>({guardian_id:`g${String(i+1).padStart(4,"0")}`,guardian_index_decimal:decimal(i+1),public_key:publicKey,public_key_digest:guardianPublicKeyDigest(publicKey)}));
  const set={schema_version:"epd2.pb01.guardian-set/1",election_instance_id:electionInstanceId,crypto_profile:CRYPTO_PROFILE,guardian_count_decimal:decimal(n),threshold_decimal:decimal(threshold),ordered_guardians:orderedGuardians};
  const setDigest=guardianSetDigest(set);
  const without={schema_version:CEREMONY_SCHEMA,canonicalization_policy_version:CANONICALIZATION_POLICY,election_instance_id:electionInstanceId,crypto_profile:CRYPTO_PROFILE,belenios_election_uuid:beleniosElectionUuid,guardian_count_decimal:decimal(n),threshold_decimal:decimal(threshold),ordered_guardians:orderedGuardians,guardian_set_digest:setDigest,election_public_key:electionPublicKey,trustees_json_base64url:Buffer.from(trusteesBytes).toString("base64url"),election_json_base64url:Buffer.from(electionBytes).toString("base64url"),ceremony_state:"CEREMONY_FROZEN"};
  return {...without,guardian_ceremony_digest:guardianCeremonyDigest(without)};
}
export function verifyGuardianCeremonyRecord(record){
  if(!record||record.schema_version!==CEREMONY_SCHEMA||record.crypto_profile!==CRYPTO_PROFILE||record.ceremony_state!=="CEREMONY_FROZEN")failI06("CEREMONY_INTEGRITY_FAILURE");
  const {guardian_ceremony_digest,...without}=record; reqHex(guardian_ceremony_digest,"CEREMONY_INTEGRITY_FAILURE");
  if(guardianCeremonyDigest(without)!==guardian_ceremony_digest)failI06("CEREMONY_INTEGRITY_FAILURE");
  const n=Number(record.guardian_count_decimal),t=Number(record.threshold_decimal); if(!Number.isInteger(n)||!Number.isInteger(t)||t<2||t>n||record.ordered_guardians?.length!==n)failI06("CEREMONY_INTEGRITY_FAILURE");
  const set={schema_version:"epd2.pb01.guardian-set/1",election_instance_id:record.election_instance_id,crypto_profile:record.crypto_profile,guardian_count_decimal:record.guardian_count_decimal,threshold_decimal:record.threshold_decimal,ordered_guardians:record.ordered_guardians};
  if(guardianSetDigest(set)!==record.guardian_set_digest)failI06("CEREMONY_INTEGRITY_FAILURE");
  for(let i=0;i<n;i++){const g=record.ordered_guardians[i];if(g.guardian_index_decimal!==String(i+1)||g.guardian_id!==`g${String(i+1).padStart(4,"0")}`||guardianPublicKeyDigest(g.public_key)!==g.public_key_digest)failI06("CEREMONY_INTEGRITY_FAILURE");}
  return {valid:true,guardian_count:n,threshold:t};
}
export function buildShareArtifact({ceremony,tally,guardianIndex,shareBytes}){
  shareBytes=normalizeBeleniosShareBytes(shareBytes);
  verifyGuardianCeremonyRecord(ceremony); const g=ceremony.ordered_guardians[guardianIndex-1]; if(!g)failI06("FOREIGN_GUARDIAN");
  const recomputedAggregate=aggregateCiphertextDigest(Buffer.from(tally.aggregate_ciphertext_bytes)); if(recomputedAggregate!==tally.aggregate_ciphertext_digest)failI06("I05_INTEGRITY_FAILURE");
  const without={schema_version:SHARE_SCHEMA,election_instance_id:ceremony.election_instance_id,crypto_profile:CRYPTO_PROFILE,tally_record_digest:tally.tally_record_digest,aggregate_ciphertext_digest:tally.aggregate_ciphertext_digest,guardian_ceremony_digest:ceremony.guardian_ceremony_digest,guardian_id:g.guardian_id,guardian_index_decimal:String(guardianIndex),guardian_public_key_digest:g.public_key_digest,belenios_partial_decryption_base64url:Buffer.from(shareBytes).toString("base64url")};
  return {...without,share_digest:partialDecryptionShareDigest(without)};
}
export function verifyShareArtifact(share,{ceremony,tally}){
  if(!share||share.schema_version!==SHARE_SCHEMA)failI06("SHARE_INTEGRITY_FAILURE"); verifyGuardianCeremonyRecord(ceremony);
  const {share_digest,...without}=share; if(partialDecryptionShareDigest(without)!==share_digest)failI06("SHARE_INTEGRITY_FAILURE");
  const i=Number(share.guardian_index_decimal),g=ceremony.ordered_guardians[i-1]; if(!g||g.guardian_id!==share.guardian_id||g.public_key_digest!==share.guardian_public_key_digest)failI06("FOREIGN_GUARDIAN");
  if(share.election_instance_id!==ceremony.election_instance_id||share.guardian_ceremony_digest!==ceremony.guardian_ceremony_digest)failI06("FOREIGN_ELECTION_SHARE");
  if(share.tally_record_digest!==tally.tally_record_digest||share.aggregate_ciphertext_digest!==tally.aggregate_ciphertext_digest)failI06("WRONG_AGGREGATE_SHARE");
  return {valid:true,guardian_index:i,share_bytes:Buffer.from(share.belenios_partial_decryption_base64url,"base64url")};
}
function normalizePlaintext(bytes){const x=JSON.parse(Buffer.from(bytes).toString("utf8"));if(!x||!Array.isArray(x.result))failI06("PLAINTEXT_TALLY_INVALID");const conv=(v)=>Array.isArray(v)?v.map(conv):(Number.isSafeInteger(v)&&v>=0?String(v):(()=>{throw new Error("bad plaintext");})());return conv(x.result);}
export function buildThresholdDecryptionRecord({ceremony,tally,thresholdShares,plaintextBytes}){
  const sorted=[...thresholdShares].sort((a,b)=>Number(a.guardian_index_decimal)-Number(b.guardian_index_decimal));
  const plainDigest=plaintextTallyDigest(plaintextBytes);
  const without={schema_version:DECRYPTION_RECORD_SCHEMA,election_instance_id:ceremony.election_instance_id,crypto_profile:CRYPTO_PROFILE,tally_record_digest:tally.tally_record_digest,f_final:tally.f_final,aggregate_ciphertext_digest:tally.aggregate_ciphertext_digest,guardian_ceremony_digest:ceremony.guardian_ceremony_digest,threshold_decimal:ceremony.threshold_decimal,ordered_threshold_share_digests:sorted.map(x=>x.share_digest),plaintext_tally:normalizePlaintext(plaintextBytes),plaintext_tally_base64url:Buffer.from(plaintextBytes).toString("base64url"),plaintext_tally_digest:plainDigest,completion_state:COMPLETE_STATE};
  return {...without,decryption_record_digest:thresholdDecryptionRecordDigest(without)};
}
export function verifyThresholdDecryptionRecord(record,{ceremony,tally}){
  if(!record||record.schema_version!==DECRYPTION_RECORD_SCHEMA||record.completion_state!==COMPLETE_STATE)failI06("DECRYPTION_RECORD_INTEGRITY_FAILURE");
  const {decryption_record_digest,...without}=record;if(thresholdDecryptionRecordDigest(without)!==decryption_record_digest)failI06("DECRYPTION_RECORD_INTEGRITY_FAILURE");
  if(record.election_instance_id!==ceremony.election_instance_id||record.guardian_ceremony_digest!==ceremony.guardian_ceremony_digest||record.tally_record_digest!==tally.tally_record_digest||record.aggregate_ciphertext_digest!==tally.aggregate_ciphertext_digest||record.f_final!==tally.f_final)failI06("DECRYPTION_RECORD_INTEGRITY_FAILURE");
  const pb=Buffer.from(record.plaintext_tally_base64url,"base64url");if(plaintextTallyDigest(pb)!==record.plaintext_tally_digest)failI06("DECRYPTION_RECORD_INTEGRITY_FAILURE");
  return {valid:true};
}
export function buildI07Handoff({ceremony,tally,acceptedShares,decryptionRecord}){
  const without={schema_version:I07_HANDOFF_SCHEMA,election_instance_id:ceremony.election_instance_id,crypto_profile:CRYPTO_PROFILE,guardian_ceremony_record:ceremony,guardian_ceremony_digest:ceremony.guardian_ceremony_digest,threshold_decimal:ceremony.threshold_decimal,tally_record_digest:tally.tally_record_digest,f_final:tally.f_final,aggregate_ciphertext_base64url:Buffer.from(tally.aggregate_ciphertext_bytes).toString("base64url"),aggregate_ciphertext_digest:tally.aggregate_ciphertext_digest,accepted_partial_decryption_shares:[...acceptedShares].sort((a,b)=>Number(a.guardian_index_decimal)-Number(b.guardian_index_decimal)),threshold_decryption_record:decryptionRecord,decryption_record_digest:decryptionRecord.decryption_record_digest,semantic_claim:"PUBLIC_CRYPTOGRAPHIC_DECRYPTION_EVIDENCE_NOT_PUBLICATION_AUTHORITY"};
  return {...without,i07_handoff_digest:i07HandoffDigest(without)};
}
