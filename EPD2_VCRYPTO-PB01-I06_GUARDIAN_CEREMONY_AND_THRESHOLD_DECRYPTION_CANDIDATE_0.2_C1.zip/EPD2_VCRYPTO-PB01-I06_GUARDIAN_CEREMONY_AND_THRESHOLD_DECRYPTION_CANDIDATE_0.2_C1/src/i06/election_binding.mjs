import { createHash } from 'node:crypto';
import { failI06 } from './errors.mjs';

function b64NoPad(bytes) {
  return Buffer.from(bytes).toString('base64').replace(/=+$/u, '');
}

function b64urlNoPad(bytes) {
  return Buffer.from(bytes).toString('base64url');
}

/**
 * Verifies the exact Belenios election bytes before an election context is
 * persisted for the I06 PostgreSQL production path. This function performs
 * no whitespace normalization: transport line terminators are not part of
 * the Belenios election artifact and must already have been removed by the
 * producer of the fixture/artifact.
 */
export function verifyPersistedElectionBinding(context, electionBytes) {
  const exact = Buffer.from(electionBytes);
  if (exact.length === 0) failI06('ELECTION_CONTEXT_BINDING_MISMATCH');

  // Fail rather than silently normalize a filesystem/text-editor line ending.
  if (exact.at(-1) === 0x0a || exact.at(-1) === 0x0d) {
    failI06('ELECTION_CONTEXT_BINDING_MISMATCH');
  }

  let election;
  try { election = JSON.parse(exact.toString('utf8')); }
  catch { failI06('ELECTION_CONTEXT_BINDING_MISMATCH'); }

  const fingerprint = b64NoPad(createHash('sha256').update(exact).digest());
  if (fingerprint !== context.belenios_election_fingerprint) {
    failI06('ELECTION_CONTEXT_BINDING_MISMATCH');
  }
  if (b64urlNoPad(exact) !== context.upstream_election_json_base64url) {
    failI06('ELECTION_CONTEXT_BINDING_MISMATCH');
  }
  if (election.uuid !== context.belenios_election_uuid) {
    failI06('ELECTION_CONTEXT_BINDING_MISMATCH');
  }
  const pk = typeof election.public_key === 'string' ? election.public_key : election.public_key?.y;
  if (typeof pk !== 'string' || pk !== context.election_public_key) {
    failI06('ELECTION_CONTEXT_BINDING_MISMATCH');
  }

  return Object.freeze({
    election_instance_id: context.election_instance_id,
    belenios_election_uuid: election.uuid,
    belenios_election_fingerprint: fingerprint,
    exact_election_byte_length: exact.length,
    exact_election_bytes_sha256_hex: createHash('sha256').update(exact).digest('hex')
  });
}
