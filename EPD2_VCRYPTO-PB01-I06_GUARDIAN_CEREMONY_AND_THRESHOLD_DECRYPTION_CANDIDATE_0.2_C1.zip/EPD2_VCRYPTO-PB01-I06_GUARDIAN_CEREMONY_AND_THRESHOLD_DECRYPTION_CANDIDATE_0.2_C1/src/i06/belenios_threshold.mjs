import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile, copyFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, join } from "node:path";
import { failI06 } from "./errors.mjs";
function sha256Hex(bytes){return createHash("sha256").update(bytes).digest("hex");}
function run(command,args,{input=null,timeoutMs=60000}={}){return new Promise((resolve,reject)=>{const child=spawn(command,args,{stdio:["pipe","pipe","pipe"]});const out=[],err=[];let timed=false;const timer=setTimeout(()=>{timed=true;child.kill("SIGKILL");},timeoutMs);child.stdout.on("data",c=>out.push(c));child.stderr.on("data",c=>err.push(c));child.once("error",reject);child.once("exit",code=>{clearTimeout(timer);const stdout=Buffer.concat(out),stderr=Buffer.concat(err).toString("utf8");if(code===0&&!timed)resolve({stdout,stderr});else reject(new Error(`BELENIOS_I06_FAILED:${code}:${stderr.trim()}`));});if(input)child.stdin.end(input);else child.stdin.end();});}
function firstLine(bytes){const i=bytes.indexOf(0x0a);return i<0?Buffer.from(bytes):Buffer.from(bytes.subarray(0,i));}
export class BeleniosThresholdAdapter {
  constructor({toolPath,templatePath,timeoutMs=60000}){this.toolPath=toolPath;this.templatePath=templatePath;this.timeoutMs=timeoutMs;}
  async verifyCeremony({thresholdBytes,trusteesBytes,electionBytes,electionUuid}){
    const dir=await mkdtemp(join(tmpdir(),"epd2-i06-ceremony-"));
    try{
      await writeFile(join(dir,"threshold.json"),thresholdBytes);await writeFile(join(dir,"public_keys.jsons"),Buffer.alloc(0));
      await run(this.toolPath,["setup","make-trustees",`--dir=${dir}`],{timeoutMs:this.timeoutMs});
      const generatedTrustees=await readFile(join(dir,"trustees.json"));
      if(!generatedTrustees.equals(Buffer.from(trusteesBytes)))failI06("CEREMONY_UPSTREAM_MISMATCH");
      await run(this.toolPath,["setup","make-election",`--dir=${dir}`,`--uuid=${electionUuid}`,"--group=Ed25519",`--template=${this.templatePath}`],{timeoutMs:this.timeoutMs});
      const generatedElection=await readFile(join(dir,"election.json"));
      if(!generatedElection.equals(Buffer.from(electionBytes)))failI06("CEREMONY_UPSTREAM_MISMATCH");
      const trustees=JSON.parse(generatedTrustees.toString("utf8"));const ped=trustees.find(x=>Array.isArray(x)&&x[0]==="Pedersen")?.[1];
      if(!ped||!Number.isInteger(ped.threshold)||ped.threshold<2||!Array.isArray(ped.verification_keys))failI06("CEREMONY_POLICY_INVALID");
      const election=JSON.parse(generatedElection.toString("utf8"));
      return {guardian_count:ped.verification_keys.length,threshold:ped.threshold,guardian_public_keys:ped.verification_keys.map(x=>x.public_key),election_public_key:election.public_key,trustees_bytes:generatedTrustees,election_bytes:generatedElection};
    } finally {await rm(dir,{recursive:true,force:true});}
  }
  async recomputeAggregateFromArchive(baseArchivePath){
    const dir=await mkdtemp(join(tmpdir(),"epd2-i06-aggregate-"));
    try{await copyFile(baseArchivePath,join(dir,basename(baseArchivePath).replace(/\.bel$/u,"")+".bel"));const r=await run(this.toolPath,["election","compute-encrypted-tally",`--dir=${dir}`],{timeoutMs:this.timeoutMs});return firstLine(r.stdout);}finally{await rm(dir,{recursive:true,force:true});}
  }
  async verifyArchiveAggregate({baseArchivePath,expectedAggregateBytes}){const got=await this.recomputeAggregateFromArchive(baseArchivePath);if(!got.equals(Buffer.from(expectedAggregateBytes)))failI06("I05_ARCHIVE_AGGREGATE_MISMATCH");return {valid:true,aggregate_bytes:got};}
  async computeVerifiedResult({baseArchivePath,shares}){
    const dir=await mkdtemp(join(tmpdir(),"epd2-i06-decrypt-"));
    try{
      const dest=join(dir,"election.bel");await copyFile(baseArchivePath,dest);
      for(const share of shares){let raw=Buffer.from(share.share_bytes);if(raw.length&&raw[raw.length-1]===0x0a)raw=raw.subarray(0,raw.length-1);if(raw.length&&raw[raw.length-1]===0x0d)raw=raw.subarray(0,raw.length-1);let obj;try{obj=JSON.parse(raw.toString("utf8"));}catch{failI06("INVALID_SHARE_PROOF");}if(!obj||!Array.isArray(obj.decryption_factors)||!Array.isArray(obj.decryption_proofs))failI06("INVALID_SHARE_PROOF");const owner=Buffer.from(JSON.stringify({owner:share.guardian_index,payload:sha256Hex(raw)}),"utf8");const input=Buffer.concat([raw,Buffer.from("\n"),owner,Buffer.from("\n")]);try{await run(this.toolPath,["archive","add-event",`--dir=${dir}`,"--type=PartialDecryption"],{input,timeoutMs:this.timeoutMs});}catch(error){failI06("INVALID_SHARE_PROOF",409,error.message);}}
      let result;try{result=await run(this.toolPath,["election","compute-result",`--dir=${dir}`],{timeoutMs:this.timeoutMs});}catch(error){failI06("THRESHOLD_DECRYPTION_FAILED",409,error.message);}
      const resultBytes=firstLine(result.stdout);
      try{await run(this.toolPath,["archive","add-event",`--dir=${dir}`,"--type=Result"],{input:Buffer.concat([resultBytes,Buffer.from("\n")]),timeoutMs:this.timeoutMs});await run(this.toolPath,["election","verify",`--dir=${dir}`],{timeoutMs:this.timeoutMs});}catch(error){failI06("THRESHOLD_DECRYPTION_FAILED",409,error.message);}
      return {plaintext_bytes:resultBytes,plaintext:JSON.parse(resultBytes.toString("utf8"))};
    } finally {await rm(dir,{recursive:true,force:true});}
  }
}
