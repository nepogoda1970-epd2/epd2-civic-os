import { guardianPublicKeyDigest } from "./hashes.mjs";
import { buildGuardianCeremonyRecord, verifyGuardianCeremonyRecord } from "./records.mjs";
import { failI06 } from "./errors.mjs";
export class GuardianCeremonyCoordinator {
  constructor({store,adapter}){this.store=store;this.adapter=adapter;}
  async create({electionInstanceId,guardianCount,threshold,beleniosElectionUuid}){
    if(!Number.isInteger(guardianCount)||guardianCount<2||!Number.isInteger(threshold)||threshold<2||threshold>guardianCount)failI06('CEREMONY_POLICY_INVALID');
    const election=await this.store.electionContext(electionInstanceId);if(!election)failI06('ELECTION_NOT_FOUND',404);
    if(election.belenios_election_uuid!==beleniosElectionUuid)failI06('CEREMONY_ELECTION_MISMATCH');
    return this.store.create({electionInstanceId,guardianCount,threshold,beleniosElectionUuid});
  }
  async registerGuardians(eid,count){for(let i=1;i<=count;i++)await this.store.registerGuardian(eid,i,`g${String(i).padStart(4,'0')}`);return this.store.read(eid);}
  async submitPublicKeys(eid,publicKeys){for(let i=0;i<publicKeys.length;i++)await this.store.submitPublicKey(eid,i+1,publicKeys[i],guardianPublicKeyDigest(publicKeys[i]));return this.store.read(eid);}
  async verifyAndFreeze(eid,{thresholdBytes,trusteesBytes,electionBytes}){
    const current=await this.store.read(eid);if(!current||current.ceremony_state!=='PUBLIC_KEYS_SUBMITTED')failI06('CEREMONY_STATE_INVALID');
    const upstream=await this.adapter.verifyCeremony({thresholdBytes,trusteesBytes,electionBytes,electionUuid:current.belenios_election_uuid});
    if(upstream.guardian_count!==current.guardian_count||upstream.threshold!==current.threshold)failI06('CEREMONY_POLICY_INVALID');
    if(current.guardians.length!==upstream.guardian_public_keys.length)failI06('CEREMONY_MEMBERSHIP_MISMATCH');
    for(let i=0;i<current.guardians.length;i++)if(current.guardians[i].public_key!==upstream.guardian_public_keys[i])failI06('CEREMONY_MEMBERSHIP_MISMATCH');
    const electionContext=await this.store.electionContext(eid);if(electionContext?.election_public_key!==upstream.election_public_key)failI06('CEREMONY_ELECTION_PUBLIC_KEY_MISMATCH');
    await this.store.markVerified(eid,{electionPublicKey:upstream.election_public_key,thresholdParametersBytes:thresholdBytes,trusteesBytes:upstream.trustees_bytes,electionBytes:upstream.election_bytes});
    const record=buildGuardianCeremonyRecord({electionInstanceId:eid,beleniosElectionUuid:current.belenios_election_uuid,guardianPublicKeys:upstream.guardian_public_keys,threshold:upstream.threshold,electionPublicKey:upstream.election_public_key,trusteesBytes:upstream.trustees_bytes,electionBytes:upstream.election_bytes});
    verifyGuardianCeremonyRecord(record);await this.store.freeze(eid,record);return record;
  }
}
