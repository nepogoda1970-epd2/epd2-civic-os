import { createServer } from 'node:http';
import { canonicalize } from '../i01_reference/pb01_profile.mjs';
import { failI06 } from './errors.mjs';
const LIMIT=1024*1024;
async function body(req){const chunks=[];let n=0;for await(const c of req){n+=c.length;if(n>LIMIT)failI06('REQUEST_TOO_LARGE',413);chunks.push(c);}return Buffer.concat(chunks);}
function send(res,status,value){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});res.end(canonicalize(value));}
export function createI06Service({engine}){return createServer(async(req,res)=>{try{
  let m=/^\/v1\/elections\/(ei1_[0-9a-f]{32})\/guardian-shares\/(g[0-9]{4})$/u.exec(req.url||'');
  if(m&&req.method==='POST'){
    if(req.headers['content-type']!=='application/json')failI06('INVALID_SHARE_SCHEMA',415);
    const raw=await body(req);let x;try{x=JSON.parse(raw.toString('utf8'));}catch{failI06('INVALID_SHARE_SCHEMA');}
    // Public Belenios contribution only. No aggregate/ciphertext selection or secret material is accepted.
    const keys=Object.keys(x??{}).sort();if(keys.join(',')!=='decryption_factors,decryption_proofs')failI06('INVALID_SHARE_SCHEMA');
    const result=await engine.submitShare(m[1],m[2],Buffer.from(JSON.stringify(x),'utf8'));
    return send(res,result.state==='NOT_DECRYPTED'?202:200,{state:result.state,share_digest:result.share_digest??null,decryption_record_digest:result.decryption_record?.decryption_record_digest??null});
  }
  m=/^\/v1\/elections\/(ei1_[0-9a-f]{32})\/threshold-decryption$/u.exec(req.url||'');
  if(m&&req.method==='POST'){
    const raw=await body(req);if(raw.length!==0)failI06('ARBITRARY_DECRYPTION_INPUT_PROHIBITED');
    const r=await engine.tryComplete(m[1]);return send(res,r.state==='NOT_DECRYPTED'?202:200,{state:r.state,decryption_record_digest:r.decryption_record?.decryption_record_digest??null});
  }
  failI06('NOT_FOUND',404);
 }catch(e){send(res,e?.status??409,{error:e?.code??'I06_INTERNAL_FAILURE'});}});}
export async function startI06Service(options){const s=createI06Service(options);await new Promise((resolve,reject)=>{s.once('error',reject);s.listen(options.port??0,options.host??'127.0.0.1',resolve)});return s;}
