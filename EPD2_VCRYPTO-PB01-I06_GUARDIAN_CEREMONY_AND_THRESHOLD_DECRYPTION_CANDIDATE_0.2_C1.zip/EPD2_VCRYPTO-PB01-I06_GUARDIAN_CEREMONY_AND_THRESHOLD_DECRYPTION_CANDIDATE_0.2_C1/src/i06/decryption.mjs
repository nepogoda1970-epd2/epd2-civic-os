import { aggregateCiphertextDigest } from "../i05/hashes.mjs";
import { buildI07Handoff, buildShareArtifact, buildThresholdDecryptionRecord, normalizeBeleniosShareBytes, verifyGuardianCeremonyRecord, verifyShareArtifact, verifyThresholdDecryptionRecord } from "./records.mjs";
import { failI06 } from "./errors.mjs";
function bytesFromArtifact(a){return Buffer.from(a.belenios_partial_decryption_base64url,'base64url');}
function verifyStoredRecordProjection(stored,c){
  if(!stored?.record)return;
  const r=stored.record,p=stored.projection??{};
  if(stored.decryption_record_digest!==r.decryption_record_digest
    ||p.tally_record_digest!==r.tally_record_digest||p.f_final!==r.f_final
    ||p.aggregate_ciphertext_digest!==r.aggregate_ciphertext_digest
    ||p.guardian_ceremony_digest!==r.guardian_ceremony_digest
    ||p.threshold!==Number(r.threshold_decimal)
    ||JSON.stringify(p.threshold_share_digests)!==JSON.stringify(r.ordered_threshold_share_digests)
    ||p.plaintext_tally_digest!==r.plaintext_tally_digest
    ||p.completion_state!==r.completion_state
    ||Buffer.from(r.plaintext_tally_base64url,'base64url').compare(stored.plaintext_tally_bytes)!==0
    ||r.tally_record_digest!==c.tally.tally_record_digest
    ||r.aggregate_ciphertext_digest!==c.tally.aggregate_ciphertext_digest
    ||r.guardian_ceremony_digest!==c.ceremony_record.guardian_ceremony_digest) failI06('DECRYPTION_RECORD_INTEGRITY_FAILURE');
}
export class ThresholdDecryptionEngine{
 constructor({finalizerStore,inboxStore,i05Engine,adapter,baseArchiveResolver,failpoint=null}){this.finalizerStore=finalizerStore;this.inboxStore=inboxStore;this.i05Engine=i05Engine;this.adapter=adapter;this.baseArchiveResolver=baseArchiveResolver;this.failpoint=failpoint;}
 async authorizedContext(eid){
   try{const r=await this.i05Engine.recompute(eid);if(r.status!=='PASS')failI06('I05_INTEGRITY_FAILURE');}catch(e){if(e?.code==='I05_INTEGRITY_FAILURE')throw e;failI06('I05_INTEGRITY_FAILURE',409,e?.code??e?.message);}
   const c=await this.finalizerStore.readContext(eid);if(!c||c.ceremony_state!=='CEREMONY_FROZEN'||!c.ceremony_record)failI06('CEREMONY_NOT_FROZEN');
   const vr=verifyGuardianCeremonyRecord(c.ceremony_record);if(vr.guardian_count!==c.guardian_count||vr.threshold!==c.threshold||c.guardian_ceremony_digest!==c.ceremony_record.guardian_ceremony_digest||c.guardian_set_digest!==c.ceremony_record.guardian_set_digest||c.election_public_key!==c.ceremony_record.election_public_key)failI06('CEREMONY_INTEGRITY_FAILURE');
   if(c.guardians.length!==c.ceremony_record.ordered_guardians.length)failI06('CEREMONY_INTEGRITY_FAILURE');for(let i=0;i<c.guardians.length;i++){const a=c.guardians[i],b=c.ceremony_record.ordered_guardians[i];if(a.guardian_index!==Number(b.guardian_index_decimal)||a.guardian_id!==b.guardian_id||a.public_key!==b.public_key||a.public_key_digest!==b.public_key_digest)failI06('CEREMONY_INTEGRITY_FAILURE');}
   const recomputed=aggregateCiphertextDigest(c.tally.aggregate_ciphertext_bytes);if(recomputed!==c.tally.aggregate_ciphertext_digest||recomputed!==c.tally.aggregate_row_digest)failI06('I05_INTEGRITY_FAILURE');
   const baseArchivePath=await this.baseArchiveResolver(eid);if(!baseArchivePath)failI06('BELENIOS_CONTEXT_MISSING');await this.adapter.verifyArchiveAggregate({baseArchivePath,expectedAggregateBytes:c.tally.aggregate_ciphertext_bytes});
   return {...c,baseArchivePath};
 }
 async submitShare(eid,guardianId,shareBytes){
   const c=await this.authorizedContext(eid);const g=c.guardians.find(x=>x.guardian_id===guardianId);if(!g)failI06('FOREIGN_GUARDIAN');
   const raw=normalizeBeleniosShareBytes(shareBytes);let parsed;try{parsed=JSON.parse(raw.toString('utf8'));}catch{failI06('INVALID_SHARE_PROOF');}if(!parsed||!Array.isArray(parsed.decryption_factors)||!Array.isArray(parsed.decryption_proofs))failI06('INVALID_SHARE_PROOF');
   const artifact=buildShareArtifact({ceremony:c.ceremony_record,tally:c.tally,guardianIndex:g.guardian_index,shareBytes:raw});verifyShareArtifact(artifact,{ceremony:c.ceremony_record,tally:c.tally});
   const insertion=await this.inboxStore.insertPending({artifact,shareBytes:raw});await this.failpoint?.('after_share_persistence_before_threshold_evaluation');
   const completion=await this.tryComplete(eid);return {...completion,share_digest:artifact.share_digest,replay:insertion.replay};
 }
 async tryComplete(eid){
   const c=await this.authorizedContext(eid);const existing=await this.finalizerStore.record(eid);const pending=await this.finalizerStore.pending(eid);const accepted=await this.finalizerStore.accepted(eid);
   const acceptedIndex=new Set(accepted.map(x=>x.guardian_index));
   if(existing){
     verifyThresholdDecryptionRecord(existing.record,{ceremony:c.ceremony_record,tally:c.tally});verifyStoredRecordProjection(existing,c);
     for(const p of pending.filter(x=>!acceptedIndex.has(x.guardian_index))){const base=accepted.slice(0,c.threshold-1).map(x=>({guardian_index:x.guardian_index,share_bytes:bytesFromArtifact(x.artifact)}));const candidate={guardian_index:p.guardian_index,share_bytes:p.share_bytes};const r=await this.adapter.computeVerifiedResult({baseArchivePath:c.baseArchivePath,shares:[...base,candidate]});if(!Buffer.from(r.plaintext_bytes).equals(existing.plaintext_tally_bytes))failI06('DECRYPTION_CONFLICT');await this.finalizerStore.acceptExtra({eid,artifact:p.artifact});}
     return {state:existing.record.completion_state,decryption_record:existing.record};
   }
   const candidates=pending.filter(x=>!acceptedIndex.has(x.guardian_index)).slice(0,c.threshold);if(candidates.length<c.threshold)return {state:'NOT_DECRYPTED',accepted_share_count:accepted.length,pending_share_count:pending.length};
   for(const p of candidates)verifyShareArtifact(p.artifact,{ceremony:c.ceremony_record,tally:c.tally});
   let verified;try{verified=await this.adapter.computeVerifiedResult({baseArchivePath:c.baseArchivePath,shares:candidates.map(x=>({guardian_index:x.guardian_index,share_bytes:x.share_bytes}))});}catch(e){failI06('INVALID_SHARE_PROOF',409,e?.detail??e?.message);}
   await this.failpoint?.('after_valid_share_verification_before_acceptance');
   const artifacts=candidates.map(x=>x.artifact);const record=buildThresholdDecryptionRecord({ceremony:c.ceremony_record,tally:c.tally,thresholdShares:artifacts,plaintextBytes:verified.plaintext_bytes});
   await this.finalizerStore.commitThreshold({eid,thresholdArtifacts:artifacts,record,failpoint:this.failpoint});await this.failpoint?.('after_final_record_commit_before_response');return {state:record.completion_state,decryption_record:record};
 }
 async recompute(eid){
   const c=await this.authorizedContext(eid),stored=await this.finalizerStore.record(eid);if(!stored)return {status:'PASS_NOT_DECRYPTED'};verifyThresholdDecryptionRecord(stored.record,{ceremony:c.ceremony_record,tally:c.tally});verifyStoredRecordProjection(stored,c);const accepted=await this.finalizerStore.accepted(eid);const byDigest=new Map(accepted.map(x=>[x.share_digest,x]));const thresholdShares=stored.record.ordered_threshold_share_digests.map(d=>byDigest.get(d));if(thresholdShares.some(x=>!x))failI06('DECRYPTION_RECORD_INTEGRITY_FAILURE');for(const x of thresholdShares)verifyShareArtifact(x.artifact,{ceremony:c.ceremony_record,tally:c.tally});const r=await this.adapter.computeVerifiedResult({baseArchivePath:c.baseArchivePath,shares:thresholdShares.map(x=>({guardian_index:x.guardian_index,share_bytes:bytesFromArtifact(x.artifact)}))});if(!Buffer.from(r.plaintext_bytes).equals(stored.plaintext_tally_bytes))failI06('DECRYPTION_RECOMPUTE_MISMATCH');return {status:'PASS',decryption_record_digest:stored.record.decryption_record_digest,plaintext_tally_digest:stored.record.plaintext_tally_digest};
 }
 async exportI07(eid){const c=await this.authorizedContext(eid),stored=await this.finalizerStore.record(eid);if(!stored)failI06('NOT_DECRYPTED');const accepted=(await this.finalizerStore.accepted(eid)).map(x=>x.artifact);return buildI07Handoff({ceremony:c.ceremony_record,tally:c.tally,acceptedShares:accepted,decryptionRecord:stored.record});}
}
