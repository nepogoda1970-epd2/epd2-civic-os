export class I06Error extends Error {
  constructor(code, status=409, detail=null){super(code);this.name="I06Error";this.code=code;this.status=status;this.detail=detail;}
}
export function failI06(code,status=409,detail=null){throw new I06Error(code,status,detail);}
