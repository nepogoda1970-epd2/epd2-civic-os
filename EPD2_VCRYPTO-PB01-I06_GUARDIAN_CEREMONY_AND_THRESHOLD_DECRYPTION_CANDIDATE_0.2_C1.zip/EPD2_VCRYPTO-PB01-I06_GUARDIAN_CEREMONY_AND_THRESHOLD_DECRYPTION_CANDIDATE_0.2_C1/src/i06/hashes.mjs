import { canonicalBytes, domainHash } from "../i01_reference/pb01_profile.mjs";
import {
  DOMAIN_GUARDIAN_CEREMONY, DOMAIN_GUARDIAN_PUBLIC_KEY, DOMAIN_GUARDIAN_SET,
  DOMAIN_I07_HANDOFF, DOMAIN_PARTIAL_DECRYPTION_SHARE, DOMAIN_PLAINTEXT_TALLY,
  DOMAIN_THRESHOLD_DECRYPTION_RECORD,
} from "./constants.mjs";
export const guardianPublicKeyDigest=(publicKey)=>domainHash(DOMAIN_GUARDIAN_PUBLIC_KEY,Buffer.from(publicKey,"ascii"));
export const guardianSetDigest=(value)=>domainHash(DOMAIN_GUARDIAN_SET,canonicalBytes(value));
export const guardianCeremonyDigest=(value)=>domainHash(DOMAIN_GUARDIAN_CEREMONY,canonicalBytes(value));
export const partialDecryptionShareDigest=(value)=>domainHash(DOMAIN_PARTIAL_DECRYPTION_SHARE,canonicalBytes(value));
export const plaintextTallyDigest=(bytes)=>domainHash(DOMAIN_PLAINTEXT_TALLY,Buffer.from(bytes));
export const thresholdDecryptionRecordDigest=(value)=>domainHash(DOMAIN_THRESHOLD_DECRYPTION_RECORD,canonicalBytes(value));
export const i07HandoffDigest=(value)=>domainHash(DOMAIN_I07_HANDOFF,canonicalBytes(value));
