import { sign, verify } from "node:crypto";
import { canonicalBytes, domainHash } from "../i01_reference/pb01_profile.mjs";
import {
  CLOSURE_AUTH_EVIDENCE_SCHEMA,
  CLOSURE_AUTH_STATEMENT_SCHEMA,
  DOMAIN_CLOSURE_AUTHORIZATION,
  DOMAIN_CLOSURE_AUTH_EVIDENCE,
  FINALIZATION_PROCESS_ID,
  REVOTE_POLICY,
} from "./constants.mjs";
import { failI04 } from "./errors.mjs";

const encoder = new TextEncoder();

function signingBytes(statement) {
  return Buffer.concat([
    Buffer.from(DOMAIN_CLOSURE_AUTHORIZATION, "ascii"),
    Buffer.from([0]),
    Buffer.from(canonicalBytes(statement)),
  ]);
}

export function validateCheckpoint(checkpoint) {
  if (!checkpoint || checkpoint.schema_version !== "epd2.pb01.closure-ledger-checkpoint/1") failI04("INVALID_FINALIZATION_SCHEMA");
  if (!/^ei1_[0-9a-f]{32}$/u.test(checkpoint.election_instance_id)) failI04("INVALID_FINALIZATION_SCHEMA");
  if (!/^(0|[1-9][0-9]*)$/u.test(checkpoint.ledger_event_count)) failI04("INVALID_FINALIZATION_SCHEMA");
  if (!/^(0|[1-9][0-9]*)$/u.test(checkpoint.ledger_seq)) failI04("INVALID_FINALIZATION_SCHEMA");
  if (checkpoint.ledger_event_count !== checkpoint.ledger_seq) failI04("LEDGER_INTEGRITY_FAILURE");
  if (!/^[0-9a-f]{64}$/u.test(checkpoint.ledger_event_hash)) failI04("INVALID_FINALIZATION_SCHEMA");
  if (!/^[0-9a-f]{64}$/u.test(checkpoint.accepted_manifest_digest)) failI04("INVALID_FINALIZATION_SCHEMA");
}

export function buildClosureAuthorizationStatement({
  electionInstanceId,
  checkpoint,
  closedAt,
  revotePolicyVersion = REVOTE_POLICY,
  finalizationProcessId = FINALIZATION_PROCESS_ID,
}) {
  const statement = {
    schema_version: CLOSURE_AUTH_STATEMENT_SCHEMA,
    election_instance_id: electionInstanceId,
    closure_ledger_checkpoint: checkpoint,
    closed_at: closedAt,
    revote_policy_version: revotePolicyVersion,
    finalization_process_id: finalizationProcessId,
  };
  validateClosureAuthorizationStatement(statement);
  return statement;
}

export function validateClosureAuthorizationStatement(statement) {
  if (!statement || Object.getPrototypeOf(statement) !== Object.prototype) failI04("INVALID_FINALIZATION_SCHEMA");
  const expected = [
    "schema_version", "election_instance_id", "closure_ledger_checkpoint", "closed_at",
    "revote_policy_version", "finalization_process_id",
  ];
  if (Object.keys(statement).sort().join("|") !== expected.sort().join("|")) failI04("INVALID_FINALIZATION_SCHEMA");
  if (statement.schema_version !== CLOSURE_AUTH_STATEMENT_SCHEMA) failI04("INVALID_FINALIZATION_SCHEMA");
  if (!/^ei1_[0-9a-f]{32}$/u.test(statement.election_instance_id)) failI04("INVALID_FINALIZATION_SCHEMA");
  if (!/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$/u.test(statement.closed_at)) failI04("INVALID_FINALIZATION_SCHEMA");
  if (statement.revote_policy_version !== REVOTE_POLICY) failI04("UNKNOWN_REVOTE_POLICY");
  if (statement.finalization_process_id !== FINALIZATION_PROCESS_ID) failI04("INVALID_FINALIZATION_SCHEMA");
  validateCheckpoint(statement.closure_ledger_checkpoint);
  if (statement.closure_ledger_checkpoint.election_instance_id !== statement.election_instance_id) failI04("INVALID_FINALIZATION_SCHEMA");
}

export function closureAuthorizationStatementDigest(statement) {
  validateClosureAuthorizationStatement(statement);
  return domainHash(DOMAIN_CLOSURE_AUTHORIZATION, canonicalBytes(statement));
}

export function issueClosureAuthorization({ statement, privateKey, keyId }) {
  validateClosureAuthorizationStatement(statement);
  if (!/^[A-Za-z0-9._:/+-]{1,128}$/u.test(keyId)) failI04("INVALID_FINALIZATION_SCHEMA");
  const evidence = {
    schema_version: CLOSURE_AUTH_EVIDENCE_SCHEMA,
    key_id: keyId,
    algorithm: "Ed25519",
    statement,
    signature_base64url: sign(null, signingBytes(statement), privateKey).toString("base64url"),
  };
  return {
    ...evidence,
    authorization_evidence_digest: domainHash(DOMAIN_CLOSURE_AUTH_EVIDENCE, canonicalBytes(evidence)),
  };
}

export class ClosureAuthorizationVerifier {
  constructor(keys) {
    this.keys = keys instanceof Map ? keys : new Map(Object.entries(keys ?? {}));
  }

  verify(evidence, expectedElectionInstanceId = null) {
    try {
      if (!evidence || evidence.schema_version !== CLOSURE_AUTH_EVIDENCE_SCHEMA || evidence.algorithm !== "Ed25519") {
        failI04("INVALID_CLOSURE_AUTHORIZATION", 403);
      }
      const expected = [
        "schema_version", "key_id", "algorithm", "statement", "signature_base64url", "authorization_evidence_digest",
      ];
      if (Object.keys(evidence).sort().join("|") !== expected.sort().join("|")) failI04("INVALID_CLOSURE_AUTHORIZATION", 403);
      validateClosureAuthorizationStatement(evidence.statement);
      if (expectedElectionInstanceId && evidence.statement.election_instance_id !== expectedElectionInstanceId) {
        failI04("INVALID_CLOSURE_AUTHORIZATION", 403);
      }
      const publicKey = this.keys.get(evidence.key_id);
      if (!publicKey) failI04("INVALID_CLOSURE_AUTHORIZATION", 403);
      const unsigned = {
        schema_version: evidence.schema_version,
        key_id: evidence.key_id,
        algorithm: evidence.algorithm,
        statement: evidence.statement,
        signature_base64url: evidence.signature_base64url,
      };
      const expectedDigest = domainHash(DOMAIN_CLOSURE_AUTH_EVIDENCE, canonicalBytes(unsigned));
      if (expectedDigest !== evidence.authorization_evidence_digest) failI04("INVALID_CLOSURE_AUTHORIZATION", 403);
      const signature = Buffer.from(evidence.signature_base64url, "base64url");
      if (signature.length !== 64 || !verify(null, signingBytes(evidence.statement), publicKey, signature)) {
        failI04("INVALID_CLOSURE_AUTHORIZATION", 403);
      }
      return evidence.statement;
    } catch (error) {
      if (error?.code === "UNKNOWN_REVOTE_POLICY") throw error;
      if (error?.code === "INVALID_FINALIZATION_SCHEMA") failI04("INVALID_CLOSURE_AUTHORIZATION", 403);
      throw error;
    }
  }
}

export function authorizationEvidenceDigest(evidence) {
  const unsigned = {
    schema_version: evidence.schema_version,
    key_id: evidence.key_id,
    algorithm: evidence.algorithm,
    statement: evidence.statement,
    signature_base64url: evidence.signature_base64url,
  };
  return domainHash(DOMAIN_CLOSURE_AUTH_EVIDENCE, canonicalBytes(unsigned));
}

export function authorizationMessageUtf8(statement) {
  return encoder.decode(signingBytes(statement));
}

