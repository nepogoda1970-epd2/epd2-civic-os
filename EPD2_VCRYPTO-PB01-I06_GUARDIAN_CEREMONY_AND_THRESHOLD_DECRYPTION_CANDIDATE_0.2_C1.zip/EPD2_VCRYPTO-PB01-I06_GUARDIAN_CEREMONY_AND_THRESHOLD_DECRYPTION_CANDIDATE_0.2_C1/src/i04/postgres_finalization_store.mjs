import { randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import pg from "pg";
import { canonicalize } from "../i02_accepted/shared/profile.mjs";
import { ledgerEventHash } from "../i03/hashes.mjs";
import { ZERO_HASH } from "../i03/constants.mjs";
import { validateClosureAuthorizationStatement } from "./closure_authority.mjs";
import { failI04 } from "./errors.mjs";
import {
  buildAcceptedManifestAtCheckpoint,
  buildAuthorizedFinalBallotSet,
  buildClosureCheckpoint,
  buildFinalArtifacts,
  resolveLatestValid,
  verifyPublicFinalEvidence,
} from "./finalization.mjs";

const { Pool } = pg;

function jsonValue(value) {
  return typeof value === "string" ? JSON.parse(value) : value;
}

function canonicalString(value) {
  return canonicalize(value);
}

function isoExpression(column) {
  return `to_char(${column} AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`;
}

function run(command, args, env) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { env, stdio: ["ignore", "pipe", "pipe"] });
    const stderr = [];
    child.stderr.on("data", (chunk) => stderr.push(chunk));
    child.once("error", reject);
    child.once("exit", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`POSTGRES_BACKUP_FAILED:${Buffer.concat(stderr).toString("utf8").trim()}`));
    });
  });
}

function sameCanonical(left, right) {
  return canonicalString(left) === canonicalString(right);
}

function verifyLedgerRows(rows, electionInstanceId) {
  let previous = ZERO_HASH;
  let sequence = 0;
  for (const row of rows) {
    sequence += 1;
    const event = jsonValue(row.event_json);
    if (
      Number(row.ledger_seq) !== sequence
      || row.previous_event_hash !== previous
      || row.election_instance_id !== electionInstanceId
      || row.submission_election_instance_id !== electionInstanceId
      || row.submission_ballot_digest !== row.ballot_digest
      || event.event_version !== row.event_version
      || event.ledger_event_id !== row.ledger_event_id
      || event.ledger_seq !== String(row.ledger_seq)
      || event.submission_id !== row.submission_id
      || event.election_instance_id !== row.election_instance_id
      || event.ballot_digest !== row.ballot_digest
      || event.accepted_at !== row.accepted_at
      || event.previous_event_hash !== row.previous_event_hash
      || ledgerEventHash(event) !== row.event_hash
    ) failI04("LEDGER_INTEGRITY_FAILURE");
    previous = row.event_hash;
  }
  return { ledger_seq: String(sequence), ledger_event_hash: previous };
}

function parseFinalizationRow(row) {
  if (!row) return null;
  return {
    election_instance_id: row.election_instance_id,
    finalization_id: row.finalization_id,
    finalization_state: row.finalization_state,
    committed_at: row.committed_at,
    closure_record: jsonValue(row.closure_record_canonical),
    closure_ledger_checkpoint: jsonValue(row.closure_checkpoint_canonical),
    closure_authorization: jsonValue(row.authorization_evidence_canonical),
    accepted_manifest_at_closure: jsonValue(row.accepted_manifest_canonical),
    cset_final: jsonValue(row.cset_final_canonical),
    cset_root: row.cset_root,
    final_set_envelope: jsonValue(row.final_set_envelope_canonical),
    final_set_envelope_digest: row.final_set_envelope_digest,
    f_final: row.f_final,
    public_evidence: jsonValue(row.public_evidence_canonical),
    public_evidence_digest: row.public_evidence_digest,
  };
}

export class PostgresFinalizationStore {
  constructor(config) {
    const { pool, backup = null, ...poolConfig } = config ?? {};
    this.pool = pool ?? new Pool(poolConfig);
    this.backup = backup;
  }

  async getElection(electionInstanceId, client = this.pool) {
    const result = await client.query(`
      SELECT election_instance_id, crypto_profile, tally_function_id, belenios_election_uuid,
        belenios_election_hash, context_json, context_sha256, election_state,
        ${isoExpression("created_at")} AS created_at
      FROM pb01_i03.elections WHERE election_instance_id = $1
    `, [electionInstanceId]);
    return result.rows[0] ?? null;
  }

  async assertFinalizerPrivileges() {
    const result = await this.pool.query(`
      SELECT current_user AS role_name,
        r.rolsuper, r.rolcreatedb, r.rolcreaterole, r.rolreplication, r.rolbypassrls,
        has_schema_privilege(current_user, 'pb01_i04', 'USAGE') AS i04_usage,
        has_schema_privilege(current_user, 'pb01_i04', 'CREATE') AS i04_create,
        has_schema_privilege(current_user, 'public', 'CREATE') AS public_create,
        has_database_privilege(current_user, current_database(), 'TEMP') AS database_temp,
        has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'SELECT') AS submission_select,
        has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'INSERT') AS submission_insert,
        has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'UPDATE') AS submission_update,
        has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'DELETE') AS submission_delete,
        has_table_privilege(current_user, 'pb01_i03.submission_ledger_events', 'UPDATE') AS ledger_update,
        has_column_privilege(current_user, 'pb01_i03.elections', 'election_state', 'UPDATE') AS state_update,
        has_table_privilege(current_user, 'pb01_i04.finalizations', 'INSERT') AS finalization_insert,
        has_table_privilege(current_user, 'pb01_i04.finalizations', 'UPDATE') AS finalization_update,
        has_table_privilege(current_user, 'pb01_i04.finalizations', 'DELETE') AS finalization_delete
      FROM pg_roles r WHERE r.rolname = current_user
    `);
    const row = result.rows[0];
    const safe = row
      && !row.rolsuper && !row.rolcreatedb && !row.rolcreaterole && !row.rolreplication && !row.rolbypassrls
      && row.i04_usage && !row.i04_create && !row.public_create && !row.database_temp
      && row.submission_select && !row.submission_insert && !row.submission_update && !row.submission_delete
      && !row.ledger_update && row.state_update && row.finalization_insert
      && !row.finalization_update && !row.finalization_delete;
    if (!safe) throw new Error("UNSAFE_FINALIZER_PRIVILEGES");
    return { ...row, validation: "PASS_FINALIZER_LEAST_PRIVILEGE" };
  }

  async loadLedgerRows(client, electionInstanceId) {
    const result = await client.query(`
      SELECT l.ledger_event_id, l.election_instance_id, l.ledger_seq, l.submission_id,
        l.ballot_digest, ${isoExpression("l.accepted_at")} AS accepted_at, l.event_version,
        l.previous_event_hash, l.event_hash, l.event_json,
        s.election_instance_id AS submission_election_instance_id,
        s.ballot_digest AS submission_ballot_digest,
        s.encrypted_ballot_bytes,
        p.election_instance_id AS lifecycle_election_instance_id,
        p.lifecycle_handle
      FROM pb01_i03.submission_ledger_events l
      JOIN pb01_i03.encrypted_submissions s ON s.submission_id = l.submission_id
      LEFT JOIN pb01_i03.private_submission_lifecycle p ON p.submission_id = l.submission_id
      WHERE l.election_instance_id = $1
      ORDER BY l.ledger_seq
    `, [electionInstanceId]);
    return result.rows.map((row) => ({ ...row, encrypted_ballot_bytes: Buffer.from(row.encrypted_ballot_bytes) }));
  }

  async previewClosure(electionInstanceId) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY");
      await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 0))", [electionInstanceId]);
      const election = await this.getElection(electionInstanceId, client);
      if (!election) failI04("UNKNOWN_ELECTION", 404);
      if (election.election_state !== "OPEN") failI04("ELECTION_NOT_CLOSABLE");
      const rows = await this.loadLedgerRows(client, electionInstanceId);
      verifyLedgerRows(rows, electionInstanceId);
      const checkpointTime = rows.at(-1)?.accepted_at ?? election.created_at;
      const acceptedManifest = buildAcceptedManifestAtCheckpoint({ election, ledgerRows: rows, checkpointTime });
      const { checkpoint, closure_checkpoint_digest } = buildClosureCheckpoint({ electionInstanceId, acceptedManifest });
      await client.query("COMMIT");
      return { checkpoint, closure_checkpoint_digest, accepted_manifest_at_checkpoint: acceptedManifest };
    } catch (error) {
      try { await client.query("ROLLBACK"); } catch { /* transaction already closed */ }
      throw error;
    } finally {
      client.release();
    }
  }

  async readFinalization(electionInstanceId, client = this.pool) {
    const result = await client.query(`
      SELECT f.election_instance_id, f.finalization_id, f.finalization_state,
        ${isoExpression("f.committed_at")} AS committed_at,
        c.closure_record_canonical, c.closure_checkpoint_canonical,
        c.authorization_evidence_canonical, f.accepted_manifest_canonical,
        f.cset_final_canonical, f.cset_root, f.final_set_envelope_canonical,
        f.final_set_envelope_digest, f.f_final, f.public_evidence_canonical,
        f.public_evidence_digest
      FROM pb01_i04.finalizations f
      JOIN pb01_i04.closure_records c USING(election_instance_id, finalization_id)
      WHERE f.election_instance_id = $1
    `, [electionInstanceId]);
    return parseFinalizationRow(result.rows[0]);
  }

  async finalize({ electionInstanceId, authorizationEvidence, authorizationVerifier, failpoint = null }) {
    const statement = authorizationVerifier.verify(authorizationEvidence, electionInstanceId);
    validateClosureAuthorizationStatement(statement);
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      const client = await this.pool.connect();
      try {
        await client.query("BEGIN ISOLATION LEVEL SERIALIZABLE");
        await client.query("SET LOCAL lock_timeout = '10s'");
        await client.query("SET LOCAL statement_timeout = '120s'");
        await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 0))", [electionInstanceId]);

        const existing = await this.readFinalization(electionInstanceId, client);
        if (existing) {
          if (existing.closure_authorization.authorization_evidence_digest !== authorizationEvidence.authorization_evidence_digest) {
            failI04("FINALIZATION_CONFLICT", 409);
          }
          await client.query("COMMIT");
          return { ...existing, replay: true };
        }

        const electionResult = await client.query(`
          SELECT election_instance_id, crypto_profile, tally_function_id, belenios_election_uuid,
            belenios_election_hash, context_sha256, election_state,
            ${isoExpression("created_at")} AS created_at
          FROM pb01_i03.elections WHERE election_instance_id = $1 FOR UPDATE
        `, [electionInstanceId]);
        const election = electionResult.rows[0];
        if (!election) failI04("UNKNOWN_ELECTION", 404);
        if (election.election_state !== "OPEN") failI04("ELECTION_NOT_CLOSABLE");

        const allRows = await this.loadLedgerRows(client, electionInstanceId);
        verifyLedgerRows(allRows, electionInstanceId);
        const boundary = Number(statement.closure_ledger_checkpoint.ledger_seq);
        if (!Number.isSafeInteger(boundary) || boundary < 0 || boundary > allRows.length) failI04("FINALIZATION_CONFLICT", 409);
        const prefixRows = allRows.slice(0, boundary);
        const prefixLastHash = prefixRows.at(-1)?.event_hash ?? ZERO_HASH;
        if (prefixLastHash !== statement.closure_ledger_checkpoint.ledger_event_hash) failI04("FINALIZATION_CONFLICT", 409);
        const checkpointTime = prefixRows.at(-1)?.accepted_at ?? election.created_at;
        const acceptedManifest = buildAcceptedManifestAtCheckpoint({ election, ledgerRows: prefixRows, checkpointTime });
        const { checkpoint } = buildClosureCheckpoint({ electionInstanceId, acceptedManifest });
        if (!sameCanonical(checkpoint, statement.closure_ledger_checkpoint)) failI04("FINALIZATION_CONFLICT", 409);

        const resolutionRecords = resolveLatestValid({
          electionInstanceId,
          rows: prefixRows,
          resolvedAt: statement.closed_at,
        });
        const artifacts = buildFinalArtifacts({ election, acceptedManifest, authorizationEvidence, resolutionRecords });
        await failpoint?.("after_closure_validation_before_resolution_writes");

        const finalizationId = randomUUID();
        const committedAt = statement.closed_at;
        await client.query(`
          INSERT INTO pb01_i04.closure_records(
            election_instance_id, finalization_id, closed_at, closure_ledger_seq,
            closure_ledger_event_hash, closure_checkpoint_digest, closure_record_digest,
            authorization_evidence_digest, revote_policy_version, closure_record_canonical,
            closure_checkpoint_canonical, authorization_evidence_canonical, committed_at
          ) VALUES ($1, $2, $3::timestamptz, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13::timestamptz)
        `, [
          electionInstanceId, finalizationId, statement.closed_at, boundary,
          checkpoint.ledger_event_hash, artifacts.closureCheckpointDigest,
          artifacts.closureRecordDigest, authorizationEvidence.authorization_evidence_digest,
          statement.revote_policy_version, canonicalString(artifacts.closureRecord),
          canonicalString(checkpoint), canonicalString(authorizationEvidence), committedAt,
        ]);

        if (resolutionRecords.length) {
          const payload = resolutionRecords.map((record) => {
            const { resolution_digest, ...canonicalRecord } = record;
            return {
              lifecycle_handle: record.lifecycle_handle,
              effective_submission_id: record.effective_submission_id,
              effective_ballot_digest: record.effective_ballot_digest,
              source_ledger_position: record.source_ledger_position,
              candidate_submission_ids: record.candidate_submission_ids,
              policy_version: record.policy_version,
              resolution_digest,
              resolution_canonical: canonicalString(canonicalRecord),
            };
          });
          await client.query(`
            INSERT INTO pb01_i04.revote_resolution_records(
              election_instance_id, finalization_id, lifecycle_handle, effective_submission_id,
              effective_ballot_digest, source_ledger_position, candidate_submission_ids,
              policy_version, resolution_digest, resolution_canonical
            )
            SELECT $1, $2, x.lifecycle_handle, x.effective_submission_id::uuid,
              x.effective_ballot_digest, x.source_ledger_position::bigint,
              ARRAY(SELECT jsonb_array_elements_text(x.candidate_submission_ids)::uuid),
              x.policy_version, x.resolution_digest, x.resolution_canonical
            FROM jsonb_to_recordset($3::jsonb) AS x(
              lifecycle_handle text, effective_submission_id text, effective_ballot_digest text,
              source_ledger_position text, candidate_submission_ids jsonb, policy_version text,
              resolution_digest text, resolution_canonical text
            )
          `, [electionInstanceId, finalizationId, canonicalString(payload)]);
        }
        await failpoint?.("during_lifecycle_resolution_persistence");

        const selectedByDigest = new Map(resolutionRecords.map((record) => [record.effective_ballot_digest, record]));
        const effectiveRows = artifacts.csetFinal.ordered_ballot_digests.map((digest, ordinal) => {
          const record = selectedByDigest.get(digest);
          return {
            canonical_ordinal: String(ordinal),
            submission_id: record.effective_submission_id,
            ballot_digest: digest,
            source_ledger_position: record.source_ledger_position,
          };
        });
        if (effectiveRows.length) {
          await client.query(`
            INSERT INTO pb01_i04.effective_submissions(
              election_instance_id, finalization_id, canonical_ordinal,
              submission_id, ballot_digest, source_ledger_position
            )
            SELECT $1, $2, x.canonical_ordinal::bigint, x.submission_id::uuid,
              x.ballot_digest, x.source_ledger_position::bigint
            FROM jsonb_to_recordset($3::jsonb) AS x(
              canonical_ordinal text, submission_id text, ballot_digest text, source_ledger_position text
            )
          `, [electionInstanceId, finalizationId, canonicalString(effectiveRows)]);
        }

        await client.query(`
          INSERT INTO pb01_i04.finalizations(
            election_instance_id, finalization_id, finalization_state,
            accepted_manifest_canonical, cset_final_canonical, cset_root,
            final_set_envelope_canonical, final_set_envelope_digest, f_final,
            public_evidence_canonical, public_evidence_digest, committed_at
          ) VALUES ($1, $2, 'FINALIZED', $3, $4, $5, $6, $7, $8, $9, $10, $11::timestamptz)
        `, [
          electionInstanceId, finalizationId, canonicalString(acceptedManifest),
          canonicalString(artifacts.csetFinal), artifacts.csetRoot,
          canonicalString(artifacts.finalSetEnvelope), artifacts.finalSetEnvelopeDigest,
          artifacts.fFinal, canonicalString(artifacts.publicEvidence),
          artifacts.publicEvidenceDigest, committedAt,
        ]);

        await client.query(`
          INSERT INTO pb01_i04.finalization_audit_events(
            audit_event_id, election_instance_id, event_code, occurred_at, detail_canonical
          ) VALUES
            ($1, $3, 'CLOSURE_AUTHORIZED', $4::timestamptz, $5),
            ($2, $3, 'FINAL_SET_COMMITTED', $4::timestamptz, $6)
        `, [
          randomUUID(), randomUUID(), electionInstanceId, committedAt,
          canonicalString({ checkpoint_digest: artifacts.closureCheckpointDigest }),
          canonicalString({ f_final: artifacts.fFinal, effective_ballot_count: String(effectiveRows.length) }),
        ]);
        if (allRows.length > boundary) {
          await client.query(`
            INSERT INTO pb01_i04.finalization_audit_events(
              audit_event_id, election_instance_id, event_code, occurred_at, detail_canonical
            ) VALUES ($1, $2, 'POST_CLOSURE_SUBMISSION', $3::timestamptz, $4)
          `, [randomUUID(), electionInstanceId, committedAt, canonicalString({ excluded_submission_count: String(allRows.length - boundary) })]);
        }

        await client.query("UPDATE pb01_i03.elections SET election_state = 'CLOSED' WHERE election_instance_id = $1", [electionInstanceId]);
        await failpoint?.("after_final_set_persistence_before_commit");
        await client.query("COMMIT");
        const finalized = await this.readFinalization(electionInstanceId);
        await failpoint?.("after_commit_before_response");
        return { ...finalized, replay: false, post_closure_excluded: allRows.length - boundary };
      } catch (error) {
        try { await client.query("ROLLBACK"); } catch { /* transaction already closed */ }
        if (error?.code === "40001" && attempt < 3) continue;
        throw error;
      } finally {
        client.release();
      }
    }
    throw new Error("SERIALIZABLE_RETRY_EXHAUSTED");
  }

  async privateResolutionAudit(electionInstanceId) {
    const result = await this.pool.query(`
      SELECT lifecycle_handle, effective_submission_id, effective_ballot_digest,
        source_ledger_position, candidate_submission_ids, policy_version,
        resolution_digest, resolution_canonical
      FROM pb01_i04.revote_resolution_records
      WHERE election_instance_id = $1 ORDER BY lifecycle_handle COLLATE "C"
    `, [electionInstanceId]);
    return result.rows.map((row) => ({
      ...jsonValue(row.resolution_canonical),
      resolution_digest: row.resolution_digest,
    }));
  }

  async exportPublicEvidence(electionInstanceId) {
    const finalization = await this.readFinalization(electionInstanceId);
    return finalization?.public_evidence ?? null;
  }

  async recompute(electionInstanceId, { authorizationVerifier = null } = {}) {
    const finalization = await this.readFinalization(electionInstanceId);
    if (!finalization) failI04("NOT_FOUND", 404);
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY");
      const election = await this.getElection(electionInstanceId, client);
      const allRows = await this.loadLedgerRows(client, electionInstanceId);
      verifyLedgerRows(allRows, electionInstanceId);
      const boundary = Number(finalization.closure_ledger_checkpoint.ledger_seq);
      const prefixRows = allRows.slice(0, boundary);
      if ((prefixRows.at(-1)?.event_hash ?? ZERO_HASH) !== finalization.closure_ledger_checkpoint.ledger_event_hash) {
        failI04("FINAL_SET_RECOMPUTE_MISMATCH");
      }
      const acceptedManifest = buildAcceptedManifestAtCheckpoint({
        election,
        ledgerRows: prefixRows,
        checkpointTime: prefixRows.at(-1)?.accepted_at ?? election.created_at,
      });
      const resolutionRecords = resolveLatestValid({
        electionInstanceId,
        rows: prefixRows,
        resolvedAt: finalization.closure_record.closed_at,
      });
      const artifacts = buildFinalArtifacts({
        election,
        acceptedManifest,
        authorizationEvidence: finalization.closure_authorization,
        resolutionRecords,
      });
      const persistedResolution = await this.privateResolutionAudit(electionInstanceId);
      const expectedResolution = resolutionRecords;
      const match = sameCanonical(acceptedManifest, finalization.accepted_manifest_at_closure)
        && sameCanonical(artifacts.csetFinal, finalization.cset_final)
        && artifacts.csetRoot === finalization.cset_root
        && sameCanonical(artifacts.finalSetEnvelope, finalization.final_set_envelope)
        && artifacts.finalSetEnvelopeDigest === finalization.final_set_envelope_digest
        && artifacts.fFinal === finalization.f_final
        && sameCanonical(artifacts.publicEvidence, finalization.public_evidence)
        && artifacts.publicEvidenceDigest === finalization.public_evidence_digest
        && sameCanonical(expectedResolution, persistedResolution);
      if (!match) failI04("FINAL_SET_RECOMPUTE_MISMATCH");
      verifyPublicFinalEvidence(finalization.public_evidence, { authorizationVerifier });
      await client.query("COMMIT");
      return {
        status: "PASS",
        election_instance_id: electionInstanceId,
        closure_ledger_seq: String(boundary),
        effective_ballot_count: String(resolutionRecords.length),
        cset_root: artifacts.csetRoot,
        f_final: artifacts.fFinal,
        public_evidence_digest: artifacts.publicEvidenceDigest,
      };
    } catch (error) {
      try { await client.query("ROLLBACK"); } catch { /* transaction already closed */ }
      throw error;
    } finally {
      client.release();
    }
  }

  async authorizedFinalBallotSet(electionInstanceId) {
    const finalization = await this.readFinalization(electionInstanceId);
    if (!finalization) failI04("NOT_FOUND", 404);
    const election = await this.getElection(electionInstanceId);
    const rows = await this.pool.query(`
      SELECT es.canonical_ordinal, es.submission_id, es.ballot_digest, s.encrypted_ballot_bytes
      FROM pb01_i04.effective_submissions es
      JOIN pb01_i03.encrypted_submissions s ON s.submission_id = es.submission_id
      WHERE es.election_instance_id = $1 ORDER BY es.canonical_ordinal
    `, [electionInstanceId]);
    return buildAuthorizedFinalBallotSet({
      election,
      finalization,
      exactRows: rows.rows.map((row) => ({ ...row, encrypted_ballot_bytes: Buffer.from(row.encrypted_ballot_bytes) })),
    });
  }

  async exactFinalBallotBytes(electionInstanceId) {
    const rows = await this.pool.query(`
      SELECT es.canonical_ordinal, es.ballot_digest, s.encrypted_ballot_bytes
      FROM pb01_i04.effective_submissions es
      JOIN pb01_i03.encrypted_submissions s ON s.submission_id = es.submission_id
      WHERE es.election_instance_id = $1 ORDER BY es.canonical_ordinal
    `, [electionInstanceId]);
    return rows.rows.map((row) => ({
      canonical_ordinal: String(row.canonical_ordinal),
      ballot_digest: row.ballot_digest,
      encrypted_ballot_bytes: Buffer.from(row.encrypted_ballot_bytes),
    }));
  }

  async recordAudit({ electionInstanceId = null, code, occurredAt, detail = {} }) {
    try {
      await this.pool.query(`
        INSERT INTO pb01_i04.finalization_audit_events(
          audit_event_id, election_instance_id, event_code, occurred_at, detail_canonical
        ) VALUES ($1, $2, $3, $4::timestamptz, $5)
      `, [randomUUID(), electionInstanceId, code, occurredAt, canonicalString(detail)]);
    } catch {
      // Audit failure must not disclose authority material or transform the public error.
    }
  }

  async backupTo(destinationPath) {
    if (!this.backup?.pgDumpPath) throw new Error("POSTGRES_BACKUP_NOT_CONFIGURED");
    const { pgDumpPath, host, port, database, user, password } = this.backup;
    await run(pgDumpPath, [
      "--format=custom", "--no-owner", "--no-privileges", "--file", destinationPath,
      "--host", host, "--port", String(port), "--username", user, database,
    ], { ...process.env, PGPASSWORD: password });
    return destinationPath;
  }

  async close() {
    await this.pool.end();
  }
}
