import { FINALIZATION_ERROR_CODES } from "./constants.mjs";

const allowed = new Set(FINALIZATION_ERROR_CODES);

export class I04Error extends Error {
  constructor(code, status = 422) {
    super(code);
    this.name = "I04Error";
    this.code = code;
    this.status = status;
  }
}

export function failI04(code, status = 422) {
  throw new I04Error(code, status);
}

export function publicI04Error(error) {
  if (error instanceof I04Error && allowed.has(error.code)) return error;
  const message = error instanceof Error ? error.message : String(error);
  if (allowed.has(message)) {
    const status = message === "FINALIZATION_CONFLICT" ? 409
      : message === "UNKNOWN_ELECTION" || message === "NOT_FOUND" ? 404
        : 422;
    return new I04Error(message, status);
  }
  return new I04Error("FINALIZATION_STORAGE_FAILED", 503);
}

