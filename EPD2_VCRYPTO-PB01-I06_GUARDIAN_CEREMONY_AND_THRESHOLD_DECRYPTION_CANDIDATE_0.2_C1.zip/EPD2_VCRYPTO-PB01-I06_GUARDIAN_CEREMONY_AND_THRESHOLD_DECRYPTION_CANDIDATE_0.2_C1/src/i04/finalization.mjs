import { createHash } from "node:crypto";
import {
  CANONICALIZATION_POLICY,
  CRYPTO_PROFILE,
  canonicalBytes,
  closureRecordDigest,
  csetRoot,
  domainHash,
  fFinal,
  finalSetEnvelopeDigest,
  validateCSet,
  validateFinalSetEnvelope,
} from "../i01_reference/pb01_profile.mjs";
import { acceptedManifestDigest } from "../i03/hashes.mjs";
import {
  AUTHORIZED_FINAL_BALLOT_SET_SCHEMA,
  CLOSURE_CHECKPOINT_SCHEMA,
  DOMAIN_CLOSURE_CHECKPOINT,
  DOMAIN_EXACT_BALLOT_BYTES,
  DOMAIN_PUBLIC_FINAL_EVIDENCE,
  DOMAIN_REVOTE_RESOLUTION,
  FINALIZATION_PROCESS_ID,
  PUBLIC_FINAL_EVIDENCE_SCHEMA,
  REVOTE_POLICY,
  REVOTE_RESOLUTION_SCHEMA,
} from "./constants.mjs";
import { authorizationEvidenceDigest, validateCheckpoint } from "./closure_authority.mjs";
import { failI04 } from "./errors.mjs";

function sha256Hex(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function compareDigest(left, right) {
  return Buffer.from(left, "hex").compare(Buffer.from(right, "hex"));
}

function assertHex64(value, code = "FINAL_SET_TAMPER_DETECTED") {
  if (!/^[0-9a-f]{64}$/u.test(value)) failI04(code);
}

export function buildAcceptedManifestAtCheckpoint({ election, ledgerRows, checkpointTime }) {
  const digests = ledgerRows.map((row) => row.ballot_digest).sort(compareDigest);
  if (new Set(digests).size !== digests.length) failI04("LIFECYCLE_INTEGRITY_FAILURE");
  const last = ledgerRows.at(-1);
  const manifest = {
    schema_version: "epd2.pb01.accepted-submission-manifest/1",
    election_instance_id: election.election_instance_id,
    crypto_profile: election.crypto_profile,
    tally_function_id: election.tally_function_id,
    generated_at: checkpointTime,
    accepted_ballot_digests: digests,
    ledger_checkpoint: {
      ledger_event_count: String(ledgerRows.length),
      ledger_seq: String(last?.ledger_seq ?? 0),
      ledger_event_hash: last?.event_hash ?? "0".repeat(64),
    },
    semantic_claim: "ACCEPTED_SUBMISSIONS_NOT_FINAL_SET_NOT_COUNTED",
  };
  return { ...manifest, manifest_digest: acceptedManifestDigest(manifest) };
}

export function buildClosureCheckpoint({ electionInstanceId, acceptedManifest }) {
  const checkpoint = {
    schema_version: CLOSURE_CHECKPOINT_SCHEMA,
    election_instance_id: electionInstanceId,
    ledger_event_count: acceptedManifest.ledger_checkpoint.ledger_event_count,
    ledger_seq: acceptedManifest.ledger_checkpoint.ledger_seq,
    ledger_event_hash: acceptedManifest.ledger_checkpoint.ledger_event_hash,
    accepted_manifest_digest: acceptedManifest.manifest_digest,
  };
  validateCheckpoint(checkpoint);
  return {
    checkpoint,
    closure_checkpoint_digest: domainHash(DOMAIN_CLOSURE_CHECKPOINT, canonicalBytes(checkpoint)),
  };
}

export function resolveLatestValid({ electionInstanceId, rows, resolvedAt }) {
  const byLifecycle = new Map();
  const submissionIds = new Set();
  for (const row of rows) {
    if (!row.lifecycle_handle || row.lifecycle_election_instance_id !== electionInstanceId) failI04("LIFECYCLE_INTEGRITY_FAILURE");
    if (submissionIds.has(row.submission_id)) failI04("LIFECYCLE_INTEGRITY_FAILURE");
    submissionIds.add(row.submission_id);
    const members = byLifecycle.get(row.lifecycle_handle) ?? [];
    members.push(row);
    byLifecycle.set(row.lifecycle_handle, members);
  }
  const records = [];
  for (const [lifecycleHandle, members] of byLifecycle) {
    members.sort((left, right) => Number(left.ledger_seq) - Number(right.ledger_seq) || left.submission_id.localeCompare(right.submission_id));
    const effective = members.at(-1);
    const record = {
      schema_version: REVOTE_RESOLUTION_SCHEMA,
      election_instance_id: electionInstanceId,
      lifecycle_handle: lifecycleHandle,
      candidate_submission_ids: members.map((row) => row.submission_id),
      effective_submission_id: effective.submission_id,
      effective_ballot_digest: effective.ballot_digest,
      selection_basis: "MAX_ACCEPTED_LEDGER_POSITION_THEN_SUBMISSION_ID",
      source_ledger_position: String(effective.ledger_seq),
      policy_version: REVOTE_POLICY,
      resolved_at_or_checkpoint: resolvedAt,
    };
    records.push({
      ...record,
      resolution_digest: domainHash(DOMAIN_REVOTE_RESOLUTION, canonicalBytes(record)),
    });
  }
  records.sort((left, right) => left.lifecycle_handle.localeCompare(right.lifecycle_handle));
  const effectiveDigests = records.map((record) => record.effective_ballot_digest);
  if (new Set(effectiveDigests).size !== effectiveDigests.length) failI04("LIFECYCLE_INTEGRITY_FAILURE");
  return records;
}

export function buildFinalArtifacts({ election, acceptedManifest, authorizationEvidence, resolutionRecords }) {
  if (election.crypto_profile !== CRYPTO_PROFILE) failI04("FINAL_SET_TAMPER_DETECTED");
  const statement = authorizationEvidence.statement;
  const { checkpoint, closure_checkpoint_digest } = buildClosureCheckpoint({
    electionInstanceId: election.election_instance_id,
    acceptedManifest,
  });
  if (canonicalBytes(checkpoint).toString() !== canonicalBytes(statement.closure_ledger_checkpoint).toString()) {
    failI04("FINALIZATION_CONFLICT", 409);
  }
  const closureRecord = {
    schema_version: "epd2.pb01.closure-record/1",
    election_instance_id: election.election_instance_id,
    closure_state: "closed",
    closed_at: statement.closed_at,
    closure_checkpoint_digest,
    finalization_process_id: FINALIZATION_PROCESS_ID,
    finalization_policy_version: REVOTE_POLICY,
    authorization_evidence_digest: authorizationEvidenceDigest(authorizationEvidence),
  };
  const closureDigest = closureRecordDigest(closureRecord);
  const orderedBallotDigests = resolutionRecords
    .map((record) => record.effective_ballot_digest)
    .sort(compareDigest);
  const csetFinal = {
    schema_version: "epd2.pb01.cset-final/1",
    election_instance_id: election.election_instance_id,
    crypto_profile: election.crypto_profile,
    belenios_election_uuid: election.belenios_election_uuid,
    belenios_election_fingerprint: election.belenios_election_hash,
    ordered_ballot_digests: orderedBallotDigests,
  };
  validateCSet(csetFinal);
  const csetRootHex = csetRoot(csetFinal);
  const finalSetEnvelope = {
    schema_version: "epd2.pb01.final-set-envelope/1",
    election_instance_id: election.election_instance_id,
    crypto_profile: election.crypto_profile,
    canonicalization_policy_version: CANONICALIZATION_POLICY,
    belenios_election_uuid: election.belenios_election_uuid,
    belenios_election_fingerprint: election.belenios_election_hash,
    closure_record_digest: closureDigest,
    ordered_ballot_digests: orderedBallotDigests,
    cset_root: csetRootHex,
    tally_function_id: election.tally_function_id,
  };
  validateFinalSetEnvelope(finalSetEnvelope);
  const envelopeDigest = finalSetEnvelopeDigest(finalSetEnvelope);
  const fFinalHex = fFinal(finalSetEnvelope);
  const publicEvidenceWithoutDigest = {
    schema_version: PUBLIC_FINAL_EVIDENCE_SCHEMA,
    election_instance_id: election.election_instance_id,
    crypto_profile: election.crypto_profile,
    tally_function_id: election.tally_function_id,
    closure_authorization: authorizationEvidence,
    closure_record: closureRecord,
    closure_record_digest: closureDigest,
    closure_ledger_checkpoint: checkpoint,
    revote_policy_version: REVOTE_POLICY,
    accepted_manifest_at_closure: acceptedManifest,
    cset_final: csetFinal,
    cset_root: csetRootHex,
    final_set_envelope: finalSetEnvelope,
    final_set_envelope_digest: envelopeDigest,
    f_final: fFinalHex,
    semantic_claim: "FINAL_EFFECTIVE_ENCRYPTED_BALLOT_SET_NOT_TALLIED_NOT_DECRYPTED",
  };
  const publicEvidenceDigest = domainHash(DOMAIN_PUBLIC_FINAL_EVIDENCE, canonicalBytes(publicEvidenceWithoutDigest));
  return {
    closureRecord,
    closureRecordDigest: closureDigest,
    closureCheckpoint: checkpoint,
    closureCheckpointDigest: closure_checkpoint_digest,
    csetFinal,
    csetRoot: csetRootHex,
    finalSetEnvelope,
    finalSetEnvelopeDigest: envelopeDigest,
    fFinal: fFinalHex,
    publicEvidence: { ...publicEvidenceWithoutDigest, public_evidence_digest: publicEvidenceDigest },
    publicEvidenceDigest,
  };
}

export function verifyPublicFinalEvidence(evidence, { authorizationVerifier = null } = {}) {
  try {
    if (!evidence || evidence.schema_version !== PUBLIC_FINAL_EVIDENCE_SCHEMA) failI04("FINAL_SET_TAMPER_DETECTED");
    const { public_evidence_digest, ...withoutDigest } = evidence;
    assertHex64(public_evidence_digest);
    if (domainHash(DOMAIN_PUBLIC_FINAL_EVIDENCE, canonicalBytes(withoutDigest)) !== public_evidence_digest) failI04("FINAL_SET_TAMPER_DETECTED");
    if (authorizationVerifier) authorizationVerifier.verify(evidence.closure_authorization, evidence.election_instance_id);
    const authDigest = authorizationEvidenceDigest(evidence.closure_authorization);
    if (evidence.closure_record.authorization_evidence_digest !== authDigest) failI04("FINAL_SET_TAMPER_DETECTED");
    validateCheckpoint(evidence.closure_ledger_checkpoint);
    const checkpointDigest = domainHash(DOMAIN_CLOSURE_CHECKPOINT, canonicalBytes(evidence.closure_ledger_checkpoint));
    if (evidence.closure_record.closure_checkpoint_digest !== checkpointDigest) failI04("FINAL_SET_TAMPER_DETECTED");
    if (closureRecordDigest(evidence.closure_record) !== evidence.closure_record_digest) failI04("FINAL_SET_TAMPER_DETECTED");
    const accepted = evidence.accepted_manifest_at_closure;
    const { manifest_digest, ...manifestWithoutDigest } = accepted;
    if (acceptedManifestDigest(manifestWithoutDigest) !== manifest_digest) failI04("FINAL_SET_TAMPER_DETECTED");
    if (manifest_digest !== evidence.closure_ledger_checkpoint.accepted_manifest_digest) failI04("FINAL_SET_TAMPER_DETECTED");
    const acceptedSet = new Set(accepted.accepted_ballot_digests);
    if (!evidence.cset_final.ordered_ballot_digests.every((digest) => acceptedSet.has(digest))) failI04("FINAL_SET_TAMPER_DETECTED");
    validateCSet(evidence.cset_final);
    if (csetRoot(evidence.cset_final) !== evidence.cset_root) failI04("FINAL_SET_TAMPER_DETECTED");
    if (evidence.final_set_envelope.cset_root !== evidence.cset_root) failI04("FINAL_SET_TAMPER_DETECTED");
    if (canonicalBytes(evidence.final_set_envelope.ordered_ballot_digests).toString() !== canonicalBytes(evidence.cset_final.ordered_ballot_digests).toString()) failI04("FINAL_SET_TAMPER_DETECTED");
    if (evidence.final_set_envelope.closure_record_digest !== evidence.closure_record_digest) failI04("FINAL_SET_TAMPER_DETECTED");
    validateFinalSetEnvelope(evidence.final_set_envelope);
    if (finalSetEnvelopeDigest(evidence.final_set_envelope) !== evidence.final_set_envelope_digest) failI04("FINAL_SET_TAMPER_DETECTED");
    if (fFinal(evidence.final_set_envelope) !== evidence.f_final) failI04("FINAL_SET_TAMPER_DETECTED");
    if (evidence.revote_policy_version !== REVOTE_POLICY || evidence.closure_record.finalization_policy_version !== REVOTE_POLICY) failI04("FINAL_SET_TAMPER_DETECTED");
    return { valid: true, public_evidence_digest, f_final: evidence.f_final };
  } catch (error) {
    if (error?.code) throw error;
    failI04("FINAL_SET_TAMPER_DETECTED");
  }
}

export function buildAuthorizedFinalBallotSet({ election, finalization, exactRows }) {
  const ordered = finalization.final_set_envelope.ordered_ballot_digests;
  const rowByDigest = new Map(exactRows.map((row) => [row.ballot_digest, row]));
  const references = ordered.map((digest) => {
    const row = rowByDigest.get(digest);
    if (!row) failI04("FINAL_SET_RECOMPUTE_MISMATCH");
    return {
      ballot_digest: digest,
      exact_ballot_byte_sha256: sha256Hex(row.encrypted_ballot_bytes),
      exact_ballot_byte_domain_digest: domainHash(DOMAIN_EXACT_BALLOT_BYTES, row.encrypted_ballot_bytes),
      byte_length_decimal: String(row.encrypted_ballot_bytes.length),
      immutable_storage_reference: `pb01_i03.encrypted_submissions/${row.submission_id}`,
    };
  });
  return {
    schema_version: AUTHORIZED_FINAL_BALLOT_SET_SCHEMA,
    election_instance_id: election.election_instance_id,
    crypto_profile: election.crypto_profile,
    tally_function_id: election.tally_function_id,
    f_final: finalization.f_final,
    ordered_ballot_digests: ordered,
    exact_ballot_byte_references: references,
    semantic_claim: "AUTHORIZED_I05_INPUT_NOT_TALLIED_NOT_DECRYPTED",
  };
}

