export const REVOTE_POLICY = "epd2.pb01.revote.latest-valid.v1";
export const FINALIZATION_PROCESS_ID = "epd2.pb01.finalization-process.i04.v1";

export const CLOSURE_CHECKPOINT_SCHEMA = "epd2.pb01.closure-ledger-checkpoint/1";
export const CLOSURE_AUTH_STATEMENT_SCHEMA = "epd2.pb01.closure-authorization-statement/1";
export const CLOSURE_AUTH_EVIDENCE_SCHEMA = "epd2.pb01.closure-authorization-evidence/1";
export const REVOTE_RESOLUTION_SCHEMA = "epd2.pb01.revote-resolution-record/1";
export const PUBLIC_FINAL_EVIDENCE_SCHEMA = "epd2.pb01.final-set-evidence/1";
export const AUTHORIZED_FINAL_BALLOT_SET_SCHEMA = "epd2.pb01.authorized-final-ballot-set/1";

export const DOMAIN_CLOSURE_CHECKPOINT = "epd2.pb01.closure-ledger-checkpoint.v1";
export const DOMAIN_CLOSURE_AUTHORIZATION = "epd2.pb01.closure-authorization.v1";
export const DOMAIN_CLOSURE_AUTH_EVIDENCE = "epd2.pb01.closure-authorization-evidence.v1";
export const DOMAIN_REVOTE_RESOLUTION = "epd2.pb01.revote-resolution-record.v1";
export const DOMAIN_PUBLIC_FINAL_EVIDENCE = "epd2.pb01.final-set-evidence.v1";
export const DOMAIN_EXACT_BALLOT_BYTES = "epd2.pb01.exact-ballot-bytes.v1";

export const FINALIZATION_ERROR_CODES = Object.freeze([
  "INVALID_FINALIZATION_SCHEMA",
  "UNKNOWN_ELECTION",
  "ELECTION_NOT_CLOSABLE",
  "INVALID_CLOSURE_AUTHORIZATION",
  "LEDGER_INTEGRITY_FAILURE",
  "LIFECYCLE_INTEGRITY_FAILURE",
  "UNKNOWN_REVOTE_POLICY",
  "FINALIZATION_CONFLICT",
  "ALREADY_FINALIZED",
  "POST_CLOSURE_SUBMISSION",
  "FINAL_SET_RECOMPUTE_MISMATCH",
  "FINAL_SET_TAMPER_DETECTED",
  "ORIGIN_NOT_ALLOWED",
  "REQUEST_TOO_LARGE",
  "NOT_FOUND",
  "METHOD_NOT_ALLOWED",
  "FINALIZATION_STORAGE_FAILED",
]);

export const MAX_FINALIZATION_REQUEST_BYTES = 32_768;
export const FINALIZATION_REQUEST_TIMEOUT_MS = 15_000;

