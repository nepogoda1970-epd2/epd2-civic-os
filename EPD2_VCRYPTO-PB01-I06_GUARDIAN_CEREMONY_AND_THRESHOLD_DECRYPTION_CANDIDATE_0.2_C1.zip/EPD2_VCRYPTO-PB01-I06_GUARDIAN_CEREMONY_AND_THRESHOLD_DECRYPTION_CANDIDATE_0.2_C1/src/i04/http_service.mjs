import { createServer } from "node:http";
import { canonicalize } from "../i02_accepted/shared/profile.mjs";
import { parseStrictJson } from "../i03/strict_json.mjs";
import {
  FINALIZATION_REQUEST_TIMEOUT_MS,
  MAX_FINALIZATION_REQUEST_BYTES,
} from "./constants.mjs";
import { failI04, publicI04Error } from "./errors.mjs";

function isoSecond(clock) {
  return clock().toISOString().replace(/\.\d{3}Z$/u, "Z");
}

async function readBody(request, limit, timeoutMs) {
  const contentLength = Number(request.headers["content-length"] ?? "0");
  if (Number.isFinite(contentLength) && contentLength > limit) failI04("REQUEST_TOO_LARGE", 413);
  const chunks = [];
  let size = 0;
  const timer = setTimeout(() => request.destroy(new Error("request timeout")), timeoutMs);
  try {
    for await (const chunk of request) {
      size += chunk.length;
      if (size > limit) failI04("REQUEST_TOO_LARGE", 413);
      chunks.push(chunk);
    }
  } catch (error) {
    if (error?.code === "REQUEST_TOO_LARGE") throw error;
    failI04("INVALID_FINALIZATION_SCHEMA");
  } finally {
    clearTimeout(timer);
  }
  return Buffer.concat(chunks);
}

function responseHeaders(allowedOrigin) {
  return {
    "access-control-allow-origin": allowedOrigin,
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-allow-headers": "content-type",
    "access-control-max-age": "600",
    "cache-control": "no-store",
    "content-type": "application/json; charset=utf-8",
    "cross-origin-resource-policy": "same-site",
    "referrer-policy": "no-referrer",
    "x-content-type-options": "nosniff",
  };
}

function send(response, status, body, allowedOrigin) {
  if (response.destroyed) return;
  response.writeHead(status, responseHeaders(allowedOrigin));
  response.end(canonicalize(body));
}

export function createI04Service({
  store,
  authorizationVerifier,
  allowedOperatorOrigin,
  clock = () => new Date(),
  bodyLimit = MAX_FINALIZATION_REQUEST_BYTES,
  requestTimeoutMs = FINALIZATION_REQUEST_TIMEOUT_MS,
  failpoint = null,
  developmentHttp = false,
}) {
  if (!developmentHttp && !allowedOperatorOrigin.startsWith("https://")) throw new Error("HTTPS_REQUIRED");
  return createServer(async (request, response) => {
    const now = isoSecond(clock);
    const route = request.url || "";
    let electionInstanceId = null;
    try {
      if (request.headers.origin !== allowedOperatorOrigin) failI04("ORIGIN_NOT_ALLOWED", 403);
      if (request.method === "OPTIONS") return send(response, 204, {}, allowedOperatorOrigin);

      let match = /^\/v1\/elections\/(ei1_[0-9a-f]{32})\/closure-preview$/u.exec(route);
      if (match && request.method === "GET") {
        electionInstanceId = match[1];
        const preview = await store.previewClosure(electionInstanceId);
        return send(response, 200, {
          schema_version: "epd2.pb01.closure-preview/1",
          election_instance_id: electionInstanceId,
          closure_ledger_checkpoint: preview.checkpoint,
          closure_checkpoint_digest: preview.closure_checkpoint_digest,
          semantic_claim: "AUTHORIZATION_INPUT_NOT_FINALIZED",
        }, allowedOperatorOrigin);
      }

      match = /^\/v1\/elections\/(ei1_[0-9a-f]{32})\/finalize$/u.exec(route);
      if (match && request.method === "POST") {
        electionInstanceId = match[1];
        if (request.headers["content-type"] !== "application/json") failI04("INVALID_FINALIZATION_SCHEMA");
        const parsed = parseStrictJson(await readBody(request, bodyLimit, requestTimeoutMs));
        if (canonicalize(parsed.value) !== parsed.text) failI04("INVALID_FINALIZATION_SCHEMA");
        const result = await store.finalize({
          electionInstanceId,
          authorizationEvidence: parsed.value,
          authorizationVerifier,
          failpoint,
        });
        return send(response, result.replay ? 200 : 201, {
          schema_version: "epd2.pb01.finalization-result/1",
          election_instance_id: electionInstanceId,
          finalization_state: "FINALIZED",
          replay: result.replay,
          cset_root: result.cset_root,
          f_final: result.f_final,
          public_evidence_digest: result.public_evidence_digest,
          semantic_claim: "FINAL_SET_ESTABLISHED_NOT_TALLIED_NOT_DECRYPTED",
        }, allowedOperatorOrigin);
      }

      match = /^\/v1\/elections\/(ei1_[0-9a-f]{32})\/final-set-evidence$/u.exec(route);
      if (match && request.method === "GET") {
        electionInstanceId = match[1];
        const evidence = await store.exportPublicEvidence(electionInstanceId);
        if (!evidence) failI04("NOT_FOUND", 404);
        return send(response, 200, evidence, allowedOperatorOrigin);
      }

      match = /^\/v1\/elections\/(ei1_[0-9a-f]{32})\/authorized-final-ballot-set$/u.exec(route);
      if (match && request.method === "GET") {
        electionInstanceId = match[1];
        const contract = await store.authorizedFinalBallotSet(electionInstanceId);
        return send(response, 200, contract, allowedOperatorOrigin);
      }

      if (["DELETE", "PATCH", "PUT"].includes(request.method)) failI04("METHOD_NOT_ALLOWED", 405);
      failI04("NOT_FOUND", 404);
    } catch (error) {
      const exposed = publicI04Error(error);
      await store.recordAudit({
        electionInstanceId,
        code: exposed.code,
        occurredAt: now,
        detail: { route_class: route.includes("finalize") ? "finalization" : "final-evidence-read" },
      });
      return send(response, exposed.status, { error: exposed.code }, allowedOperatorOrigin);
    }
  });
}

export async function startI04Service(options) {
  const server = createI04Service(options);
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port ?? 32904, options.host ?? "127.0.0.1", resolve);
  });
  return server;
}

