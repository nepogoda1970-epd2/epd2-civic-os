function mutateHex(value) {
  const last = value.at(-1);
  return `${value.slice(0, -1)}${last === "0" ? "1" : "0"}`;
}

function mutateDecimal(value) {
  const last = value.at(-1);
  return `${value.slice(0, -1)}${last === "0" ? "1" : "0"}`;
}

export function mutateRawBallot(rawBallot, kind) {
  const ballot = JSON.parse(rawBallot);
  switch (kind) {
    case "ciphertext":
      ballot.answers[0].choices[0].alpha = mutateHex(ballot.answers[0].choices[0].alpha);
      break;
    case "proof-challenge":
      ballot.answers[0].individual_proofs[0][0].challenge = mutateDecimal(ballot.answers[0].individual_proofs[0][0].challenge);
      break;
    case "proof-response":
      ballot.answers[0].individual_proofs[0][0].response = mutateDecimal(ballot.answers[0].individual_proofs[0][0].response);
      break;
    case "signature-response":
      ballot.signature.proof.response = mutateDecimal(ballot.signature.proof.response);
      break;
    default:
      throw new Error("unknown mutation");
  }
  return JSON.stringify(ballot);
}
