import { execFile } from "node:child_process";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import { encodeSelection, validateContext, validateHandoff } from "../shared/profile.mjs";

const execFileAsync = promisify(execFile);

async function runTool(toolPath, args) {
  return execFileAsync(toolPath, args, {
    env: { ...process.env, BELENIOS_USE_URANDOM: "1" },
    encoding: "utf8",
    maxBuffer: 4 * 1024 * 1024,
    timeout: 120000,
  });
}

export async function verifyWithBelenios({ toolPath, electionDir, rawBallot }) {
  const work = await mkdtemp(join(tmpdir(), "epd2-i02-verify-"));
  const ballotPath = join(work, "ballot.json");
  try {
    await writeFile(ballotPath, rawBallot, { encoding: "utf8", mode: 0o600, flag: "wx" });
    const result = await runTool(toolPath, ["election", "verify-ballot", `--dir=${electionDir}`, `--ballot=${ballotPath}`]);
    if (!result.stderr.includes("ballot is valid")) throw new Error("INVALID_ENCRYPTED_BALLOT");
    return "PASS";
  } catch {
    throw new Error("INVALID_ENCRYPTED_BALLOT");
  } finally {
    await rm(work, { recursive: true, force: true });
  }
}

export async function generateAndVerifyBallot({ toolPath, electionDir, context, handoff, choice }) {
  validateContext(context);
  validateHandoff(handoff);
  if (handoff.election_instance_id !== context.election_instance_id) throw new Error("INVALID_ELECTION_CONTEXT");
  const plaintext = encodeSelection(choice);
  const work = await mkdtemp(join(tmpdir(), "epd2-i02-encrypt-"));
  const credentialPath = join(work, "credential.txt");
  const choicePath = join(work, "choice.json");
  try {
    await writeFile(credentialPath, `${handoff.scoped_credential.secret}\n`, { encoding: "utf8", mode: 0o600, flag: "wx" });
    await writeFile(choicePath, `${JSON.stringify(plaintext)}\n`, { encoding: "utf8", mode: 0o600, flag: "wx" });
    const { stdout } = await runTool(toolPath, ["election", "generate-ballot", `--dir=${electionDir}`, `--privcred=${credentialPath}`, `--choice=${choicePath}`]);
    const rawBallot = stdout.endsWith("\n") ? stdout.slice(0, -1) : stdout;
    if (!rawBallot.startsWith("{") || !rawBallot.endsWith("}")) throw new Error("ENCRYPTION_FAILED");
    await verifyWithBelenios({ toolPath, electionDir, rawBallot });
    return {
      encrypted_ballot_base64url: Buffer.from(rawBallot, "utf8").toString("base64url"),
      local_verification: "PASS",
      crypto_runtime: "pinned-belenios-3.3.0-native-client-helper",
    };
  } catch (error) {
    if (error instanceof Error && ["INVALID_BALLOT_ENCODING", "INVALID_ENCRYPTED_BALLOT"].includes(error.message)) throw error;
    throw new Error("ENCRYPTION_FAILED");
  } finally {
    await rm(work, { recursive: true, force: true });
  }
}
