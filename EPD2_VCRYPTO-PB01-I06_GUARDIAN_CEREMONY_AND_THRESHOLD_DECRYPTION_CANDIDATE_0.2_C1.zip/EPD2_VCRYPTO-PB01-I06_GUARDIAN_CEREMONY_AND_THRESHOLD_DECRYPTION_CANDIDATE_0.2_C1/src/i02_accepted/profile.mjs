import { createHash } from "node:crypto";

export const CRYPTO_PROFILE = "epd2.belenios-homomorphic/1";
export const TALLY_FUNCTION = "epd2.pb01.tally.single-choice.v1";
export const CONTEXT_SCHEMA = "epd2.pb01.election-crypto-context/1";
export const HANDOFF_SCHEMA = "epd2.pb01.voting-handoff/1";
export const SUBMISSION_SCHEMA = "epd2.pb01.encrypted-submission-artifact/1";
export const UPSTREAM_BALLOT_FORMAT = "belenios.ballot/3.3.0-protocol-v1";
export const CLIENT_BUILD_ID = "epd2.pb01.i02.native-helper/0.1+belenios-3.3.0";
export const DOMAIN_BALLOT_DIGEST = "epd2.pb01.ballot-digest.v1";

const encoder = new TextEncoder();
const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: false });

export function canonicalize(value) {
  if (value === null) return "null";
  if (value === true) return "true";
  if (value === false) return "false";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") throw new Error("numbers prohibited by PB01 restricted JCS profile");
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(",")}]`;
  if (typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype) {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalize(value[key])}`).join(",")}}`;
  }
  throw new Error("unsupported JSON value");
}

export function canonicalBytes(value) {
  return encoder.encode(canonicalize(value));
}

export function parseCanonical(bytes) {
  if (!(bytes instanceof Uint8Array)) throw new Error("Uint8Array required");
  if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) throw new Error("BOM prohibited");
  const text = decoder.decode(bytes);
  const value = JSON.parse(text);
  if (canonicalize(value) !== text) throw new Error("non-canonical or duplicate-member JSON");
  return value;
}

export function domainHash(tag, bytes) {
  return createHash("sha256").update(Buffer.from(tag, "ascii")).update(Buffer.from([0])).update(bytes).digest("hex");
}

function exactKeys(object, allowed, error) {
  if (object === null || Array.isArray(object) || typeof object !== "object") throw new Error(error);
  const actual = Object.keys(object).sort();
  const expected = [...allowed].sort();
  if (actual.length !== expected.length || actual.some((value, index) => value !== expected[index])) throw new Error(error);
}

function assertElectionId(value) {
  if (!/^ei1_[0-9a-f]{32}$/.test(value)) throw new Error("INVALID_ELECTION_CONTEXT");
}

export function validateContext(value) {
  exactKeys(value, ["schema_version", "election_instance_id", "crypto_profile", "belenios_election_uuid", "belenios_election_fingerprint", "election_public_key", "upstream_election_json_base64url", "contest_definition", "tally_function_id", "ballot_encoding_version", "proof_profile", "upstream_crypto_parameters", "receiver_url"], "INVALID_ELECTION_CONTEXT");
  if (value.schema_version !== CONTEXT_SCHEMA) throw new Error("INVALID_ELECTION_CONTEXT");
  assertElectionId(value.election_instance_id);
  if (value.crypto_profile !== CRYPTO_PROFILE) throw new Error("UNSUPPORTED_CRYPTO_PROFILE");
  if (value.tally_function_id !== TALLY_FUNCTION) throw new Error("UNSUPPORTED_TALLY_FUNCTION");
  if (!/^[1-9A-HJ-NP-Za-km-z]{14,128}$/.test(value.belenios_election_uuid)) throw new Error("INVALID_ELECTION_CONTEXT");
  if (!/^[A-Za-z0-9+/]{43}$/.test(value.belenios_election_fingerprint)) throw new Error("INVALID_ELECTION_CONTEXT");
  if (!/^[A-Za-z0-9_-]+$/.test(value.upstream_election_json_base64url)) throw new Error("INVALID_ELECTION_CONTEXT");
  exactKeys(value.contest_definition, ["contest_id", "kind", "minimum_selections", "maximum_selections", "options"], "INVALID_CONTEST");
  if (value.contest_definition.kind !== "single-choice" || value.contest_definition.minimum_selections !== "1" || value.contest_definition.maximum_selections !== "1") throw new Error("INVALID_CONTEST");
  if (!Array.isArray(value.contest_definition.options) || value.contest_definition.options.length !== 3) throw new Error("INVALID_CONTEST");
  const codes = value.contest_definition.options.map((option) => option.code);
  if (codes.join(",") !== "yes,no,abstain") throw new Error("INVALID_CONTEST");
  return value;
}

export function validateHandoff(value, now = Date.now()) {
  exactKeys(value, ["schema_version", "election_instance_id", "crypto_profile", "scoped_credential", "expires_at", "nonce"], "INVALID_HANDOFF");
  if (value.schema_version !== HANDOFF_SCHEMA || value.crypto_profile !== CRYPTO_PROFILE) throw new Error("INVALID_HANDOFF");
  assertElectionId(value.election_instance_id);
  if (!/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$/.test(value.expires_at) || Date.parse(value.expires_at) <= now) throw new Error("EXPIRED_HANDOFF");
  if (!/^[0-9a-f]{32}$/.test(value.nonce)) throw new Error("INVALID_HANDOFF");
  exactKeys(value.scoped_credential, ["kind", "secret"], "INVALID_SCOPED_CREDENTIAL");
  if (value.scoped_credential.kind !== "fixture-belenios-private-credential" || typeof value.scoped_credential.secret !== "string" || value.scoped_credential.secret.length < 8) throw new Error("INVALID_SCOPED_CREDENTIAL");
  return value;
}

export function encodeSelection(choice) {
  const map = {
    yes: [[1, 0, 0]],
    no: [[0, 1, 0]],
    abstain: [[0, 0, 1]],
  };
  if (!(choice in map)) throw new Error("INVALID_BALLOT_ENCODING");
  return map[choice];
}

export function ballotDigestInput(context, encryptedBallotBase64url) {
  validateContext(context);
  if (!/^[A-Za-z0-9_-]+$/.test(encryptedBallotBase64url)) throw new Error("INVALID_ENCRYPTED_BALLOT");
  const raw = Buffer.from(encryptedBallotBase64url, "base64url");
  if (raw.length === 0 || raw.length > 1048576) throw new Error("INVALID_ENCRYPTED_BALLOT");
  const parsed = JSON.parse(decoder.decode(raw));
  if (parsed === null || Array.isArray(parsed) || typeof parsed !== "object") throw new Error("INVALID_ENCRYPTED_BALLOT");
  return {
    schema_version: "epd2.pb01.ballot-digest-input/1",
    election_instance_id: context.election_instance_id,
    crypto_profile: context.crypto_profile,
    belenios_election_uuid: context.belenios_election_uuid,
    belenios_election_fingerprint: context.belenios_election_fingerprint,
    belenios_ballot_base64url: encryptedBallotBase64url,
  };
}

export function ballotDigest(context, encryptedBallotBase64url) {
  return domainHash(DOMAIN_BALLOT_DIGEST, canonicalBytes(ballotDigestInput(context, encryptedBallotBase64url)));
}

export function validateSubmission(value) {
  exactKeys(value, ["schema_version", "election_instance_id", "crypto_profile", "tally_function_id", "ballot_digest", "encrypted_ballot", "upstream_ballot_format_version", "client_crypto_build_id"], "INVALID_SUBMISSION_SCHEMA");
  if (value.schema_version !== SUBMISSION_SCHEMA) throw new Error("INVALID_SUBMISSION_SCHEMA");
  assertElectionId(value.election_instance_id);
  if (value.crypto_profile !== CRYPTO_PROFILE) throw new Error("UNSUPPORTED_CRYPTO_PROFILE");
  if (value.tally_function_id !== TALLY_FUNCTION) throw new Error("UNSUPPORTED_TALLY_FUNCTION");
  if (!/^[0-9a-f]{64}$/.test(value.ballot_digest)) throw new Error("BALLOT_DIGEST_MISMATCH");
  if (!/^[A-Za-z0-9_-]+$/.test(value.encrypted_ballot)) throw new Error("INVALID_ENCRYPTED_BALLOT");
  if (value.upstream_ballot_format_version !== UPSTREAM_BALLOT_FORMAT) throw new Error("INVALID_ENCRYPTED_BALLOT");
  if (value.client_crypto_build_id !== CLIENT_BUILD_ID) throw new Error("INVALID_CLIENT_BUILD");
  return value;
}

export function buildSubmissionArtifact(context, encryptedBallotBase64url, localVerification) {
  if (localVerification !== "PASS") throw new Error("LOCAL_PROOF_VERIFICATION_FAILED");
  return {
    schema_version: SUBMISSION_SCHEMA,
    election_instance_id: context.election_instance_id,
    crypto_profile: context.crypto_profile,
    tally_function_id: context.tally_function_id,
    ballot_digest: ballotDigest(context, encryptedBallotBase64url),
    encrypted_ballot: encryptedBallotBase64url,
    upstream_ballot_format_version: UPSTREAM_BALLOT_FORMAT,
    client_crypto_build_id: CLIENT_BUILD_ID,
  };
}

export function redactError(error) {
  const allowed = new Set(["UNSUPPORTED_CRYPTO_PROFILE", "UNSUPPORTED_TALLY_FUNCTION", "INVALID_ELECTION_CONTEXT", "INVALID_CONTEST", "INVALID_HANDOFF", "EXPIRED_HANDOFF", "INVALID_SCOPED_CREDENTIAL", "INVALID_BALLOT_ENCODING", "SECURE_RNG_UNAVAILABLE", "ENCRYPTION_FAILED", "LOCAL_PROOF_VERIFICATION_FAILED", "INVALID_ENCRYPTED_BALLOT", "BALLOT_DIGEST_MISMATCH", "FOREIGN_ELECTION_BALLOT", "INVALID_SUBMISSION_SCHEMA", "INVALID_CLIENT_BUILD", "DUPLICATE_BALLOT"]);
  const value = error instanceof Error ? error.message : String(error);
  return allowed.has(value) ? value : "INTERNAL_CRYPTO_ERROR";
}
