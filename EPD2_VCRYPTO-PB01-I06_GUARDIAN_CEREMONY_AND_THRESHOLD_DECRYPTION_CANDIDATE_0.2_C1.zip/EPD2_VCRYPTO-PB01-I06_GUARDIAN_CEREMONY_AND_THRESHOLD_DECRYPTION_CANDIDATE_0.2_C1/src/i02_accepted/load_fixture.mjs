import { readFile } from "node:fs/promises";
import { join } from "node:path";

export async function loadFixture(root, name) {
  const electionDir = join(root, "evidence", "fixtures", name);
  return {
    electionDir,
    context: JSON.parse(await readFile(join(electionDir, "context.json"), "utf8")),
    handoff: JSON.parse(await readFile(join(electionDir, "handoff.fixture.json"), "utf8")),
  };
}
