import { createHash } from "node:crypto";

export const CRYPTO_PROFILE = "epd2.belenios-homomorphic/1";
export const CANONICALIZATION_POLICY = "epd2.pb01.jcs-rfc8785-restricted/1";
export const DOMAIN_BALLOT_DIGEST = "epd2.pb01.ballot-digest.v1";
export const DOMAIN_CSET_ROOT = "epd2.pb01.cset-root.v1";
export const DOMAIN_CLOSURE_RECORD = "epd2.pb01.closure-record.v1";
export const DOMAIN_FINAL_SET_ENVELOPE = "epd2.pb01.final-set-envelope.v1";
export const DOMAIN_F_FINAL = "epd2.pb01.f-final.v1";
export const TALLY = new Set([
  "epd2.pb01.tally.single-choice.v1",
  "epd2.pb01.tally.approval.v1",
]);

const encoder = new TextEncoder();
const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: false });

export function canonicalize(value) {
  if (value === null) return "null";
  if (value === true) return "true";
  if (value === false) return "false";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") throw new Error("numbers prohibited by PB01 restricted JCS profile");
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(",")}]`;
  if (typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype) {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${canonicalize(value[key])}`)
      .join(",")}}`;
  }
  throw new Error("unsupported JSON value");
}

export function canonicalBytes(value) {
  return encoder.encode(canonicalize(value));
}

export function parseCanonical(bytes) {
  if (!(bytes instanceof Uint8Array)) throw new Error("Uint8Array required");
  if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
    throw new Error("BOM prohibited");
  }
  const text = decoder.decode(bytes);
  const value = JSON.parse(text);
  if (canonicalize(value) !== text) throw new Error("non-canonical or duplicate-member JSON");
  return value;
}

export function domainHash(tag, bytes) {
  return createHash("sha256")
    .update(Buffer.from(tag, "ascii"))
    .update(Buffer.from([0]))
    .update(bytes)
    .digest("hex");
}

function requireHex64(value, name) {
  if (!/^[0-9a-f]{64}$/.test(value)) throw new Error(`invalid ${name}`);
}

function validateCommon(value) {
  if (value.crypto_profile !== CRYPTO_PROFILE) throw new Error("unknown crypto profile");
  if (!/^ei1_[0-9a-f]{32}$/.test(value.election_instance_id)) throw new Error("invalid election instance id");
}

function validateOrderedDigests(digests) {
  if (!Array.isArray(digests) || digests.length > 100000) throw new Error("invalid CSet size");
  let previous = null;
  for (const digest of digests) {
    requireHex64(digest, "ballot digest");
    if (previous !== null && previous >= digest) throw new Error("duplicate or wrong digest order");
    previous = digest;
  }
}

export function validateBallotDigestInput(value) {
  if (value.schema_version !== "epd2.pb01.ballot-digest-input/1") throw new Error("unknown schema");
  validateCommon(value);
  if (!/^[1-9A-HJ-NP-Za-km-z]{14,128}$/.test(value.belenios_election_uuid)) throw new Error("invalid Belenios UUID");
  if (!/^[A-Za-z0-9+/]{43}$/.test(value.belenios_election_fingerprint)) throw new Error("invalid Belenios fingerprint");
  if (!/^[A-Za-z0-9_-]+$/.test(value.belenios_ballot_base64url)) throw new Error("invalid ballot base64url");
  const raw = Buffer.from(value.belenios_ballot_base64url, "base64url");
  if (raw.length === 0 || raw.length > 1048576) throw new Error("invalid ballot length");
  const text = decoder.decode(raw);
  if (!text.startsWith("{") || !text.endsWith("}")) throw new Error("upstream ballot is not compact JSON object");
  const parsed = JSON.parse(text);
  if (parsed === null || Array.isArray(parsed) || typeof parsed !== "object") throw new Error("upstream ballot is not object");
}

export function ballotDigest(value) {
  validateBallotDigestInput(value);
  return domainHash(DOMAIN_BALLOT_DIGEST, canonicalBytes(value));
}

export function validateCSet(value) {
  if (value.schema_version !== "epd2.pb01.cset-final/1") throw new Error("unknown schema");
  validateCommon(value);
  validateOrderedDigests(value.ordered_ballot_digests);
}

export function csetRoot(value) {
  validateCSet(value);
  return domainHash(DOMAIN_CSET_ROOT, canonicalBytes(value));
}

export function closureRecordDigest(value) {
  if (value.schema_version !== "epd2.pb01.closure-record/1") throw new Error("unknown schema");
  if (!/^ei1_[0-9a-f]{32}$/.test(value.election_instance_id)) throw new Error("invalid election instance id");
  if (value.closure_state !== "closed") throw new Error("not closed");
  requireHex64(value.closure_checkpoint_digest, "checkpoint digest");
  requireHex64(value.authorization_evidence_digest, "authorization evidence digest");
  return domainHash(DOMAIN_CLOSURE_RECORD, canonicalBytes(value));
}

export function validateFinalSetEnvelope(value) {
  if (value.schema_version !== "epd2.pb01.final-set-envelope/1") throw new Error("unknown schema");
  validateCommon(value);
  if (value.canonicalization_policy_version !== CANONICALIZATION_POLICY) throw new Error("unknown canonicalization policy");
  if (!TALLY.has(value.tally_function_id)) throw new Error("unknown tally function");
  validateOrderedDigests(value.ordered_ballot_digests);
  requireHex64(value.closure_record_digest, "closure record digest");
  requireHex64(value.cset_root, "CSet root");
  const cset = {
    schema_version: "epd2.pb01.cset-final/1",
    election_instance_id: value.election_instance_id,
    crypto_profile: value.crypto_profile,
    belenios_election_uuid: value.belenios_election_uuid,
    belenios_election_fingerprint: value.belenios_election_fingerprint,
    ordered_ballot_digests: value.ordered_ballot_digests,
  };
  if (csetRoot(cset) !== value.cset_root) throw new Error("CSet root mismatch");
}

export function finalSetEnvelopeDigest(value) {
  validateFinalSetEnvelope(value);
  return domainHash(DOMAIN_FINAL_SET_ENVELOPE, canonicalBytes(value));
}

export function fFinal(value) {
  validateFinalSetEnvelope(value);
  return domainHash(DOMAIN_F_FINAL, canonicalBytes(value));
}

