import { createHash } from "node:crypto";
import { canonicalBytes, CRYPTO_PROFILE, domainHash, TALLY } from "../i01_reference/pb01_profile.mjs";
import { ballotDigest } from "../i02_accepted/shared/profile.mjs";
import { DOMAIN_EXACT_BALLOT_BYTES } from "../i04/constants.mjs";
import {
  AUTHORIZED_ENCRYPTED_TALLY_SCHEMA,
  TALLY_EVIDENCE_SCHEMA,
  TALLY_INPUT_SCHEMA,
  TALLY_PRODUCER_VERSION,
  TALLY_RECORD_SCHEMA,
} from "./constants.mjs";
import { failI05 } from "./errors.mjs";
import { aggregateCiphertextDigest, tallyEvidenceDigest, tallyInputDigest, tallyRecordDigest } from "./hashes.mjs";

function sha256Hex(bytes) { return createHash("sha256").update(bytes).digest("hex"); }
function same(a, b) { return Buffer.from(canonicalBytes(a)).equals(Buffer.from(canonicalBytes(b))); }
function ensureHex64(x, code = "FINAL_SET_MISMATCH") { if (!/^[0-9a-f]{64}$/u.test(x ?? "")) failI05(code); }

export function buildTallyInputManifest({ finalization, authorizedSet }) {
  const manifest = {
    schema_version: TALLY_INPUT_SCHEMA,
    election_instance_id: authorizedSet.election_instance_id,
    crypto_profile: authorizedSet.crypto_profile,
    tally_function_id: authorizedSet.tally_function_id,
    f_final: authorizedSet.f_final,
    cset_root: finalization.cset_root,
    ordered_ballot_digests: [...authorizedSet.ordered_ballot_digests],
    final_set_envelope_digest: finalization.final_set_envelope_digest,
    ballot_count_decimal: String(authorizedSet.ordered_ballot_digests.length),
  };
  if (manifest.crypto_profile !== CRYPTO_PROFILE || !TALLY.has(manifest.tally_function_id)) failI05("UNSUPPORTED_TALLY_FUNCTION");
  ensureHex64(manifest.f_final); ensureHex64(manifest.cset_root); ensureHex64(manifest.final_set_envelope_digest);
  return manifest;
}

export function buildTallyArtifacts({ finalization, authorizedSet, aggregate }) {
  const tallyInputManifest = buildTallyInputManifest({ finalization, authorizedSet });
  const inputDigest = tallyInputDigest(tallyInputManifest);
  const aggregateDigest = aggregateCiphertextDigest(aggregate.aggregateBytes);
  const recordWithoutDigest = {
    schema_version: TALLY_RECORD_SCHEMA,
    election_instance_id: authorizedSet.election_instance_id,
    crypto_profile: authorizedSet.crypto_profile,
    tally_function_id: authorizedSet.tally_function_id,
    f_final: authorizedSet.f_final,
    cset_root: finalization.cset_root,
    final_set_envelope_digest: finalization.final_set_envelope_digest,
    tally_input_digest: inputDigest,
    ballot_count_decimal: String(authorizedSet.ordered_ballot_digests.length),
    aggregate_ciphertext: aggregate.aggregateCiphertext,
    aggregate_ciphertext_base64url: Buffer.from(aggregate.aggregateBytes).toString("base64url"),
    aggregate_ciphertext_digest: aggregateDigest,
    upstream_belenios_sized_tally_base64url: Buffer.from(aggregate.upstreamSizedTallyBytes).toString("base64url"),
    producer_version: TALLY_PRODUCER_VERSION,
  };
  const recordDigest = tallyRecordDigest(recordWithoutDigest);
  const homomorphicTallyRecord = { ...recordWithoutDigest, tally_record_digest: recordDigest };
  const evidenceWithoutDigest = {
    schema_version: TALLY_EVIDENCE_SCHEMA,
    election_instance_id: authorizedSet.election_instance_id,
    crypto_profile: authorizedSet.crypto_profile,
    tally_function_id: authorizedSet.tally_function_id,
    final_set_envelope: finalization.final_set_envelope,
    final_set_envelope_digest: finalization.final_set_envelope_digest,
    f_final: authorizedSet.f_final,
    cset_root: finalization.cset_root,
    ordered_ballot_digests: [...authorizedSet.ordered_ballot_digests],
    tally_input_manifest: tallyInputManifest,
    tally_input_digest: inputDigest,
    aggregate_ciphertext: aggregate.aggregateCiphertext,
    aggregate_ciphertext_base64url: Buffer.from(aggregate.aggregateBytes).toString("base64url"),
    aggregate_ciphertext_digest: aggregateDigest,
    homomorphic_tally_record: homomorphicTallyRecord,
    tally_record_digest: recordDigest,
    semantic_claim: "AUTHORIZED_ENCRYPTED_TALLY_EXACT_FINAL_SET_NOT_DECRYPTED",
  };
  const evidenceDigest = tallyEvidenceDigest(evidenceWithoutDigest);
  const tallyEvidenceBundle = { ...evidenceWithoutDigest, tally_evidence_digest: evidenceDigest };
  const authorizedEncryptedTally = {
    schema_version: AUTHORIZED_ENCRYPTED_TALLY_SCHEMA,
    election_instance_id: authorizedSet.election_instance_id,
    crypto_profile: authorizedSet.crypto_profile,
    tally_function_id: authorizedSet.tally_function_id,
    f_final: authorizedSet.f_final,
    tally_record_digest: recordDigest,
    aggregate_ciphertext: aggregate.aggregateCiphertext,
    aggregate_ciphertext_base64url: Buffer.from(aggregate.aggregateBytes).toString("base64url"),
    aggregate_ciphertext_digest: aggregateDigest,
    semantic_claim: "AUTHORIZED_I06_INPUT_ENCRYPTED_TALLY_NOT_DECRYPTED",
  };
  return { tallyInputManifest, tallyInputDigest: inputDigest, homomorphicTallyRecord, tallyRecordDigest: recordDigest, tallyEvidenceBundle, tallyEvidenceDigest: evidenceDigest, authorizedEncryptedTally };
}

export function verifyTallyEvidence(bundle) {
  if (!bundle || bundle.schema_version !== TALLY_EVIDENCE_SCHEMA) failI05("TALLY_RECOMPUTE_MISMATCH");
  const { tally_evidence_digest, ...withoutEvidenceDigest } = bundle;
  if (tallyEvidenceDigest(withoutEvidenceDigest) !== tally_evidence_digest) failI05("TALLY_RECOMPUTE_MISMATCH");
  const m = bundle.tally_input_manifest;
  if (!m || m.schema_version !== TALLY_INPUT_SCHEMA || tallyInputDigest(m) !== bundle.tally_input_digest) failI05("TALLY_RECOMPUTE_MISMATCH");
  if (m.f_final !== bundle.f_final || m.cset_root !== bundle.cset_root || m.final_set_envelope_digest !== bundle.final_set_envelope_digest) failI05("FINAL_SET_MISMATCH");
  if (!same(m.ordered_ballot_digests, bundle.ordered_ballot_digests)) failI05("FINAL_SET_MISMATCH");
  const aggBytes = Buffer.from(bundle.aggregate_ciphertext_base64url, "base64url");
  if (aggregateCiphertextDigest(aggBytes) !== bundle.aggregate_ciphertext_digest) failI05("TALLY_RECOMPUTE_MISMATCH");
  if (aggBytes.toString("utf8") !== JSON.stringify(bundle.aggregate_ciphertext)) failI05("TALLY_RECOMPUTE_MISMATCH");
  const r = bundle.homomorphic_tally_record;
  const { tally_record_digest, ...r0 } = r;
  if (tallyRecordDigest(r0) !== tally_record_digest || tally_record_digest !== bundle.tally_record_digest) failI05("TALLY_RECOMPUTE_MISMATCH");
  if (r.tally_input_digest !== bundle.tally_input_digest || r.aggregate_ciphertext_digest !== bundle.aggregate_ciphertext_digest || r.f_final !== bundle.f_final) failI05("FINAL_SET_MISMATCH");
  return { valid: true, f_final: bundle.f_final, tally_record_digest: bundle.tally_record_digest, aggregate_ciphertext_digest: bundle.aggregate_ciphertext_digest };
}

export class TallyEngine {
  constructor({ finalizationStore, tallyStore, aggregator, electionDir, authorizationVerifier = null, failpoint = null }) {
    this.finalizationStore = finalizationStore;
    this.tallyStore = tallyStore;
    this.aggregator = aggregator;
    this.electionDir = electionDir;
    this.authorizationVerifier = authorizationVerifier;
    this.failpoint = failpoint;
  }

  async deriveAuthorizedInput(electionInstanceId) {
    try {
      const recompute = await this.finalizationStore.recompute(electionInstanceId, { authorizationVerifier: this.authorizationVerifier });
      if (recompute.status !== "PASS") failI05("FINALIZATION_INTEGRITY_FAILURE");
    } catch { failI05("FINALIZATION_INTEGRITY_FAILURE"); }
    const finalization = await this.finalizationStore.readFinalization(electionInstanceId);
    const authorizedSet = await this.finalizationStore.authorizedFinalBallotSet(electionInstanceId);
    const exactRows = await this.finalizationStore.exactFinalBallotBytes(electionInstanceId);
    const election = await this.finalizationStore.getElection(electionInstanceId);
    if (!finalization || !authorizedSet || !election) failI05("TALLY_NOT_AUTHORIZED", 404);
    if (finalization.f_final !== authorizedSet.f_final || finalization.cset_root !== finalization.final_set_envelope.cset_root) failI05("FINAL_SET_MISMATCH");
    if (!same(finalization.final_set_envelope.ordered_ballot_digests, authorizedSet.ordered_ballot_digests)) failI05("FINAL_SET_MISMATCH");
    if (exactRows.length !== authorizedSet.ordered_ballot_digests.length || exactRows.length !== authorizedSet.exact_ballot_byte_references.length) failI05("FINAL_SET_MISMATCH");
    const orderedBytes = [];
    for (let i = 0; i < authorizedSet.ordered_ballot_digests.length; i += 1) {
      const digest = authorizedSet.ordered_ballot_digests[i];
      const row = exactRows[i];
      const ref = authorizedSet.exact_ballot_byte_references[i];
      if (!row || !ref) failI05("BALLOT_NOT_FOUND");
      if (row.ballot_digest !== digest || ref.ballot_digest !== digest) failI05("FINAL_SET_MISMATCH");
      const bytes = Buffer.from(row.encrypted_ballot_bytes);
      if (sha256Hex(bytes) !== ref.exact_ballot_byte_sha256) failI05("BALLOT_DIGEST_MISMATCH");
      if (domainHash(DOMAIN_EXACT_BALLOT_BYTES, bytes) !== ref.exact_ballot_byte_domain_digest) failI05("BALLOT_DIGEST_MISMATCH");
      if (String(bytes.length) !== ref.byte_length_decimal) failI05("BALLOT_DIGEST_MISMATCH");
      const computed = ballotDigest(election.context_json ?? election.context ?? election, bytes.toString("base64url"));
      if (computed !== digest) failI05("BALLOT_DIGEST_MISMATCH");
      await this.aggregator.verifyBallot({ electionDir: this.electionDir, ballotBytes: bytes });
      orderedBytes.push(bytes);
    }
    return { finalization, authorizedSet, exactRows, election, orderedBytes };
  }

  async compute(electionInstanceId) {
    const input = await this.deriveAuthorizedInput(electionInstanceId);
    await this.failpoint?.("after_finalization_verification_before_aggregation");
    const aggregate = await this.aggregator.aggregate({ orderedBallotBytes: input.orderedBytes });
    await this.failpoint?.("during_aggregate_construction");
    const artifacts = buildTallyArtifacts({ finalization: input.finalization, authorizedSet: input.authorizedSet, aggregate });
    return { ...input, aggregate, artifacts };
  }

  async execute(electionInstanceId) {
    const computed = await this.compute(electionInstanceId);
    const persisted = await this.tallyStore.commit({
      electionInstanceId,
      fFinal: computed.authorizedSet.f_final,
      artifacts: computed.artifacts,
      aggregate: computed.aggregate,
      failpoint: this.failpoint,
    });
    await this.failpoint?.("after_commit_before_response");
    return persisted;
  }

  async recompute(electionInstanceId) {
    const persisted = await this.tallyStore.read(electionInstanceId);
    if (!persisted) failI05("TALLY_NOT_AUTHORIZED", 404);

    // PB01-DEBT-I05-RECOMPUTE-AGGREGATE-BYTES-01 closure:
    // the persisted bytea is an independently authenticated input, not a value
    // whose companion digest column may be trusted. This check intentionally
    // happens before ballot re-aggregation so privileged byte-only mutation is
    // fail-closed and I06 can use recompute() as its mandatory integrity gate.
    const persistedAggregateDigest = aggregateCiphertextDigest(Buffer.from(persisted.aggregate_ciphertext_bytes));
    if (persistedAggregateDigest !== persisted.aggregate_ciphertext_digest) failI05("TALLY_RECOMPUTE_MISMATCH");
    if (persisted.tally_evidence_bundle?.aggregate_ciphertext_digest !== persistedAggregateDigest) failI05("TALLY_RECOMPUTE_MISMATCH");
    if (persisted.tally_evidence_bundle?.aggregate_ciphertext_base64url !== Buffer.from(persisted.aggregate_ciphertext_bytes).toString("base64url")) failI05("TALLY_RECOMPUTE_MISMATCH");

    const computed = await this.compute(electionInstanceId);
    if (persisted.tally_record_digest !== computed.artifacts.tallyRecordDigest
      || persisted.aggregate_ciphertext_digest !== computed.artifacts.homomorphicTallyRecord.aggregate_ciphertext_digest
      || persisted.tally_input_digest !== computed.artifacts.tallyInputDigest
      || persisted.f_final !== computed.authorizedSet.f_final) failI05("TALLY_RECOMPUTE_MISMATCH");
    return { status: "PASS", election_instance_id: electionInstanceId, f_final: persisted.f_final, tally_record_digest: persisted.tally_record_digest, aggregate_ciphertext_digest: persisted.aggregate_ciphertext_digest };
  }
}
