import http from "node:http";
import { failI05 } from "./errors.mjs";
function json(res, status, value) { const body = Buffer.from(JSON.stringify(value)); res.writeHead(status,{"content-type":"application/json","content-length":body.length}); res.end(body); }
export function startI05Service({ engine, tallyStore, authorizeTally = null, port = 0 }) {
  return new Promise((resolve) => {
    const server = http.createServer(async (req,res) => {
      try {
        const u = new URL(req.url, "http://localhost");
        let m = /^\/v1\/elections\/(ei1_[0-9a-f]{32})\/tally$/u.exec(u.pathname);
        if (m && req.method === "POST") {
          if (!authorizeTally || !(await authorizeTally(req, m[1]))) failI05("TALLY_NOT_AUTHORIZED",403);
          let n=0; for await (const chunk of req) n += chunk.length;
          if (n !== 0) failI05("TALLY_NOT_AUTHORIZED",400);
          const out = await engine.execute(m[1]);
          return json(res,200,{status:"AGGREGATED",election_instance_id:m[1],f_final:out.f_final,tally_record_digest:out.tally_record_digest,aggregate_ciphertext_digest:out.aggregate_ciphertext_digest,replay:out.replay});
        }
        m = /^\/v1\/elections\/(ei1_[0-9a-f]{32})\/tally-evidence$/u.exec(u.pathname);
        if (m && req.method === "GET") {
          const evidence = await tallyStore.exportEvidence(m[1]);
          if (!evidence) failI05("TALLY_NOT_AUTHORIZED",404);
          return json(res,200,evidence);
        }
        json(res,404,{error:"NOT_FOUND"});
      } catch (e) { json(res,e?.status ?? 500,{error:e?.code ?? "INTERNAL_ERROR"}); }
    });
    server.listen(port,"127.0.0.1",()=>resolve(server));
  });
}
