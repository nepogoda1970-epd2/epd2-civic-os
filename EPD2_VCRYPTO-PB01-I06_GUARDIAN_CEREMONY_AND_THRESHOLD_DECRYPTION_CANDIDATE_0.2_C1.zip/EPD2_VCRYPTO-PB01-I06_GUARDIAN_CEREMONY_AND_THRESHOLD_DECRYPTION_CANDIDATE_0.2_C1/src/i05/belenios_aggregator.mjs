import { spawn } from "node:child_process";
import { copyFile, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { basename, join } from "node:path";
import { tmpdir } from "node:os";
import { failI05 } from "./errors.mjs";

function run(toolPath, args, { input = null, timeoutMs = 120000 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(toolPath, args, {
      env: { ...process.env, BELENIOS_USE_URANDOM: "1" },
      stdio: ["pipe", "pipe", "pipe"],
    });
    const out = [], err = [];
    const timer = setTimeout(() => { child.kill("SIGKILL"); reject(new Error("BELENIOS_TIMEOUT")); }, timeoutMs);
    child.stdout.on("data", (x) => out.push(x));
    child.stderr.on("data", (x) => err.push(x));
    child.once("error", (e) => { clearTimeout(timer); reject(e); });
    child.once("exit", (code) => {
      clearTimeout(timer);
      if (code === 0) resolve({ stdout: Buffer.concat(out), stderr: Buffer.concat(err) });
      else reject(new Error(`BELENIOS_EXIT_${code}:${Buffer.concat(err).toString("utf8").trim()}`));
    });
    if (input !== null) child.stdin.end(input); else child.stdin.end();
  });
}

export class BeleniosHomomorphicAggregator {
  constructor({ toolPath, baseElectionArchivePath, timeoutMs = 120000, onInvocation = null }) {
    this.toolPath = toolPath;
    this.baseElectionArchivePath = baseElectionArchivePath;
    this.timeoutMs = timeoutMs;
    this.onInvocation = onInvocation;
  }

  async verifyBallot({ electionDir, ballotBytes }) {
    const work = await mkdtemp(join(tmpdir(), "epd2-i05-ballot-verify-"));
    try {
      const ballotPath = join(work, "ballot.json");
      await writeFile(ballotPath, ballotBytes, { mode: 0o600, flag: "wx" });
      this.onInvocation?.("verify-ballot");
      const result = await run(this.toolPath, ["election", "verify-ballot", `--dir=${electionDir}`, `--ballot=${ballotPath}`], { timeoutMs: this.timeoutMs });
      if (!result.stderr.toString("utf8").includes("ballot is valid")) failI05("BALLOT_REVERIFICATION_FAILED");
      return "PASS_NATIVE_BELENIOS_3.3.0";
    } catch (error) {
      if (error?.code === "BALLOT_REVERIFICATION_FAILED") throw error;
      failI05("BALLOT_REVERIFICATION_FAILED");
    } finally {
      await rm(work, { recursive: true, force: true });
    }
  }

  async aggregate({ orderedBallotBytes }) {
    const work = await mkdtemp(join(tmpdir(), "epd2-i05-aggregate-"));
    try {
      const archiveName = basename(this.baseElectionArchivePath);
      await copyFile(this.baseElectionArchivePath, join(work, archiveName));
      for (const ballotBytes of orderedBallotBytes) {
        this.onInvocation?.("archive-add-ballot");
        await run(this.toolPath, ["archive", "add-event", `--dir=${work}`, "--type=Ballot"], { input: Buffer.concat([Buffer.from(ballotBytes), Buffer.from("\n")]), timeoutMs: this.timeoutMs });
      }
      this.onInvocation?.("archive-end-ballots");
      await run(this.toolPath, ["archive", "add-event", `--dir=${work}`, "--type=EndBallots"], { input: Buffer.alloc(0), timeoutMs: this.timeoutMs });
      this.onInvocation?.("compute-encrypted-tally");
      const result = await run(this.toolPath, ["election", "compute-encrypted-tally", `--dir=${work}`], { timeoutMs: this.timeoutMs });
      const lines = result.stdout.toString("utf8").split("\n").filter((x) => x.length > 0);
      if (lines.length !== 2) failI05("AGGREGATION_FAILED");
      const aggregateBytes = Buffer.from(lines[0], "utf8");
      let aggregateCiphertext, sized;
      try { aggregateCiphertext = JSON.parse(lines[0]); sized = JSON.parse(lines[1]); } catch { failI05("AGGREGATION_FAILED"); }
      if (String(sized.num_tallied) !== String(orderedBallotBytes.length)) failI05("AGGREGATION_FAILED");
      return {
        aggregateCiphertext,
        aggregateBytes,
        upstreamSizedTallyBytes: Buffer.from(lines[1], "utf8"),
        upstreamSizedTally: {
          num_tallied_decimal: String(sized.num_tallied),
          total_weight_decimal: String(sized.total_weight),
          encrypted_tally: String(sized.encrypted_tally),
        },
      };
    } catch (error) {
      if (error?.code === "AGGREGATION_FAILED") throw error;
      failI05("AGGREGATION_FAILED");
    } finally {
      await rm(work, { recursive: true, force: true });
    }
  }
}
