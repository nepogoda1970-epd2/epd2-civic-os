import { randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import pg from "pg";
import { canonicalize } from "../i02_accepted/shared/profile.mjs";
import { failI05 } from "./errors.mjs";
const { Pool } = pg;
function jsonValue(value) { return typeof value === "string" ? JSON.parse(value) : value; }
function isoNow() { return new Date().toISOString().replace(/\.\d{3}Z$/u, "Z"); }

function run(command, args, env) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { env, stdio: ["ignore", "pipe", "pipe"] });
    const stderr = [];
    child.stderr.on("data", (chunk) => stderr.push(chunk));
    child.once("error", reject);
    child.once("exit", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`POSTGRES_BACKUP_FAILED:${Buffer.concat(stderr).toString("utf8").trim()}`));
    });
  });
}

export class PostgresTallyStore {
  constructor(config) {
    const { pool, backup = null, ...poolConfig } = config ?? {};
    this.pool = pool ?? new Pool(poolConfig);
    this.backup = backup;
  }
  async close() { await this.pool.end(); }

  async backupTo(destinationPath) {
    if (!this.backup?.pgDumpPath) throw new Error("POSTGRES_BACKUP_NOT_CONFIGURED");
    const { pgDumpPath, host, port, database, user, password } = this.backup;
    await run(pgDumpPath, [
      "--format=custom", "--no-owner", "--no-privileges", "--file", destinationPath,
      "--host", host, "--port", String(port), "--username", user, database,
    ], { ...process.env, PGPASSWORD: password });
    return destinationPath;
  }

  async read(electionInstanceId) {
    const r = await this.pool.query(`
      SELECT r.election_instance_id, r.f_final, r.cset_root, r.final_set_envelope_digest,
        r.tally_input_digest, r.aggregate_ciphertext_digest, r.tally_record_digest,
        r.tally_evidence_digest, r.tally_input_manifest_canonical, r.tally_record_canonical,
        r.tally_evidence_canonical, a.ballot_count, a.aggregate_ciphertext_bytes,
        a.upstream_sized_tally_bytes
      FROM pb01_i05.tally_records r JOIN pb01_i05.aggregates a USING (election_instance_id)
      WHERE r.election_instance_id = $1
    `, [electionInstanceId]);
    if (r.rowCount !== 1) return null;
    const x = r.rows[0];
    return {
      election_instance_id: x.election_instance_id,
      f_final: x.f_final,
      cset_root: x.cset_root,
      final_set_envelope_digest: x.final_set_envelope_digest,
      tally_input_digest: x.tally_input_digest,
      aggregate_ciphertext_digest: x.aggregate_ciphertext_digest,
      tally_record_digest: x.tally_record_digest,
      tally_evidence_digest: x.tally_evidence_digest,
      ballot_count_decimal: String(x.ballot_count),
      aggregate_ciphertext_bytes: Buffer.from(x.aggregate_ciphertext_bytes),
      upstream_sized_tally_bytes: Buffer.from(x.upstream_sized_tally_bytes),
      tally_input_manifest: jsonValue(x.tally_input_manifest_canonical),
      homomorphic_tally_record: jsonValue(x.tally_record_canonical),
      tally_evidence_bundle: jsonValue(x.tally_evidence_canonical),
    };
  }

  async commit({ electionInstanceId, fFinal, artifacts, aggregate, failpoint = null }) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN ISOLATION LEVEL SERIALIZABLE");
      await client.query("SET LOCAL lock_timeout = '10s'");
      await client.query("SET LOCAL statement_timeout = '60s'");
      await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 5))", [electionInstanceId]);
      const authority = await client.query("SELECT f_final FROM pb01_i04.finalizations WHERE election_instance_id = $1 AND finalization_state = 'FINALIZED'", [electionInstanceId]);
      if (authority.rowCount !== 1) failI05("TALLY_NOT_AUTHORIZED", 409);
      if (authority.rows[0].f_final !== fFinal) failI05("TALLY_CONFLICT", 409);
      const existing = await client.query("SELECT f_final, tally_record_digest FROM pb01_i05.tally_records WHERE election_instance_id = $1", [electionInstanceId]);
      if (existing.rowCount === 1) {
        if (existing.rows[0].f_final !== fFinal || existing.rows[0].tally_record_digest !== artifacts.tallyRecordDigest) failI05("TALLY_CONFLICT", 409);
        await client.query("COMMIT");
        return { ...(await this.read(electionInstanceId)), replay: true };
      }
      const committedAt = isoNow();
      await client.query(`
        INSERT INTO pb01_i05.aggregates(election_instance_id, f_final, ballot_count,
          aggregate_ciphertext_bytes, aggregate_ciphertext_digest, upstream_sized_tally_bytes, created_at)
        VALUES ($1,$2,$3::bigint,$4,$5,$6,$7::timestamptz)
      `, [electionInstanceId, fFinal, artifacts.tallyInputManifest.ballot_count_decimal,
        Buffer.from(aggregate.aggregateBytes), artifacts.homomorphicTallyRecord.aggregate_ciphertext_digest,
        Buffer.from(aggregate.upstreamSizedTallyBytes), committedAt]);
      await failpoint?.("after_aggregate_persistence_before_tally_record_commit");
      await client.query(`
        INSERT INTO pb01_i05.tally_records(election_instance_id, f_final, cset_root,
          final_set_envelope_digest, tally_input_digest, aggregate_ciphertext_digest,
          tally_record_digest, tally_evidence_digest, tally_input_manifest_canonical,
          tally_record_canonical, tally_evidence_canonical, committed_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12::timestamptz)
      `, [electionInstanceId, fFinal, artifacts.tallyInputManifest.cset_root,
        artifacts.tallyInputManifest.final_set_envelope_digest, artifacts.tallyInputDigest,
        artifacts.homomorphicTallyRecord.aggregate_ciphertext_digest, artifacts.tallyRecordDigest,
        artifacts.tallyEvidenceDigest, canonicalize(artifacts.tallyInputManifest),
        canonicalize(artifacts.homomorphicTallyRecord), canonicalize(artifacts.tallyEvidenceBundle), committedAt]);
      await client.query(`INSERT INTO pb01_i05.tally_audit_events(audit_event_id,election_instance_id,event_code,occurred_at,detail_canonical)
        VALUES($1,$2,'TALLY_COMMITTED',$3::timestamptz,$4)`, [randomUUID(), electionInstanceId, committedAt,
        canonicalize({ f_final: fFinal, tally_record_digest: artifacts.tallyRecordDigest, aggregate_ciphertext_digest: artifacts.homomorphicTallyRecord.aggregate_ciphertext_digest })]);
      await client.query("COMMIT");
      return { ...(await this.read(electionInstanceId)), replay: false };
    } catch (error) {
      try { await client.query("ROLLBACK"); } catch { /* ignored */ }
      throw error;
    } finally { client.release(); }
  }

  async exportEvidence(electionInstanceId) {
    const x = await this.read(electionInstanceId);
    return x?.tally_evidence_bundle ?? null;
  }

  async assertRuntimePrivileges() {
    const r = await this.pool.query(`SELECT current_user AS role_name,
      p.rolsuper,p.rolcreatedb,p.rolcreaterole,p.rolreplication,p.rolbypassrls,
      has_schema_privilege(current_user,'pb01_i05','USAGE') AS i05_usage,
      has_schema_privilege(current_user,'pb01_i05','CREATE') AS i05_create,
      has_schema_privilege(current_user,'public','CREATE') AS public_create,
      has_database_privilege(current_user,current_database(),'TEMP') AS db_temp,
      has_table_privilege(current_user,'pb01_i03.encrypted_submissions','SELECT') AS i03_read,
      has_table_privilege(current_user,'pb01_i03.encrypted_submissions','UPDATE') AS i03_update,
      has_table_privilege(current_user,'pb01_i04.finalizations','SELECT') AS i04_read,
      has_table_privilege(current_user,'pb01_i04.finalizations','UPDATE') AS i04_update,
      has_table_privilege(current_user,'pb01_i05.tally_records','INSERT') AS tally_insert,
      has_table_privilege(current_user,'pb01_i05.tally_records','UPDATE') AS tally_update
      FROM pg_roles p WHERE p.rolname=current_user`);
    const x = r.rows[0];
    const safe = x && !x.rolsuper && !x.rolcreatedb && !x.rolcreaterole && !x.rolreplication && !x.rolbypassrls
      && x.i05_usage && !x.i05_create && !x.public_create && !x.db_temp && x.i03_read && !x.i03_update
      && x.i04_read && !x.i04_update && x.tally_insert && !x.tally_update;
    if (!safe) throw new Error("UNSAFE_I05_POSTGRES_RUNTIME_PRIVILEGES");
    return { ...x, validation: "PASS_TALLY_LEAST_PRIVILEGE" };
  }
}
