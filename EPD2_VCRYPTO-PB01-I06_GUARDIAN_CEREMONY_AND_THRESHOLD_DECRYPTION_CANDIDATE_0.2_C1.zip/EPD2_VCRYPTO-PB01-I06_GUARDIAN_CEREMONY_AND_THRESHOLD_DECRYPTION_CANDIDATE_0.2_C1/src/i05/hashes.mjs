import { canonicalBytes, domainHash } from "../i01_reference/pb01_profile.mjs";
import {
  DOMAIN_AGGREGATE_CIPHERTEXT,
  DOMAIN_TALLY_EVIDENCE,
  DOMAIN_TALLY_INPUT,
  DOMAIN_TALLY_RECORD,
} from "./constants.mjs";

export const tallyInputDigest = (manifest) => domainHash(DOMAIN_TALLY_INPUT, canonicalBytes(manifest));
export const aggregateCiphertextDigest = (exactBytes) => domainHash(DOMAIN_AGGREGATE_CIPHERTEXT, Buffer.from(exactBytes));
export const tallyRecordDigest = (recordWithoutDigest) => domainHash(DOMAIN_TALLY_RECORD, canonicalBytes(recordWithoutDigest));
export const tallyEvidenceDigest = (bundleWithoutDigest) => domainHash(DOMAIN_TALLY_EVIDENCE, canonicalBytes(bundleWithoutDigest));
