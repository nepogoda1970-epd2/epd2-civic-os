export class I05Error extends Error {
  constructor(code, status = 422) {
    super(code);
    this.name = "I05Error";
    this.code = code;
    this.status = status;
  }
}
export function failI05(code, status = 422) { throw new I05Error(code, status); }
