export const TALLY_INPUT_SCHEMA = "epd2.pb01.tally-input-manifest/1";
export const TALLY_RECORD_SCHEMA = "epd2.pb01.homomorphic-tally-record/1";
export const TALLY_EVIDENCE_SCHEMA = "epd2.pb01.tally-evidence-bundle/1";
export const AUTHORIZED_ENCRYPTED_TALLY_SCHEMA = "epd2.pb01.authorized-encrypted-tally/1";

export const DOMAIN_TALLY_INPUT = "epd2.pb01.tally-input.v1";
export const DOMAIN_AGGREGATE_CIPHERTEXT = "epd2.pb01.aggregate-ciphertext.v1";
export const DOMAIN_TALLY_RECORD = "epd2.pb01.homomorphic-tally-record.v1";
export const DOMAIN_TALLY_EVIDENCE = "epd2.pb01.tally-evidence.v1";

export const TALLY_PRODUCER_VERSION = "epd2.pb01.i05/0.1+belenios-3.3.0";
export const TALLY_STATE = Object.freeze({ NOT_TALLIED: "NOT_TALLIED", TALLYING: "TALLYING", AGGREGATED: "AGGREGATED" });
export const TALLY_ERROR_CODES = Object.freeze([
  "TALLY_NOT_AUTHORIZED",
  "FINALIZATION_INTEGRITY_FAILURE",
  "FINAL_SET_MISMATCH",
  "BALLOT_NOT_FOUND",
  "BALLOT_DIGEST_MISMATCH",
  "BALLOT_REVERIFICATION_FAILED",
  "FOREIGN_ELECTION_BALLOT",
  "UNSUPPORTED_TALLY_FUNCTION",
  "AGGREGATION_FAILED",
  "TALLY_CONFLICT",
  "TALLY_RECOMPUTE_MISMATCH",
]);
