import { TextDecoder } from "node:util";
import {
  ballotDigest,
  canonicalize,
  validateContext,
  validateSubmission,
} from "../i02_accepted/shared/profile.mjs";
import { MAX_BALLOT_BYTES, MAX_JSON_DEPTH } from "./constants.mjs";
import { fail } from "./errors.mjs";
import { jsonDepth } from "./strict_json.mjs";

const utf8 = new TextDecoder("utf-8", { fatal: true, ignoreBOM: false });

export function validateArtifactSchema(value) {
  try {
    return validateSubmission(value);
  } catch (error) {
    const code = error instanceof Error ? error.message : "INVALID_SUBMISSION_SCHEMA";
    if (code === "UNSUPPORTED_CRYPTO_PROFILE") fail(code);
    if (code === "UNSUPPORTED_TALLY_FUNCTION") fail(code);
    if (code === "INVALID_ENCRYPTED_BALLOT") fail(code);
    if (code === "BALLOT_DIGEST_MISMATCH") fail(code);
    fail("INVALID_SUBMISSION_SCHEMA");
  }
}

export function validateElectionBinding({ artifact, context, routeElectionId }) {
  validateContext(context);
  if (artifact.election_instance_id !== routeElectionId || artifact.election_instance_id !== context.election_instance_id) fail("FOREIGN_ELECTION_BALLOT");
  if (artifact.crypto_profile !== context.crypto_profile) fail("UNSUPPORTED_CRYPTO_PROFILE");
  if (artifact.tally_function_id !== context.tally_function_id) fail("UNSUPPORTED_TALLY_FUNCTION");
}

export function decodeAndInspectBallot(artifact, context) {
  if (!/^[A-Za-z0-9_-]+$/u.test(artifact.encrypted_ballot)) fail("INVALID_ENCRYPTED_BALLOT");
  const ballotBytes = Buffer.from(artifact.encrypted_ballot, "base64url");
  if (ballotBytes.length < 1 || ballotBytes.length > MAX_BALLOT_BYTES || ballotBytes.toString("base64url") !== artifact.encrypted_ballot) fail("INVALID_ENCRYPTED_BALLOT");
  let raw;
  try {
    raw = JSON.parse(utf8.decode(ballotBytes));
    jsonDepth(raw, 0);
  } catch {
    fail("INVALID_ENCRYPTED_BALLOT");
  }
  if (raw === null || Array.isArray(raw) || typeof raw !== "object") fail("INVALID_ENCRYPTED_BALLOT");
  if (jsonDepth(raw) > MAX_JSON_DEPTH) fail("INVALID_ENCRYPTED_BALLOT");
  if (raw.election_uuid !== context.belenios_election_uuid || raw.election_hash !== context.belenios_election_fingerprint) fail("FOREIGN_ELECTION_BALLOT");
  return ballotBytes;
}

export function recomputeDigest(artifact, context) {
  const recomputed = ballotDigest(context, artifact.encrypted_ballot);
  if (recomputed !== artifact.ballot_digest) fail("BALLOT_DIGEST_MISMATCH");
  return recomputed;
}

export function requireCanonicalArtifact(text, artifact) {
  if (canonicalize(artifact) !== text) fail("INVALID_SUBMISSION_SCHEMA");
}
