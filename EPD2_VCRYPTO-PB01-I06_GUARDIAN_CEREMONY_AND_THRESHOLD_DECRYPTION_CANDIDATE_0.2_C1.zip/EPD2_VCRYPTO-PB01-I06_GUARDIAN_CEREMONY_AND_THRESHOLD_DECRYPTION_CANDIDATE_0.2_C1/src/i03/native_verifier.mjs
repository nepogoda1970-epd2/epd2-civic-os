import { execFile } from "node:child_process";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import { VERIFY_TIMEOUT_MS } from "./constants.mjs";
import { fail } from "./errors.mjs";

const execFileAsync = promisify(execFile);

export class NativeBeleniosVerifier {
  constructor({ toolPath, timeoutMs = VERIFY_TIMEOUT_MS, onInvocation = null }) {
    this.toolPath = toolPath;
    this.timeoutMs = timeoutMs;
    this.onInvocation = onInvocation;
  }

  async verify({ electionDir, ballotBytes }) {
    this.onInvocation?.();
    const work = await mkdtemp(join(tmpdir(), "epd2-i03-verify-"));
    const ballotPath = join(work, "ballot.json");
    try {
      await writeFile(ballotPath, ballotBytes, { mode: 0o600, flag: "wx" });
      const result = await execFileAsync(
        this.toolPath,
        ["election", "verify-ballot", `--dir=${electionDir}`, `--ballot=${ballotPath}`],
        {
          env: { ...process.env, BELENIOS_USE_URANDOM: "1" },
          encoding: "utf8",
          maxBuffer: 4 * 1024 * 1024,
          timeout: this.timeoutMs,
        },
      );
      if (!result.stderr.includes("ballot is valid")) fail("INVALID_ENCRYPTED_BALLOT");
      return "PASS_NATIVE_BELENIOS_3.3.0";
    } catch (error) {
      if (error instanceof Error && error.message === "INVALID_ENCRYPTED_BALLOT") throw error;
      fail("INVALID_ENCRYPTED_BALLOT");
    } finally {
      await rm(work, { recursive: true, force: true });
    }
  }
}
