import { createHmac, timingSafeEqual } from "node:crypto";
import { canonicalBytes, canonicalize } from "../i02_accepted/shared/profile.mjs";
import {
  AUTH_KIND,
  AUTH_SCHEMA,
  DOMAIN_AUTH_CAPABILITY,
  DOMAIN_LIFECYCLE_HANDLE,
} from "./constants.mjs";
import { fail } from "./errors.mjs";

function b64url(value) {
  return Buffer.from(value).toString("base64url");
}

function mac(secret, payloadB64) {
  return createHmac("sha256", secret)
    .update(DOMAIN_AUTH_CAPABILITY, "ascii")
    .update(Buffer.from([0]))
    .update(payloadB64, "ascii")
    .digest();
}

function exactKeys(value, expected) {
  if (value === null || Array.isArray(value) || typeof value !== "object") return false;
  const actual = Object.keys(value).sort();
  const target = [...expected].sort();
  return actual.length === target.length && actual.every((entry, index) => entry === target[index]);
}

export class ScopedCredentialAuthority {
  constructor({ capabilityKey, lifecycleKey, issuer = "epd2-ws03" }) {
    if (!Buffer.isBuffer(capabilityKey) || capabilityKey.length < 32) throw new Error("capabilityKey must be at least 32 bytes");
    if (!Buffer.isBuffer(lifecycleKey) || lifecycleKey.length < 32) throw new Error("lifecycleKey must be at least 32 bytes");
    this.capabilityKey = capabilityKey;
    this.lifecycleKey = lifecycleKey;
    this.issuer = issuer;
  }

  issue({ electionInstanceId, lifecycleNonce, expiresAt, revoteAllowed = true }) {
    const payload = {
      schema_version: AUTH_SCHEMA,
      issuer: this.issuer,
      election_instance_id: electionInstanceId,
      lifecycle_nonce: lifecycleNonce,
      expires_at: expiresAt,
      revote_allowed: revoteAllowed ? "true" : "false",
    };
    const payloadB64 = b64url(canonicalBytes(payload));
    const signature = mac(this.capabilityKey, payloadB64).toString("base64url");
    return {
      schema_version: AUTH_SCHEMA,
      scoped_credential: {
        kind: AUTH_KIND,
        secret: `${payloadB64}.${signature}`,
      },
    };
  }

  verify(authorizationHeader, electionInstanceId, now = new Date()) {
    if (typeof authorizationHeader !== "string" || !authorizationHeader.startsWith("EPD2-Scoped ")) fail("INVALID_SCOPED_CREDENTIAL", 401);
    const token = authorizationHeader.slice("EPD2-Scoped ".length);
    const parts = token.split(".");
    if (parts.length !== 2 || !parts.every((part) => /^[A-Za-z0-9_-]+$/u.test(part))) fail("INVALID_SCOPED_CREDENTIAL", 401);
    const expected = mac(this.capabilityKey, parts[0]);
    const supplied = Buffer.from(parts[1], "base64url");
    if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) fail("INVALID_SCOPED_CREDENTIAL", 401);
    let payload;
    try {
      const text = Buffer.from(parts[0], "base64url").toString("utf8");
      payload = JSON.parse(text);
      if (canonicalize(payload) !== text) throw new Error("non-canonical capability");
    } catch {
      fail("INVALID_SCOPED_CREDENTIAL", 401);
    }
    if (!exactKeys(payload, ["schema_version", "issuer", "election_instance_id", "lifecycle_nonce", "expires_at", "revote_allowed"])) fail("INVALID_SCOPED_CREDENTIAL", 401);
    if (payload.schema_version !== AUTH_SCHEMA || payload.issuer !== this.issuer || payload.election_instance_id !== electionInstanceId) fail("INVALID_SCOPED_CREDENTIAL", 401);
    if (!/^[0-9a-f]{32}$/u.test(payload.lifecycle_nonce) || !/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$/u.test(payload.expires_at)) fail("INVALID_SCOPED_CREDENTIAL", 401);
    if (Date.parse(payload.expires_at) <= now.getTime()) fail("EXPIRED_SCOPED_CREDENTIAL", 401);
    const lifecycleHandle = createHmac("sha256", this.lifecycleKey)
      .update(DOMAIN_LIFECYCLE_HANDLE, "ascii")
      .update(Buffer.from([0]))
      .update(electionInstanceId, "ascii")
      .update(Buffer.from([0]))
      .update(payload.lifecycle_nonce, "ascii")
      .digest("hex");
    return {
      lifecycle_handle: lifecycleHandle,
      expires_at: payload.expires_at,
      revote_allowed: payload.revote_allowed === "true",
    };
  }
}
