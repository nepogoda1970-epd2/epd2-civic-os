import { TextDecoder } from "node:util";
import { MAX_JSON_DEPTH } from "./constants.mjs";
import { fail } from "./errors.mjs";

const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: false });

export function jsonDepth(value, depth = 0) {
  if (depth > MAX_JSON_DEPTH) fail("INVALID_SUBMISSION_SCHEMA");
  if (Array.isArray(value)) {
    for (const item of value) jsonDepth(item, depth + 1);
  } else if (value !== null && typeof value === "object") {
    for (const item of Object.values(value)) jsonDepth(item, depth + 1);
  }
  return depth;
}

class Parser {
  constructor(text, maxDepth) {
    this.text = text;
    this.index = 0;
    this.maxDepth = maxDepth;
  }

  parse() {
    const value = this.value(0);
    this.ws();
    if (this.index !== this.text.length) throw new Error("trailing JSON data");
    return value;
  }

  ws() {
    while (/[\u0009\u000a\u000d\u0020]/u.test(this.text[this.index] || "")) this.index += 1;
  }

  value(depth) {
    if (depth > this.maxDepth) throw new Error("JSON nesting limit");
    this.ws();
    const char = this.text[this.index];
    if (char === "{") return this.object(depth + 1);
    if (char === "[") return this.array(depth + 1);
    if (char === '"') return this.string();
    if (this.text.startsWith("true", this.index)) return this.literal("true", true);
    if (this.text.startsWith("false", this.index)) return this.literal("false", false);
    if (this.text.startsWith("null", this.index)) return this.literal("null", null);
    if (char === "-" || /[0-9]/u.test(char || "")) return this.number();
    throw new Error("invalid JSON token");
  }

  literal(token, value) {
    this.index += token.length;
    return value;
  }

  string() {
    const start = this.index;
    this.index += 1;
    while (this.index < this.text.length) {
      const char = this.text[this.index++];
      if (char === '"') return JSON.parse(this.text.slice(start, this.index));
      if (char === "\\") {
        const escaped = this.text[this.index++];
        if (escaped === "u") {
          const hex = this.text.slice(this.index, this.index + 4);
          if (!/^[0-9a-fA-F]{4}$/u.test(hex)) throw new Error("invalid unicode escape");
          this.index += 4;
        } else if (!/["\\/bfnrt]/u.test(escaped || "")) throw new Error("invalid escape");
      } else if (char.charCodeAt(0) < 0x20) throw new Error("control character in string");
    }
    throw new Error("unterminated string");
  }

  number() {
    const match = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/u.exec(this.text.slice(this.index));
    if (!match) throw new Error("invalid number");
    this.index += match[0].length;
    const value = Number(match[0]);
    if (!Number.isFinite(value)) throw new Error("invalid number");
    return value;
  }

  object(depth) {
    const result = {};
    const keys = new Set();
    this.index += 1;
    this.ws();
    if (this.text[this.index] === "}") {
      this.index += 1;
      return result;
    }
    while (true) {
      this.ws();
      if (this.text[this.index] !== '"') throw new Error("object key required");
      const key = this.string();
      if (keys.has(key)) throw new Error("duplicate JSON member");
      keys.add(key);
      this.ws();
      if (this.text[this.index++] !== ":") throw new Error("colon required");
      result[key] = this.value(depth);
      this.ws();
      const next = this.text[this.index++];
      if (next === "}") return result;
      if (next !== ",") throw new Error("comma required");
    }
  }

  array(depth) {
    const result = [];
    this.index += 1;
    this.ws();
    if (this.text[this.index] === "]") {
      this.index += 1;
      return result;
    }
    while (true) {
      result.push(this.value(depth));
      this.ws();
      const next = this.text[this.index++];
      if (next === "]") return result;
      if (next !== ",") throw new Error("comma required");
    }
  }
}

export function parseStrictJson(bytes, { maxDepth = MAX_JSON_DEPTH } = {}) {
  try {
    if (!(bytes instanceof Uint8Array)) throw new Error("bytes required");
    if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) throw new Error("BOM prohibited");
    const text = decoder.decode(bytes);
    const value = new Parser(text, maxDepth).parse();
    jsonDepth(value);
    return { value, text };
  } catch {
    fail("INVALID_SUBMISSION_SCHEMA");
  }
}
