import { createHash, randomUUID } from "node:crypto";
import { spawn } from "node:child_process";
import pg from "pg";
import { canonicalize, validateContext } from "../i02_accepted/shared/profile.mjs";
import {
  ACCEPTED_EVENT_VERSION,
  MANIFEST_SCHEMA,
  STATUS_SCHEMA,
  ZERO_HASH,
} from "./constants.mjs";
import { fail } from "./errors.mjs";
import { acceptedManifestDigest, ledgerEventHash } from "./hashes.mjs";

const { Pool } = pg;

function jsonObject(value) {
  return typeof value === "string" ? JSON.parse(value) : value;
}

function isoExpression(column) {
  return `to_char(${column} AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`;
}

function run(command, args, env) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { env, stdio: ["ignore", "pipe", "pipe"] });
    const stderr = [];
    child.stderr.on("data", (chunk) => stderr.push(chunk));
    child.once("error", reject);
    child.once("exit", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`POSTGRES_BACKUP_FAILED:${Buffer.concat(stderr).toString("utf8").trim()}`));
    });
  });
}

export class PostgresSubmissionStore {
  constructor(config) {
    const { pool, backup = null, ...poolConfig } = config ?? {};
    this.pool = pool ?? new Pool(poolConfig);
    this.backup = backup;
  }

  async registerElection(context, createdAt = new Date().toISOString().replace(/\.\d{3}Z$/u, "Z")) {
    validateContext(context);
    const contextJson = canonicalize(context);
    const contextHash = createHash("sha256").update(contextJson, "utf8").digest("hex");
    await this.pool.query(`
      INSERT INTO pb01_i03.elections(
        election_instance_id, crypto_profile, tally_function_id, belenios_election_uuid,
        belenios_election_hash, context_json, context_sha256, election_state, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7, 'OPEN', $8::timestamptz)
      ON CONFLICT (election_instance_id) DO NOTHING
    `, [
      context.election_instance_id,
      context.crypto_profile,
      context.tally_function_id,
      context.belenios_election_uuid,
      context.belenios_election_fingerprint,
      contextJson,
      contextHash,
      createdAt,
    ]);
    const existing = await this.pool.query(
      "SELECT context_sha256 FROM pb01_i03.elections WHERE election_instance_id = $1",
      [context.election_instance_id],
    );
    if (existing.rowCount !== 1 || existing.rows[0].context_sha256 !== contextHash) throw new Error("ELECTION_CONTEXT_CONFLICT");
  }

  async getElection(electionInstanceId) {
    const result = await this.pool.query(`
      SELECT election_instance_id, crypto_profile, tally_function_id, belenios_election_uuid,
        belenios_election_hash, context_json, context_sha256, election_state,
        ${isoExpression("created_at")} AS created_at
      FROM pb01_i03.elections WHERE election_instance_id = $1
    `, [electionInstanceId]);
    return result.rows[0] ?? null;
  }

  async recordAudit({ electionInstanceId = null, code, occurredAt, detail = {} }) {
    try {
      await this.pool.query(`
        INSERT INTO pb01_i03.security_audit_events(
          audit_event_id, election_instance_id, event_code, occurred_at, detail_json
        ) VALUES ($1, $2, $3, $4::timestamptz, $5::jsonb)
      `, [randomUUID(), electionInstanceId, code, occurredAt, canonicalize(detail)]);
    } catch {
      // Audit failure must never disclose the rejected request or transform its public error.
    }
  }

  async assertRuntimePrivileges() {
    const result = await this.pool.query(`
      SELECT current_user AS role_name,
        r.rolsuper, r.rolcreatedb, r.rolcreaterole, r.rolreplication, r.rolbypassrls,
        has_schema_privilege(current_user, 'pb01_i03', 'USAGE') AS schema_usage,
        has_schema_privilege(current_user, 'pb01_i03', 'CREATE') AS schema_create,
        has_schema_privilege(current_user, 'public', 'CREATE') AS public_schema_create,
        has_database_privilege(current_user, current_database(), 'TEMP') AS database_temp,
        has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'SELECT') AS submissions_select,
        has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'INSERT') AS submissions_insert,
        has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'UPDATE') AS submissions_update,
        has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'DELETE') AS submissions_delete,
        has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'TRUNCATE') AS submissions_truncate
      FROM pg_roles r WHERE r.rolname = current_user
    `);
    const row = result.rows[0];
    const safe = row
      && !row.rolsuper
      && !row.rolcreatedb
      && !row.rolcreaterole
      && !row.rolreplication
      && !row.rolbypassrls
      && row.schema_usage
      && !row.schema_create
      && !row.public_schema_create
      && !row.database_temp
      && row.submissions_select
      && row.submissions_insert
      && !row.submissions_update
      && !row.submissions_delete
      && !row.submissions_truncate;
    if (!safe) throw new Error("UNSAFE_POSTGRES_RUNTIME_PRIVILEGES");
    return { ...row, validation: "PASS_NO_RUNTIME_DDL" };
  }

  async accept({
    artifact,
    ballotBytes,
    lifecycleHandle,
    credentialExpiresAt,
    idempotencyKeyHash,
    semanticRequestHash,
    receivedAt,
    acceptedAt,
    receiptSigner,
  }) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      await client.query("SET LOCAL lock_timeout = '10s'");
      await client.query("SET LOCAL statement_timeout = '30s'");
      await client.query(
        "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))",
        [artifact.election_instance_id],
      );

      const priorKey = await client.query(`
        SELECT semantic_request_hash, response_json
        FROM pb01_i03.idempotency_records
        WHERE election_instance_id = $1 AND idempotency_key_hash = $2
      `, [artifact.election_instance_id, idempotencyKeyHash]);
      if (priorKey.rowCount === 1) {
        if (priorKey.rows[0].semantic_request_hash !== semanticRequestHash) fail("IDEMPOTENCY_CONFLICT", 409);
        await client.query("COMMIT");
        return { receipt: jsonObject(priorKey.rows[0].response_json), replay: true, duplicate_digest: false };
      }

      const priorDigest = await client.query(`
        SELECT s.submission_id, s.encrypted_ballot_bytes, s.receipt_json, p.lifecycle_handle
        FROM pb01_i03.encrypted_submissions s
        JOIN pb01_i03.private_submission_lifecycle p USING(submission_id)
        WHERE s.election_instance_id = $1 AND s.ballot_digest = $2
      `, [artifact.election_instance_id, artifact.ballot_digest]);
      if (priorDigest.rowCount === 1) {
        const row = priorDigest.rows[0];
        const exact = Buffer.from(row.encrypted_ballot_bytes).equals(Buffer.from(ballotBytes));
        if (!exact || row.lifecycle_handle !== lifecycleHandle) fail("INVALID_SCOPED_CREDENTIAL", 401);
        const receipt = jsonObject(row.receipt_json);
        await client.query(`
          INSERT INTO pb01_i03.idempotency_records(
            election_instance_id, idempotency_key_hash, semantic_request_hash,
            submission_id, response_json, created_at
          ) VALUES ($1, $2, $3, $4, $5::jsonb, $6::timestamptz)
        `, [
          artifact.election_instance_id,
          idempotencyKeyHash,
          semanticRequestHash,
          row.submission_id,
          canonicalize(receipt),
          acceptedAt,
        ]);
        await client.query("COMMIT");
        return { receipt, replay: true, duplicate_digest: true };
      }

      const last = await client.query(`
        SELECT ledger_seq, event_hash FROM pb01_i03.submission_ledger_events
        WHERE election_instance_id = $1 ORDER BY ledger_seq DESC LIMIT 1
      `, [artifact.election_instance_id]);
      const ledgerSeq = Number(last.rows[0]?.ledger_seq ?? 0) + 1;
      const previousEventHash = last.rows[0]?.event_hash ?? ZERO_HASH;
      const submissionId = randomUUID();
      const ledgerEventId = randomUUID();
      const event = {
        event_version: ACCEPTED_EVENT_VERSION,
        ledger_event_id: ledgerEventId,
        ledger_seq: String(ledgerSeq),
        submission_id: submissionId,
        election_instance_id: artifact.election_instance_id,
        ballot_digest: artifact.ballot_digest,
        accepted_at: acceptedAt,
        previous_event_hash: previousEventHash,
      };
      const eventHash = ledgerEventHash(event);
      const receipt = receiptSigner.issue({
        submission_id: submissionId,
        election_instance_id: artifact.election_instance_id,
        ballot_digest: artifact.ballot_digest,
        accepted_at: acceptedAt,
        ledger_event_id: ledgerEventId,
        ledger_event_hash: eventHash,
        acceptance_claim: "ACCEPTED_NOT_FINAL_NOT_COUNTED",
      });
      const receiptJson = canonicalize(receipt);

      await client.query(`
        INSERT INTO pb01_i03.encrypted_submissions(
          submission_id, election_instance_id, ballot_digest, crypto_profile, tally_function_id,
          encrypted_ballot_bytes, upstream_format_version, received_at, accepted_at,
          verification_result, client_crypto_build_id, ledger_event_id, receipt_json
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8::timestamptz, $9::timestamptz,
          'PASS_NATIVE_BELENIOS_3.3.0', $10, $11, $12::jsonb)
      `, [
        submissionId,
        artifact.election_instance_id,
        artifact.ballot_digest,
        artifact.crypto_profile,
        artifact.tally_function_id,
        Buffer.from(ballotBytes),
        artifact.upstream_ballot_format_version,
        receivedAt,
        acceptedAt,
        artifact.client_crypto_build_id,
        ledgerEventId,
        receiptJson,
      ]);
      await client.query(`
        INSERT INTO pb01_i03.private_submission_lifecycle(
          submission_id, election_instance_id, lifecycle_handle, credential_expires_at, bound_at
        ) VALUES ($1, $2, $3, $4::timestamptz, $5::timestamptz)
      `, [submissionId, artifact.election_instance_id, lifecycleHandle, credentialExpiresAt, acceptedAt]);
      await client.query(`
        INSERT INTO pb01_i03.submission_ledger_events(
          ledger_event_id, election_instance_id, ledger_seq, submission_id, ballot_digest,
          accepted_at, event_version, previous_event_hash, event_hash, event_json
        ) VALUES ($1, $2, $3, $4, $5, $6::timestamptz, $7, $8, $9, $10::jsonb)
      `, [
        ledgerEventId,
        artifact.election_instance_id,
        ledgerSeq,
        submissionId,
        artifact.ballot_digest,
        acceptedAt,
        ACCEPTED_EVENT_VERSION,
        previousEventHash,
        eventHash,
        canonicalize(event),
      ]);
      await client.query(`
        INSERT INTO pb01_i03.idempotency_records(
          election_instance_id, idempotency_key_hash, semantic_request_hash,
          submission_id, response_json, created_at
        ) VALUES ($1, $2, $3, $4, $5::jsonb, $6::timestamptz)
      `, [
        artifact.election_instance_id,
        idempotencyKeyHash,
        semanticRequestHash,
        submissionId,
        receiptJson,
        acceptedAt,
      ]);
      await client.query("COMMIT");
      return { receipt, replay: false, duplicate_digest: false };
    } catch (error) {
      try { await client.query("ROLLBACK"); } catch { /* transaction already resolved */ }
      throw error;
    } finally {
      client.release();
    }
  }

  async lookupStatus(electionInstanceId, ballotDigest) {
    const result = await this.pool.query(`
      SELECT submission_id, ballot_digest, ${isoExpression("accepted_at")} AS accepted_at,
        ledger_event_id, receipt_json
      FROM pb01_i03.encrypted_submissions
      WHERE election_instance_id = $1 AND ballot_digest = $2
    `, [electionInstanceId, ballotDigest]);
    if (result.rowCount === 0) return null;
    const row = result.rows[0];
    const receipt = jsonObject(row.receipt_json);
    return {
      schema_version: STATUS_SCHEMA,
      election_instance_id: electionInstanceId,
      submission_id: row.submission_id,
      ballot_digest: row.ballot_digest,
      accepted_at: row.accepted_at,
      ledger_event_id: row.ledger_event_id,
      ledger_event_hash: receipt.ledger_event_hash,
      status: "ACCEPTED",
      finality_claim: "NOT_FINAL_NOT_COUNTED",
    };
  }

  async privateLifecycleForSubmission(submissionId) {
    const result = await this.pool.query(`
      SELECT election_instance_id, lifecycle_handle,
        ${isoExpression("credential_expires_at")} AS credential_expires_at,
        ${isoExpression("bound_at")} AS bound_at
      FROM pb01_i03.private_submission_lifecycle WHERE submission_id = $1
    `, [submissionId]);
    return result.rows[0] ?? null;
  }

  async privateLifecycleMembers(electionInstanceId, lifecycleHandle) {
    const result = await this.pool.query(`
      SELECT submission_id, ${isoExpression("bound_at")} AS bound_at
      FROM pb01_i03.private_submission_lifecycle
      WHERE election_instance_id = $1 AND lifecycle_handle = $2
      ORDER BY bound_at, submission_id
    `, [electionInstanceId, lifecycleHandle]);
    return result.rows;
  }

  async exactBallotBytes(electionInstanceId, ballotDigest) {
    const result = await this.pool.query(`
      SELECT encrypted_ballot_bytes FROM pb01_i03.encrypted_submissions
      WHERE election_instance_id = $1 AND ballot_digest = $2
    `, [electionInstanceId, ballotDigest]);
    return result.rowCount === 1 ? Buffer.from(result.rows[0].encrypted_ballot_bytes) : null;
  }

  async counts(electionInstanceId) {
    const result = await this.pool.query(`
      SELECT
        (SELECT count(*) FROM pb01_i03.encrypted_submissions WHERE election_instance_id = $1) AS submissions,
        (SELECT count(*) FROM pb01_i03.private_submission_lifecycle WHERE election_instance_id = $1) AS lifecycle_bindings,
        (SELECT count(*) FROM pb01_i03.submission_ledger_events WHERE election_instance_id = $1) AS ledger_events,
        (SELECT count(*) FROM pb01_i03.idempotency_records WHERE election_instance_id = $1) AS idempotency_records
    `, [electionInstanceId]);
    return Object.fromEntries(Object.entries(result.rows[0]).map(([key, value]) => [key, Number(value)]));
  }

  async checkpoint(electionInstanceId) {
    const result = await this.pool.query(`
      SELECT ledger_seq, event_hash, ${isoExpression("accepted_at")} AS accepted_at
      FROM pb01_i03.submission_ledger_events
      WHERE election_instance_id = $1 ORDER BY ledger_seq DESC LIMIT 1
    `, [electionInstanceId]);
    const count = await this.pool.query(
      "SELECT count(*) AS count FROM pb01_i03.submission_ledger_events WHERE election_instance_id = $1",
      [electionInstanceId],
    );
    const row = result.rows[0];
    const election = row ? null : await this.getElection(electionInstanceId);
    return {
      ledger_event_count: String(count.rows[0].count),
      ledger_seq: String(row?.ledger_seq ?? 0),
      ledger_event_hash: row?.event_hash ?? ZERO_HASH,
      checkpoint_time: row?.accepted_at ?? election?.created_at,
    };
  }

  async verifyLedger(electionInstanceId, expectedCheckpoint = null) {
    const result = await this.pool.query(`
      SELECT ledger_event_id, election_instance_id, ledger_seq, submission_id, ballot_digest,
        ${isoExpression("accepted_at")} AS accepted_at, event_version, previous_event_hash,
        event_hash, event_json
      FROM pb01_i03.submission_ledger_events
      WHERE election_instance_id = $1 ORDER BY ledger_seq
    `, [electionInstanceId]);
    let previous = ZERO_HASH;
    let sequence = 0;
    for (const row of result.rows) {
      sequence += 1;
      if (Number(row.ledger_seq) !== sequence || row.previous_event_hash !== previous) return { valid: false, reason: "CHAIN_ORDER_OR_LINK_MISMATCH" };
      const event = jsonObject(row.event_json);
      if (
        event.ledger_seq !== String(row.ledger_seq)
        || event.ledger_event_id !== row.ledger_event_id
        || event.submission_id !== row.submission_id
        || event.ballot_digest !== row.ballot_digest
        || event.previous_event_hash !== row.previous_event_hash
      ) return { valid: false, reason: "ROW_EVENT_MISMATCH" };
      const computed = ledgerEventHash(event);
      if (computed !== row.event_hash) return { valid: false, reason: "EVENT_HASH_MISMATCH" };
      previous = row.event_hash;
    }
    const checkpoint = await this.checkpoint(electionInstanceId);
    if (expectedCheckpoint && (
      checkpoint.ledger_event_count !== expectedCheckpoint.ledger_event_count
      || checkpoint.ledger_event_hash !== expectedCheckpoint.ledger_event_hash
    )) return { valid: false, reason: "CHECKPOINT_CONFLICT", checkpoint };
    return { valid: true, reason: "PASS", checkpoint };
  }

  async exportAcceptedManifest(electionInstanceId) {
    const election = await this.getElection(electionInstanceId);
    if (!election) return null;
    const result = await this.pool.query(`
      SELECT ballot_digest FROM pb01_i03.encrypted_submissions
      WHERE election_instance_id = $1 ORDER BY ballot_digest COLLATE "C"
    `, [electionInstanceId]);
    const checkpoint = await this.checkpoint(electionInstanceId);
    const manifest = {
      schema_version: MANIFEST_SCHEMA,
      election_instance_id: electionInstanceId,
      crypto_profile: election.crypto_profile,
      tally_function_id: election.tally_function_id,
      generated_at: checkpoint.checkpoint_time,
      accepted_ballot_digests: result.rows.map((row) => row.ballot_digest),
      ledger_checkpoint: {
        ledger_event_count: checkpoint.ledger_event_count,
        ledger_seq: checkpoint.ledger_seq,
        ledger_event_hash: checkpoint.ledger_event_hash,
      },
      semantic_claim: "ACCEPTED_SUBMISSIONS_NOT_FINAL_SET_NOT_COUNTED",
    };
    return { ...manifest, manifest_digest: acceptedManifestDigest(manifest) };
  }

  async backupTo(destinationPath) {
    if (!this.backup?.pgDumpPath) throw new Error("POSTGRES_BACKUP_NOT_CONFIGURED");
    const { pgDumpPath, host, port, database, user, password } = this.backup;
    await run(pgDumpPath, [
      "--format=custom",
      "--no-owner",
      "--no-privileges",
      "--file", destinationPath,
      "--host", host,
      "--port", String(port),
      "--username", user,
      database,
    ], { ...process.env, PGPASSWORD: password });
    return destinationPath;
  }

  async close() {
    await this.pool.end();
  }
}
