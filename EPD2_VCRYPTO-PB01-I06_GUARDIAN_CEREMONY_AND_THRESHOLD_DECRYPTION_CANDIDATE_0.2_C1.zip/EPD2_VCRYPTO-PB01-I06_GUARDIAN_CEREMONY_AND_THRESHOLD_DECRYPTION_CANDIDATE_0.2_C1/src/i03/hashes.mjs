import { createHmac } from "node:crypto";
import { canonicalBytes, domainHash } from "../i02_accepted/shared/profile.mjs";
import {
  DOMAIN_ACCEPTED_MANIFEST,
  DOMAIN_IDEMPOTENCY_KEY,
  DOMAIN_LEDGER_EVENT,
  DOMAIN_REQUEST_HASH,
} from "./constants.mjs";

export { canonicalBytes, domainHash };

export function ledgerEventHash(eventWithoutHash) {
  return domainHash(DOMAIN_LEDGER_EVENT, canonicalBytes(eventWithoutHash));
}

export function acceptedManifestDigest(manifestWithoutDigest) {
  return domainHash(DOMAIN_ACCEPTED_MANIFEST, canonicalBytes(manifestWithoutDigest));
}

export function submissionRequestHash(artifact) {
  return domainHash(DOMAIN_REQUEST_HASH, canonicalBytes(artifact));
}

export function idempotencyKeyHash(secret, electionInstanceId, idempotencyKey) {
  return createHmac("sha256", secret)
    .update(DOMAIN_IDEMPOTENCY_KEY, "ascii")
    .update(Buffer.from([0]))
    .update(electionInstanceId, "ascii")
    .update(Buffer.from([0]))
    .update(idempotencyKey, "utf8")
    .digest("hex");
}
