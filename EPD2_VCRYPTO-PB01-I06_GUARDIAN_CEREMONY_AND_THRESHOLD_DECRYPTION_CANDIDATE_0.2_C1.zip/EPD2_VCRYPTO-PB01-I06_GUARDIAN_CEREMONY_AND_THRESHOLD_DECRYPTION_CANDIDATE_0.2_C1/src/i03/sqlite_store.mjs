import { createHash, randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { backup, DatabaseSync } from "node:sqlite";
import { canonicalBytes, canonicalize, validateContext } from "../i02_accepted/shared/profile.mjs";
import {
  ACCEPTED_EVENT_VERSION,
  MANIFEST_SCHEMA,
  STATUS_SCHEMA,
  ZERO_HASH,
} from "./constants.mjs";
import { fail } from "./errors.mjs";
import { acceptedManifestDigest, ledgerEventHash } from "./hashes.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const defaultMigration = resolve(here, "../../migrations/001_i03_sqlite.sql");

function parseRowJson(value) {
  return JSON.parse(value);
}

export class SqliteSubmissionStore {
  constructor(databasePath) {
    this.databasePath = databasePath;
    this.db = new DatabaseSync(databasePath);
    this.db.exec("PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;");
  }

  migrate(migrationPath = defaultMigration) {
    this.db.exec(readFileSync(migrationPath, "utf8"));
  }

  registerElection(context, createdAt = new Date().toISOString().replace(/\.\d{3}Z$/u, "Z")) {
    validateContext(context);
    const contextJson = canonicalize(context);
    const contextHash = createHash("sha256").update(contextJson, "utf8").digest("hex");
    this.db.prepare(`
      INSERT OR IGNORE INTO elections(
        election_instance_id, crypto_profile, tally_function_id, belenios_election_uuid,
        belenios_election_hash, context_json, context_sha256, election_state, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'OPEN', ?)
    `).run(
      context.election_instance_id,
      context.crypto_profile,
      context.tally_function_id,
      context.belenios_election_uuid,
      context.belenios_election_fingerprint,
      contextJson,
      contextHash,
      createdAt,
    );
    const existing = this.db.prepare("SELECT context_sha256 FROM elections WHERE election_instance_id = ?").get(context.election_instance_id);
    if (!existing || existing.context_sha256 !== contextHash) throw new Error("ELECTION_CONTEXT_CONFLICT");
  }

  getElection(electionInstanceId) {
    return this.db.prepare("SELECT * FROM elections WHERE election_instance_id = ?").get(electionInstanceId);
  }

  recordAudit({ electionInstanceId = null, code, occurredAt, detail = {} }) {
    try {
      this.db.prepare(`
        INSERT INTO security_audit_events(audit_event_id, election_instance_id, event_code, occurred_at, detail_json)
        VALUES (?, ?, ?, ?, ?)
      `).run(randomUUID(), electionInstanceId, code, occurredAt, canonicalize(detail));
    } catch {
      // Audit failure must never disclose the rejected request or transform its public error.
    }
  }

  accept({
    artifact,
    ballotBytes,
    lifecycleHandle,
    credentialExpiresAt,
    idempotencyKeyHash,
    semanticRequestHash,
    receivedAt,
    acceptedAt,
    receiptSigner,
  }) {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const priorKey = this.db.prepare(`
        SELECT semantic_request_hash, response_json FROM idempotency_records
        WHERE election_instance_id = ? AND idempotency_key_hash = ?
      `).get(artifact.election_instance_id, idempotencyKeyHash);
      if (priorKey) {
        if (priorKey.semantic_request_hash !== semanticRequestHash) fail("IDEMPOTENCY_CONFLICT", 409);
        this.db.exec("COMMIT");
        return { receipt: parseRowJson(priorKey.response_json), replay: true, duplicate_digest: false };
      }

      const priorDigest = this.db.prepare(`
        SELECT s.submission_id, s.encrypted_ballot_bytes, s.receipt_json, p.lifecycle_handle
        FROM encrypted_submissions s JOIN private_submission_lifecycle p USING(submission_id)
        WHERE s.election_instance_id = ? AND s.ballot_digest = ?
      `).get(artifact.election_instance_id, artifact.ballot_digest);
      if (priorDigest) {
        const exact = Buffer.from(priorDigest.encrypted_ballot_bytes).equals(Buffer.from(ballotBytes));
        if (!exact || priorDigest.lifecycle_handle !== lifecycleHandle) fail("INVALID_SCOPED_CREDENTIAL", 401);
        const responseJson = priorDigest.receipt_json;
        this.db.prepare(`
          INSERT INTO idempotency_records(
            election_instance_id, idempotency_key_hash, semantic_request_hash,
            submission_id, response_json, created_at
          ) VALUES (?, ?, ?, ?, ?, ?)
        `).run(
          artifact.election_instance_id,
          idempotencyKeyHash,
          semanticRequestHash,
          priorDigest.submission_id,
          responseJson,
          acceptedAt,
        );
        this.db.exec("COMMIT");
        return { receipt: parseRowJson(responseJson), replay: true, duplicate_digest: true };
      }

      const last = this.db.prepare(`
        SELECT ledger_seq, event_hash FROM submission_ledger_events
        WHERE election_instance_id = ? ORDER BY ledger_seq DESC LIMIT 1
      `).get(artifact.election_instance_id);
      const ledgerSeq = (last?.ledger_seq ?? 0) + 1;
      const previousEventHash = last?.event_hash ?? ZERO_HASH;
      const submissionId = randomUUID();
      const ledgerEventId = randomUUID();
      const event = {
        event_version: ACCEPTED_EVENT_VERSION,
        ledger_event_id: ledgerEventId,
        ledger_seq: String(ledgerSeq),
        submission_id: submissionId,
        election_instance_id: artifact.election_instance_id,
        ballot_digest: artifact.ballot_digest,
        accepted_at: acceptedAt,
        previous_event_hash: previousEventHash,
      };
      const eventHash = ledgerEventHash(event);
      const receipt = receiptSigner.issue({
        submission_id: submissionId,
        election_instance_id: artifact.election_instance_id,
        ballot_digest: artifact.ballot_digest,
        accepted_at: acceptedAt,
        ledger_event_id: ledgerEventId,
        ledger_event_hash: eventHash,
        acceptance_claim: "ACCEPTED_NOT_FINAL_NOT_COUNTED",
      });
      const receiptJson = canonicalize(receipt);

      this.db.prepare(`
        INSERT INTO encrypted_submissions(
          submission_id, election_instance_id, ballot_digest, crypto_profile, tally_function_id,
          encrypted_ballot_bytes, upstream_format_version, received_at, accepted_at,
          verification_result, client_crypto_build_id, ledger_event_id, receipt_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PASS_NATIVE_BELENIOS_3.3.0', ?, ?, ?)
      `).run(
        submissionId,
        artifact.election_instance_id,
        artifact.ballot_digest,
        artifact.crypto_profile,
        artifact.tally_function_id,
        Buffer.from(ballotBytes),
        artifact.upstream_ballot_format_version,
        receivedAt,
        acceptedAt,
        artifact.client_crypto_build_id,
        ledgerEventId,
        receiptJson,
      );
      this.db.prepare(`
        INSERT INTO private_submission_lifecycle(
          submission_id, election_instance_id, lifecycle_handle, credential_expires_at, bound_at
        ) VALUES (?, ?, ?, ?, ?)
      `).run(submissionId, artifact.election_instance_id, lifecycleHandle, credentialExpiresAt, acceptedAt);
      this.db.prepare(`
        INSERT INTO submission_ledger_events(
          ledger_event_id, election_instance_id, ledger_seq, submission_id, ballot_digest,
          accepted_at, event_version, previous_event_hash, event_hash, event_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        ledgerEventId,
        artifact.election_instance_id,
        ledgerSeq,
        submissionId,
        artifact.ballot_digest,
        acceptedAt,
        ACCEPTED_EVENT_VERSION,
        previousEventHash,
        eventHash,
        canonicalize(event),
      );
      this.db.prepare(`
        INSERT INTO idempotency_records(
          election_instance_id, idempotency_key_hash, semantic_request_hash,
          submission_id, response_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        artifact.election_instance_id,
        idempotencyKeyHash,
        semanticRequestHash,
        submissionId,
        receiptJson,
        acceptedAt,
      );
      this.db.exec("COMMIT");
      return { receipt, replay: false, duplicate_digest: false };
    } catch (error) {
      try { this.db.exec("ROLLBACK"); } catch { /* transaction already resolved */ }
      throw error;
    }
  }

  lookupStatus(electionInstanceId, ballotDigest) {
    const row = this.db.prepare(`
      SELECT submission_id, ballot_digest, accepted_at, ledger_event_id, receipt_json
      FROM encrypted_submissions WHERE election_instance_id = ? AND ballot_digest = ?
    `).get(electionInstanceId, ballotDigest);
    if (!row) return null;
    const receipt = parseRowJson(row.receipt_json);
    return {
      schema_version: STATUS_SCHEMA,
      election_instance_id: electionInstanceId,
      submission_id: row.submission_id,
      ballot_digest: row.ballot_digest,
      accepted_at: row.accepted_at,
      ledger_event_id: row.ledger_event_id,
      ledger_event_hash: receipt.ledger_event_hash,
      status: "ACCEPTED",
      finality_claim: "NOT_FINAL_NOT_COUNTED",
    };
  }

  privateLifecycleForSubmission(submissionId) {
    return this.db.prepare(`
      SELECT election_instance_id, lifecycle_handle, credential_expires_at, bound_at
      FROM private_submission_lifecycle WHERE submission_id = ?
    `).get(submissionId) ?? null;
  }

  privateLifecycleMembers(electionInstanceId, lifecycleHandle) {
    return this.db.prepare(`
      SELECT submission_id, bound_at FROM private_submission_lifecycle
      WHERE election_instance_id = ? AND lifecycle_handle = ? ORDER BY bound_at, submission_id
    `).all(electionInstanceId, lifecycleHandle);
  }

  exactBallotBytes(electionInstanceId, ballotDigest) {
    const row = this.db.prepare(`
      SELECT encrypted_ballot_bytes FROM encrypted_submissions
      WHERE election_instance_id = ? AND ballot_digest = ?
    `).get(electionInstanceId, ballotDigest);
    return row ? Buffer.from(row.encrypted_ballot_bytes) : null;
  }

  counts(electionInstanceId) {
    const one = (table) => this.db.prepare(`SELECT count(*) AS count FROM ${table} WHERE election_instance_id = ?`).get(electionInstanceId).count;
    return {
      submissions: one("encrypted_submissions"),
      lifecycle_bindings: one("private_submission_lifecycle"),
      ledger_events: one("submission_ledger_events"),
      idempotency_records: one("idempotency_records"),
    };
  }

  checkpoint(electionInstanceId) {
    const row = this.db.prepare(`
      SELECT ledger_seq, event_hash, accepted_at FROM submission_ledger_events
      WHERE election_instance_id = ? ORDER BY ledger_seq DESC LIMIT 1
    `).get(electionInstanceId);
    const count = this.db.prepare("SELECT count(*) AS count FROM submission_ledger_events WHERE election_instance_id = ?").get(electionInstanceId).count;
    return {
      ledger_event_count: String(count),
      ledger_seq: String(row?.ledger_seq ?? 0),
      ledger_event_hash: row?.event_hash ?? ZERO_HASH,
      checkpoint_time: row?.accepted_at ?? this.getElection(electionInstanceId)?.created_at,
    };
  }

  verifyLedger(electionInstanceId, expectedCheckpoint = null) {
    const rows = this.db.prepare(`
      SELECT * FROM submission_ledger_events WHERE election_instance_id = ? ORDER BY ledger_seq
    `).all(electionInstanceId);
    let previous = ZERO_HASH;
    let sequence = 0;
    for (const row of rows) {
      sequence += 1;
      if (row.ledger_seq !== sequence || row.previous_event_hash !== previous) return { valid: false, reason: "CHAIN_ORDER_OR_LINK_MISMATCH" };
      const event = parseRowJson(row.event_json);
      if (canonicalize(event) !== row.event_json) return { valid: false, reason: "NON_CANONICAL_EVENT" };
      if (
        event.ledger_seq !== String(row.ledger_seq)
        || event.ledger_event_id !== row.ledger_event_id
        || event.submission_id !== row.submission_id
        || event.ballot_digest !== row.ballot_digest
        || event.previous_event_hash !== row.previous_event_hash
      ) return { valid: false, reason: "ROW_EVENT_MISMATCH" };
      const computed = ledgerEventHash(event);
      if (computed !== row.event_hash) return { valid: false, reason: "EVENT_HASH_MISMATCH" };
      previous = row.event_hash;
    }
    const checkpoint = this.checkpoint(electionInstanceId);
    if (expectedCheckpoint && (
      checkpoint.ledger_event_count !== expectedCheckpoint.ledger_event_count
      || checkpoint.ledger_event_hash !== expectedCheckpoint.ledger_event_hash
    )) return { valid: false, reason: "CHECKPOINT_CONFLICT", checkpoint };
    return { valid: true, reason: "PASS", checkpoint };
  }

  exportAcceptedManifest(electionInstanceId) {
    const election = this.getElection(electionInstanceId);
    if (!election) return null;
    const digests = this.db.prepare(`
      SELECT ballot_digest FROM encrypted_submissions
      WHERE election_instance_id = ? ORDER BY ballot_digest COLLATE BINARY
    `).all(electionInstanceId).map((row) => row.ballot_digest);
    const checkpoint = this.checkpoint(electionInstanceId);
    const manifest = {
      schema_version: MANIFEST_SCHEMA,
      election_instance_id: electionInstanceId,
      crypto_profile: election.crypto_profile,
      tally_function_id: election.tally_function_id,
      generated_at: checkpoint.checkpoint_time,
      accepted_ballot_digests: digests,
      ledger_checkpoint: {
        ledger_event_count: checkpoint.ledger_event_count,
        ledger_seq: checkpoint.ledger_seq,
        ledger_event_hash: checkpoint.ledger_event_hash,
      },
      semantic_claim: "ACCEPTED_SUBMISSIONS_NOT_FINAL_SET_NOT_COUNTED",
    };
    return { ...manifest, manifest_digest: acceptedManifestDigest(manifest) };
  }

  async backupTo(destinationPath) {
    await backup(this.db, destinationPath);
    return destinationPath;
  }

  close() {
    this.db.close();
  }
}
