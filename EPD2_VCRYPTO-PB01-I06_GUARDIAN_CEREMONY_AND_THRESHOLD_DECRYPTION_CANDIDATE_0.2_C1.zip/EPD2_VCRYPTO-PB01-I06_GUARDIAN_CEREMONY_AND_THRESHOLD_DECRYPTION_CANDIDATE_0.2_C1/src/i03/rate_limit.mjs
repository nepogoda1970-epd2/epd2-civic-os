import { fail } from "./errors.mjs";

export class FixedWindowRateLimiter {
  constructor({ windowMs = 60_000, submissionLimit = 30, lookupLimit = 120, invalidLimit = 20 } = {}) {
    this.windowMs = windowMs;
    this.limits = { submission: submissionLimit, lookup: lookupLimit, invalid: invalidLimit };
    this.buckets = new Map();
  }

  take(key, category, now = Date.now()) {
    const composite = `${category}:${key}`;
    const current = this.buckets.get(composite);
    const limit = this.limits[category];
    if (!current || now - current.started >= this.windowMs) {
      this.buckets.set(composite, { started: now, count: 1 });
      return;
    }
    current.count += 1;
    if (current.count > limit) fail("RATE_LIMITED", 429);
  }
}

export class VerificationSemaphore {
  constructor(limit = 4) {
    this.limit = limit;
    this.active = 0;
    this.queue = [];
  }

  async run(task) {
    if (this.active >= this.limit) await new Promise((resolve) => this.queue.push(resolve));
    this.active += 1;
    try {
      return await task();
    } finally {
      this.active -= 1;
      this.queue.shift()?.();
    }
  }
}
