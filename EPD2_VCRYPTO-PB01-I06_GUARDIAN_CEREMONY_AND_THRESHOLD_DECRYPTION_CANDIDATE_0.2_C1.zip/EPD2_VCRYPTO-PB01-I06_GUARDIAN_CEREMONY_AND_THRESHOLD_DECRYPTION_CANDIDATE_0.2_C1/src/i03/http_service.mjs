import { createServer } from "node:http";
import { canonicalize } from "../i02_accepted/shared/profile.mjs";
import {
  MAX_REQUEST_BYTES,
  REQUEST_TIMEOUT_MS,
} from "./constants.mjs";
import { fail, publicError } from "./errors.mjs";
import { idempotencyKeyHash, submissionRequestHash } from "./hashes.mjs";
import { FixedWindowRateLimiter, VerificationSemaphore } from "./rate_limit.mjs";
import { parseStrictJson } from "./strict_json.mjs";
import {
  decodeAndInspectBallot,
  recomputeDigest,
  requireCanonicalArtifact,
  validateArtifactSchema,
  validateElectionBinding,
} from "./validation.mjs";

function isoSecond(clock) {
  return clock().toISOString().replace(/\.\d{3}Z$/u, "Z");
}

async function readBody(request, limit, timeoutMs) {
  const contentLength = Number(request.headers["content-length"] ?? "0");
  if (Number.isFinite(contentLength) && contentLength > limit) fail("REQUEST_TOO_LARGE", 413);
  const chunks = [];
  let size = 0;
  const timer = setTimeout(() => request.destroy(new Error("request timeout")), timeoutMs);
  try {
    for await (const chunk of request) {
      size += chunk.length;
      if (size > limit) fail("REQUEST_TOO_LARGE", 413);
      chunks.push(chunk);
    }
  } catch (error) {
    if (error instanceof Error && error.message === "REQUEST_TOO_LARGE") throw error;
    fail("INVALID_SUBMISSION_SCHEMA");
  } finally {
    clearTimeout(timer);
  }
  return Buffer.concat(chunks);
}

function headers(allowedOrigin) {
  return {
    "access-control-allow-origin": allowedOrigin,
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-allow-headers": "authorization, content-type, idempotency-key",
    "access-control-max-age": "600",
    "cache-control": "no-store",
    "content-type": "application/json; charset=utf-8",
    "cross-origin-resource-policy": "same-site",
    "referrer-policy": "no-referrer",
    "x-content-type-options": "nosniff",
  };
}

function send(response, status, body, allowedOrigin) {
  if (response.destroyed) return;
  response.writeHead(status, headers(allowedOrigin));
  response.end(canonicalize(body));
}

function clientKey(request) {
  return request.socket.remoteAddress || "unknown";
}

export function createI03Service({
  store,
  electionFixtures,
  verifier,
  credentialAuthority,
  receiptSigner,
  idempotencySecret,
  allowedOrigin,
  clock = () => new Date(),
  bodyLimit = MAX_REQUEST_BYTES,
  requestTimeoutMs = REQUEST_TIMEOUT_MS,
  limiter = new FixedWindowRateLimiter(),
  verificationSemaphore = new VerificationSemaphore(4),
  failpoint = null,
  developmentHttp = false,
}) {
  if (!developmentHttp && !allowedOrigin.startsWith("https://")) throw new Error("HTTPS_REQUIRED");
  if (!Buffer.isBuffer(idempotencySecret) || idempotencySecret.length < 32) throw new Error("idempotencySecret must be at least 32 bytes");

  return createServer(async (request, response) => {
    const requestOrigin = request.headers.origin;
    const route = request.url || "";
    const now = isoSecond(clock);
    let routeElectionId = null;
    try {
      if (requestOrigin !== allowedOrigin) fail("ORIGIN_NOT_ALLOWED", 403);
      if (request.method === "OPTIONS") return send(response, 204, {}, allowedOrigin);

      let match = /^\/v1\/elections\/(ei1_[0-9a-f]{32})\/encrypted-ballots$/u.exec(route);
      if (match && request.method === "POST") {
        routeElectionId = match[1];
        limiter.take(clientKey(request), "submission");
        const fixture = electionFixtures.get(routeElectionId);
        if (!fixture || !await store.getElection(routeElectionId)) fail("UNKNOWN_ELECTION", 404);
        if (request.headers["content-type"] !== "application/json") fail("INVALID_SUBMISSION_SCHEMA");
        const idempotencyKey = request.headers["idempotency-key"];
        if (typeof idempotencyKey !== "string" || !/^[A-Za-z0-9._~-]{16,128}$/u.test(idempotencyKey)) fail("INVALID_SUBMISSION_SCHEMA");

        const receivedAt = now;
        const body = await readBody(request, bodyLimit, requestTimeoutMs);
        const parsed = parseStrictJson(body);
        const artifact = validateArtifactSchema(parsed.value);
        requireCanonicalArtifact(parsed.text, artifact);
        validateElectionBinding({ artifact, context: fixture.context, routeElectionId });
        const ballotBytes = decodeAndInspectBallot(artifact, fixture.context);
        recomputeDigest(artifact, fixture.context);
        await verificationSemaphore.run(() => verifier.verify({ electionDir: fixture.electionDir, ballotBytes }));
        await failpoint?.("after_crypto_before_transaction");
        const authorization = credentialAuthority.verify(request.headers.authorization, routeElectionId, clock());
        if (!authorization.revote_allowed) fail("INVALID_SCOPED_CREDENTIAL", 401);
        const keyHash = idempotencyKeyHash(idempotencySecret, routeElectionId, idempotencyKey);
        const semanticHash = submissionRequestHash({ artifact, lifecycle_handle: authorization.lifecycle_handle });
        const acceptedAt = isoSecond(clock);
        const result = await store.accept({
          artifact,
          ballotBytes,
          lifecycleHandle: authorization.lifecycle_handle,
          credentialExpiresAt: authorization.expires_at,
          idempotencyKeyHash: keyHash,
          semanticRequestHash: semanticHash,
          receivedAt,
          acceptedAt,
          receiptSigner,
        });
        await store.recordAudit({ electionInstanceId: routeElectionId, code: "ACCEPTED_SUBMISSION", occurredAt: acceptedAt, detail: { ballot_digest: artifact.ballot_digest } });
        await failpoint?.("after_commit_before_response");
        return send(response, result.replay ? 200 : 201, result.receipt, allowedOrigin);
      }

      match = /^\/v1\/elections\/(ei1_[0-9a-f]{32})\/ballots\/([0-9a-f]{64})$/u.exec(route);
      if (match && request.method === "GET") {
        routeElectionId = match[1];
        limiter.take(clientKey(request), "lookup");
        if (!await store.getElection(routeElectionId)) fail("UNKNOWN_ELECTION", 404);
        const status = await store.lookupStatus(routeElectionId, match[2]);
        if (!status) fail("NOT_FOUND", 404);
        return send(response, 200, status, allowedOrigin);
      }

      match = /^\/v1\/elections\/(ei1_[0-9a-f]{32})\/accepted-submission-manifest$/u.exec(route);
      if (match && request.method === "GET") {
        routeElectionId = match[1];
        limiter.take(clientKey(request), "lookup");
        const manifest = await store.exportAcceptedManifest(routeElectionId);
        if (!manifest) fail("UNKNOWN_ELECTION", 404);
        return send(response, 200, manifest, allowedOrigin);
      }

      if (request.method === "DELETE" || request.method === "PATCH" || request.method === "PUT") fail("METHOD_NOT_ALLOWED", 405);
      fail("NOT_FOUND", 404);
    } catch (error) {
      const exposed = publicError(error);
      try { limiter.take(clientKey(request), "invalid"); } catch { /* current response remains stable */ }
      await store.recordAudit({
        electionInstanceId: routeElectionId,
        code: exposed.code,
        occurredAt: now,
        detail: { route_class: route.includes("encrypted-ballots") ? "submission" : "public-read" },
      });
      return send(response, exposed.status, { error: exposed.code }, allowedOrigin);
    }
  });
}

export async function startI03Service(options) {
  const server = createI03Service(options);
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port ?? 32902, options.host ?? "127.0.0.1", resolve);
  });
  return server;
}
