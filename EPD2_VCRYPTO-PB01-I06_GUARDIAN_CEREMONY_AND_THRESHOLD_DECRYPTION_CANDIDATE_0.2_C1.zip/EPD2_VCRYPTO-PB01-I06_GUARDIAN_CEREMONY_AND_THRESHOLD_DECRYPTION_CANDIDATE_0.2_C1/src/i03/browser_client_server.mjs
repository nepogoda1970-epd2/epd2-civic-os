import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join, normalize } from "node:path";
import { canonicalize, validateContext, validateHandoff } from "../i02_accepted/shared/profile.mjs";

const mediaTypes = new Map([
  [".html", "text/html; charset=utf-8"],
  [".mjs", "text/javascript; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".css", "text/css; charset=utf-8"],
  [".wasm", "application/wasm"],
]);

function securityHeaders(receiverOrigin, contentType) {
  return {
    "cache-control": "no-store",
    "content-security-policy": `default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self'; connect-src 'self' ${receiverOrigin}; img-src 'self'; font-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'`,
    "content-type": contentType,
    "cross-origin-opener-policy": "same-origin",
    "cross-origin-resource-policy": "same-origin",
    "permissions-policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
    "referrer-policy": "no-referrer",
    "x-content-type-options": "nosniff",
    "x-frame-options": "DENY",
  };
}

function sendJson(response, status, value, receiverOrigin) {
  response.writeHead(status, securityHeaders(receiverOrigin, "application/json; charset=utf-8"));
  response.end(canonicalize(value));
}

export function createI03BrowserClientServer({ clientDir, context, handoff, submissionAuthorization }) {
  validateContext(context);
  validateHandoff(handoff);
  const receiverOrigin = new URL(context.receiver_url).origin;
  return createServer(async (request, response) => {
    try {
      if (request.method === "GET" && request.url === "/fixture/context.json") return sendJson(response, 200, context, receiverOrigin);
      if (request.method === "GET" && request.url === "/fixture/handoff.json") return sendJson(response, 200, handoff, receiverOrigin);
      if (request.method === "GET" && request.url === "/fixture/i03-authorization.json") return sendJson(response, 200, submissionAuthorization, receiverOrigin);
      if (request.method === "POST") return sendJson(response, 404, { error: "NOT_FOUND" }, receiverOrigin);
      if (request.method === "GET") {
        const requested = request.url === "/" ? "index.html" : (request.url || "").slice(1);
        const safe = normalize(requested).replace(/^(\.\.(\/|\\|$))+/u, "");
        if (!safe || safe.includes("..") || !mediaTypes.has(extname(safe))) return sendJson(response, 404, { error: "NOT_FOUND" }, receiverOrigin);
        const bytes = await readFile(join(clientDir, safe));
        response.writeHead(200, securityHeaders(receiverOrigin, mediaTypes.get(extname(safe))));
        return response.end(bytes);
      }
      return sendJson(response, 404, { error: "NOT_FOUND" }, receiverOrigin);
    } catch {
      return sendJson(response, 422, { error: "INVALID_ELECTION_CONTEXT" }, receiverOrigin);
    }
  });
}

export async function startI03BrowserClientServer(options) {
  const server = createI03BrowserClientServer(options);
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(options.port ?? 32901, options.host ?? "127.0.0.1", resolve);
  });
  return server;
}
