import { createPublicKey, sign, verify } from "node:crypto";
import { canonicalBytes } from "../i02_accepted/shared/profile.mjs";
import { DOMAIN_RECEIPT, RECEIPT_PROFILE } from "./constants.mjs";

function signingBytes(body) {
  return Buffer.concat([Buffer.from(DOMAIN_RECEIPT, "ascii"), Buffer.from([0]), Buffer.from(canonicalBytes(body))]);
}

export class ReceiptSigner {
  constructor({ privateKey, keyId }) {
    this.privateKey = privateKey;
    this.publicKey = createPublicKey(privateKey);
    this.keyId = keyId;
  }

  issue(body) {
    const signedBody = { receipt_profile: RECEIPT_PROFILE, receipt_key_id: this.keyId, ...body };
    return { ...signedBody, signature: sign(null, signingBytes(signedBody), this.privateKey).toString("base64url") };
  }

  exportPublicKeyPem() {
    return this.publicKey.export({ type: "spki", format: "pem" });
  }
}

export function verifyReceipt(receipt, publicKey) {
  const { signature, ...body } = receipt;
  return typeof signature === "string" && verify(null, signingBytes(body), publicKey, Buffer.from(signature, "base64url"));
}
