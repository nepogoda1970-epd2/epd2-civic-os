import { ERROR_CODES } from "./constants.mjs";

const allowed = new Set(ERROR_CODES);

export class I03Error extends Error {
  constructor(code, status = 422) {
    super(code);
    this.name = "I03Error";
    this.code = code;
    this.status = status;
  }
}

export function fail(code, status = 422) {
  throw new I03Error(code, status);
}

export function publicError(error) {
  if (error instanceof I03Error && allowed.has(error.code)) return error;
  const message = error instanceof Error ? error.message : String(error);
  if (allowed.has(message)) return new I03Error(message, message === "IDEMPOTENCY_CONFLICT" ? 409 : 422);
  return new I03Error("SUBMISSION_STORAGE_FAILED", 503);
}
