export const I03_SCHEMA_VERSION = "epd2.pb01.i03/1";
export const ACCEPTED_EVENT_VERSION = "epd2.pb01.submission-accepted/1";
export const RECEIPT_PROFILE = "epd2.pb01.submission-receipt.ed25519/1";
export const STATUS_SCHEMA = "epd2.pb01.accepted-submission-status/1";
export const MANIFEST_SCHEMA = "epd2.pb01.accepted-submission-manifest/1";
export const AUTH_SCHEMA = "epd2.pb01.i03-submission-authorization/1";
export const AUTH_KIND = "epd2.pb01.scoped-submission-capability/1";

export const DOMAIN_LEDGER_EVENT = "epd2.pb01.submission-ledger-event.v1";
export const DOMAIN_ACCEPTED_MANIFEST = "epd2.pb01.accepted-submission-manifest.v1";
export const DOMAIN_RECEIPT = "epd2.pb01.submission-receipt.v1";
export const DOMAIN_AUTH_CAPABILITY = "epd2.pb01.submission-authorization.v1";
export const DOMAIN_LIFECYCLE_HANDLE = "epd2.pb01.private-lifecycle-handle.v1";
export const DOMAIN_IDEMPOTENCY_KEY = "epd2.pb01.idempotency-key.v1";
export const DOMAIN_REQUEST_HASH = "epd2.pb01.submission-request.v1";

export const ZERO_HASH = "0".repeat(64);
export const MAX_REQUEST_BYTES = 1_500_000;
export const MAX_BALLOT_BYTES = 1_048_576;
export const MAX_JSON_DEPTH = 32;
export const REQUEST_TIMEOUT_MS = 15_000;
export const VERIFY_TIMEOUT_MS = 120_000;

export const ERROR_CODES = Object.freeze([
  "INVALID_SUBMISSION_SCHEMA",
  "UNSUPPORTED_CRYPTO_PROFILE",
  "UNSUPPORTED_TALLY_FUNCTION",
  "UNKNOWN_ELECTION",
  "FOREIGN_ELECTION_BALLOT",
  "BALLOT_DIGEST_MISMATCH",
  "INVALID_ENCRYPTED_BALLOT",
  "INVALID_SCOPED_CREDENTIAL",
  "EXPIRED_SCOPED_CREDENTIAL",
  "IDEMPOTENCY_CONFLICT",
  "SUBMISSION_STORAGE_FAILED",
  "REQUEST_TOO_LARGE",
  "RATE_LIMITED",
  "ORIGIN_NOT_ALLOWED",
  "NOT_FOUND",
  "METHOD_NOT_ALLOWED",
]);
