# Belenios Homomorphic Aggregation

The producer does not implement ElGamal/group mathematics. `BeleniosHomomorphicAggregator` adds exact canonical-final ballot bytes to a temporary copy of the accepted `.bel` archive and invokes pinned upstream `belenios-tool 3.3.0 election compute-encrypted-tally`. The exact first output line is the aggregate ciphertext serialization and is persisted/digested without normalization. `BELENIOS CRYPTO PATCH COUNT = 0`; the tool is byte-identical to I04 evidence.

The empty final set is defined by upstream behavior: the identity aggregate is accepted and vectorized as I05-V04.
