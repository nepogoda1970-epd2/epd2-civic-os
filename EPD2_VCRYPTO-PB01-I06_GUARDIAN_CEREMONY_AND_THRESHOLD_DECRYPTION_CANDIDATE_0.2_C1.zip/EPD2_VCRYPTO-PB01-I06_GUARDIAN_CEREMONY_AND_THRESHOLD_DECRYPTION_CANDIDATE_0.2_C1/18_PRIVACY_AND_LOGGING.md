# Privacy and logging

Security audit records contain only stable error/event code, optional election
scope, time and a safe route class or accepted digest. They exclude request
bodies, selection, ciphertext internals, capability token, Belenios private
credential, randomness, private keys and lifecycle handle.

Automated storage inspection confirms the encrypted submission schema has no
identity/plaintext/randomness columns and that accepted BLOB/audit/private rows
do not contain known fixture plaintext or credentials. Election option labels
remain part of the governed public election definition, not a recorded vote.
