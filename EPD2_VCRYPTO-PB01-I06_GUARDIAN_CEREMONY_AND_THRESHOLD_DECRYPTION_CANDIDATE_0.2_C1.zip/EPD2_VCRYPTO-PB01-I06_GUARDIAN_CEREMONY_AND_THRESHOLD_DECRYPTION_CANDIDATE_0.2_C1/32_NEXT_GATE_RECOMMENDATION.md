# Next gate recommendation

Authorize only:

`PB01-I04 — Revote Lifecycle & Canonical Final Set`

I04 must read, never rewrite, the accepted I03 submissions and private lifecycle
relations. It must add closure and latest-valid resolution, then derive the
deterministic effective set, `CSet_final`, `cset_root`, `FinalSetEnvelope` and
`F_final` under unchanged I01 semantics.

I03 does not authorize tally, guardian/decryption work, TFCAR/PRDCI or any
production/binding election.
