import { createHash, verify as verifySignature } from "node:crypto";

const DOMAIN = Object.freeze({
  acceptedManifest: "epd2.pb01.accepted-submission-manifest.v1",
  closureAuthorization: "epd2.pb01.closure-authorization.v1",
  closureAuthorizationEvidence: "epd2.pb01.closure-authorization-evidence.v1",
  closureCheckpoint: "epd2.pb01.closure-ledger-checkpoint.v1",
  closureRecord: "epd2.pb01.closure-record.v1",
  csetRoot: "epd2.pb01.cset-root.v1",
  finalSetEnvelope: "epd2.pb01.final-set-envelope.v1",
  fFinal: "epd2.pb01.f-final.v1",
  publicEvidence: "epd2.pb01.final-set-evidence.v1",
});

function canonicalize(value) {
  if (value === null) return "null";
  if (value === true) return "true";
  if (value === false) return "false";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") throw new Error("VERIFIER_B_NUMBERS_PROHIBITED");
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(",")}]`;
  if (value && typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype) {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalize(value[key])}`).join(",")}}`;
  }
  throw new Error("VERIFIER_B_UNSUPPORTED_JSON");
}

function hash(tag, value) {
  return createHash("sha256").update(tag, "ascii").update(Buffer.from([0])).update(canonicalize(value), "utf8").digest("hex");
}

function fail() {
  throw new Error("VERIFIER_B_I04_COMPOSITION_FAILURE");
}

function same(left, right) {
  return canonicalize(left) === canonicalize(right);
}

function orderedUniqueHex(values) {
  if (!Array.isArray(values)) fail();
  for (let index = 0; index < values.length; index += 1) {
    if (!/^[0-9a-f]{64}$/u.test(values[index])) fail();
    if (index && Buffer.from(values[index - 1], "hex").compare(Buffer.from(values[index], "hex")) >= 0) fail();
  }
}

export function verifyI04PublicEvidence(evidence, { closurePublicKeys = new Map() } = {}) {
  try {
    if (evidence.schema_version !== "epd2.pb01.final-set-evidence/1") fail();
    const { public_evidence_digest: publicDigest, ...publicBody } = evidence;
    if (hash(DOMAIN.publicEvidence, publicBody) !== publicDigest) fail();

    const auth = evidence.closure_authorization;
    const { authorization_evidence_digest: authDigest, ...authBody } = auth;
    if (hash(DOMAIN.closureAuthorizationEvidence, authBody) !== authDigest) fail();
    const key = closurePublicKeys.get(auth.key_id);
    if (!key || auth.algorithm !== "Ed25519") fail();
    const signature = Buffer.from(auth.signature_base64url, "base64url");
    const signingBytes = Buffer.concat([
      Buffer.from(DOMAIN.closureAuthorization, "ascii"),
      Buffer.from([0]),
      Buffer.from(canonicalize(auth.statement), "utf8"),
    ]);
    if (signature.length !== 64 || !verifySignature(null, signingBytes, key, signature)) fail();
    if (evidence.closure_record.authorization_evidence_digest !== authDigest) fail();

    const checkpoint = evidence.closure_ledger_checkpoint;
    if (checkpoint.ledger_event_count !== checkpoint.ledger_seq) fail();
    if (hash(DOMAIN.closureCheckpoint, checkpoint) !== evidence.closure_record.closure_checkpoint_digest) fail();
    if (!same(checkpoint, auth.statement.closure_ledger_checkpoint)) fail();
    if (auth.statement.revote_policy_version !== "epd2.pb01.revote.latest-valid.v1") fail();
    if (auth.statement.election_instance_id !== evidence.election_instance_id) fail();

    const { manifest_digest: manifestDigest, ...manifestBody } = evidence.accepted_manifest_at_closure;
    if (hash(DOMAIN.acceptedManifest, manifestBody) !== manifestDigest) fail();
    if (manifestDigest !== checkpoint.accepted_manifest_digest) fail();
    const accepted = new Set(manifestBody.accepted_ballot_digests);
    if (accepted.size !== manifestBody.accepted_ballot_digests.length) fail();

    const cset = evidence.cset_final;
    orderedUniqueHex(cset.ordered_ballot_digests);
    if (!cset.ordered_ballot_digests.every((digest) => accepted.has(digest))) fail();
    const csetRoot = hash(DOMAIN.csetRoot, cset);
    if (csetRoot !== evidence.cset_root) fail();

    const closureDigest = hash(DOMAIN.closureRecord, evidence.closure_record);
    if (closureDigest !== evidence.closure_record_digest) fail();
    const envelope = evidence.final_set_envelope;
    if (!same(envelope.ordered_ballot_digests, cset.ordered_ballot_digests)) fail();
    if (envelope.cset_root !== csetRoot || envelope.closure_record_digest !== closureDigest) fail();
    if (hash(DOMAIN.finalSetEnvelope, envelope) !== evidence.final_set_envelope_digest) fail();
    if (hash(DOMAIN.fFinal, envelope) !== evidence.f_final) fail();
    if (evidence.revote_policy_version !== auth.statement.revote_policy_version) fail();
    if (JSON.stringify(evidence).includes("lifecycle_handle")) fail();
    return {
      status: "PASS",
      election_instance_id: evidence.election_instance_id,
      effective_ballot_count: String(cset.ordered_ballot_digests.length),
      cset_root: csetRoot,
      f_final: evidence.f_final,
      public_evidence_digest: publicDigest,
    };
  } catch (error) {
    if (error?.message === "VERIFIER_B_I04_COMPOSITION_FAILURE") throw error;
    fail();
  }
}

export { canonicalize as verifierBCanonicalize };
