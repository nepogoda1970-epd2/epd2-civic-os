package main

import (
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"unicode/utf16"
)

const (
	dAcceptedManifest    = "epd2.pb01.accepted-submission-manifest.v1"
	dClosureAuth         = "epd2.pb01.closure-authorization.v1"
	dClosureAuthEvidence = "epd2.pb01.closure-authorization-evidence.v1"
	dCheckpoint          = "epd2.pb01.closure-ledger-checkpoint.v1"
	dClosureRecord       = "epd2.pb01.closure-record.v1"
	dCSetRoot            = "epd2.pb01.cset-root.v1"
	dEnvelope            = "epd2.pb01.final-set-envelope.v1"
	dFFinal              = "epd2.pb01.f-final.v1"
	dPublicEvidence      = "epd2.pb01.final-set-evidence.v1"

	schemaPublic        = "epd2.pb01.final-set-evidence/1"
	schemaAuthEvidence  = "epd2.pb01.closure-authorization-evidence/1"
	schemaAuthStatement = "epd2.pb01.closure-authorization-statement/1"
	schemaCheckpoint    = "epd2.pb01.closure-ledger-checkpoint/1"
	schemaManifest      = "epd2.pb01.accepted-submission-manifest/1"
	schemaClosureRecord = "epd2.pb01.closure-record/1"
	schemaCSet          = "epd2.pb01.cset-final/1"
	schemaEnvelope      = "epd2.pb01.final-set-envelope/1"
	cryptoProfile       = "epd2.belenios-homomorphic/1"
	canonPolicy         = "epd2.pb01.jcs-rfc8785-restricted/1"
	revotePolicy        = "epd2.pb01.revote.latest-valid.v1"
	finalizationProcess = "epd2.pb01.finalization-process.i04.v1"
	dTallyInput         = "epd2.pb01.tally-input.v1"
	dAggregate          = "epd2.pb01.aggregate-ciphertext.v1"
	dTallyRecord        = "epd2.pb01.homomorphic-tally-record.v1"
	dTallyEvidence      = "epd2.pb01.tally-evidence.v1"
	dBallotDigest       = "epd2.pb01.ballot-digest.v1"
	schemaTallyInput    = "epd2.pb01.tally-input-manifest/1"
	schemaTallyRecord   = "epd2.pb01.homomorphic-tally-record/1"
	schemaTallyEvidence = "epd2.pb01.tally-evidence-bundle/1"
)

type result struct {
	Status                               string `json:"status"`
	ElectionInstanceID                   string `json:"election_instance_id"`
	EffectiveBallotCount                 string `json:"effective_ballot_count"`
	CSetRoot                             string `json:"cset_root"`
	FFinal                               string `json:"f_final"`
	PublicEvidenceDigest                 string `json:"public_evidence_digest"`
	CanonicalPublicEvidenceUTF8Base64URL string `json:"canonical_public_evidence_utf8_base64url"`
}

type vectorReport struct {
	Case                 string `json:"case"`
	Status               string `json:"status"`
	ByteForByteAgreement bool   `json:"byte_for_byte_agreement"`
	CSetRoot             string `json:"cset_root"`
	FFinal               string `json:"f_final"`
	PublicEvidenceDigest string `json:"public_evidence_digest"`
}

type mutationReport struct {
	Name     string `json:"name"`
	Expected string `json:"expected"`
	Observed string `json:"observed"`
}

type report struct {
	SchemaVersion        string           `json:"schema_version"`
	Status               string           `json:"status"`
	Implementation       string           `json:"implementation"`
	Vectors              []vectorReport   `json:"vectors"`
	Mutations            []mutationReport `json:"mutations"`
	ProducerCodeImports  bool             `json:"producer_code_imports"`
	ByteForByteAgreement bool             `json:"byte_for_byte_agreement"`
}

func fail(msg string) error { return errors.New(msg) }

func parseJSON(data []byte) (any, error) {
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	var v any
	if err := dec.Decode(&v); err != nil {
		return nil, err
	}
	var extra any
	if dec.Decode(&extra) == nil {
		return nil, fail("trailing JSON value")
	}
	if err := rejectNumbers(v); err != nil {
		return nil, err
	}
	return v, nil
}

func rejectNumbers(v any) error {
	switch x := v.(type) {
	case json.Number, float64:
		return fail("numbers prohibited by PB01 restricted canonicalization")
	case []any:
		for _, e := range x {
			if err := rejectNumbers(e); err != nil {
				return err
			}
		}
	case map[string]any:
		for _, e := range x {
			if err := rejectNumbers(e); err != nil {
				return err
			}
		}
	}
	return nil
}

func utf16Less(a, b string) bool {
	aa, bb := utf16.Encode([]rune(a)), utf16.Encode([]rune(b))
	n := len(aa)
	if len(bb) < n {
		n = len(bb)
	}
	for i := 0; i < n; i++ {
		if aa[i] != bb[i] {
			return aa[i] < bb[i]
		}
	}
	return len(aa) < len(bb)
}

func appendJSONString(buf *bytes.Buffer, s string) {
	buf.WriteByte('"')
	for _, r := range s {
		switch r {
		case '"':
			buf.WriteString("\\\"")
		case '\\':
			buf.WriteString("\\\\")
		case '\b':
			buf.WriteString("\\b")
		case '\f':
			buf.WriteString("\\f")
		case '\n':
			buf.WriteString("\\n")
		case '\r':
			buf.WriteString("\\r")
		case '\t':
			buf.WriteString("\\t")
		default:
			if r >= 0 && r <= 0x1f {
				fmt.Fprintf(buf, "\\u%04x", r)
			} else {
				buf.WriteRune(r)
			}
		}
	}
	buf.WriteByte('"')
}

func canonical(v any) ([]byte, error) {
	var buf bytes.Buffer
	var rec func(any) error
	rec = func(x any) error {
		switch t := x.(type) {
		case nil:
			buf.WriteString("null")
		case bool:
			if t {
				buf.WriteString("true")
			} else {
				buf.WriteString("false")
			}
		case string:
			appendJSONString(&buf, t)
		case []any:
			buf.WriteByte('[')
			for i, e := range t {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := rec(e); err != nil {
					return err
				}
			}
			buf.WriteByte(']')
		case map[string]any:
			keys := make([]string, 0, len(t))
			for k := range t {
				keys = append(keys, k)
			}
			sort.Slice(keys, func(i, j int) bool { return utf16Less(keys[i], keys[j]) })
			buf.WriteByte('{')
			for i, k := range keys {
				if i > 0 {
					buf.WriteByte(',')
				}
				appendJSONString(&buf, k)
				buf.WriteByte(':')
				if err := rec(t[k]); err != nil {
					return err
				}
			}
			buf.WriteByte('}')
		default:
			return fail("unsupported JSON type / number prohibited")
		}
		return nil
	}
	if err := rec(v); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func domainHash(tag string, v any) (string, error) {
	c, err := canonical(v)
	if err != nil {
		return "", err
	}
	h := sha256.New()
	h.Write([]byte(tag))
	h.Write([]byte{0})
	h.Write(c)
	return hex.EncodeToString(h.Sum(nil)), nil
}

func obj(v any) (map[string]any, error) {
	x, ok := v.(map[string]any)
	if !ok {
		return nil, fail("object required")
	}
	return x, nil
}
func arr(v any) ([]any, error) {
	x, ok := v.([]any)
	if !ok {
		return nil, fail("array required")
	}
	return x, nil
}
func str(m map[string]any, k string) (string, error) {
	x, ok := m[k].(string)
	if !ok {
		return "", fail("string required: " + k)
	}
	return x, nil
}
func eq(a, b any) bool {
	ca, ea := canonical(a)
	cb, eb := canonical(b)
	return ea == nil && eb == nil && bytes.Equal(ca, cb)
}
func clone(v any) any { b, _ := json.Marshal(v); x, _ := parseJSON(b); return x }
func without(m map[string]any, key string) map[string]any {
	n := make(map[string]any, len(m)-1)
	for k, v := range m {
		if k != key {
			n[k] = v
		}
	}
	return n
}
func isHex64(s string) bool {
	if len(s) != 64 {
		return false
	}
	_, err := hex.DecodeString(s)
	if err != nil {
		return false
	}
	return strings.ToLower(s) == s
}
func requireSchema(m map[string]any, want string) error {
	s, e := str(m, "schema_version")
	if e != nil || s != want {
		return fail("schema mismatch: " + want)
	}
	return nil
}
func requireSameString(a map[string]any, ak string, b map[string]any, bk string) error {
	x, e := str(a, ak)
	if e != nil {
		return e
	}
	y, e := str(b, bk)
	if e != nil {
		return e
	}
	if x != y {
		return fail("linkage mismatch: " + ak + "/" + bk)
	}
	return nil
}

func verifyOrderedHex(v any) ([]string, error) {
	a, err := arr(v)
	if err != nil {
		return nil, err
	}
	out := make([]string, len(a))
	var prev string
	for i, e := range a {
		s, ok := e.(string)
		if !ok || !isHex64(s) {
			return nil, fail("invalid digest")
		}
		if i > 0 && prev >= s {
			return nil, fail("noncanonical digest order or duplicate")
		}
		out[i] = s
		prev = s
	}
	return out, nil
}

func containsLifecycleHandle(v any) bool {
	switch x := v.(type) {
	case map[string]any:
		for k, e := range x {
			if k == "lifecycle_handle" || containsLifecycleHandle(e) {
				return true
			}
		}
	case []any:
		for _, e := range x {
			if containsLifecycleHandle(e) {
				return true
			}
		}
	}
	return false
}

func verifyEvidence(evidence any, expectedKeyID string, publicKey ed25519.PublicKey) (result, error) {
	e, err := obj(evidence)
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(e, schemaPublic); err != nil {
		return result{}, err
	}
	if containsLifecycleHandle(e) {
		return result{}, fail("private lifecycle handle present in public evidence")
	}
	eid, err := str(e, "election_instance_id")
	if err != nil {
		return result{}, err
	}
	if p, _ := str(e, "crypto_profile"); p != cryptoProfile {
		return result{}, fail("crypto profile mismatch")
	}
	if r, _ := str(e, "revote_policy_version"); r != revotePolicy {
		return result{}, fail("revote policy mismatch")
	}
	tally, err := str(e, "tally_function_id")
	if err != nil {
		return result{}, err
	}
	if tally != "epd2.pb01.tally.single-choice.v1" && tally != "epd2.pb01.tally.approval.v1" {
		return result{}, fail("unknown tally function")
	}

	publicDigest, err := str(e, "public_evidence_digest")
	if err != nil || !isHex64(publicDigest) {
		return result{}, fail("invalid public evidence digest")
	}
	got, err := domainHash(dPublicEvidence, without(e, "public_evidence_digest"))
	if err != nil || got != publicDigest {
		return result{}, fail("public evidence digest mismatch")
	}

	auth, err := obj(e["closure_authorization"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(auth, schemaAuthEvidence); err != nil {
		return result{}, err
	}
	if keyID, _ := str(auth, "key_id"); keyID != expectedKeyID {
		return result{}, fail("unknown closure key")
	}
	if alg, _ := str(auth, "algorithm"); alg != "Ed25519" {
		return result{}, fail("closure algorithm mismatch")
	}
	authDigest, err := str(auth, "authorization_evidence_digest")
	if err != nil {
		return result{}, err
	}
	got, err = domainHash(dClosureAuthEvidence, without(auth, "authorization_evidence_digest"))
	if err != nil || got != authDigest {
		return result{}, fail("authorization evidence digest mismatch")
	}
	statement, err := obj(auth["statement"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(statement, schemaAuthStatement); err != nil {
		return result{}, err
	}
	if x, _ := str(statement, "election_instance_id"); x != eid {
		return result{}, fail("authorization election mismatch")
	}
	if x, _ := str(statement, "revote_policy_version"); x != revotePolicy {
		return result{}, fail("signed revote policy mismatch")
	}
	if x, _ := str(statement, "finalization_process_id"); x != finalizationProcess {
		return result{}, fail("finalization process mismatch")
	}
	sigText, err := str(auth, "signature_base64url")
	if err != nil {
		return result{}, err
	}
	sig, err := base64.RawURLEncoding.DecodeString(sigText)
	if err != nil || len(sig) != ed25519.SignatureSize {
		return result{}, fail("bad closure signature encoding")
	}
	stmtCanonical, err := canonical(statement)
	if err != nil {
		return result{}, err
	}
	msg := append(append([]byte(dClosureAuth), 0), stmtCanonical...)
	if !ed25519.Verify(publicKey, msg, sig) {
		return result{}, fail("Ed25519 closure signature invalid")
	}

	checkpoint, err := obj(e["closure_ledger_checkpoint"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(checkpoint, schemaCheckpoint); err != nil {
		return result{}, err
	}
	if x, _ := str(checkpoint, "election_instance_id"); x != eid {
		return result{}, fail("checkpoint election mismatch")
	}
	lec, _ := str(checkpoint, "ledger_event_count")
	ls, _ := str(checkpoint, "ledger_seq")
	if lec != ls {
		return result{}, fail("checkpoint count/seq mismatch")
	}
	if !eq(checkpoint, statement["closure_ledger_checkpoint"]) {
		return result{}, fail("signed checkpoint mismatch")
	}
	checkpointDigest, err := domainHash(dCheckpoint, checkpoint)
	if err != nil {
		return result{}, err
	}

	closure, err := obj(e["closure_record"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(closure, schemaClosureRecord); err != nil {
		return result{}, err
	}
	if x, _ := str(closure, "election_instance_id"); x != eid {
		return result{}, fail("closure election mismatch")
	}
	if x, _ := str(closure, "closure_state"); x != "closed" {
		return result{}, fail("not closed")
	}
	if x, _ := str(closure, "closure_checkpoint_digest"); x != checkpointDigest {
		return result{}, fail("closure checkpoint digest mismatch")
	}
	if x, _ := str(closure, "authorization_evidence_digest"); x != authDigest {
		return result{}, fail("closure authorization digest linkage mismatch")
	}
	if x, _ := str(closure, "finalization_policy_version"); x != revotePolicy {
		return result{}, fail("closure policy mismatch")
	}
	if x, _ := str(closure, "finalization_process_id"); x != finalizationProcess {
		return result{}, fail("closure process mismatch")
	}
	closureDigest, err := domainHash(dClosureRecord, closure)
	if err != nil {
		return result{}, err
	}
	if x, _ := str(e, "closure_record_digest"); x != closureDigest {
		return result{}, fail("closure record digest mismatch")
	}

	manifest, err := obj(e["accepted_manifest_at_closure"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(manifest, schemaManifest); err != nil {
		return result{}, err
	}
	if x, _ := str(manifest, "election_instance_id"); x != eid {
		return result{}, fail("manifest election mismatch")
	}
	if x, _ := str(manifest, "crypto_profile"); x != cryptoProfile {
		return result{}, fail("manifest profile mismatch")
	}
	if x, _ := str(manifest, "tally_function_id"); x != tally {
		return result{}, fail("manifest tally mismatch")
	}
	manifestDigest, err := str(manifest, "manifest_digest")
	if err != nil {
		return result{}, err
	}
	got, err = domainHash(dAcceptedManifest, without(manifest, "manifest_digest"))
	if err != nil || got != manifestDigest {
		return result{}, fail("accepted manifest digest mismatch")
	}
	if x, _ := str(checkpoint, "accepted_manifest_digest"); x != manifestDigest {
		return result{}, fail("checkpoint/manifest digest mismatch")
	}
	mlc, err := obj(manifest["ledger_checkpoint"])
	if err != nil {
		return result{}, err
	}
	for _, k := range []string{"ledger_event_count", "ledger_seq", "ledger_event_hash"} {
		if err = requireSameString(checkpoint, k, mlc, k); err != nil {
			return result{}, fail("manifest/checkpoint ledger mismatch")
		}
	}
	acceptedArray, err := arr(manifest["accepted_ballot_digests"])
	if err != nil {
		return result{}, err
	}
	accepted := map[string]bool{}
	for _, v := range acceptedArray {
		s, ok := v.(string)
		if !ok || !isHex64(s) || accepted[s] {
			return result{}, fail("invalid/duplicate accepted digest")
		}
		accepted[s] = true
	}

	cset, err := obj(e["cset_final"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(cset, schemaCSet); err != nil {
		return result{}, err
	}
	if x, _ := str(cset, "election_instance_id"); x != eid {
		return result{}, fail("CSet election mismatch")
	}
	if x, _ := str(cset, "crypto_profile"); x != cryptoProfile {
		return result{}, fail("CSet profile mismatch")
	}
	ordered, err := verifyOrderedHex(cset["ordered_ballot_digests"])
	if err != nil {
		return result{}, err
	}
	for _, d := range ordered {
		if !accepted[d] {
			return result{}, fail("CSet digest not in accepted manifest")
		}
	}
	csetRoot, err := domainHash(dCSetRoot, cset)
	if err != nil {
		return result{}, err
	}
	if x, _ := str(e, "cset_root"); x != csetRoot {
		return result{}, fail("cset_root mismatch")
	}

	env, err := obj(e["final_set_envelope"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(env, schemaEnvelope); err != nil {
		return result{}, err
	}
	if x, _ := str(env, "election_instance_id"); x != eid {
		return result{}, fail("envelope election mismatch")
	}
	if x, _ := str(env, "crypto_profile"); x != cryptoProfile {
		return result{}, fail("envelope profile mismatch")
	}
	if x, _ := str(env, "canonicalization_policy_version"); x != canonPolicy {
		return result{}, fail("canonicalization policy mismatch")
	}
	if x, _ := str(env, "tally_function_id"); x != tally {
		return result{}, fail("envelope tally mismatch")
	}
	if !eq(env["ordered_ballot_digests"], cset["ordered_ballot_digests"]) {
		return result{}, fail("envelope/CSet order mismatch")
	}
	if x, _ := str(env, "cset_root"); x != csetRoot {
		return result{}, fail("envelope cset_root mismatch")
	}
	if x, _ := str(env, "closure_record_digest"); x != closureDigest {
		return result{}, fail("envelope closure digest mismatch")
	}
	if err = requireSameString(env, "belenios_election_uuid", cset, "belenios_election_uuid"); err != nil {
		return result{}, err
	}
	if err = requireSameString(env, "belenios_election_fingerprint", cset, "belenios_election_fingerprint"); err != nil {
		return result{}, err
	}
	envDigest, err := domainHash(dEnvelope, env)
	if err != nil {
		return result{}, err
	}
	if x, _ := str(e, "final_set_envelope_digest"); x != envDigest {
		return result{}, fail("FinalSetEnvelope digest mismatch")
	}
	fFinal, err := domainHash(dFFinal, env)
	if err != nil {
		return result{}, err
	}
	if x, _ := str(e, "f_final"); x != fFinal {
		return result{}, fail("F_final mismatch")
	}
	canonicalEvidence, err := canonical(e)
	if err != nil {
		return result{}, err
	}
	return result{Status: "PASS", ElectionInstanceID: eid, EffectiveBallotCount: fmt.Sprintf("%d", len(ordered)), CSetRoot: csetRoot, FFinal: fFinal, PublicEvidenceDigest: publicDigest, CanonicalPublicEvidenceUTF8Base64URL: base64.RawURLEncoding.EncodeToString(canonicalEvidence)}, nil
}

func load(path string) (any, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	return parseJSON(b)
}
func flipHex(s string) string {
	if len(s) == 0 {
		return s
	}
	if s[0] == '0' {
		return "1" + s[1:]
	}
	return "0" + s[1:]
}
func rawDomainHash(tag string, b []byte) string {
	h := sha256.New()
	h.Write([]byte(tag))
	h.Write([]byte{0})
	h.Write(b)
	return hex.EncodeToString(h.Sum(nil))
}
func ballotDigestIndependent(ctx map[string]any, ballotB64 string) (string, error) {
	in := map[string]any{
		"schema_version":                "epd2.pb01.ballot-digest-input/1",
		"election_instance_id":          ctx["election_instance_id"],
		"crypto_profile":                ctx["crypto_profile"],
		"belenios_election_uuid":        ctx["belenios_election_uuid"],
		"belenios_election_fingerprint": ctx["belenios_election_fingerprint"],
		"belenios_ballot_base64url":     ballotB64,
	}
	return domainHash(dBallotDigest, in)
}
func verifyI05Vector(v map[string]any, keyID string, pub ed25519.PublicKey) error {
	i04, err := obj(v["i04_public_evidence"])
	if err != nil {
		return err
	}
	i04r, err := verifyEvidence(i04, keyID, pub)
	if err != nil {
		return fmt.Errorf("I04: %w", err)
	}
	b, err := obj(v["tally_evidence_bundle"])
	if err != nil {
		return err
	}
	if err = requireSchema(b, schemaTallyEvidence); err != nil {
		return err
	}
	if containsLifecycleHandle(b) {
		return fail("private lifecycle handle in tally evidence")
	}
	if x, _ := str(b, "f_final"); x != i04r.FFinal {
		return fail("I05 F_final/I04 mismatch")
	}
	if x, _ := str(b, "cset_root"); x != i04r.CSetRoot {
		return fail("I05 cset_root/I04 mismatch")
	}
	if x, _ := str(b, "final_set_envelope_digest"); x != i04["final_set_envelope_digest"] {
		return fail("envelope digest mismatch")
	}
	if !eq(b["final_set_envelope"], i04["final_set_envelope"]) {
		return fail("envelope object mismatch")
	}
	i04cs, _ := obj(i04["cset_final"])
	if !eq(b["ordered_ballot_digests"], i04cs["ordered_ballot_digests"]) {
		return fail("I05 exact set/order mismatch")
	}
	// Evidence digest.
	evd, _ := str(b, "tally_evidence_digest")
	got, er := domainHash(dTallyEvidence, without(b, "tally_evidence_digest"))
	if er != nil || got != evd {
		return fail("tally evidence digest mismatch")
	}
	// Input manifest.
	m, er := obj(b["tally_input_manifest"])
	if er != nil {
		return er
	}
	if er = requireSchema(m, schemaTallyInput); er != nil {
		return er
	}
	mid, _ := str(b, "tally_input_digest")
	got, er = domainHash(dTallyInput, m)
	if er != nil || got != mid {
		return fail("tally input digest mismatch")
	}
	for _, k := range []string{"election_instance_id", "crypto_profile", "tally_function_id", "f_final", "cset_root", "final_set_envelope_digest"} {
		if x, _ := str(m, k); x != b[k] {
			return fail("manifest linkage mismatch: " + k)
		}
	}
	if !eq(m["ordered_ballot_digests"], b["ordered_ballot_digests"]) {
		return fail("manifest order mismatch")
	}
	ordered, er := verifyOrderedHex(m["ordered_ballot_digests"])
	if er != nil {
		return er
	}
	if bc, _ := str(m, "ballot_count_decimal"); bc != fmt.Sprintf("%d", len(ordered)) {
		return fail("ballot count mismatch")
	}
	// Exact ballots and independent PB01 ballot digest recomputation.
	ex, er := arr(v["exact_ballots"])
	if er != nil {
		return er
	}
	if len(ex) != len(ordered) {
		return fail("exact ballot set length mismatch")
	}
	ctx, er := obj(v["election_context"])
	if er != nil {
		return er
	}
	for i, x := range ex {
		em, _ := obj(x)
		d, _ := str(em, "ballot_digest")
		if d != ordered[i] {
			return fail("exact ballot order/digest mismatch")
		}
		bb, _ := str(em, "encrypted_ballot_base64url")
		gd, e2 := ballotDigestIndependent(ctx, bb)
		if e2 != nil || gd != d {
			return fail("ballot digest recomputation mismatch")
		}
	}
	// Aggregate exact bytes/digest.
	ab64, _ := str(b, "aggregate_ciphertext_base64url")
	abytes, er := base64.RawURLEncoding.DecodeString(ab64)
	if er != nil {
		return fail("aggregate base64")
	}
	ad, _ := str(b, "aggregate_ciphertext_digest")
	if rawDomainHash(dAggregate, abytes) != ad {
		return fail("aggregate digest mismatch")
	}
	// The upstream JSON object must be exactly the bytes when canonically encoded. Upstream output is compact and canonical for this fixture.
	ac, er := canonical(b["aggregate_ciphertext"])
	if er != nil {
		return er
	}
	if !bytes.Equal(ac, abytes) {
		return fail("aggregate serialization byte mismatch")
	}
	// Tally record.
	r, er := obj(b["homomorphic_tally_record"])
	if er != nil {
		return er
	}
	if er = requireSchema(r, schemaTallyRecord); er != nil {
		return er
	}
	rd, _ := str(r, "tally_record_digest")
	got, er = domainHash(dTallyRecord, without(r, "tally_record_digest"))
	if er != nil || got != rd {
		return fail("tally record digest mismatch")
	}
	if x, _ := str(b, "tally_record_digest"); x != rd {
		return fail("record/bundle digest mismatch")
	}
	for _, k := range []string{"f_final", "cset_root", "final_set_envelope_digest", "tally_input_digest", "aggregate_ciphertext_digest"} {
		if x, _ := str(r, k); x != b[k] {
			return fail("record linkage mismatch: " + k)
		}
	}
	if !eq(r["aggregate_ciphertext"], b["aggregate_ciphertext"]) {
		return fail("record aggregate mismatch")
	}
	if x, _ := str(r, "aggregate_ciphertext_base64url"); x != ab64 {
		return fail("record aggregate bytes mismatch")
	}
	return nil
}
func recomputeAggregate(v map[string]any, tool, baseArchive string) error {
	work, err := os.MkdirTemp("", "epd2-i05-go-agg-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(work)
	src, err := os.ReadFile(baseArchive)
	if err != nil {
		return err
	}
	dst := filepath.Join(work, filepath.Base(baseArchive))
	if err = os.WriteFile(dst, src, 0600); err != nil {
		return err
	}
	ex, _ := arr(v["exact_ballots"])
	run := func(args []string, input []byte) ([]byte, error) {
		cmd := exec.Command(tool, args...)
		cmd.Env = append(os.Environ(), "BELENIOS_USE_URANDOM=1")
		if input != nil {
			cmd.Stdin = bytes.NewReader(input)
		}
		var stderr bytes.Buffer
		cmd.Stderr = &stderr
		out, err := cmd.Output()
		if err != nil {
			return append(out, stderr.Bytes()...), err
		}
		return out, nil
	}
	for _, x := range ex {
		em, _ := obj(x)
		bb, _ := str(em, "encrypted_ballot_base64url")
		raw, e := base64.RawURLEncoding.DecodeString(bb)
		if e != nil {
			return e
		}
		raw = append(raw, '\n')
		if out, e := run([]string{"archive", "add-event", "--dir=" + work, "--type=Ballot"}, raw); e != nil {
			return fmt.Errorf("add ballot: %w %s", e, out)
		}
	}
	if out, e := run([]string{"archive", "add-event", "--dir=" + work, "--type=EndBallots"}, []byte{}); e != nil {
		return fmt.Errorf("end ballots: %w %s", e, out)
	}
	out, e := run([]string{"election", "compute-encrypted-tally", "--dir=" + work}, nil)
	if e != nil {
		return fmt.Errorf("compute: %w %s", e, out)
	}
	line := bytes.Split(out, []byte("\n"))[0]
	wantB64, _ := str(v, "expected_aggregate_ciphertext_base64url")
	want, e := base64.RawURLEncoding.DecodeString(wantB64)
	if e != nil {
		return e
	}
	if !bytes.Equal(line, want) {
		return fail("independent upstream aggregate byte mismatch")
	}
	return nil
}
func mutationReports(base map[string]any, keyID string, pub ed25519.PublicKey) []mutationReport {
	out := []mutationReport{}
	test := func(name string, v map[string]any) {
		err := verifyI05Vector(v, keyID, pub)
		obs := "REJECT"
		if err == nil {
			obs = "ACCEPT"
		}
		out = append(out, mutationReport{Name: name, Expected: "REJECT", Observed: obs})
	}
	// N01 remove exact final ballot.
	v := clone(base).(map[string]any)
	ex := v["exact_ballots"].([]any)
	v["exact_ballots"] = ex[:len(ex)-1]
	test("I05-N01-remove-one-final-ballot", v)
	// N02 add superseded ballot (reuse a non-final ballot fixture reference represented as extra set member).
	v = clone(base).(map[string]any)
	ex = v["exact_ballots"].([]any)
	ex = append(ex, clone(ex[0]))
	v["exact_ballots"] = ex
	test("I05-N02-add-superseded-ballot", v)
	// N03 foreign/extra ballot at composition boundary.
	v = clone(base).(map[string]any)
	ex = v["exact_ballots"].([]any)
	fm := clone(ex[0]).(map[string]any)
	fm["ballot_digest"] = "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
	ex = append(ex, fm)
	v["exact_ballots"] = ex
	test("I05-N03-add-foreign-ballot", v)
	// N04 mutate exact bytes.
	v = clone(base).(map[string]any)
	em := v["exact_ballots"].([]any)[0].(map[string]any)
	s := em["encrypted_ballot_base64url"].(string)
	em["encrypted_ballot_base64url"] = s[:len(s)-1] + "A"
	test("I05-N04-change-ballot-bytes", v)
	// N05 digest.
	v = clone(base).(map[string]any)
	em = v["exact_ballots"].([]any)[0].(map[string]any)
	em["ballot_digest"] = flipHex(em["ballot_digest"].(string))
	test("I05-N05-change-ballot-digest", v)
	// N06 order in tally manifest/bundle only.
	v = clone(base).(map[string]any)
	b := v["tally_evidence_bundle"].(map[string]any)
	a := b["ordered_ballot_digests"].([]any)
	a[0], a[1] = a[1], a[0]
	test("I05-N06-change-CSet-order", v)
	// N07 cset root.
	v = clone(base).(map[string]any)
	b = v["tally_evidence_bundle"].(map[string]any)
	b["cset_root"] = flipHex(b["cset_root"].(string))
	test("I05-N07-change-cset-root", v)
	// N08 F_final.
	v = clone(base).(map[string]any)
	b = v["tally_evidence_bundle"].(map[string]any)
	b["f_final"] = flipHex(b["f_final"].(string))
	test("I05-N08-change-F-final", v)
	// N09 aggregate bytes.
	v = clone(base).(map[string]any)
	b = v["tally_evidence_bundle"].(map[string]any)
	s = b["aggregate_ciphertext_base64url"].(string)
	b["aggregate_ciphertext_base64url"] = s[:len(s)-1] + "A"
	test("I05-N09-change-aggregate-ciphertext", v)
	// N10 aggregate digest.
	v = clone(base).(map[string]any)
	b = v["tally_evidence_bundle"].(map[string]any)
	b["aggregate_ciphertext_digest"] = flipHex(b["aggregate_ciphertext_digest"].(string))
	test("I05-N10-change-aggregate-digest", v)
	// N11 manifest.
	v = clone(base).(map[string]any)
	b = v["tally_evidence_bundle"].(map[string]any)
	m := b["tally_input_manifest"].(map[string]any)
	m["ballot_count_decimal"] = "999"
	test("I05-N11-change-tally-input-manifest", v)
	// N12 tally record digest.
	v = clone(base).(map[string]any)
	b = v["tally_evidence_bundle"].(map[string]any)
	b["tally_record_digest"] = flipHex(b["tally_record_digest"].(string))
	test("I05-N12-change-tally-record-digest", v)
	return out
}

type i05VectorReport struct {
	Case                   string `json:"case"`
	Status                 string `json:"status"`
	AggregateByteAgreement bool   `json:"aggregate_byte_agreement"`
	TallyRecordDigest      string `json:"tally_record_digest"`
}
type i05Report struct {
	SchemaVersion                     string            `json:"schema_version"`
	Status                            string            `json:"status"`
	Implementation                    string            `json:"implementation"`
	ProducerCodeImports               bool              `json:"producer_code_imports"`
	Vectors                           []i05VectorReport `json:"vectors"`
	Mutations                         []mutationReport  `json:"mutations"`
	IndependentAggregateRecomputation bool              `json:"independent_aggregate_recomputation"`
}

func main() {
	vectors := flag.String("vectors", "", "I05 vector directory")
	index := flag.String("index", "", "I05 index")
	tool := flag.String("tool", "", "pinned belenios-tool")
	archive := flag.String("archive", "", "base .bel archive")
	outp := flag.String("out", "", "report path")
	flag.Parse()
	if *vectors == "" || *index == "" || *tool == "" || *archive == "" {
		fmt.Fprintln(os.Stderr, "--vectors --index --tool --archive required")
		os.Exit(2)
	}
	iv, err := load(*index)
	if err != nil {
		panic(err)
	}
	idx := iv.(map[string]any)
	keyID := idx["key_id"].(string)
	jwk := idx["closure_public_jwk"].(map[string]any)
	x, _ := base64.RawURLEncoding.DecodeString(jwk["x"].(string))
	pub := ed25519.PublicKey(x)
	rep := i05Report{SchemaVersion: "epd2.pb01.i05-cross-language-verifier-report/1", Status: "PASS", Implementation: "Go stdlib independent Verifier B I04+I05 composition + pinned upstream Belenios aggregate recomputation", ProducerCodeImports: false, IndependentAggregateRecomputation: true}
	var mut map[string]any
	for _, cv := range idx["cases"].([]any) {
		c := cv.(map[string]any)
		vv, er := load(filepath.Join(*vectors, c["file"].(string)))
		if er != nil {
			panic(er)
		}
		v := vv.(map[string]any)
		vr := i05VectorReport{Case: v["case"].(string), Status: "PASS", AggregateByteAgreement: true, TallyRecordDigest: v["expected_tally_record_digest"].(string)}
		if er = verifyI05Vector(v, keyID, pub); er != nil {
			vr.Status = "FAIL: " + er.Error()
			vr.AggregateByteAgreement = false
			rep.Status = "FAIL"
		}
		if er = recomputeAggregate(v, *tool, *archive); er != nil {
			vr.Status = "FAIL: " + er.Error()
			vr.AggregateByteAgreement = false
			rep.Status = "FAIL"
		}
		rep.Vectors = append(rep.Vectors, vr)
		if strings.Contains(vr.Case, "revotes") {
			mut = clone(v).(map[string]any)
		}
	}
	if mut == nil {
		panic("missing mutation vector")
	}
	rep.Mutations = mutationReports(mut, keyID, pub)
	for _, m := range rep.Mutations {
		if m.Observed != "REJECT" {
			rep.Status = "FAIL"
		}
	}
	b, _ := json.MarshalIndent(rep, "", "  ")
	b = append(b, '\n')
	if *outp != "" {
		if writeErr := os.WriteFile(*outp, b, 0644); writeErr != nil {
			panic(writeErr)
		}
	}
	os.Stdout.Write(b)
	if rep.Status != "PASS" {
		os.Exit(1)
	}
}
