import { createPublicKey } from "node:crypto";
import { readFile } from "node:fs/promises";
import { verifyI04PublicEvidence } from "./i04_verifier_b.mjs";

const [evidencePath, publicKeyPath, keyId] = process.argv.slice(2);
if (!evidencePath || !publicKeyPath || !keyId) {
  throw new Error("usage: verify-i04-evidence.mjs <evidence.json> <closure-public-key.pem> <key-id>");
}
const evidence = JSON.parse(await readFile(evidencePath, "utf8"));
const publicKey = createPublicKey(await readFile(publicKeyPath));
const result = verifyI04PublicEvidence(evidence, { closurePublicKeys: new Map([[keyId, publicKey]]) });
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
