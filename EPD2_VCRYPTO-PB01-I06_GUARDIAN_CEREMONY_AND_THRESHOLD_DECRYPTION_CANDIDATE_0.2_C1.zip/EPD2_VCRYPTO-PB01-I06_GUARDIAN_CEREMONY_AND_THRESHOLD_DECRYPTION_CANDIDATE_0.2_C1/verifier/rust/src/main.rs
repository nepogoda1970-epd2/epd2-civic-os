use anyhow::{anyhow, bail, Context, Result};
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine as _};
use ed25519_dalek::{Signature, Verifier, VerifyingKey};
use serde_json::{Map, Value};
use sha2::{Digest, Sha256};
use std::{cmp::Ordering, env, fs, path::{Path, PathBuf}};

const D_ACCEPTED_MANIFEST: &str = "epd2.pb01.accepted-submission-manifest.v1";
const D_CLOSURE_AUTH: &str = "epd2.pb01.closure-authorization.v1";
const D_CLOSURE_AUTH_EVIDENCE: &str = "epd2.pb01.closure-authorization-evidence.v1";
const D_CHECKPOINT: &str = "epd2.pb01.closure-ledger-checkpoint.v1";
const D_CLOSURE_RECORD: &str = "epd2.pb01.closure-record.v1";
const D_CSET_ROOT: &str = "epd2.pb01.cset-root.v1";
const D_ENVELOPE: &str = "epd2.pb01.final-set-envelope.v1";
const D_F_FINAL: &str = "epd2.pb01.f-final.v1";
const D_PUBLIC: &str = "epd2.pb01.final-set-evidence.v1";

const CRYPTO_PROFILE: &str = "epd2.belenios-homomorphic/1";
const CANON_POLICY: &str = "epd2.pb01.jcs-rfc8785-restricted/1";
const REVOTE_POLICY: &str = "epd2.pb01.revote.latest-valid.v1";
const FINALIZATION_PROCESS: &str = "epd2.pb01.finalization-process.i04.v1";

fn utf16_cmp(a: &str, b: &str) -> Ordering {
    let aa: Vec<u16> = a.encode_utf16().collect();
    let bb: Vec<u16> = b.encode_utf16().collect();
    aa.cmp(&bb)
}

fn write_json_string(out: &mut String, s: &str) {
    out.push('"');
    for ch in s.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\u{0008}' => out.push_str("\\b"),
            '\u{000C}' => out.push_str("\\f"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) <= 0x1f => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
}

fn canonicalize(v: &Value) -> Result<Vec<u8>> {
    fn rec(v: &Value, out: &mut String) -> Result<()> {
        match v {
            Value::Null => out.push_str("null"),
            Value::Bool(true) => out.push_str("true"),
            Value::Bool(false) => out.push_str("false"),
            Value::String(s) => write_json_string(out, s),
            Value::Number(_) => bail!("numbers prohibited by PB01 restricted canonicalization"),
            Value::Array(a) => {
                out.push('[');
                for (i, e) in a.iter().enumerate() {
                    if i != 0 { out.push(','); }
                    rec(e, out)?;
                }
                out.push(']');
            }
            Value::Object(m) => {
                let mut keys: Vec<&String> = m.keys().collect();
                keys.sort_by(|a,b| utf16_cmp(a,b));
                out.push('{');
                for (i,k) in keys.into_iter().enumerate() {
                    if i != 0 { out.push(','); }
                    write_json_string(out,k);
                    out.push(':');
                    rec(&m[k],out)?;
                }
                out.push('}');
            }
        }
        Ok(())
    }
    let mut out=String::new(); rec(v,&mut out)?; Ok(out.into_bytes())
}

fn domain_hash(tag: &str, v: &Value) -> Result<String> {
    let c=canonicalize(v)?;
    let mut h=Sha256::new(); h.update(tag.as_bytes()); h.update([0u8]); h.update(c);
    Ok(format!("{:x}",h.finalize()))
}

fn object(v: &Value) -> Result<&Map<String,Value>> { v.as_object().ok_or_else(||anyhow!("object required")) }
fn string<'a>(m: &'a Map<String,Value>, k:&str) -> Result<&'a str> { m.get(k).and_then(Value::as_str).ok_or_else(||anyhow!("string required: {k}")) }
fn schema(m:&Map<String,Value>, want:&str)->Result<()> { if string(m,"schema_version")? != want {bail!("schema mismatch: {want}")}; Ok(()) }
fn without(m:&Map<String,Value>, key:&str)->Value { let mut n=m.clone(); n.remove(key); Value::Object(n) }
fn same(a:&Value,b:&Value)->Result<bool>{Ok(canonicalize(a)?==canonicalize(b)?)}
fn hex64(s:&str)->bool{s.len()==64 && s.bytes().all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c))}

fn ordered_hex(v:&Value)->Result<Vec<String>>{
    let a=v.as_array().ok_or_else(||anyhow!("digest array required"))?;
    let mut out=Vec::with_capacity(a.len()); let mut prev:Option<String>=None;
    for e in a { let s=e.as_str().ok_or_else(||anyhow!("digest string required"))?; if !hex64(s){bail!("invalid digest")}; if let Some(p)=&prev {if p.as_str()>=s{bail!("noncanonical digest order or duplicate")}}; prev=Some(s.to_owned()); out.push(s.to_owned()); }
    Ok(out)
}

fn has_lifecycle_handle(v:&Value)->bool{match v{Value::Object(m)=>m.iter().any(|(k,e)|k=="lifecycle_handle"||has_lifecycle_handle(e)),Value::Array(a)=>a.iter().any(has_lifecycle_handle),_=>false}}

#[derive(Debug)]
struct VerifyResult { count:String, cset_root:String, f_final:String, public_digest:String, canonical_b64:String }

fn verify_evidence(v:&Value,key_id:&str,key:&VerifyingKey)->Result<VerifyResult>{
    let e=object(v)?; schema(e,"epd2.pb01.final-set-evidence/1")?; if has_lifecycle_handle(v){bail!("private lifecycle handle exposed")}
    let eid=string(e,"election_instance_id")?; if string(e,"crypto_profile")? != CRYPTO_PROFILE{bail!("profile mismatch")}; if string(e,"revote_policy_version")? != REVOTE_POLICY{bail!("revote policy mismatch")};
    let tally=string(e,"tally_function_id")?; if tally!="epd2.pb01.tally.single-choice.v1"&&tally!="epd2.pb01.tally.approval.v1"{bail!("unknown tally")}
    let pd=string(e,"public_evidence_digest")?; if domain_hash(D_PUBLIC,&without(e,"public_evidence_digest"))? != pd{bail!("public evidence digest mismatch")}

    let auth=object(e.get("closure_authorization").context("closure_authorization")?)?; schema(auth,"epd2.pb01.closure-authorization-evidence/1")?; if string(auth,"key_id")? != key_id||string(auth,"algorithm")? != "Ed25519"{bail!("closure key/algorithm mismatch")};
    let ad=string(auth,"authorization_evidence_digest")?; if domain_hash(D_CLOSURE_AUTH_EVIDENCE,&without(auth,"authorization_evidence_digest"))? != ad{bail!("authorization evidence digest mismatch")}
    let st=object(auth.get("statement").context("statement")?)?; schema(st,"epd2.pb01.closure-authorization-statement/1")?; if string(st,"election_instance_id")? != eid||string(st,"revote_policy_version")? != REVOTE_POLICY||string(st,"finalization_process_id")? != FINALIZATION_PROCESS{bail!("signed statement mismatch")}
    let sig_bytes=URL_SAFE_NO_PAD.decode(string(auth,"signature_base64url")?)?; let sig=Signature::from_slice(&sig_bytes)?; let mut msg=D_CLOSURE_AUTH.as_bytes().to_vec(); msg.push(0); msg.extend(canonicalize(auth.get("statement").unwrap())?); key.verify(&msg,&sig).context("Ed25519 closure signature invalid")?;

    let cpv=e.get("closure_ledger_checkpoint").context("checkpoint")?; let cp=object(cpv)?; schema(cp,"epd2.pb01.closure-ledger-checkpoint/1")?; if string(cp,"election_instance_id")? != eid||string(cp,"ledger_event_count")? != string(cp,"ledger_seq")?{bail!("checkpoint mismatch")}; if !same(cpv,st.get("closure_ledger_checkpoint").context("signed checkpoint")?)?{bail!("signed checkpoint mismatch")}; let cpd=domain_hash(D_CHECKPOINT,cpv)?;

    let crv=e.get("closure_record").context("closure_record")?; let cr=object(crv)?; schema(cr,"epd2.pb01.closure-record/1")?; if string(cr,"election_instance_id")? != eid||string(cr,"closure_state")? != "closed"||string(cr,"closure_checkpoint_digest")? != cpd||string(cr,"authorization_evidence_digest")? != ad||string(cr,"finalization_policy_version")? != REVOTE_POLICY||string(cr,"finalization_process_id")? != FINALIZATION_PROCESS{bail!("closure record mismatch")}; let crd=domain_hash(D_CLOSURE_RECORD,crv)?; if string(e,"closure_record_digest")? != crd{bail!("closure record digest mismatch")}

    let mv=e.get("accepted_manifest_at_closure").context("manifest")?; let m=object(mv)?; schema(m,"epd2.pb01.accepted-submission-manifest/1")?; if string(m,"election_instance_id")? != eid||string(m,"crypto_profile")? != CRYPTO_PROFILE||string(m,"tally_function_id")? != tally{bail!("manifest binding mismatch")}; let md=string(m,"manifest_digest")?; if domain_hash(D_ACCEPTED_MANIFEST,&without(m,"manifest_digest"))? != md||string(cp,"accepted_manifest_digest")? != md{bail!("manifest digest binding mismatch")}
    let ml=object(m.get("ledger_checkpoint").context("manifest ledger checkpoint")?)?; for k in ["ledger_event_count","ledger_seq","ledger_event_hash"]{if string(ml,k)? != string(cp,k)?{bail!("manifest/checkpoint ledger mismatch")}}
    let aa=m.get("accepted_ballot_digests").and_then(Value::as_array).context("accepted digests")?; let mut accepted=std::collections::BTreeSet::new(); for x in aa{let s=x.as_str().context("accepted digest string")?; if !hex64(s)||!accepted.insert(s){bail!("invalid/duplicate accepted digest")}}

    let csv=e.get("cset_final").context("cset")?; let cs=object(csv)?; schema(cs,"epd2.pb01.cset-final/1")?; if string(cs,"election_instance_id")? != eid||string(cs,"crypto_profile")? != CRYPTO_PROFILE{bail!("CSet binding mismatch")}; let ordered=ordered_hex(cs.get("ordered_ballot_digests").context("ordered digests")?)?; if ordered.iter().any(|d|!accepted.contains(d.as_str())){bail!("CSet digest outside accepted manifest")}; let csr=domain_hash(D_CSET_ROOT,csv)?; if string(e,"cset_root")? != csr{bail!("cset_root mismatch")}

    let envv=e.get("final_set_envelope").context("envelope")?; let envm=object(envv)?; schema(envm,"epd2.pb01.final-set-envelope/1")?; if string(envm,"election_instance_id")? != eid||string(envm,"crypto_profile")? != CRYPTO_PROFILE||string(envm,"canonicalization_policy_version")? != CANON_POLICY||string(envm,"tally_function_id")? != tally||string(envm,"cset_root")? != csr||string(envm,"closure_record_digest")? != crd{bail!("envelope binding mismatch")}; if !same(envm.get("ordered_ballot_digests").context("env ordered")?,cs.get("ordered_ballot_digests").context("cset ordered")?)?{bail!("envelope/CSet order mismatch")}; for k in ["belenios_election_uuid","belenios_election_fingerprint"]{if string(envm,k)? != string(cs,k)?{bail!("Belenios context mismatch")}}
    let ed=domain_hash(D_ENVELOPE,envv)?; if string(e,"final_set_envelope_digest")? != ed{bail!("FinalSetEnvelope digest mismatch")}; let ff=domain_hash(D_F_FINAL,envv)?; if string(e,"f_final")? != ff{bail!("F_final mismatch")}
    Ok(VerifyResult{count:ordered.len().to_string(),cset_root:csr,f_final:ff,public_digest:pd.to_owned(),canonical_b64:URL_SAFE_NO_PAD.encode(canonicalize(v)?)})
}

fn read_json(path:&Path)->Result<Value>{let b=fs::read(path).with_context(||format!("read {}",path.display()))?; let v:Value=serde_json::from_slice(&b)?; fn reject_numbers(v:&Value)->Result<()>{match v{Value::Number(_)=>bail!("numbers prohibited"),Value::Array(a)=>for e in a{reject_numbers(e)?},Value::Object(m)=>for e in m.values(){reject_numbers(e)?},_=>{}};Ok(())}; reject_numbers(&v)?; Ok(v)}

fn main()->Result<()>{
    let mut args=env::args().skip(1); let mut vectors:Option<PathBuf>=None;
    while let Some(a)=args.next(){if a=="--vectors"{vectors=Some(PathBuf::from(args.next().context("--vectors value")?))}else{bail!("unknown argument {a}")}}
    let dir=vectors.context("--vectors is required")?; let idx=read_json(&dir.join("index.json"))?; let im=object(&idx)?; let key_id=string(im,"key_id")?; let jwk=object(im.get("public_jwk").context("public_jwk")?)?; let xb=URL_SAFE_NO_PAD.decode(string(jwk,"x")?)?; let x:[u8;32]=xb.try_into().map_err(|_|anyhow!("Ed25519 JWK x must be 32 bytes"))?; let key=VerifyingKey::from_bytes(&x)?;
    let cases=im.get("cases").and_then(Value::as_array).context("cases")?; let mut reports=Vec::new(); let mut overall=true;
    for c in cases{let cm=object(c)?; let file=string(cm,"file")?; let v=read_json(&dir.join(file))?; let vm=object(&v)?; let r=verify_evidence(vm.get("public_evidence").context("public_evidence")?,key_id,&key)?; let pr=object(vm.get("producer_result").context("producer_result")?)?; let bytes_ok=r.canonical_b64==string(vm,"producer_canonical_public_evidence_utf8_base64url")?; let digests_ok=r.cset_root==string(pr,"cset_root")?&&r.f_final==string(pr,"f_final")?&&r.public_digest==string(pr,"public_evidence_digest")?; let ok=bytes_ok&&digests_ok; overall&=ok; reports.push(serde_json::json!({"case":string(vm,"case")?,"status":if ok{"PASS"}else{"FAIL"},"effective_ballot_count":r.count,"byte_for_byte_agreement":bytes_ok,"cset_root":r.cset_root,"f_final":r.f_final,"public_evidence_digest":r.public_digest})); }
    let output=serde_json::json!({"schema_version":"epd2.pb01.i04-rust-verifier-b-report/1","status":if overall{"PASS"}else{"FAIL"},"implementation":"Rust independent Verifier B extension","producer_code_imports":false,"vectors":reports}); println!("{}",serde_json::to_string_pretty(&output)?); if !overall{bail!("agreement failure")}; Ok(())
}
