# Rust Verifier B — I04 extension

This directory extends the independent Rust/reference Verifier B path to PB01-I04 without importing producer modules. It implements restricted canonicalization, SHA-256 domain separation, Ed25519 closure authorization verification, checkpoint/accepted-manifest binding, canonical CSet_final validation, cset_root, closure_record_digest, FinalSetEnvelope digest, F_final and public-evidence digest.

Run from this directory with a Rust toolchain:

```sh
cargo run --release -- --vectors ../../test-vectors/i04-verifier-b
```

The runtime used to produce the candidate evidence is the standard-library Go reference under `../reference-go/`, because the candidate build environment did not contain `rustc`/`cargo`. Both implementations are source-independent from the Node producer; the Go path is the executed cross-language acceptance gate in this candidate.
