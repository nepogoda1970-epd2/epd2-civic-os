package main

import (
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"unicode/utf16"
)

const (
	dAcceptedManifest    = "epd2.pb01.accepted-submission-manifest.v1"
	dClosureAuth         = "epd2.pb01.closure-authorization.v1"
	dClosureAuthEvidence = "epd2.pb01.closure-authorization-evidence.v1"
	dCheckpoint          = "epd2.pb01.closure-ledger-checkpoint.v1"
	dClosureRecord       = "epd2.pb01.closure-record.v1"
	dCSetRoot            = "epd2.pb01.cset-root.v1"
	dEnvelope            = "epd2.pb01.final-set-envelope.v1"
	dFFinal              = "epd2.pb01.f-final.v1"
	dPublicEvidence      = "epd2.pb01.final-set-evidence.v1"

	schemaPublic        = "epd2.pb01.final-set-evidence/1"
	schemaAuthEvidence  = "epd2.pb01.closure-authorization-evidence/1"
	schemaAuthStatement = "epd2.pb01.closure-authorization-statement/1"
	schemaCheckpoint    = "epd2.pb01.closure-ledger-checkpoint/1"
	schemaManifest      = "epd2.pb01.accepted-submission-manifest/1"
	schemaClosureRecord = "epd2.pb01.closure-record/1"
	schemaCSet          = "epd2.pb01.cset-final/1"
	schemaEnvelope      = "epd2.pb01.final-set-envelope/1"
	cryptoProfile       = "epd2.belenios-homomorphic/1"
	canonPolicy         = "epd2.pb01.jcs-rfc8785-restricted/1"
	revotePolicy        = "epd2.pb01.revote.latest-valid.v1"
	finalizationProcess = "epd2.pb01.finalization-process.i04.v1"
)

type result struct {
	Status                               string `json:"status"`
	ElectionInstanceID                   string `json:"election_instance_id"`
	EffectiveBallotCount                 string `json:"effective_ballot_count"`
	CSetRoot                             string `json:"cset_root"`
	FFinal                               string `json:"f_final"`
	PublicEvidenceDigest                 string `json:"public_evidence_digest"`
	CanonicalPublicEvidenceUTF8Base64URL string `json:"canonical_public_evidence_utf8_base64url"`
}

type vectorReport struct {
	Case                 string `json:"case"`
	Status               string `json:"status"`
	ByteForByteAgreement bool   `json:"byte_for_byte_agreement"`
	CSetRoot             string `json:"cset_root"`
	FFinal               string `json:"f_final"`
	PublicEvidenceDigest string `json:"public_evidence_digest"`
}

type mutationReport struct {
	Name     string `json:"name"`
	Expected string `json:"expected"`
	Observed string `json:"observed"`
}

type report struct {
	SchemaVersion        string           `json:"schema_version"`
	Status               string           `json:"status"`
	Implementation       string           `json:"implementation"`
	Vectors              []vectorReport   `json:"vectors"`
	Mutations            []mutationReport `json:"mutations"`
	ProducerCodeImports  bool             `json:"producer_code_imports"`
	ByteForByteAgreement bool             `json:"byte_for_byte_agreement"`
}

func fail(msg string) error { return errors.New(msg) }

func parseJSON(data []byte) (any, error) {
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	var v any
	if err := dec.Decode(&v); err != nil {
		return nil, err
	}
	var extra any
	if dec.Decode(&extra) == nil {
		return nil, fail("trailing JSON value")
	}
	if err := rejectNumbers(v); err != nil {
		return nil, err
	}
	return v, nil
}

func rejectNumbers(v any) error {
	switch x := v.(type) {
	case json.Number, float64:
		return fail("numbers prohibited by PB01 restricted canonicalization")
	case []any:
		for _, e := range x {
			if err := rejectNumbers(e); err != nil {
				return err
			}
		}
	case map[string]any:
		for _, e := range x {
			if err := rejectNumbers(e); err != nil {
				return err
			}
		}
	}
	return nil
}

func utf16Less(a, b string) bool {
	aa, bb := utf16.Encode([]rune(a)), utf16.Encode([]rune(b))
	n := len(aa)
	if len(bb) < n {
		n = len(bb)
	}
	for i := 0; i < n; i++ {
		if aa[i] != bb[i] {
			return aa[i] < bb[i]
		}
	}
	return len(aa) < len(bb)
}

func appendJSONString(buf *bytes.Buffer, s string) {
	buf.WriteByte('"')
	for _, r := range s {
		switch r {
		case '"':
			buf.WriteString("\\\"")
		case '\\':
			buf.WriteString("\\\\")
		case '\b':
			buf.WriteString("\\b")
		case '\f':
			buf.WriteString("\\f")
		case '\n':
			buf.WriteString("\\n")
		case '\r':
			buf.WriteString("\\r")
		case '\t':
			buf.WriteString("\\t")
		default:
			if r >= 0 && r <= 0x1f {
				fmt.Fprintf(buf, "\\u%04x", r)
			} else {
				buf.WriteRune(r)
			}
		}
	}
	buf.WriteByte('"')
}

func canonical(v any) ([]byte, error) {
	var buf bytes.Buffer
	var rec func(any) error
	rec = func(x any) error {
		switch t := x.(type) {
		case nil:
			buf.WriteString("null")
		case bool:
			if t {
				buf.WriteString("true")
			} else {
				buf.WriteString("false")
			}
		case string:
			appendJSONString(&buf, t)
		case []any:
			buf.WriteByte('[')
			for i, e := range t {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := rec(e); err != nil {
					return err
				}
			}
			buf.WriteByte(']')
		case map[string]any:
			keys := make([]string, 0, len(t))
			for k := range t {
				keys = append(keys, k)
			}
			sort.Slice(keys, func(i, j int) bool { return utf16Less(keys[i], keys[j]) })
			buf.WriteByte('{')
			for i, k := range keys {
				if i > 0 {
					buf.WriteByte(',')
				}
				appendJSONString(&buf, k)
				buf.WriteByte(':')
				if err := rec(t[k]); err != nil {
					return err
				}
			}
			buf.WriteByte('}')
		default:
			return fail("unsupported JSON type / number prohibited")
		}
		return nil
	}
	if err := rec(v); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func domainHash(tag string, v any) (string, error) {
	c, err := canonical(v)
	if err != nil {
		return "", err
	}
	h := sha256.New()
	h.Write([]byte(tag))
	h.Write([]byte{0})
	h.Write(c)
	return hex.EncodeToString(h.Sum(nil)), nil
}

func obj(v any) (map[string]any, error) {
	x, ok := v.(map[string]any)
	if !ok {
		return nil, fail("object required")
	}
	return x, nil
}
func arr(v any) ([]any, error) {
	x, ok := v.([]any)
	if !ok {
		return nil, fail("array required")
	}
	return x, nil
}
func str(m map[string]any, k string) (string, error) {
	x, ok := m[k].(string)
	if !ok {
		return "", fail("string required: " + k)
	}
	return x, nil
}
func eq(a, b any) bool {
	ca, ea := canonical(a)
	cb, eb := canonical(b)
	return ea == nil && eb == nil && bytes.Equal(ca, cb)
}
func clone(v any) any { b, _ := json.Marshal(v); x, _ := parseJSON(b); return x }
func without(m map[string]any, key string) map[string]any {
	n := make(map[string]any, len(m)-1)
	for k, v := range m {
		if k != key {
			n[k] = v
		}
	}
	return n
}
func isHex64(s string) bool {
	if len(s) != 64 {
		return false
	}
	_, err := hex.DecodeString(s)
	if err != nil {
		return false
	}
	return strings.ToLower(s) == s
}
func requireSchema(m map[string]any, want string) error {
	s, e := str(m, "schema_version")
	if e != nil || s != want {
		return fail("schema mismatch: " + want)
	}
	return nil
}
func requireSameString(a map[string]any, ak string, b map[string]any, bk string) error {
	x, e := str(a, ak)
	if e != nil {
		return e
	}
	y, e := str(b, bk)
	if e != nil {
		return e
	}
	if x != y {
		return fail("linkage mismatch: " + ak + "/" + bk)
	}
	return nil
}

func verifyOrderedHex(v any) ([]string, error) {
	a, err := arr(v)
	if err != nil {
		return nil, err
	}
	out := make([]string, len(a))
	var prev string
	for i, e := range a {
		s, ok := e.(string)
		if !ok || !isHex64(s) {
			return nil, fail("invalid digest")
		}
		if i > 0 && prev >= s {
			return nil, fail("noncanonical digest order or duplicate")
		}
		out[i] = s
		prev = s
	}
	return out, nil
}

func containsLifecycleHandle(v any) bool {
	switch x := v.(type) {
	case map[string]any:
		for k, e := range x {
			if k == "lifecycle_handle" || containsLifecycleHandle(e) {
				return true
			}
		}
	case []any:
		for _, e := range x {
			if containsLifecycleHandle(e) {
				return true
			}
		}
	}
	return false
}

func verifyEvidence(evidence any, expectedKeyID string, publicKey ed25519.PublicKey) (result, error) {
	e, err := obj(evidence)
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(e, schemaPublic); err != nil {
		return result{}, err
	}
	if containsLifecycleHandle(e) {
		return result{}, fail("private lifecycle handle present in public evidence")
	}
	eid, err := str(e, "election_instance_id")
	if err != nil {
		return result{}, err
	}
	if p, _ := str(e, "crypto_profile"); p != cryptoProfile {
		return result{}, fail("crypto profile mismatch")
	}
	if r, _ := str(e, "revote_policy_version"); r != revotePolicy {
		return result{}, fail("revote policy mismatch")
	}
	tally, err := str(e, "tally_function_id")
	if err != nil {
		return result{}, err
	}
	if tally != "epd2.pb01.tally.single-choice.v1" && tally != "epd2.pb01.tally.approval.v1" {
		return result{}, fail("unknown tally function")
	}

	publicDigest, err := str(e, "public_evidence_digest")
	if err != nil || !isHex64(publicDigest) {
		return result{}, fail("invalid public evidence digest")
	}
	got, err := domainHash(dPublicEvidence, without(e, "public_evidence_digest"))
	if err != nil || got != publicDigest {
		return result{}, fail("public evidence digest mismatch")
	}

	auth, err := obj(e["closure_authorization"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(auth, schemaAuthEvidence); err != nil {
		return result{}, err
	}
	if keyID, _ := str(auth, "key_id"); keyID != expectedKeyID {
		return result{}, fail("unknown closure key")
	}
	if alg, _ := str(auth, "algorithm"); alg != "Ed25519" {
		return result{}, fail("closure algorithm mismatch")
	}
	authDigest, err := str(auth, "authorization_evidence_digest")
	if err != nil {
		return result{}, err
	}
	got, err = domainHash(dClosureAuthEvidence, without(auth, "authorization_evidence_digest"))
	if err != nil || got != authDigest {
		return result{}, fail("authorization evidence digest mismatch")
	}
	statement, err := obj(auth["statement"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(statement, schemaAuthStatement); err != nil {
		return result{}, err
	}
	if x, _ := str(statement, "election_instance_id"); x != eid {
		return result{}, fail("authorization election mismatch")
	}
	if x, _ := str(statement, "revote_policy_version"); x != revotePolicy {
		return result{}, fail("signed revote policy mismatch")
	}
	if x, _ := str(statement, "finalization_process_id"); x != finalizationProcess {
		return result{}, fail("finalization process mismatch")
	}
	sigText, err := str(auth, "signature_base64url")
	if err != nil {
		return result{}, err
	}
	sig, err := base64.RawURLEncoding.DecodeString(sigText)
	if err != nil || len(sig) != ed25519.SignatureSize {
		return result{}, fail("bad closure signature encoding")
	}
	stmtCanonical, err := canonical(statement)
	if err != nil {
		return result{}, err
	}
	msg := append(append([]byte(dClosureAuth), 0), stmtCanonical...)
	if !ed25519.Verify(publicKey, msg, sig) {
		return result{}, fail("Ed25519 closure signature invalid")
	}

	checkpoint, err := obj(e["closure_ledger_checkpoint"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(checkpoint, schemaCheckpoint); err != nil {
		return result{}, err
	}
	if x, _ := str(checkpoint, "election_instance_id"); x != eid {
		return result{}, fail("checkpoint election mismatch")
	}
	lec, _ := str(checkpoint, "ledger_event_count")
	ls, _ := str(checkpoint, "ledger_seq")
	if lec != ls {
		return result{}, fail("checkpoint count/seq mismatch")
	}
	if !eq(checkpoint, statement["closure_ledger_checkpoint"]) {
		return result{}, fail("signed checkpoint mismatch")
	}
	checkpointDigest, err := domainHash(dCheckpoint, checkpoint)
	if err != nil {
		return result{}, err
	}

	closure, err := obj(e["closure_record"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(closure, schemaClosureRecord); err != nil {
		return result{}, err
	}
	if x, _ := str(closure, "election_instance_id"); x != eid {
		return result{}, fail("closure election mismatch")
	}
	if x, _ := str(closure, "closure_state"); x != "closed" {
		return result{}, fail("not closed")
	}
	if x, _ := str(closure, "closure_checkpoint_digest"); x != checkpointDigest {
		return result{}, fail("closure checkpoint digest mismatch")
	}
	if x, _ := str(closure, "authorization_evidence_digest"); x != authDigest {
		return result{}, fail("closure authorization digest linkage mismatch")
	}
	if x, _ := str(closure, "finalization_policy_version"); x != revotePolicy {
		return result{}, fail("closure policy mismatch")
	}
	if x, _ := str(closure, "finalization_process_id"); x != finalizationProcess {
		return result{}, fail("closure process mismatch")
	}
	closureDigest, err := domainHash(dClosureRecord, closure)
	if err != nil {
		return result{}, err
	}
	if x, _ := str(e, "closure_record_digest"); x != closureDigest {
		return result{}, fail("closure record digest mismatch")
	}

	manifest, err := obj(e["accepted_manifest_at_closure"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(manifest, schemaManifest); err != nil {
		return result{}, err
	}
	if x, _ := str(manifest, "election_instance_id"); x != eid {
		return result{}, fail("manifest election mismatch")
	}
	if x, _ := str(manifest, "crypto_profile"); x != cryptoProfile {
		return result{}, fail("manifest profile mismatch")
	}
	if x, _ := str(manifest, "tally_function_id"); x != tally {
		return result{}, fail("manifest tally mismatch")
	}
	manifestDigest, err := str(manifest, "manifest_digest")
	if err != nil {
		return result{}, err
	}
	got, err = domainHash(dAcceptedManifest, without(manifest, "manifest_digest"))
	if err != nil || got != manifestDigest {
		return result{}, fail("accepted manifest digest mismatch")
	}
	if x, _ := str(checkpoint, "accepted_manifest_digest"); x != manifestDigest {
		return result{}, fail("checkpoint/manifest digest mismatch")
	}
	mlc, err := obj(manifest["ledger_checkpoint"])
	if err != nil {
		return result{}, err
	}
	for _, k := range []string{"ledger_event_count", "ledger_seq", "ledger_event_hash"} {
		if err = requireSameString(checkpoint, k, mlc, k); err != nil {
			return result{}, fail("manifest/checkpoint ledger mismatch")
		}
	}
	acceptedArray, err := arr(manifest["accepted_ballot_digests"])
	if err != nil {
		return result{}, err
	}
	accepted := map[string]bool{}
	for _, v := range acceptedArray {
		s, ok := v.(string)
		if !ok || !isHex64(s) || accepted[s] {
			return result{}, fail("invalid/duplicate accepted digest")
		}
		accepted[s] = true
	}

	cset, err := obj(e["cset_final"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(cset, schemaCSet); err != nil {
		return result{}, err
	}
	if x, _ := str(cset, "election_instance_id"); x != eid {
		return result{}, fail("CSet election mismatch")
	}
	if x, _ := str(cset, "crypto_profile"); x != cryptoProfile {
		return result{}, fail("CSet profile mismatch")
	}
	ordered, err := verifyOrderedHex(cset["ordered_ballot_digests"])
	if err != nil {
		return result{}, err
	}
	for _, d := range ordered {
		if !accepted[d] {
			return result{}, fail("CSet digest not in accepted manifest")
		}
	}
	csetRoot, err := domainHash(dCSetRoot, cset)
	if err != nil {
		return result{}, err
	}
	if x, _ := str(e, "cset_root"); x != csetRoot {
		return result{}, fail("cset_root mismatch")
	}

	env, err := obj(e["final_set_envelope"])
	if err != nil {
		return result{}, err
	}
	if err = requireSchema(env, schemaEnvelope); err != nil {
		return result{}, err
	}
	if x, _ := str(env, "election_instance_id"); x != eid {
		return result{}, fail("envelope election mismatch")
	}
	if x, _ := str(env, "crypto_profile"); x != cryptoProfile {
		return result{}, fail("envelope profile mismatch")
	}
	if x, _ := str(env, "canonicalization_policy_version"); x != canonPolicy {
		return result{}, fail("canonicalization policy mismatch")
	}
	if x, _ := str(env, "tally_function_id"); x != tally {
		return result{}, fail("envelope tally mismatch")
	}
	if !eq(env["ordered_ballot_digests"], cset["ordered_ballot_digests"]) {
		return result{}, fail("envelope/CSet order mismatch")
	}
	if x, _ := str(env, "cset_root"); x != csetRoot {
		return result{}, fail("envelope cset_root mismatch")
	}
	if x, _ := str(env, "closure_record_digest"); x != closureDigest {
		return result{}, fail("envelope closure digest mismatch")
	}
	if err = requireSameString(env, "belenios_election_uuid", cset, "belenios_election_uuid"); err != nil {
		return result{}, err
	}
	if err = requireSameString(env, "belenios_election_fingerprint", cset, "belenios_election_fingerprint"); err != nil {
		return result{}, err
	}
	envDigest, err := domainHash(dEnvelope, env)
	if err != nil {
		return result{}, err
	}
	if x, _ := str(e, "final_set_envelope_digest"); x != envDigest {
		return result{}, fail("FinalSetEnvelope digest mismatch")
	}
	fFinal, err := domainHash(dFFinal, env)
	if err != nil {
		return result{}, err
	}
	if x, _ := str(e, "f_final"); x != fFinal {
		return result{}, fail("F_final mismatch")
	}
	canonicalEvidence, err := canonical(e)
	if err != nil {
		return result{}, err
	}
	return result{Status: "PASS", ElectionInstanceID: eid, EffectiveBallotCount: fmt.Sprintf("%d", len(ordered)), CSetRoot: csetRoot, FFinal: fFinal, PublicEvidenceDigest: publicDigest, CanonicalPublicEvidenceUTF8Base64URL: base64.RawURLEncoding.EncodeToString(canonicalEvidence)}, nil
}

func load(path string) (any, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	return parseJSON(b)
}
func setDigest(m map[string]any, tag, field string) {
	d, _ := domainHash(tag, without(m, field))
	m[field] = d
}
func flipHex(s string) string {
	if s[0] == '0' {
		return "1" + s[1:]
	}
	return "0" + s[1:]
}
func resealPublic(e map[string]any) {
	d, _ := domainHash(dPublicEvidence, without(e, "public_evidence_digest"))
	e["public_evidence_digest"] = d
}

func runMutations(base map[string]any, keyID string, pub ed25519.PublicKey) []mutationReport {
	out := []mutationReport{}
	expectReject := func(name string, e any) {
		_, err := verifyEvidence(e, keyID, pub)
		observed := "REJECT"
		if err == nil {
			observed = "ACCEPT"
		}
		out = append(out, mutationReport{Name: name, Expected: "REJECT", Observed: observed})
	}

	// 1. checkpoint: mutate the exported checkpoint but keep signed statement unchanged; reseal outer digest.
	e := clone(base).(map[string]any)
	cp := e["closure_ledger_checkpoint"].(map[string]any)
	h := cp["ledger_event_hash"].(string)
	cp["ledger_event_hash"] = flipHex(h)
	resealPublic(e)
	expectReject("MUT-I04-CHECKPOINT", e)

	// 2. accepted set: change accepted membership and recompute the manifest's own digest; signed checkpoint still binds original manifest.
	e = clone(base).(map[string]any)
	man := e["accepted_manifest_at_closure"].(map[string]any)
	aa := man["accepted_ballot_digests"].([]any)
	if len(aa) > 0 {
		man["accepted_ballot_digests"] = aa[:len(aa)-1]
	}
	setDigest(man, dAcceptedManifest, "manifest_digest")
	resealPublic(e)
	expectReject("MUT-I04-ACCEPTED-SET", e)

	// 3. CSet order: force descending order where at least two members exist.
	e = clone(base).(map[string]any)
	cs := e["cset_final"].(map[string]any)
	oa := cs["ordered_ballot_digests"].([]any)
	if len(oa) >= 2 {
		oa[0], oa[1] = oa[1], oa[0]
	} else {
		oa = append(oa, "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff")
		cs["ordered_ballot_digests"] = oa
	}
	resealPublic(e)
	expectReject("MUT-I04-CSET-ORDER", e)

	// 4. closure signature: make all downstream digests internally consistent with a bit-flipped signature; only Ed25519 should still reject.
	e = clone(base).(map[string]any)
	au := e["closure_authorization"].(map[string]any)
	sig, _ := base64.RawURLEncoding.DecodeString(au["signature_base64url"].(string))
	sig[0] ^= 1
	au["signature_base64url"] = base64.RawURLEncoding.EncodeToString(sig)
	setDigest(au, dClosureAuthEvidence, "authorization_evidence_digest")
	cr := e["closure_record"].(map[string]any)
	cr["authorization_evidence_digest"] = au["authorization_evidence_digest"]
	crd, _ := domainHash(dClosureRecord, cr)
	e["closure_record_digest"] = crd
	env := e["final_set_envelope"].(map[string]any)
	env["closure_record_digest"] = crd
	ed, _ := domainHash(dEnvelope, env)
	e["final_set_envelope_digest"] = ed
	ff, _ := domainHash(dFFinal, env)
	e["f_final"] = ff
	resealPublic(e)
	expectReject("MUT-I04-CLOSURE-SIGNATURE", e)

	// 5. envelope: switch to another allowed tally id and reseal envelope/F_final/public digest; cross-object binding must reject.
	e = clone(base).(map[string]any)
	env = e["final_set_envelope"].(map[string]any)
	if env["tally_function_id"] == "epd2.pb01.tally.single-choice.v1" {
		env["tally_function_id"] = "epd2.pb01.tally.approval.v1"
	} else {
		env["tally_function_id"] = "epd2.pb01.tally.single-choice.v1"
	}
	ed, _ = domainHash(dEnvelope, env)
	e["final_set_envelope_digest"] = ed
	ff, _ = domainHash(dFFinal, env)
	e["f_final"] = ff
	resealPublic(e)
	expectReject("MUT-I04-FINAL-SET-ENVELOPE", e)

	// 6. F_final: change only F_final and reseal public evidence.
	e = clone(base).(map[string]any)
	e["f_final"] = flipHex(e["f_final"].(string))
	resealPublic(e)
	expectReject("MUT-I04-F-FINAL", e)
	return out
}

func main() {
	vectors := flag.String("vectors", "", "directory containing I04 verifier vectors")
	outPath := flag.String("out", "", "optional JSON report path")
	flag.Parse()
	if *vectors == "" {
		fmt.Fprintln(os.Stderr, "--vectors is required")
		os.Exit(2)
	}
	idxV, err := load(filepath.Join(*vectors, "index.json"))
	if err != nil {
		panic(err)
	}
	idx := idxV.(map[string]any)
	keyID := idx["key_id"].(string)
	jwk := idx["public_jwk"].(map[string]any)
	x, err := base64.RawURLEncoding.DecodeString(jwk["x"].(string))
	if err != nil || len(x) != ed25519.PublicKeySize {
		panic("invalid Ed25519 JWK")
	}
	pub := ed25519.PublicKey(x)
	cases := idx["cases"].([]any)
	rep := report{SchemaVersion: "epd2.pb01.i04-cross-language-verifier-report/1", Status: "PASS", Implementation: "Go 1.23 stdlib independent Verifier B reference", ProducerCodeImports: false, ByteForByteAgreement: true}
	var mutationBase map[string]any
	for _, cv := range cases {
		c := cv.(map[string]any)
		file := c["file"].(string)
		vv, err := load(filepath.Join(*vectors, file))
		if err != nil {
			panic(err)
		}
		v := vv.(map[string]any)
		ev := v["public_evidence"]
		got, err := verifyEvidence(ev, keyID, pub)
		vr := vectorReport{Case: v["case"].(string), Status: "PASS", ByteForByteAgreement: true}
		if err != nil {
			vr.Status = "FAIL: " + err.Error()
			rep.Status = "FAIL"
			rep.ByteForByteAgreement = false
		} else {
			prodCanon := v["producer_canonical_public_evidence_utf8_base64url"].(string)
			pr := v["producer_result"].(map[string]any)
			if got.CanonicalPublicEvidenceUTF8Base64URL != prodCanon || got.CSetRoot != pr["cset_root"] || got.FFinal != pr["f_final"] || got.PublicEvidenceDigest != pr["public_evidence_digest"] {
				vr.Status = "FAIL: byte agreement"
				vr.ByteForByteAgreement = false
				rep.Status = "FAIL"
				rep.ByteForByteAgreement = false
			}
			vr.CSetRoot = got.CSetRoot
			vr.FFinal = got.FFinal
			vr.PublicEvidenceDigest = got.PublicEvidenceDigest
		}
		rep.Vectors = append(rep.Vectors, vr)
		if v["case"] == "three-lifecycles-mixed-revotes" {
			mutationBase = clone(ev).(map[string]any)
		}
	}
	if mutationBase == nil {
		panic("missing mutation base vector")
	}
	rep.Mutations = runMutations(mutationBase, keyID, pub)
	for _, m := range rep.Mutations {
		if m.Observed != "REJECT" {
			rep.Status = "FAIL"
		}
	}
	b, _ := json.MarshalIndent(rep, "", "  ")
	b = append(b, '\n')
	if *outPath != "" {
		if err = os.WriteFile(*outPath, b, 0644); err != nil {
			panic(err)
		}
	}
	os.Stdout.Write(b)
	if rep.Status != "PASS" {
		os.Exit(1)
	}
}
