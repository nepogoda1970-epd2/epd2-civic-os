module epd2/i04-verifier-b-reference

go 1.23
