import { createPublicKey } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ballotDigest } from '../src/i02_accepted/shared/profile.mjs';
import { verifyPublicFinalEvidence } from '../src/i04/finalization.mjs';
import { ClosureAuthorizationVerifier } from '../src/i04/closure_authority.mjs';
import { verifyTallyEvidence } from '../src/i05/tally.mjs';
import { BeleniosHomomorphicAggregator } from '../src/i05/belenios_aggregator.mjs';

export async function verifyI05Vector({ vector, closurePublicJwk, aggregator, electionDir }) {
  const closureKeyId = vector.i04_public_evidence.closure_authorization.key_id;
  const authorizationVerifier = new ClosureAuthorizationVerifier(new Map([[closureKeyId, createPublicKey({ key: closurePublicJwk, format: 'jwk' })]]));
  const i04 = verifyPublicFinalEvidence(vector.i04_public_evidence, { authorizationVerifier });
  if (!i04.valid) throw new Error('FINALIZATION_INTEGRITY_FAILURE');
  const tally = verifyTallyEvidence(vector.tally_evidence_bundle);
  if (tally.f_final !== i04.f_final) throw new Error('FINAL_SET_MISMATCH');
  const wanted = vector.i04_public_evidence.cset_final.ordered_ballot_digests;
  if (JSON.stringify(vector.tally_evidence_bundle.ordered_ballot_digests) !== JSON.stringify(wanted)) throw new Error('FINAL_SET_MISMATCH');
  if (vector.exact_ballots.length !== wanted.length) throw new Error('FINAL_SET_MISMATCH');
  const bytes = [];
  for (let i = 0; i < vector.exact_ballots.length; i += 1) {
    const item = vector.exact_ballots[i];
    if (item.ballot_digest !== wanted[i]) throw new Error('FINAL_SET_MISMATCH');
    if (ballotDigest(vector.election_context, item.encrypted_ballot_base64url) !== item.ballot_digest) throw new Error('BALLOT_DIGEST_MISMATCH');
    const raw = Buffer.from(item.encrypted_ballot_base64url, 'base64url');
    await aggregator.verifyBallot({ electionDir, ballotBytes: raw });
    bytes.push(raw);
  }
  const recomputed = await aggregator.aggregate({ orderedBallotBytes: bytes });
  const expected = Buffer.from(vector.expected_aggregate_ciphertext_base64url, 'base64url');
  if (!recomputed.aggregateBytes.equals(expected)) throw new Error('AGGREGATE_BYTE_MISMATCH');
  if (tally.aggregate_ciphertext_digest !== vector.expected_aggregate_ciphertext_digest) throw new Error('AGGREGATE_DIGEST_MISMATCH');
  if (tally.tally_record_digest !== vector.expected_tally_record_digest) throw new Error('TALLY_RECORD_DIGEST_MISMATCH');
  return { status: 'PASS', case: vector.case, f_final: tally.f_final, tally_record_digest: tally.tally_record_digest, aggregate_ciphertext_digest: tally.aggregate_ciphertext_digest, byte_for_byte_agreement: true };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const index = JSON.parse(await readFile(join(root, 'test-vectors/i05/index.json'), 'utf8'));
  const aggregator = new BeleniosHomomorphicAggregator({
    toolPath: join(root, 'evidence/build/belenios-tool-3.3.0-linux-x86_64'),
    baseElectionArchivePath: join(root, `evidence/fixtures/i05-election/${index.election_context.belenios_election_uuid}.bel`),
  });
  const results = [];
  for (const c of index.cases) {
    const vector = JSON.parse(await readFile(join(root, 'test-vectors/i05/vectors', c.file), 'utf8'));
    results.push(await verifyI05Vector({ vector, closurePublicJwk: index.closure_public_jwk, aggregator, electionDir: join(root, 'evidence/fixtures/i05-election') }));
  }
  process.stdout.write(`${JSON.stringify({ schema_version: 'epd2.pb01.i05-verifier-a-report/1', status: 'PASS', implementation: 'Node producer-language Verifier A + pinned native Belenios 3.3.0', vectors: results }, null, 2)}\n`);
}
