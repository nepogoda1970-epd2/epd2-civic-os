# Mutation and negative results

All previously accepted I03/I04 negative and tamper evidence remains unchanged.

Candidate `0.2_C1` adds the independent cross-language Verifier B mutation battery required to close the verifier gap. The executed Go reference verifier rejected all six targeted composition mutations:

- `MUT-I04-CHECKPOINT` — modified closure checkpoint;
- `MUT-I04-ACCEPTED-SET` — modified accepted manifest/set with its local manifest digest recomputed;
- `MUT-I04-CSET-ORDER` — non-canonical `CSet_final` order;
- `MUT-I04-CLOSURE-SIGNATURE` — bit-flipped Ed25519 signature with downstream evidence digests resealed;
- `MUT-I04-FINAL-SET-ENVELOPE` — modified but locally rehashed envelope;
- `MUT-I04-F-FINAL` — modified `F_final` with public evidence digest resealed.

Observed result for every case: `REJECT`. See `evidence/results/i04-cross-language-verifier.json` and `.tap`.
