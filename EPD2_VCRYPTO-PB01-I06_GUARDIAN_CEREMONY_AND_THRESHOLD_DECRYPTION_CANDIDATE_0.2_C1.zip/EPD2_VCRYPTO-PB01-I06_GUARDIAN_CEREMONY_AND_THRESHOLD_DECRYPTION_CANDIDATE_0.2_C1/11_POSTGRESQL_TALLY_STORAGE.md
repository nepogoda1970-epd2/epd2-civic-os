# PostgreSQL Tally Storage

Migrations `005_i05_tally.sql` and `006_i05_roles.sql` add `pb01_i05.aggregates`, `tally_records`, append-only audit events, mutation-reject triggers, and the public evidence view. Commit uses a SERIALIZABLE transaction plus an election advisory lock, verifies the authoritative finalized I04 `f_final`, writes aggregate then record atomically, and rolls back on CRASH-03. `PostgresTallyStore.backupTo()` produces a custom-format `pg_dump` under an administrative credential, mirroring the accepted I03/I04 stores.

**Runtime status:** executed and verified against PostgreSQL 16.14 with `fsync=on`, `synchronous_commit=on`, `full_page_writes=on`. Migrations `001`–`006` apply under `ON_ERROR_STOP=1`; the four-file PostgreSQL suite is 15/15 pass, exit 0. See `evidence/results/i05/postgres-runtime.json` and the raw log `evidence/results/i05/postgres-suite-run.txt`.

Operational note: `commit()` performs no SQLSTATE `40001` retry. Under more than two concurrent executions a caller may receive a serialization failure; no divergent tally is ever committed and a retry converges on the identical record. Tracked as `PB01-DEBT-I05-PG-SERIALIZATION-RETRY-01`.
