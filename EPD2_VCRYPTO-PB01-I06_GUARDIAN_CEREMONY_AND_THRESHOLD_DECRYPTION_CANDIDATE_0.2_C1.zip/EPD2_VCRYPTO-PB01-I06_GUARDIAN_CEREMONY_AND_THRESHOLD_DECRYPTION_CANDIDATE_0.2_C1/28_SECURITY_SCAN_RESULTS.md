# Security Scan Results

The I05 runtime/fixture secret scan finds no embedded decryption or guardian private material. Vector regeneration requires an externally supplied test closure JWK. `node --check` passes across all shipped ES modules and `go vet` passes on the Go verifier. The dependency set is inherited and pinned; Belenios is byte-identical to I04 and the crypto patch count is zero. SBOM carries I05 CycloneDX metadata and Go verifier provenance.

`npm audit` was network-blocked in the `0.1` environment. It has now been executed: **exit code 0, 0 vulnerabilities across 18 audited dependencies** (`evidence/results/i05/npm-audit.json`). The security-scan gate is therefore `PASS` rather than `PARTIAL_ENVIRONMENT_BOUNDED`.
