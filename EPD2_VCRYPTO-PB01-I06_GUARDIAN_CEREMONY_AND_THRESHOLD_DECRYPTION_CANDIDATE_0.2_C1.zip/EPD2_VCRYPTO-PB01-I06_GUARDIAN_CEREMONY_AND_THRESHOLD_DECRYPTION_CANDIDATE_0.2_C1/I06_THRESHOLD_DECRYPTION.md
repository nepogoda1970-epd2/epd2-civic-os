# Threshold Decryption

I06 accepts only an election reference. It resolves the authoritative I05 tally internally and runs I05 `recompute()` before any share acceptance or decryption attempt.

A public guardian contribution is first stored only as **pending**. It is not counted as an accepted share merely because a client supplied it. When at least T distinct pending guardian contributions exist, I06 passes exactly a threshold-capable set to pinned Belenios 3.3.0 `compute-result`; Belenios validates the partial-decryption proofs and reconstructs the plaintext result. Only if that cryptographic verification succeeds are the shares atomically promoted to accepted and the immutable final record committed.

Before threshold, state is `NOT_DECRYPTED` and no plaintext is exposed. At completion the state is:

`CRYPTOGRAPHICALLY_DECRYPTED_NOT_YET_PUBLISHED`

Extra valid shares may be recorded after completion only after Belenios verification with a threshold-capable set and only if they reproduce the already committed exact plaintext bytes. They do not alter the result.

The N=5/T=3 vector explicitly verifies that guardians 1/2/3, guardians 3/4/5, and all five valid shares reconstruct the same plaintext.


`guardian-side/partial_decrypt.sh` is the corresponding guardian-side reference wrapper for Belenios `election decrypt-threshold`. It reads one guardian's own `.key/.dkey` locally and emits only the public partial-decryption/proof JSON that the I06 ingester accepts. The application runtime never receives the private files.
