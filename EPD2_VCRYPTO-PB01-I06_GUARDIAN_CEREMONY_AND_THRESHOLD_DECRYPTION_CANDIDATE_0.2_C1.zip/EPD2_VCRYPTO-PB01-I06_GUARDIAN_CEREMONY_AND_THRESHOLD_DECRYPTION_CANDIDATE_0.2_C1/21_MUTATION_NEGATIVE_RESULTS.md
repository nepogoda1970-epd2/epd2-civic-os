# Mutation Negative Results

Independent Verifier B machine-tests I05-N01 through I05-N12: remove final ballot; add superseded; add foreign/extra; change ballot bytes; change digest; change CSet order; change cset root; change `F_final`; change aggregate ciphertext; change aggregate digest; change input manifest; change tally record digest. **12/12 rejected.** I04 checkpoint/manifest/CSet/signature/envelope/`F_final` verification is also executed for every I05 vector by the independent Go path.
