# Idempotency

`Idempotency-Key` is mandatory. Only an HMAC-derived key hash is stored. The
semantic request hash commits the accepted I02 artifact and private lifecycle
handle.

- same key + same request: identical stored receipt, no new event;
- same key + different request/lifecycle: `409 IDEMPOTENCY_CONFLICT`;
- same digest + new key + same lifecycle/exact bytes: same receipt, new key map,
  no event;
- same digest under a different lifecycle: rejected;
- new valid randomized ballot under the same lifecycle: new immutable acceptance.

Concurrent tests prove one submission/event for retry races and two submissions
for legitimate concurrent revotes.
