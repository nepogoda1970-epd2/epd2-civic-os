# Native verification boundary

The service writes the received, decoded ballot bytes to a mode-0600 temporary
file and invokes the hash-pinned Belenios 3.3.0 native command:

`belenios-tool election verify-ballot --dir=<pinned election> --ballot=<exact file>`

Acceptance requires the upstream `ballot is valid` result. The temporary file
is removed in `finally`. The verifier has a 120-second upper bound and a
four-operation concurrency semaphore. The accepted I02 verification semantics
and binary are unchanged; no JavaScript reimplementation is accepted as the
server authority.
