# Rate and resource limits

Defaults:

- request body: 1,500,000 bytes;
- decoded ballot: 1,048,576 bytes;
- JSON nesting: 32;
- request read timeout: 15 seconds;
- native verification timeout: 120 seconds;
- concurrent native verifications: 4;
- submission/lookup/invalid fixed-window limits: 30/120/20 per minute/client.

Body length, UTF-8, schema, election binding and digest checks precede expensive
proof verification. Windows reset, so a voter is not permanently locked out.
Multi-instance production must put equivalent shared controls at the security
edge; correctness remains authoritative even when throttling state is lost.
