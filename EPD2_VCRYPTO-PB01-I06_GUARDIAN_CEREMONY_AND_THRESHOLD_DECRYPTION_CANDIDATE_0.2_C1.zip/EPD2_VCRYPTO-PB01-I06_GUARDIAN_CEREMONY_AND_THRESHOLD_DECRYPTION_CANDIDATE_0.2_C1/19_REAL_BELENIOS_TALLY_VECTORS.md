# Real Belenios Tally Vectors

- I05-V01: one final ballot.
- I05-V02: three independent final ballots.
- I05-V03: three lifecycles with A1→A2, B1, C1→C2→C3; exact effective set A2/B1/C3.
- I05-V04: empty final set; upstream identity aggregate.

Each vector contains I04 final evidence, exact ballot bytes (base64url), expected exact upstream aggregate bytes, aggregate digest, tally input digest, tally record digest and I06 handoff example. V02 and V03 produce identical aggregate bytes because their effective final ciphertext set is exactly the same.
