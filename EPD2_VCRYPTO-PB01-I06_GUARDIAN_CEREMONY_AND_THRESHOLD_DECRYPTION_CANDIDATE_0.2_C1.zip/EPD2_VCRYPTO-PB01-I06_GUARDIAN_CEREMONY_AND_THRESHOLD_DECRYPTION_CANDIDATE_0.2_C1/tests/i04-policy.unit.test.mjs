import assert from "node:assert/strict";
import test from "node:test";
import { resolveLatestValid } from "../src/i04/finalization.mjs";

const electionId = "ei1_0123456789abcdef0123456789abcdef";

function row({ id, digest, seq, lifecycle = "a".repeat(64) }) {
  return {
    submission_id: id,
    ballot_digest: digest,
    ledger_seq: String(seq),
    lifecycle_handle: lifecycle,
    lifecycle_election_instance_id: electionId,
  };
}

test("latest-valid ordering is stable across input permutations", () => {
  const rows = [
    row({ id: "00000000-0000-4000-8000-000000000001", digest: "1".repeat(64), seq: 1 }),
    row({ id: "00000000-0000-4000-8000-000000000002", digest: "2".repeat(64), seq: 2 }),
    row({ id: "00000000-0000-4000-8000-000000000003", digest: "3".repeat(64), seq: 3 }),
    row({ id: "00000000-0000-4000-8000-000000000004", digest: "4".repeat(64), seq: 4 }),
  ];
  for (let iteration = 0; iteration < 50; iteration += 1) {
    const rotated = rows.slice(iteration % rows.length).concat(rows.slice(0, iteration % rows.length));
    if (iteration % 2) rotated.reverse();
    const resolved = resolveLatestValid({ electionInstanceId: electionId, rows: rotated, resolvedAt: "2026-08-17T21:30:00Z" });
    assert.equal(resolved[0].effective_submission_id, rows[3].submission_id);
    assert.deepEqual(resolved[0].candidate_submission_ids, rows.map((entry) => entry.submission_id));
  }
});

test("missing or cross-election lifecycle binding fails closed", () => {
  const missing = row({ id: "00000000-0000-4000-8000-000000000001", digest: "1".repeat(64), seq: 1, lifecycle: null });
  assert.throws(() => resolveLatestValid({ electionInstanceId: electionId, rows: [missing], resolvedAt: "2026-08-17T21:30:00Z" }), /LIFECYCLE_INTEGRITY_FAILURE/u);
  const foreign = row({ id: "00000000-0000-4000-8000-000000000001", digest: "1".repeat(64), seq: 1 });
  foreign.lifecycle_election_instance_id = "ei1_ffffffffffffffffffffffffffffffff";
  assert.throws(() => resolveLatestValid({ electionInstanceId: electionId, rows: [foreign], resolvedAt: "2026-08-17T21:30:00Z" }), /LIFECYCLE_INTEGRITY_FAILURE/u);
});
