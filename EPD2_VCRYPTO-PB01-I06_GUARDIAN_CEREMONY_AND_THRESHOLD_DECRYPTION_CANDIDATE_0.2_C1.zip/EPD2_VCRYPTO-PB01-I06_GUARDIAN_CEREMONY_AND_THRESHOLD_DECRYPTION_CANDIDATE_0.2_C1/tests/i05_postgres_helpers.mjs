import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import pg from 'pg';
import { adminPool, adminUrl } from './postgres_helpers.mjs';
import { root } from './helpers.mjs';
const { Pool }=pg;
function required(n){const v=process.env[n];if(!v)throw new Error(`required I05 PostgreSQL test environment missing: ${n}`);return v;}
export const tallyUrl=required('EPD2_I05_PG_TALLY_URL');
export const i05EvidenceUrl=required('EPD2_I05_PG_EVIDENCE_URL');
export async function applyI05Migrations(){const p=await adminPool();try{await p.query('DROP SCHEMA IF EXISTS pb01_i05 CASCADE');await p.query(await readFile(join(root,'migrations/postgresql/005_i05_tally.sql'),'utf8'));await p.query(await readFile(join(root,'migrations/postgresql/006_i05_roles.sql'),'utf8'));}finally{await p.end();}}
export async function rolePool(url){const p=new Pool({connectionString:url,ssl:false,max:3});p.on('error',()=>{});await p.query('SELECT 1');return p;}

// --- 0.2_C1 additions: real-PostgreSQL acceptance support (no in-memory doubles) ---

import { canonicalize } from '../src/i02_accepted/shared/profile.mjs';
import { BeleniosHomomorphicAggregator } from '../src/i05/belenios_aggregator.mjs';
import { PostgresTallyStore } from '../src/i05/postgres_tally_store.mjs';
import { TallyEngine } from '../src/i05/tally.mjs';
import { createPostgresHarness } from './postgres_helpers.mjs';
import { createI04Harness } from './i04_postgres_helpers.mjs';
import { realBrowserArtifact, realVectorArtifact, submissionHeaders, toolPath } from './helpers.mjs';

export const pgCtlPath=process.env.EPD2_I05_PG_CTL_PATH ?? null;
export const pgDataDir=process.env.EPD2_I05_PG_DATA_DIR ?? null;
export const pgStartOptions=process.env.EPD2_I05_PG_START_OPTIONS ?? '';
export const pgDumpPath=required('EPD2_I03_PG_DUMP_PATH');
export const pgPort=required('EPD2_I03_PG_PORT');

export function runProcess(command,args,env=process.env){
  return new Promise((resolve,reject)=>{
    const child=spawn(command,args,{env,stdio:['ignore','pipe','pipe']});
    const out=[],err=[];
    child.stdout.on('data',(c)=>out.push(c));
    child.stderr.on('data',(c)=>err.push(c));
    child.once('error',reject);
    child.once('exit',(code)=>code===0
      ? resolve(Buffer.concat(out).toString('utf8'))
      : reject(new Error(`${command} exit ${code}: ${Buffer.concat(err).toString('utf8').trim()}`)));
  });
}

/** Hard crash + restart of the production PostgreSQL server (immediate mode, no clean shutdown). */
export async function crashRestartPostgres(){
  if(!pgCtlPath||!pgDataDir) throw new Error('EPD2_I05_PG_CTL_PATH and EPD2_I05_PG_DATA_DIR are required for restart-persistence coverage');
  await runProcess(pgCtlPath,['-D',pgDataDir,'-m','immediate','stop']);
  await runProcess(pgCtlPath,['-D',pgDataDir,'-o',pgStartOptions,'-l',join(pgDataDir,'restart.log'),'-w','start']);
}

export function tallyStore({max=8,backup=false}={}){
  // Backup is an operator/administrator capability, exactly as in the accepted I04 harness:
  // pg_dump runs with the administrative credential, never with the least-privilege tally role.
  const admin=new URL(adminUrl);
  return new PostgresTallyStore({
    connectionString:tallyUrl,ssl:false,max,application_name:'epd2-pb01-i05-postgres-test-tally',
    backup:backup?{pgDumpPath,host:admin.hostname,port:Number(pgPort),database:admin.pathname.slice(1),
      user:admin.username,password:decodeURIComponent(admin.password)}:null,
  });
}

export function aggregatorFor(i03,{onInvocation=null}={}){
  const ctx=i03.fixtures.a.context;
  return new BeleniosHomomorphicAggregator({
    toolPath,
    baseElectionArchivePath:join(i03.fixtures.a.electionDir,`${ctx.belenios_election_uuid}.bel`),
    onInvocation,
  });
}

export function engineFor({i03,i04,store,failpoint=null,onInvocation=null,finalizationStore=null}){
  return new TallyEngine({
    finalizationStore:finalizationStore ?? i04.store,
    tallyStore:store,
    aggregator:aggregatorFor(i03,{onInvocation}),
    electionDir:i03.fixtures.a.electionDir,
    authorizationVerifier:i04.authorizationVerifier,
    failpoint,
  });
}

async function accept(i03,artifact,key,token=i03.token){
  const r=await fetch(`${i03.baseUrl}/v1/elections/${i03.fixtures.a.context.election_instance_id}/encrypted-ballots`,
    {method:'POST',headers:submissionHeaders(token,key),body:canonicalize(artifact)});
  assert.equal(r.status,201);
  return r.json();
}

/**
 * Builds the real I03 -> I04 -> I05 production chain on PostgreSQL:
 * accepted browser-produced ballot(s), authorized closure, finalized I04 set, I05 schema applied.
 * Nothing here is stubbed; every store is the production PostgreSQL implementation.
 */
export async function finalizedFixture(t,{ballots=1}={}){
  const i03=await createPostgresHarness();
  t.after(i03.cleanup);
  const eid=i03.fixtures.a.context.election_instance_id;
  await accept(i03,await realBrowserArtifact(),'i05-c1-accept-0001');
  if(ballots>1){
    const second=await realVectorArtifact(i03.fixtures.a.context,'I02-P02.json');
    const auth2=i03.credentialAuthority.issue({
      electionInstanceId:eid,
      lifecycleNonce:'3123456789abcdef0123456789abcdef',
      expiresAt:'2030-01-01T00:00:00Z',
      revoteAllowed:true,
    });
    await accept(i03,second,'i05-c1-accept-0002',auth2.scoped_credential.secret);
  }
  const i04=await createI04Harness();
  t.after(i04.cleanup);
  const preview=await i04.store.previewClosure(eid);
  const auth=await i04.authorizePreview(eid,preview);
  const fin=await i04.store.finalize({electionInstanceId:eid,authorizationEvidence:auth,authorizationVerifier:i04.authorizationVerifier});
  await applyI05Migrations();
  return {i03,i04,eid,fin};
}
