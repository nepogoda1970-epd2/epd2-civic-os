import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import pg from "pg";
import { canonicalize } from "../src/i02_accepted/shared/profile.mjs";
import { verifyPublicFinalEvidence } from "../src/i04/finalization.mjs";
import { createPostgresHarness, adminPool, adminUrl, createdbPath, dropdbPath, pgRestorePath } from "./postgres_helpers.mjs";
import { createI04Harness, finalizerUrl, i04EvidenceUrl, rolePool, submissionUrl } from "./i04_postgres_helpers.mjs";
import { realBrowserArtifact, realVectorArtifact, submissionHeaders } from "./helpers.mjs";

const { Pool } = pg;

function run(command, args, env = process.env) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { env, stdio: ["ignore", "pipe", "pipe"] });
    const stderr = [];
    child.stderr.on("data", (chunk) => stderr.push(chunk));
    child.once("error", reject);
    child.once("exit", (code) => code === 0 ? resolve() : reject(new Error(Buffer.concat(stderr).toString("utf8"))));
  });
}

async function accept(i03, artifact, key, token = i03.token) {
  const response = await fetch(`${i03.baseUrl}/v1/elections/${i03.fixtures.a.context.election_instance_id}/encrypted-ballots`, {
    method: "POST",
    headers: submissionHeaders(token, key),
    body: canonicalize(artifact),
  });
  assert.equal(response.status, 201);
  return response.json();
}

async function finalizedTwoLifecycleHarness(t) {
  const i03 = await createPostgresHarness();
  t.after(i03.cleanup);
  const first = await realBrowserArtifact();
  const second = await realVectorArtifact(i03.fixtures.a.context, "I02-P02.json");
  const auth2 = i03.credentialAuthority.issue({
    electionInstanceId: i03.fixtures.a.context.election_instance_id,
    lifecycleNonce: "3123456789abcdef0123456789abcdef",
    expiresAt: "2030-01-01T00:00:00Z",
    revoteAllowed: true,
  });
  await accept(i03, first, "i04-tamper-first-0001");
  await accept(i03, second, "i04-tamper-second-0001", auth2.scoped_credential.secret);
  const i04 = await createI04Harness();
  t.after(i04.cleanup);
  const electionId = i03.fixtures.a.context.election_instance_id;
  const preview = await i04.store.previewClosure(electionId);
  const authorization = await i04.authorizePreview(electionId, preview);
  const finalized = await i04.store.finalize({ electionInstanceId: electionId, authorizationEvidence: authorization, authorizationVerifier: i04.authorizationVerifier });
  return { i03, i04, electionId, finalized };
}

test("I04 public verifier detects every committed-field tamper class", async (t) => {
  const { i04, finalized } = await finalizedTwoLifecycleHarness(t);
  const original = finalized.public_evidence;
  const mutations = [
    (x) => { x.cset_final.ordered_ballot_digests[0] = "0".repeat(64); },
    (x) => { x.cset_final.ordered_ballot_digests.pop(); },
    (x) => { x.cset_final.ordered_ballot_digests.push("1".repeat(64)); },
    (x) => { x.cset_final.ordered_ballot_digests.reverse(); },
    (x) => { x.closure_ledger_checkpoint.ledger_event_hash = "2".repeat(64); },
    (x) => { x.revote_policy_version = "epd2.pb01.revote.unknown.v1"; },
    (x) => { x.cset_root = "3".repeat(64); },
    (x) => { x.final_set_envelope.cset_root = "4".repeat(64); },
    (x) => { x.f_final = "5".repeat(64); },
  ];
  for (const mutate of mutations) {
    const changed = structuredClone(original);
    mutate(changed);
    assert.throws(() => verifyPublicFinalEvidence(changed, { authorizationVerifier: i04.authorizationVerifier }), /FINAL_SET_TAMPER_DETECTED|UNKNOWN_REVOTE_POLICY/u);
  }
});

test("I04 refuses finalization when I03 ledger integrity has been altered", async (t) => {
  const i03 = await createPostgresHarness();
  t.after(i03.cleanup);
  await accept(i03, await realBrowserArtifact(), "i04-ledger-tamper-0001");
  const i04 = await createI04Harness();
  t.after(i04.cleanup);
  const pool = await adminPool();
  try {
    await pool.query("ALTER TABLE pb01_i03.submission_ledger_events DISABLE TRIGGER USER");
    await pool.query("UPDATE pb01_i03.submission_ledger_events SET event_hash = repeat('f', 64)");
    await pool.query("ALTER TABLE pb01_i03.submission_ledger_events ENABLE TRIGGER USER");
  } finally {
    await pool.end();
  }
  const electionId = i03.fixtures.a.context.election_instance_id;
  await assert.rejects(i04.store.previewClosure(electionId), (error) => error.code === "LEDGER_INTEGRITY_FAILURE");
});

test("I04 PostgreSQL roles enforce submission/finalizer/evidence/migration separation", async (t) => {
  const { i04, electionId, finalized } = await finalizedTwoLifecycleHarness(t);
  assert.equal(i04.privilegeEvidence.validation, "PASS_FINALIZER_LEAST_PRIVILEGE");
  const submission = await rolePool(submissionUrl);
  const finalizer = await rolePool(finalizerUrl);
  const evidence = await rolePool(i04EvidenceUrl);
  t.after(async () => Promise.all([submission.end(), finalizer.end(), evidence.end()]));
  const checks = await Promise.all([
    submission.query("SELECT has_schema_privilege(current_user, 'pb01_i04', 'USAGE') AS allowed"),
    finalizer.query("SELECT has_table_privilege(current_user, 'pb01_i03.encrypted_submissions', 'UPDATE,DELETE,TRUNCATE') AS allowed"),
    evidence.query("SELECT has_table_privilege(current_user, 'pb01_i04.finalizations', 'INSERT,UPDATE,DELETE,TRUNCATE') AS allowed"),
    finalizer.query("SELECT has_schema_privilege(current_user, 'pb01_i04', 'CREATE') AS allowed"),
  ]);
  assert.deepEqual(checks.map((result) => result.rows[0].allowed), [false, false, false, false]);
  await assert.rejects(submission.query("INSERT INTO pb01_i04.finalization_audit_events(audit_event_id,event_code,occurred_at,detail_canonical) VALUES(gen_random_uuid(),'X',now(),'{}')"));
  await assert.rejects(finalizer.query("UPDATE pb01_i03.encrypted_submissions SET encrypted_ballot_bytes = ''::bytea WHERE election_instance_id = $1", [electionId]));
  await assert.rejects(finalizer.query("DELETE FROM pb01_i04.finalizations WHERE election_instance_id = $1", [electionId]));
  await assert.rejects(evidence.query("UPDATE pb01_i04.finalizations SET f_final = repeat('0',64) WHERE election_instance_id = $1", [electionId]));
  const publicRow = await evidence.query("SELECT f_final FROM pb01_i04.public_finalizations WHERE election_instance_id = $1", [electionId]);
  assert.equal(publicRow.rows[0].f_final, finalized.f_final);
});

test("I04 backup/restore preserves exact I03 history and identical final artifacts", async (t) => {
  const { i04, electionId, finalized } = await finalizedTwoLifecycleHarness(t);
  const temporary = await mkdtemp(join(tmpdir(), "epd2-i04-backup-"));
  t.after(() => rm(temporary, { recursive: true, force: true }));
  const dump = join(temporary, "i04.dump");
  await i04.store.backupTo(dump);
  const restoredDb = `epd2_i04_restore_${process.pid}`;
  const source = new URL(adminUrl);
  const args = ["-h", source.hostname, "-p", source.port, "-U", source.username];
  await run(dropdbPath, [...args, "--if-exists", restoredDb]);
  await run(createdbPath, [...args, restoredDb]);
  t.after(() => run(dropdbPath, [...args, "--if-exists", "--force", restoredDb]));
  await run(pgRestorePath, [...args, "--no-owner", "--no-privileges", "-d", restoredDb, dump]);
  const restoredUrl = new URL(adminUrl);
  restoredUrl.pathname = `/${restoredDb}`;
  const restored = new Pool({ connectionString: restoredUrl.toString(), ssl: false });
  const restoredFinal = await restored.query("SELECT f_final, cset_root, public_evidence_digest FROM pb01_i04.finalizations WHERE election_instance_id = $1", [electionId]);
  assert.deepEqual(restoredFinal.rows[0], {
    f_final: finalized.f_final,
    cset_root: finalized.cset_root,
    public_evidence_digest: finalized.public_evidence_digest,
  });
  const sourceBytes = await i04.store.exactFinalBallotBytes(electionId);
  const restoredBytes = await restored.query(`
    SELECT es.canonical_ordinal, es.ballot_digest, s.encrypted_ballot_bytes
    FROM pb01_i04.effective_submissions es
    JOIN pb01_i03.encrypted_submissions s ON s.submission_id = es.submission_id
    WHERE es.election_instance_id = $1 ORDER BY es.canonical_ordinal
  `, [electionId]);
  assert.deepEqual(restoredBytes.rows.map((row) => ({
    canonical_ordinal: String(row.canonical_ordinal),
    ballot_digest: row.ballot_digest,
    encrypted_ballot_bytes: Buffer.from(row.encrypted_ballot_bytes),
  })), sourceBytes);
  await restored.end();
});
