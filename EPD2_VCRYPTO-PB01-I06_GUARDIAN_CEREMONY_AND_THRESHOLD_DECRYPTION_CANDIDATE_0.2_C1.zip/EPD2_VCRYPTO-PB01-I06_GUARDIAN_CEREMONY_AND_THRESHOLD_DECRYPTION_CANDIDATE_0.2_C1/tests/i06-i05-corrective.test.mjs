import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { root, toolPath } from './helpers.mjs';
import { TallyEngine } from '../src/i05/tally.mjs';
import { BeleniosHomomorphicAggregator } from '../src/i05/belenios_aggregator.mjs';
import { ThresholdDecryptionEngine } from '../src/i06/decryption.mjs';

const vector = JSON.parse(await readFile(join(root, 'test-vectors/i05/vectors/I05-V03-revotes-effective-final-set.json'), 'utf8'));
const finalization = { ...vector.i04_public_evidence };
class FinalStore {
  async recompute(){ return { status: 'PASS' }; }
  async readFinalization(){ return finalization; }
  async authorizedFinalBallotSet(){ return vector.authorized_final_ballot_set; }
  async exactFinalBallotBytes(){ return vector.exact_ballots.map(x => ({ ballot_digest: x.ballot_digest, encrypted_ballot_bytes: Buffer.from(x.encrypted_ballot_base64url, 'base64url') })); }
  async getElection(){ return { context_json: vector.election_context }; }
}
class FullMemTallyStore {
  constructor(){ this.row = null; }
  async commit({ fFinal, artifacts, aggregate }) {
    this.row = {
      f_final: fFinal,
      tally_record_digest: artifacts.tallyRecordDigest,
      aggregate_ciphertext_digest: artifacts.homomorphicTallyRecord.aggregate_ciphertext_digest,
      tally_input_digest: artifacts.tallyInputDigest,
      aggregate_ciphertext_bytes: Buffer.from(aggregate.aggregateBytes),
      tally_evidence_bundle: structuredClone(artifacts.tallyEvidenceBundle),
    };
    return { ...this.row, replay: false };
  }
  async read(){ return this.row; }
}
function makeEngine(store){
  return new TallyEngine({
    finalizationStore: new FinalStore(),
    tallyStore: store,
    aggregator: new BeleniosHomomorphicAggregator({
      toolPath,
      baseElectionArchivePath: join(root, `evidence/fixtures/i05-election/${vector.election_context.belenios_election_uuid}.bel`),
    }),
    electionDir: join(root, 'evidence/fixtures/i05-election'),
  });
}

test('I05 corrective recomputes digest from persisted aggregate bytes and I06 refuses byte-only mutation before ceremony access', async () => {
  const store = new FullMemTallyStore();
  const i05 = makeEngine(store);
  await i05.execute(vector.election_context.election_instance_id);
  assert.equal((await i05.recompute(vector.election_context.election_instance_id)).status, 'PASS');
  store.row.aggregate_ciphertext_bytes = Buffer.concat([store.row.aggregate_ciphertext_bytes, Buffer.from(' ')]);
  await assert.rejects(i05.recompute(vector.election_context.election_instance_id), e => e.code === 'TALLY_RECOMPUTE_MISMATCH');
  let downstreamRead = false;
  const i06 = new ThresholdDecryptionEngine({
    finalizerStore: { async readContext(){ downstreamRead = true; throw new Error('must not be reached'); } },
    inboxStore: {}, i05Engine: i05, adapter: {}, baseArchiveResolver: async () => null,
  });
  await assert.rejects(i06.authorizedContext(vector.election_context.election_instance_id), e => e.code === 'I05_INTEGRITY_FAILURE');
  assert.equal(downstreamRead, false);
});

test('stale/unauthorized I05 tally cannot enter guardian/decryption path', async () => {
  let downstreamRead = false;
  const i06 = new ThresholdDecryptionEngine({
    finalizerStore: { async readContext(){ downstreamRead = true; throw new Error('must not be reached'); } },
    inboxStore: {},
    i05Engine: { async recompute(){ throw Object.assign(new Error('not authorized'), { code: 'TALLY_NOT_AUTHORIZED' }); } },
    adapter: {}, baseArchiveResolver: async () => null,
  });
  await assert.rejects(i06.authorizedContext(vector.election_context.election_instance_id), e => e.code === 'I05_INTEGRITY_FAILURE');
  assert.equal(downstreamRead, false);
});
