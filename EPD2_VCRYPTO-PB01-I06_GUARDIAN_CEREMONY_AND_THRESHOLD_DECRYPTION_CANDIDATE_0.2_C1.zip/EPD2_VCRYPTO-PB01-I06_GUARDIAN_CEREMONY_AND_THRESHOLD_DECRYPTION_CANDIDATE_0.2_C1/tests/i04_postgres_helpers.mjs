import { generateKeyPairSync } from "node:crypto";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import pg from "pg";
import {
  buildClosureAuthorizationStatement,
  ClosureAuthorizationVerifier,
  issueClosureAuthorization,
} from "../src/i04/closure_authority.mjs";
import { PostgresFinalizationStore } from "../src/i04/postgres_finalization_store.mjs";
import { startI04Service } from "../src/i04/http_service.mjs";
import { adminPool, adminUrl } from "./postgres_helpers.mjs";
import { allowedOrigin, root } from "./helpers.mjs";

const { Pool } = pg;

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`required I04 PostgreSQL test environment missing: ${name}`);
  return value;
}

export const finalizerUrl = required("EPD2_I04_PG_FINALIZER_URL");
export const i04EvidenceUrl = required("EPD2_I04_PG_EVIDENCE_URL");
export const submissionUrl = required("EPD2_I03_PG_RUNTIME_URL");

export async function applyI04Migrations() {
  const pool = await adminPool();
  try {
    await pool.query("DROP SCHEMA IF EXISTS pb01_i04 CASCADE");
    const migration3 = await readFile(join(root, "migrations/postgresql/003_i04_finalization.sql"), "utf8");
    const migration4 = await readFile(join(root, "migrations/postgresql/004_i04_roles.sql"), "utf8");
    await pool.query(migration3);
    await pool.query(migration4);
  } finally {
    await pool.end();
  }
}

export async function createI04Harness({ startServer = false, failpoint = null } = {}) {
  await applyI04Migrations();
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const keyId = "epd2-i04-test-closure-key-1";
  const authorizationVerifier = new ClosureAuthorizationVerifier(new Map([[keyId, publicKey]]));
  const store = new PostgresFinalizationStore({
    connectionString: finalizerUrl,
    ssl: false,
    max: 12,
    application_name: "epd2-pb01-i04-postgres-test-finalizer",
    backup: {
      pgDumpPath: required("EPD2_I03_PG_DUMP_PATH"),
      host: "127.0.0.1",
      port: Number(required("EPD2_I03_PG_PORT")),
      database: new URL(adminUrl).pathname.slice(1),
      user: new URL(adminUrl).username,
      password: decodeURIComponent(new URL(adminUrl).password),
    },
  });
  const privilegeEvidence = await store.assertFinalizerPrivileges();
  let server = null;
  let baseUrl = null;
  if (startServer) {
    server = await startI04Service({
      store,
      authorizationVerifier,
      allowedOperatorOrigin: allowedOrigin,
      port: 0,
      developmentHttp: true,
      failpoint,
    });
    baseUrl = `http://127.0.0.1:${server.address().port}`;
  }
  const authorizePreview = async (electionInstanceId, preview, overrides = {}) => {
    const statement = buildClosureAuthorizationStatement({
      electionInstanceId,
      checkpoint: preview.checkpoint,
      closedAt: overrides.closedAt ?? "2026-08-17T21:30:00Z",
      revotePolicyVersion: overrides.revotePolicyVersion,
    });
    return issueClosureAuthorization({ statement, privateKey, keyId });
  };
  const cleanup = async () => {
    if (server) await new Promise((resolve) => server.close(resolve));
    await store.close();
  };
  return {
    store,
    server,
    baseUrl,
    privateKey,
    publicKey,
    keyId,
    authorizationVerifier,
    privilegeEvidence,
    authorizePreview,
    cleanup,
  };
}

export async function rolePool(connectionString) {
  const pool = new Pool({ connectionString, ssl: false, max: 2 });
  await pool.query("SELECT 1");
  return pool;
}
