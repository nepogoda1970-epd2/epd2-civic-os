import { performance } from "node:perf_hooks";
import os from "node:os";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import { canonicalize, buildSubmissionArtifact } from "../src/i02_accepted/shared/profile.mjs";
import { generateAndVerifyBallot } from "../src/i02_accepted/client/native_helper_adapter.mjs";
import { createHarness, root, submissionHeaders, toolPath } from "./helpers.mjs";

function stats(samples) {
  const sorted = [...samples].sort((a, b) => a - b);
  const percentile = (p) => sorted[Math.min(sorted.length - 1, Math.floor((sorted.length - 1) * p))];
  return {
    samples: String(samples.length),
    min_ms: sorted[0].toFixed(3),
    median_ms: percentile(0.5).toFixed(3),
    p95_ms: percentile(0.95).toFixed(3),
    max_ms: sorted.at(-1).toFixed(3),
  };
}

const postgresMode = process.env.EPD2_I03_PERFORMANCE_STORE === "postgres";
const h = postgresMode
  ? await (await import("./postgres_helpers.mjs")).createPostgresHarness()
  : await createHarness();
const nativeSamples = [];
const transactionSamples = [];
const acceptanceSamples = [];
const generated = [];
const originalAccept = h.store.accept.bind(h.store);
h.store.accept = async (input) => {
  const start = performance.now();
  const result = await originalAccept(input);
  transactionSamples.push(performance.now() - start);
  return result;
};

try {
  const real = await (await import("./helpers.mjs")).realBrowserArtifact();
  const bytes = Buffer.from(real.encrypted_ballot, "base64url");
  for (let i = 0; i < 20; i += 1) {
    const start = performance.now();
    await (await import("../src/i03/native_verifier.mjs")).NativeBeleniosVerifier.prototype.verify.call(
      { toolPath, timeoutMs: 120000, onInvocation: null },
      { electionDir: h.fixtures.a.electionDir, ballotBytes: bytes },
    );
    nativeSamples.push(performance.now() - start);
  }

  for (let i = 0; i < 20; i += 1) {
    const choice = ["yes", "no", "abstain"][i % 3];
    const local = await generateAndVerifyBallot({
      toolPath,
      electionDir: h.fixtures.a.electionDir,
      context: h.fixtures.a.context,
      handoff: h.fixtures.a.handoff,
      choice,
    });
    generated.push(buildSubmissionArtifact(h.fixtures.a.context, local.encrypted_ballot_base64url, "PASS"));
  }

  const endpoint = `${h.baseUrl}/v1/elections/${h.fixtures.a.context.election_instance_id}/encrypted-ballots`;
  const startBatch = performance.now();
  const responses = await Promise.all(generated.map(async (artifact, index) => {
    const start = performance.now();
    const response = await fetch(endpoint, {
      method: "POST",
      headers: submissionHeaders(h.token, `idem-performance-${String(index).padStart(6, "0")}`),
      body: canonicalize(artifact),
    });
    acceptanceSamples.push(performance.now() - start);
    if (response.status !== 201) throw new Error(`performance acceptance failed: ${response.status}`);
    return response;
  }));
  const batchMs = performance.now() - startBatch;
  const results = {
    environment: {
      node: process.version,
      platform: `${process.platform}/${process.arch}`,
      cpu: os.cpus()[0]?.model ?? "unknown",
      storage: postgresMode
        ? "PostgreSQL 16.10 fsync=on synchronous_commit=on full_page_writes=on"
        : "node:sqlite WAL/FULL on temporary filesystem",
    },
    native_ballot_verification: stats(nativeSamples),
    total_acceptance_latency: stats(acceptanceSamples),
    database_transaction_latency: stats(transactionSamples),
    concurrent_acceptance: {
      submissions: String(responses.length),
      wall_time_ms: batchMs.toFixed(3),
      throughput_per_second: (responses.length / (batchMs / 1000)).toFixed(3),
      verification_concurrency_limit: "4",
    },
    security_priority: "CORRECTNESS_OVER_THROUGHPUT",
  };
  await writeFile(join(root, "evidence/results/performance.json"), `${JSON.stringify(results, null, 2)}\n`);
  process.stdout.write(`${JSON.stringify(results, null, 2)}\n`);
} finally {
  await h.cleanup();
}
