// PB01-I05 0.2_C1 — privileged tamper detection, role separation, runtime privilege floor
// and backup/restore byte preservation, all against real PostgreSQL.
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import pg from 'pg';
import { verifyTallyEvidence } from '../src/i05/tally.mjs';
import { aggregateCiphertextDigest } from '../src/i05/hashes.mjs';
import { adminPool, adminUrl, createdbPath, dropdbPath, pgRestorePath } from './postgres_helpers.mjs';
import { finalizerUrl, i04EvidenceUrl, submissionUrl } from './i04_postgres_helpers.mjs';
import {
  engineFor, finalizedFixture, i05EvidenceUrl, rolePool, runProcess, tallyStore, tallyUrl,
} from './i05_postgres_helpers.mjs';

const { Pool } = pg;

async function committedTally(t) {
  const fixture = await finalizedFixture(t);
  const store = tallyStore({ backup: true });
  t.after(() => store.close());
  const engine = engineFor({ ...fixture, store });
  const committed = await engine.execute(fixture.eid);
  return { ...fixture, store, engine, committed };
}

test('I05/PG append-only triggers reject mutation of committed tally state even for the schema owner', async (t) => {
  const { eid } = await committedTally(t);
  const pool = await adminPool();
  t.after(() => pool.end());
  const mutations = [
    ["UPDATE pb01_i05.tally_records SET f_final = repeat('0',64) WHERE election_instance_id = $1", [eid]],
    ["UPDATE pb01_i05.tally_records SET tally_record_digest = repeat('0',64) WHERE election_instance_id = $1", [eid]],
    ['DELETE FROM pb01_i05.tally_records WHERE election_instance_id = $1', [eid]],
    ["UPDATE pb01_i05.aggregates SET aggregate_ciphertext_bytes = '\\x00'::bytea WHERE election_instance_id = $1", [eid]],
    ['DELETE FROM pb01_i05.aggregates WHERE election_instance_id = $1', [eid]],
  ];
  for (const [sql, params] of mutations) {
    await assert.rejects(pool.query(sql, params), /TALLY_APPEND_ONLY_VIOLATION/u, sql);
  }
});

test('I05/PG privileged tamper that bypasses the triggers is still detected by evidence and recompute', async (t) => {
  const { eid, store, engine, committed } = await committedTally(t);
  const pool = await adminPool();
  t.after(() => pool.end());

  // (a) Aggregate ciphertext byte tamper — forced in with triggers disabled (a DBA-level attack).
  await pool.query('ALTER TABLE pb01_i05.aggregates DISABLE TRIGGER USER');
  await pool.query("UPDATE pb01_i05.aggregates SET aggregate_ciphertext_bytes = aggregate_ciphertext_bytes || '\\x20'::bytea WHERE election_instance_id = $1", [eid]);
  await pool.query('ALTER TABLE pb01_i05.aggregates ENABLE TRIGGER USER');
  const tamperedBytes = await store.read(eid);
  // The stored bytes no longer hash to the committed aggregate digest, and no longer match
  // the aggregate carried inside the committed, digest-sealed evidence bundle.
  assert.notEqual(aggregateCiphertextDigest(tamperedBytes.aggregate_ciphertext_bytes), tamperedBytes.aggregate_ciphertext_digest);
  assert.notDeepEqual(tamperedBytes.aggregate_ciphertext_bytes, committed.aggregate_ciphertext_bytes);
  assert.notEqual(
    tamperedBytes.aggregate_ciphertext_bytes.toString('base64url'),
    tamperedBytes.tally_evidence_bundle.aggregate_ciphertext_base64url,
  );
  // The sealed evidence bundle itself is untouched and still verifies, which is what
  // isolates the tamper to the mutable bytea column.
  assert.equal(verifyTallyEvidence(tamperedBytes.tally_evidence_bundle).valid, true);
  // I06 mandatory precondition: recompute derives the digest from persisted aggregate bytes.
  await assert.rejects(engine.recompute(eid), (error) => error.code === 'TALLY_RECOMPUTE_MISMATCH');

  // Restore the authentic bytes so the following tamper classes are isolated.
  await pool.query('ALTER TABLE pb01_i05.aggregates DISABLE TRIGGER USER');
  await pool.query('UPDATE pb01_i05.aggregates SET aggregate_ciphertext_bytes = $2 WHERE election_instance_id = $1', [eid, committed.aggregate_ciphertext_bytes]);
  await pool.query('ALTER TABLE pb01_i05.aggregates ENABLE TRIGGER USER');
  assert.equal((await engine.recompute(eid)).status, 'PASS');

  // (b) Committed digest tamper.
  await pool.query('ALTER TABLE pb01_i05.tally_records DISABLE TRIGGER USER');
  await pool.query("UPDATE pb01_i05.tally_records SET tally_record_digest = repeat('a',64) WHERE election_instance_id = $1", [eid]);
  await pool.query('ALTER TABLE pb01_i05.tally_records ENABLE TRIGGER USER');
  await assert.rejects(engine.recompute(eid), (error) => error.code === 'TALLY_RECOMPUTE_MISMATCH');
  await pool.query('ALTER TABLE pb01_i05.tally_records DISABLE TRIGGER USER');
  await pool.query('UPDATE pb01_i05.tally_records SET tally_record_digest = $2 WHERE election_instance_id = $1', [eid, committed.tally_record_digest]);
  await pool.query('ALTER TABLE pb01_i05.tally_records ENABLE TRIGGER USER');

  // (c) Canonical evidence-bundle tamper is caught by the public evidence verifier.
  const bundle = structuredClone(committed.tally_evidence_bundle);
  bundle.ordered_ballot_digests = [...bundle.ordered_ballot_digests].reverse().concat();
  bundle.f_final = 'd'.repeat(64);
  await pool.query('ALTER TABLE pb01_i05.tally_records DISABLE TRIGGER USER');
  await pool.query('UPDATE pb01_i05.tally_records SET tally_evidence_canonical = $2 WHERE election_instance_id = $1', [eid, JSON.stringify(bundle)]);
  await pool.query('ALTER TABLE pb01_i05.tally_records ENABLE TRIGGER USER');
  const tamperedBundle = (await store.read(eid)).tally_evidence_bundle;
  assert.throws(() => verifyTallyEvidence(tamperedBundle), (error) => error.code === 'TALLY_RECOMPUTE_MISMATCH' || error.code === 'FINAL_SET_MISMATCH');
});

test('I05/PG tally runtime cannot mutate I03 or I04 state', async (t) => {
  const { eid, store } = await committedTally(t);
  assert.equal((await store.assertRuntimePrivileges()).validation, 'PASS_TALLY_LEAST_PRIVILEGE');
  const tally = await rolePool(tallyUrl);
  t.after(() => tally.end());

  const readable = await tally.query('SELECT has_table_privilege(current_user,$1,$2) AS allowed', ['pb01_i04.finalizations', 'SELECT']);
  assert.equal(readable.rows[0].allowed, true, 'tally runtime must be able to read the authoritative final set');

  const forbidden = await Promise.all([
    tally.query('SELECT has_table_privilege(current_user,$1,$2) AS allowed', ['pb01_i03.encrypted_submissions', 'UPDATE,DELETE,TRUNCATE']),
    tally.query('SELECT has_table_privilege(current_user,$1,$2) AS allowed', ['pb01_i03.submission_ledger_events', 'INSERT,UPDATE,DELETE,TRUNCATE']),
    tally.query('SELECT has_table_privilege(current_user,$1,$2) AS allowed', ['pb01_i04.finalizations', 'INSERT,UPDATE,DELETE,TRUNCATE']),
    tally.query('SELECT has_table_privilege(current_user,$1,$2) AS allowed', ['pb01_i04.effective_submissions', 'INSERT,UPDATE,DELETE,TRUNCATE']),
  ]);
  assert.deepEqual(forbidden.map((r) => r.rows[0].allowed), [false, false, false, false]);

  await assert.rejects(tally.query("UPDATE pb01_i03.encrypted_submissions SET encrypted_ballot_bytes = ''::bytea WHERE election_instance_id = $1", [eid]));
  await assert.rejects(tally.query("UPDATE pb01_i04.finalizations SET f_final = repeat('0',64) WHERE election_instance_id = $1", [eid]));
  await assert.rejects(tally.query('DELETE FROM pb01_i04.effective_submissions WHERE election_instance_id = $1', [eid]));
  await assert.rejects(tally.query("INSERT INTO pb01_i03.submission_ledger_events(election_instance_id) VALUES ($1)", [eid]));
});

test('I05/PG submission, finalizer and evidence roles cannot mutate I05 tally state', async (t) => {
  const { eid } = await committedTally(t);
  const submission = await rolePool(submissionUrl);
  const finalizer = await rolePool(finalizerUrl);
  const i04Evidence = await rolePool(i04EvidenceUrl);
  const i05Evidence = await rolePool(i05EvidenceUrl);
  t.after(async () => { await Promise.all([submission.end(), finalizer.end(), i04Evidence.end(), i05Evidence.end()]); });

  // Privileges are evaluated through the administrative connection, because a role without
  // USAGE on pb01_i05 cannot even resolve the table name to ask the question itself.
  const admin = await adminPool();
  t.after(() => admin.end());
  for (const [name, pool, roleName] of [
    ['submission', submission, 'epd2_i03_runtime_test'],
    ['finalizer', finalizer, 'epd2_i04_finalizer_test'],
    ['i04-evidence', i04Evidence, 'epd2_i04_evidence_test'],
  ]) {
    const checks = await Promise.all([
      admin.query('SELECT has_table_privilege($1,$2,$3) AS allowed', [roleName, 'pb01_i05.tally_records', 'INSERT,UPDATE,DELETE,TRUNCATE']),
      admin.query('SELECT has_table_privilege($1,$2,$3) AS allowed', [roleName, 'pb01_i05.aggregates', 'INSERT,UPDATE,DELETE,TRUNCATE']),
      admin.query('SELECT has_schema_privilege($1,$2,$3) AS allowed', [roleName, 'pb01_i05', 'CREATE']),
    ]);
    assert.deepEqual(checks.map((r) => r.rows[0].allowed), [false, false, false], `${name} must not write I05`);
    await assert.rejects(pool.query("UPDATE pb01_i05.tally_records SET f_final = repeat('0',64) WHERE election_instance_id = $1", [eid]), undefined, `${name} update`);
    await assert.rejects(pool.query('DELETE FROM pb01_i05.aggregates WHERE election_instance_id = $1', [eid]), undefined, `${name} delete`);
    await assert.rejects(pool.query("INSERT INTO pb01_i05.tally_audit_events(audit_event_id,election_instance_id,event_code,occurred_at,detail_canonical) VALUES(gen_random_uuid(),$1,'X',now(),'{}')", [eid]), undefined, `${name} audit insert`);
  }

  // The evidence reader may read the published view and nothing else.
  const published = await i05Evidence.query('SELECT f_final, tally_record_digest FROM pb01_i05.public_tallies WHERE election_instance_id = $1', [eid]);
  assert.equal(published.rowCount, 1);
  await assert.rejects(i05Evidence.query("UPDATE pb01_i05.tally_records SET f_final = repeat('0',64) WHERE election_instance_id = $1", [eid]));
  await assert.rejects(i05Evidence.query('SELECT * FROM pb01_i05.tally_audit_events'));
});

test('I05/PG tally and evidence roles hold no DDL or TEMP privilege anywhere', async (t) => {
  await committedTally(t);
  const tally = await rolePool(tallyUrl);
  const evidence = await rolePool(i05EvidenceUrl);
  t.after(async () => { await Promise.all([tally.end(), evidence.end()]); });

  for (const [name, pool] of [['tally', tally], ['evidence', evidence]]) {
    const r = await pool.query(`SELECT
      p.rolsuper, p.rolcreatedb, p.rolcreaterole, p.rolreplication, p.rolbypassrls,
      has_database_privilege(current_user, current_database(), 'TEMP') AS db_temp,
      has_schema_privilege(current_user,'pb01_i03','CREATE') AS c3,
      has_schema_privilege(current_user,'pb01_i04','CREATE') AS c4,
      has_schema_privilege(current_user,'pb01_i05','CREATE') AS c5,
      has_schema_privilege(current_user,'public','CREATE') AS cpublic
      FROM pg_roles p WHERE p.rolname = current_user`);
    assert.deepEqual(r.rows[0], {
      rolsuper: false, rolcreatedb: false, rolcreaterole: false, rolreplication: false, rolbypassrls: false,
      db_temp: false, c3: false, c4: false, c5: false, cpublic: false,
    }, `${name} privilege floor`);
    await assert.rejects(pool.query('CREATE TABLE pb01_i05.attacker_table(x int)'), undefined, `${name} DDL`);
    await assert.rejects(pool.query('CREATE TEMP TABLE attacker_temp(x int)'), undefined, `${name} TEMP`);
  }
});

test('I05/PG backup and restore preserve exact aggregate and tally bytes and every digest', async (t) => {
  const { eid, store, committed } = await committedTally(t);
  const source = await store.read(eid);

  const temporary = await mkdtemp(join(tmpdir(), 'epd2-i05-backup-'));
  t.after(() => rm(temporary, { recursive: true, force: true }));
  const dump = join(temporary, 'i05.dump');
  await store.backupTo(dump);

  const admin = new URL(adminUrl);
  const args = ['-h', admin.hostname, '-p', admin.port, '-U', admin.username];
  const restoredDb = `epd2_i05_restore_${process.pid}`;
  await runProcess(dropdbPath, [...args, '--if-exists', '--force', restoredDb]);
  await runProcess(createdbPath, [...args, restoredDb]);
  t.after(() => runProcess(dropdbPath, [...args, '--if-exists', '--force', restoredDb]));
  await runProcess(pgRestorePath, [...args, '--no-owner', '--no-privileges', '-d', restoredDb, dump]);

  const restoredUrl = new URL(adminUrl);
  restoredUrl.pathname = `/${restoredDb}`;
  const restored = new Pool({ connectionString: restoredUrl.toString(), ssl: false });
  restored.on('error', () => {});

  const row = await restored.query(`
    SELECT r.f_final, r.cset_root, r.final_set_envelope_digest, r.tally_input_digest,
      r.aggregate_ciphertext_digest, r.tally_record_digest, r.tally_evidence_digest,
      r.tally_input_manifest_canonical, r.tally_record_canonical, r.tally_evidence_canonical,
      a.ballot_count, a.aggregate_ciphertext_bytes, a.upstream_sized_tally_bytes
    FROM pb01_i05.tally_records r JOIN pb01_i05.aggregates a USING (election_instance_id)
    WHERE r.election_instance_id = $1`, [eid]);
  assert.equal(row.rowCount, 1);
  const restoredRow = row.rows[0];

  // Every digest survives unchanged.
  assert.equal(restoredRow.f_final, committed.f_final);
  assert.equal(restoredRow.cset_root, source.cset_root);
  assert.equal(restoredRow.final_set_envelope_digest, source.final_set_envelope_digest);
  assert.equal(restoredRow.tally_input_digest, source.tally_input_digest);
  assert.equal(restoredRow.aggregate_ciphertext_digest, source.aggregate_ciphertext_digest);
  assert.equal(restoredRow.tally_record_digest, source.tally_record_digest);
  assert.equal(restoredRow.tally_evidence_digest, source.tally_evidence_digest);
  assert.equal(String(restoredRow.ballot_count), source.ballot_count_decimal);

  // Exact bytes survive unchanged, and still hash to the committed digest.
  assert.deepEqual(Buffer.from(restoredRow.aggregate_ciphertext_bytes), source.aggregate_ciphertext_bytes);
  assert.deepEqual(Buffer.from(restoredRow.upstream_sized_tally_bytes), source.upstream_sized_tally_bytes);
  assert.equal(aggregateCiphertextDigest(Buffer.from(restoredRow.aggregate_ciphertext_bytes)), source.aggregate_ciphertext_digest);

  // Canonical evidence survives byte-for-byte and still verifies independently.
  assert.deepEqual(JSON.parse(restoredRow.tally_record_canonical), source.homomorphic_tally_record);
  assert.deepEqual(JSON.parse(restoredRow.tally_input_manifest_canonical), source.tally_input_manifest);
  assert.deepEqual(JSON.parse(restoredRow.tally_evidence_canonical), source.tally_evidence_bundle);
  assert.equal(verifyTallyEvidence(JSON.parse(restoredRow.tally_evidence_canonical)).valid, true);

  // Close before the restored database is dropped, so teardown cannot masquerade as a failure.
  await restored.end();
});
