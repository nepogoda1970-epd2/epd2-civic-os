import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const root = new URL('../', import.meta.url);
const read = async p => JSON.parse(await readFile(new URL(p, root), 'utf8'));

test('I05 real Belenios vectors and both verifier reports pass', async () => {
  const a = await read('evidence/results/i05/verifier-a.json');
  const b = await read('evidence/results/i05/cross-language-verifier.json');
  assert.equal(a.status, 'PASS'); assert.equal(b.status, 'PASS');
  assert.equal(a.vectors.length, 4); assert.equal(b.vectors.length, 4);
  assert.ok(a.vectors.every(x => x.byte_for_byte_agreement));
  assert.ok(b.vectors.every(x => x.aggregate_byte_agreement));
  assert.equal(b.producer_code_imports, false);
  assert.equal(b.independent_aggregate_recomputation, true);
  assert.deepEqual(b.mutations.map(x=>x.observed), Array(12).fill('REJECT'));
});

test('revote vector consumes only A2/B1/C3 and agrees with independent three-ballot aggregate', async () => {
  const v2 = await read('test-vectors/i05/vectors/I05-V02-three-independent-ballots.json');
  const v3 = await read('test-vectors/i05/vectors/I05-V03-revotes-effective-final-set.json');
  assert.deepEqual(new Set(v3.effective_ballot_names), new Set(['A2','B1','C3']));
  for (const superseded of ['A1','C1','C2']) assert.ok(!v3.effective_ballot_names.includes(superseded));
  assert.equal(v2.expected_aggregate_ciphertext_base64url, v3.expected_aggregate_ciphertext_base64url);
  assert.equal(v2.expected_aggregate_ciphertext_digest, v3.expected_aggregate_ciphertext_digest);
});

test('empty final set has deterministic upstream identity aggregate', async () => {
  const v4 = await read('test-vectors/i05/vectors/I05-V04-empty-final-set.json');
  assert.equal(v4.exact_ballots.length, 0);
  assert.equal(v4.tally_evidence_bundle.tally_input_manifest.ballot_count_decimal, '0');
  const text = Buffer.from(v4.expected_aggregate_ciphertext_base64url, 'base64url').toString('utf8');
  const agg = JSON.parse(text);
  for (const question of agg) for (const choice of question) { assert.equal(choice.alpha, '0000000000000000000000000000000000000000000000000000000000000001'); assert.equal(choice.beta, choice.alpha); }
});

test('real alternate aggregates and foreign ballot attacks are rejected', async () => {
  const r = await read('evidence/results/i05/adversarial-composition.json');
  assert.equal(r.status, 'PASS');
  assert.ok(r.attacks.every(x => x.observed === 'REJECT'));
  assert.ok(r.attacks.some(x => x.upstream_aggregate_formed === true && x.internally_resealed_tally_record === true));
});

test('independently encrypted/revoted ciphertexts remain distinct exact ballots', async () => {
  const digests = await read('test-vectors/i05/ballot-digests.json');
  assert.notEqual(digests.ballots.A1, digests.ballots.A2);
  assert.notEqual(digests.ballots.C1, digests.ballots.C2);
  assert.notEqual(digests.ballots.C2, digests.ballots.C3);
});
