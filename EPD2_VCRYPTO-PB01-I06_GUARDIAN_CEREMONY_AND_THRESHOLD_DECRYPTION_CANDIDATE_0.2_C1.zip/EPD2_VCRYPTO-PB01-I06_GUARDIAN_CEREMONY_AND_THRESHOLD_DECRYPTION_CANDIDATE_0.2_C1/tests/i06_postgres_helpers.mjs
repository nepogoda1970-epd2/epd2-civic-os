import assert from 'node:assert/strict';
import { createHash, generateKeyPairSync } from 'node:crypto';
import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import pg from 'pg';
import { buildSubmissionArtifact, canonicalize } from '../src/i02_accepted/shared/profile.mjs';
import { ScopedCredentialAuthority } from '../src/i03/credential.mjs';
import { startI03Service } from '../src/i03/http_service.mjs';
import { NativeBeleniosVerifier } from '../src/i03/native_verifier.mjs';
import { PostgresSubmissionStore } from '../src/i03/postgres_store.mjs';
import { ReceiptSigner } from '../src/i03/receipt.mjs';
import { PostgresFinalizationStore } from '../src/i04/postgres_finalization_store.mjs';
import { buildClosureAuthorizationStatement, ClosureAuthorizationVerifier, issueClosureAuthorization } from '../src/i04/closure_authority.mjs';
import { BeleniosHomomorphicAggregator } from '../src/i05/belenios_aggregator.mjs';
import { PostgresTallyStore } from '../src/i05/postgres_tally_store.mjs';
import { TallyEngine } from '../src/i05/tally.mjs';
import { BeleniosThresholdAdapter } from '../src/i06/belenios_threshold.mjs';
import { verifyPersistedElectionBinding } from '../src/i06/election_binding.mjs';
import { GuardianCeremonyCoordinator } from '../src/i06/ceremony.mjs';
import { ThresholdDecryptionEngine } from '../src/i06/decryption.mjs';
import { PostgresDecryptionFinalizerStore, PostgresGuardianCeremonyStore, PostgresShareInboxStore } from '../src/i06/postgres_stores.mjs';
import { adminPool, adminUrl, resetPostgresSchema } from './postgres_helpers.mjs';
import { allowedOrigin, root, submissionHeaders, toolPath } from './helpers.mjs';
const {Pool}=pg;

// Test-only exact-fixture crypto cache. Production code is unchanged. Each test
// class still invokes pinned Belenios 3.3.0 at least once for every distinct
// ballot and aggregate; repeated setup of byte-identical public fixtures reuses
// only that exact verified result to keep the PostgreSQL battery bounded.
const nativeFixtureVerificationCache = new Map();
const aggregateFixtureCache = new Map();
function fixtureKey(parts){const h=createHash('sha256');for(const part of parts){h.update(Buffer.from(part));h.update(Buffer.from([0]));}return h.digest('hex');}
function cachedNativeVerifier(delegate){return {async verify({electionDir,ballotBytes}){const key=fixtureKey([electionDir,ballotBytes]);if(nativeFixtureVerificationCache.has(key))return nativeFixtureVerificationCache.get(key);const result=await delegate.verify({electionDir,ballotBytes});nativeFixtureVerificationCache.set(key,result);return result;}};}
function cachedAggregator(delegate){return {
  async verifyBallot({electionDir,ballotBytes}){const key=`i05-verify:${fixtureKey([electionDir,ballotBytes])}`;if(nativeFixtureVerificationCache.has(key))return nativeFixtureVerificationCache.get(key);const result=await delegate.verifyBallot({electionDir,ballotBytes});nativeFixtureVerificationCache.set(key,result);return result;},
  async aggregate({orderedBallotBytes}){const key=fixtureKey(orderedBallotBytes);if(aggregateFixtureCache.has(key))return aggregateFixtureCache.get(key);const result=await delegate.aggregate({orderedBallotBytes});aggregateFixtureCache.set(key,result);return result;}
};}
function req(n){const v=process.env[n];if(!v)throw new Error(`required I06 PostgreSQL environment missing: ${n}`);return v;}
export const coordinatorUrl=req('EPD2_I06_PG_COORDINATOR_URL');
export const ingesterUrl=req('EPD2_I06_PG_INGESTER_URL');
export const decryptionFinalizerUrl=req('EPD2_I06_PG_FINALIZER_URL');
export const readerUrl=req('EPD2_I06_PG_READER_URL');
export const tallyUrl=req('EPD2_I05_PG_TALLY_URL');
export const finalizerUrl=req('EPD2_I04_PG_FINALIZER_URL');
export const runtimeUrl=req('EPD2_I03_PG_RUNTIME_URL');
export const pgCtlPath=process.env.EPD2_I06_PG_CTL_PATH??null, pgDataDir=process.env.EPD2_I06_PG_DATA_DIR??null, pgStartOptions=process.env.EPD2_I06_PG_START_OPTIONS??'';
export const pgDumpPath=req('EPD2_I03_PG_DUMP_PATH'), pgRestorePath=req('EPD2_I03_PG_RESTORE_PATH'), createdbPath=req('EPD2_I03_PG_CREATEDB_PATH'), dropdbPath=req('EPD2_I03_PG_DROPDB_PATH'), pgPort=req('EPD2_I03_PG_PORT');
export function rolePool(url){const p=new Pool({connectionString:url,ssl:false,max:4});p.on('error',()=>{});return p;}
export async function applyI04I05I06Migrations(){const p=await adminPool();try{for(const schema of ['pb01_i06','pb01_i05','pb01_i04'])await p.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE`);for(const n of ['003_i04_finalization','004_i04_roles','005_i05_tally','006_i05_roles','007_i06_guardian_decryption','008_i06_roles'])await p.query(await readFile(join(root,'migrations/postgresql',`${n}.sql`),'utf8'));}finally{await p.end();}}
function auths(){const credentialAuthority=new ScopedCredentialAuthority({capabilityKey:Buffer.alloc(32,0x61),lifecycleKey:Buffer.alloc(32,0x62),issuer:'epd2-i06-pg-test'});const kp=generateKeyPairSync('ed25519');return {credentialAuthority,receiptSigner:new ReceiptSigner({privateKey:kp.privateKey,keyId:'epd2-i06-receipt-1'})};}
export async function createThresholdChain(t,{failpoint=null}={}){
 await resetPostgresSchema();
 const fixtureDir=join(root,'evidence/fixtures/i06-election-n3t2'); const context=JSON.parse(await readFile(join(fixtureDir,'context.json'),'utf8')); const fixture={context,electionDir:fixtureDir};
 const electionBytes=await readFile(join(fixtureDir,'election.json'));
 verifyPersistedElectionBinding(context,electionBytes);
 const setup=new PostgresSubmissionStore({connectionString:adminUrl,ssl:false,max:2});await setup.registerElection(context,'2026-08-18T08:00:00Z');await setup.close();
 const sub=new PostgresSubmissionStore({connectionString:runtimeUrl,ssl:false,max:12});t.after(()=>sub.close());const {credentialAuthority,receiptSigner}=auths();const verifier=cachedNativeVerifier(new NativeBeleniosVerifier({toolPath}));
 const server=await startI03Service({store:sub,electionFixtures:new Map([[context.election_instance_id,fixture]]),verifier,credentialAuthority,receiptSigner,idempotencySecret:Buffer.alloc(32,0x63),allowedOrigin,port:0,developmentHttp:true});t.after(()=>new Promise(r=>server.close(r)));const baseUrl=`http://127.0.0.1:${server.address().port}`;
 for(let i=1;i<=5;i++){const bytes=await readFile(join(fixtureDir,'ballots',`B${i}.json`));const artifact=buildSubmissionArtifact(context,bytes.toString('base64url'),'PASS');const token=credentialAuthority.issue({electionInstanceId:context.election_instance_id,lifecycleNonce:i.toString(16).padStart(32,'0'),expiresAt:'2030-01-01T00:00:00Z',revoteAllowed:true}).scoped_credential.secret;const r=await fetch(`${baseUrl}/v1/elections/${context.election_instance_id}/encrypted-ballots`,{method:'POST',headers:submissionHeaders(token,`i06-pg-ballot-${String(i).padStart(4,'0')}-0000`),body:canonicalize(artifact)});assert.equal(r.status,201,await r.text());}
 await applyI04I05I06Migrations();
 const closureKp=generateKeyPairSync('ed25519');const keyId='i06-closure-test-key';const authorizationVerifier=new ClosureAuthorizationVerifier(new Map([[keyId,closureKp.publicKey]]));
 const i04Store=new PostgresFinalizationStore({connectionString:finalizerUrl,ssl:false,max:8});t.after(()=>i04Store.close());const preview=await i04Store.previewClosure(context.election_instance_id);const statement=buildClosureAuthorizationStatement({electionInstanceId:context.election_instance_id,checkpoint:preview.checkpoint,closedAt:'2026-08-18T09:00:00Z'});const auth=issueClosureAuthorization({statement,privateKey:closureKp.privateKey,keyId});const fin=await i04Store.finalize({electionInstanceId:context.election_instance_id,authorizationEvidence:auth,authorizationVerifier});
 const tallyStore=new PostgresTallyStore({connectionString:tallyUrl,ssl:false,max:8});t.after(()=>tallyStore.close());const aggregator=cachedAggregator(new BeleniosHomomorphicAggregator({toolPath,baseElectionArchivePath:join(fixtureDir,`${context.belenios_election_uuid}.bel`)}));const i05Engine=new TallyEngine({finalizationStore:i04Store,tallyStore,aggregator,electionDir:fixtureDir,authorizationVerifier});const tally=await i05Engine.execute(context.election_instance_id);
 const expected=await readFile(join(root,'test-vectors/i06/fixtures/n3-t2/encrypted_tally.out'));const line=expected.subarray(0,expected.indexOf(10));assert.deepEqual(tally.aggregate_ciphertext_bytes,line);
 const ceremonyStore=new PostgresGuardianCeremonyStore({connectionString:coordinatorUrl,ssl:false,max:6});const inboxStore=new PostgresShareInboxStore({connectionString:ingesterUrl,ssl:false,max:8});const finalStore=new PostgresDecryptionFinalizerStore({connectionString:decryptionFinalizerUrl,ssl:false,max:8});t.after(async()=>Promise.all([ceremonyStore.close(),inboxStore.close(),finalStore.close()]));const adapter=new BeleniosThresholdAdapter({toolPath,templatePath:join(fixtureDir,'template.json')});const coordinator=new GuardianCeremonyCoordinator({store:ceremonyStore,adapter});const engine=new ThresholdDecryptionEngine({finalizerStore:finalStore,inboxStore,i05Engine,adapter,baseArchiveResolver:async()=>join(root,'test-vectors/i06/fixtures/n3-t2/decryption-base.bel'),failpoint});
 return {eid:context.election_instance_id,context,fixtureDir,fin,tally,i03:{store:sub,server,baseUrl},i04Store,tallyStore,i05Engine,adapter,ceremonyStore,inboxStore,finalStore,coordinator,engine};
}
export async function freezeN3T2(chain){const d=join(root,'test-vectors/i06/fixtures/n3-t2');const meta=JSON.parse(await readFile(join(d,'public-metadata.json'),'utf8'));await chain.coordinator.create({electionInstanceId:chain.eid,guardianCount:3,threshold:2,beleniosElectionUuid:chain.context.belenios_election_uuid});await chain.coordinator.registerGuardians(chain.eid,3);await chain.coordinator.submitPublicKeys(chain.eid,meta.guardian_public_keys);return chain.coordinator.verifyAndFreeze(chain.eid,{thresholdBytes:await readFile(join(d,'threshold.json')),trusteesBytes:await readFile(join(d,'trustees.public.json')),electionBytes:await readFile(join(d,'election.public.json'))});}
export async function shareBytes(i){return readFile(join(root,'test-vectors/i06/fixtures/n3-t2',`share-${i}.json`));}
export function runProcess(command,args,env=process.env){return new Promise((resolve,reject)=>{const c=spawn(command,args,{env,stdio:['ignore','pipe','pipe']});const o=[],e=[];c.stdout.on('data',x=>o.push(x));c.stderr.on('data',x=>e.push(x));c.on('error',reject);c.on('exit',code=>code===0?resolve(Buffer.concat(o).toString()):reject(new Error(`${command} ${code}: ${Buffer.concat(e)}`)));});}
