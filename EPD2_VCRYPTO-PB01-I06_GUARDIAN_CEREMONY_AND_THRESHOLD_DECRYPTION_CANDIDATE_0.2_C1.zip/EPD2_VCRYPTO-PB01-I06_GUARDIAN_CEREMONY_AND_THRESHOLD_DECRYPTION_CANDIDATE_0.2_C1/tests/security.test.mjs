import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import test from "node:test";
import { FixedWindowRateLimiter } from "../src/i03/rate_limit.mjs";
import { createHarness, postArtifact, realBrowserArtifact, root } from "./helpers.mjs";

async function sourceText(directory) {
  const parts = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) parts.push(await sourceText(path));
    else if (/\.(?:mjs|js|sql)$/u.test(entry.name)) parts.push(await readFile(path, "utf8"));
  }
  return parts.join("\n");
}

test("privacy-preserving storage and audit contain no selection, credential token or randomness", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();
  const response = await postArtifact(h, artifact, "idem-privacy-00000001");
  assert.equal(response.status, 201);
  const encrypted = h.store.db.prepare("SELECT CAST(encrypted_ballot_bytes AS TEXT) AS raw FROM encrypted_submissions").get().raw;
  const audit = h.store.db.prepare("SELECT group_concat(detail_json, '') AS details FROM security_audit_events").get().details;
  const privateRows = JSON.stringify(h.store.db.prepare("SELECT * FROM private_submission_lifecycle").all());
  for (const prohibited of ["\"yes\"", h.token, h.fixtures.a.handoff.scoped_credential.secret, "belenios_plaintext", "randomness", "member@example", "member_id"]) {
    assert.equal(encrypted.includes(prohibited), false);
    assert.equal((audit || "").includes(prohibited), false);
    assert.equal(privateRows.includes(prohibited), false);
  }
  const columns = h.store.db.prepare("PRAGMA table_info(encrypted_submissions)").all().map((row) => row.name);
  assert.equal(columns.some((name) => /plaintext|choice|randomness|email|member|username/iu.test(name)), false);
});

test("CORS is exact, non-credentialed and arbitrary origin is rejected", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();
  const rejected = await fetch(`${h.baseUrl}/v1/elections/${h.fixtures.a.context.election_instance_id}/encrypted-ballots`, {
    method: "POST",
    headers: {
      origin: "https://attacker.invalid",
      authorization: `EPD2-Scoped ${h.token}`,
      "content-type": "application/json",
      "idempotency-key": "idem-bad-origin-000001",
    },
    body: JSON.stringify(artifact),
  });
  assert.equal(rejected.status, 403);
  assert.equal(rejected.headers.get("access-control-allow-origin"), "http://127.0.0.1:32901");
  assert.equal(rejected.headers.has("access-control-allow-credentials"), false);
  assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).submissions, 0);
});

test("cheap invalid schema is rejected before native verification", async (t) => {
  let verifierCalls = 0;
  const h = await createHarness({ verifierInvocation: () => { verifierCalls += 1; } });
  t.after(h.cleanup);
  const response = await postArtifact(h, { invalid: "object" }, "idem-cheap-reject-0001");
  assert.equal(response.status, 422);
  assert.equal(verifierCalls, 0);
});

test("bounded limiter resets and cannot permanently lock out a legitimate client", () => {
  const limiter = new FixedWindowRateLimiter({ windowMs: 1000, submissionLimit: 2, lookupLimit: 2, invalidLimit: 2 });
  limiter.take("client", "submission", 0);
  limiter.take("client", "submission", 1);
  assert.throws(() => limiter.take("client", "submission", 2), /RATE_LIMITED/u);
  assert.doesNotThrow(() => limiter.take("client", "submission", 1001));
});

test("production source exposes no tally/decrypt/guardian route and SQL roles lack destructive grants", async () => {
  const production = await sourceText(join(root, "src"));
  const server = await sourceText(join(root, "server"));
  const combined = `${production}\n${server}`;
  assert.doesNotMatch(combined, /\/decrypt|\/tally|guardian-share|private[_-]key.*route/iu);
  const roles = await readFile(join(root, "migrations/postgresql/002_i03_roles.sql"), "utf8");
  assert.match(roles, /REVOKE UPDATE, DELETE, TRUNCATE/iu);
  assert.match(roles, /REVOKE CREATE ON SCHEMA/iu);
  assert.match(roles, /NOSUPERUSER/iu);
  assert.doesNotMatch(roles, /\bSUPERUSER\b/iu);
});

test("submission capability grants no election administration or ledger mutation authority", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  for (const suffix of ["configure", "close", "tally", "decrypt", "guardians"]) {
    const response = await fetch(`${h.baseUrl}/v1/elections/${h.fixtures.a.context.election_instance_id}/${suffix}`, {
      method: "POST",
      headers: {
        origin: "http://127.0.0.1:32901",
        authorization: `EPD2-Scoped ${h.token}`,
        "content-type": "application/json",
        "idempotency-key": `idem-authority-${suffix.padEnd(16, "0")}`,
      },
      body: "{}",
    });
    assert.equal(response.status, 404);
  }
  assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).submissions, 0);
});
