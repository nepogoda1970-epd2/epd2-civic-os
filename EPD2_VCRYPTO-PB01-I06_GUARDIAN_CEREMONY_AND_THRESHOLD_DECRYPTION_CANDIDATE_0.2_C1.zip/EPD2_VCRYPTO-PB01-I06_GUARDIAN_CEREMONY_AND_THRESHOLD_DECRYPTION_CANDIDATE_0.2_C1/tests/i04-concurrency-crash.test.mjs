import assert from "node:assert/strict";
import test from "node:test";
import { canonicalize } from "../src/i02_accepted/shared/profile.mjs";
import { createPostgresHarness } from "./postgres_helpers.mjs";
import { createI04Harness } from "./i04_postgres_helpers.mjs";
import { allowedOrigin, realBrowserArtifact, realVectorArtifact, submissionHeaders } from "./helpers.mjs";

async function submit(i03, artifact, key) {
  return fetch(`${i03.baseUrl}/v1/elections/${i03.fixtures.a.context.election_instance_id}/encrypted-ballots`, {
    method: "POST",
    headers: submissionHeaders(i03.token, key),
    body: canonicalize(artifact),
  });
}

async function seedOne() {
  const i03 = await createPostgresHarness();
  const artifact = await realBrowserArtifact();
  const response = await submit(i03, artifact, "i04-seed-one-000001");
  assert.equal(response.status, 201);
  return { i03, artifact };
}

test("I04 concurrent identical and conflicting finalizers converge without split state", async (t) => {
  const { i03 } = await seedOne();
  t.after(i03.cleanup);
  const i04 = await createI04Harness();
  t.after(i04.cleanup);
  const electionId = i03.fixtures.a.context.election_instance_id;
  const preview = await i04.store.previewClosure(electionId);
  const authorization = await i04.authorizePreview(electionId, preview);
  const results = await Promise.all([
    i04.store.finalize({ electionInstanceId: electionId, authorizationEvidence: authorization, authorizationVerifier: i04.authorizationVerifier }),
    i04.store.finalize({ electionInstanceId: electionId, authorizationEvidence: authorization, authorizationVerifier: i04.authorizationVerifier }),
  ]);
  assert.equal(new Set(results.map((row) => row.f_final)).size, 1);
  assert.equal(results.filter((row) => row.replay).length, 1);

  const conflictAuthorization = await i04.authorizePreview(electionId, preview, { closedAt: "2026-08-17T21:31:00Z" });
  await assert.rejects(
    i04.store.finalize({ electionInstanceId: electionId, authorizationEvidence: conflictAuthorization, authorizationVerifier: i04.authorizationVerifier }),
    (error) => error.code === "FINALIZATION_CONFLICT",
  );
});

for (const [name, failpointName, committed] of [
  ["I04-CRASH-01", "after_closure_validation_before_resolution_writes", false],
  ["I04-CRASH-02", "during_lifecycle_resolution_persistence", false],
  ["I04-CRASH-03", "after_final_set_persistence_before_commit", false],
  ["I04-CRASH-04", "after_commit_before_response", true],
]) {
  test(`${name} is atomic and retry converges`, async (t) => {
    const { i03 } = await seedOne();
    t.after(i03.cleanup);
    let fired = false;
    const i04 = await createI04Harness();
    t.after(i04.cleanup);
    const electionId = i03.fixtures.a.context.election_instance_id;
    const preview = await i04.store.previewClosure(electionId);
    const authorization = await i04.authorizePreview(electionId, preview);
    await assert.rejects(i04.store.finalize({
      electionInstanceId: electionId,
      authorizationEvidence: authorization,
      authorizationVerifier: i04.authorizationVerifier,
      failpoint: async (point) => {
        if (!fired && point === failpointName) {
          fired = true;
          throw new Error(name);
        }
      },
    }), new RegExp(name));
    assert.equal(Boolean(await i04.store.readFinalization(electionId)), committed);
    const retry = await i04.store.finalize({ electionInstanceId: electionId, authorizationEvidence: authorization, authorizationVerifier: i04.authorizationVerifier });
    assert.equal(retry.replay, committed);
    assert.equal((await i04.store.recompute(electionId, { authorizationVerifier: i04.authorizationVerifier })).status, "PASS");
  });
}

test("I04 submission-versus-closure race has one deterministic boundary outcome", async (t) => {
  const { i03 } = await seedOne();
  t.after(i03.cleanup);
  const i04 = await createI04Harness();
  t.after(i04.cleanup);
  const electionId = i03.fixtures.a.context.election_instance_id;
  const preview = await i04.store.previewClosure(electionId);
  const authorization = await i04.authorizePreview(electionId, preview);
  const revote = await realVectorArtifact(i03.fixtures.a.context, "I02-P02.json");
  const [finalizationResult, submissionResult] = await Promise.allSettled([
    i04.store.finalize({ electionInstanceId: electionId, authorizationEvidence: authorization, authorizationVerifier: i04.authorizationVerifier }),
    submit(i03, revote, "i04-closure-race-0001").then(async (response) => ({ status: response.status, body: await response.json() })),
  ]);
  assert.equal(finalizationResult.status, "fulfilled");
  assert.equal(submissionResult.status, "fulfilled");
  const submission = submissionResult.value;
  assert.ok([201, 422].includes(submission.status));
  const finalized = finalizationResult.value;
  assert.equal(finalized.cset_final.ordered_ballot_digests.length, 1);
  if (submission.status === 201) {
    assert.equal(finalized.cset_final.ordered_ballot_digests.includes(revote.ballot_digest), false);
    assert.ok([0, 1].includes(finalized.post_closure_excluded));
  } else {
    assert.equal(submission.body.error, "ELECTION_NOT_OPEN");
  }
});
