import assert from "node:assert/strict";
import { generateKeyPairSync } from "node:crypto";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { chromium } from "playwright";
import { ballotDigest, canonicalize } from "../src/i02_accepted/shared/profile.mjs";
import { mutateRawBallot } from "../src/i02_accepted/shared/mutations.mjs";
import { ScopedCredentialAuthority } from "../src/i03/credential.mjs";
import { startI03BrowserClientServer } from "../src/i03/browser_client_server.mjs";
import { startI03Service } from "../src/i03/http_service.mjs";
import { NativeBeleniosVerifier } from "../src/i03/native_verifier.mjs";
import { PostgresSubmissionStore } from "../src/i03/postgres_store.mjs";
import { ReceiptSigner } from "../src/i03/receipt.mjs";
import { SqliteSubmissionStore } from "../src/i03/sqlite_store.mjs";
import { loadFixtures, root, toolPath } from "./helpers.mjs";

const clientOrigin = "http://127.0.0.1:33901";
const receiverPort = 33902;
const temporary = await mkdtemp(join(tmpdir(), "epd2-i03-browser-e2e-"));
const fixtures = await loadFixtures(receiverPort);
const postgresMode = process.env.EPD2_I03_E2E_STORE === "postgres";
let store;
if (postgresMode) {
  const { adminUrl, resetPostgresSchema, runtimeUrl } = await import("./postgres_helpers.mjs");
  await resetPostgresSchema();
  const setupStore = new PostgresSubmissionStore({ connectionString: adminUrl, ssl: false, max: 2 });
  await setupStore.registerElection(fixtures.a.context, "2026-08-17T00:00:00Z");
  await setupStore.registerElection(fixtures.b.context, "2026-08-17T00:00:00Z");
  await setupStore.close();
  store = new PostgresSubmissionStore({ connectionString: runtimeUrl, ssl: false, max: 8 });
  await store.assertRuntimePrivileges();
} else {
  store = new SqliteSubmissionStore(join(temporary, "i03.sqlite"));
  store.migrate();
  store.registerElection(fixtures.a.context, "2026-08-17T00:00:00Z");
  store.registerElection(fixtures.b.context, "2026-08-17T00:00:00Z");
}
const credentialAuthority = new ScopedCredentialAuthority({
  capabilityKey: Buffer.alloc(32, 0x51),
  lifecycleKey: Buffer.alloc(32, 0x52),
  issuer: "epd2-i03-browser-e2e-ws03",
});
const submissionAuthorization = credentialAuthority.issue({
  electionInstanceId: fixtures.a.context.election_instance_id,
  lifecycleNonce: "11223344556677889900aabbccddeeff",
  expiresAt: "2030-01-01T00:00:00Z",
  revoteAllowed: true,
});
const { privateKey } = generateKeyPairSync("ed25519");
const receiptSigner = new ReceiptSigner({ privateKey, keyId: "epd2-i03-browser-e2e-key" });
let verifierCalls = 0;
const verifier = new NativeBeleniosVerifier({ toolPath, onInvocation: () => { verifierCalls += 1; } });
const receiver = await startI03Service({
  store,
  electionFixtures: new Map([
    [fixtures.a.context.election_instance_id, fixtures.a],
    [fixtures.b.context.election_instance_id, fixtures.b],
  ]),
  verifier,
  credentialAuthority,
  receiptSigner,
  idempotencySecret: Buffer.alloc(32, 0x53),
  allowedOrigin: clientOrigin,
  port: receiverPort,
  developmentHttp: true,
});
const client = await startI03BrowserClientServer({
  clientDir: join(root, "client"),
  context: fixtures.a.context,
  handoff: fixtures.a.handoff,
  submissionAuthorization,
  port: 33901,
});
const browser = await chromium.launch({ headless: true });
const browserContext = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "en-US" });
const page = await browserContext.newPage();
const network = [];
const submittedArtifacts = [];
page.on("request", (request) => {
  const url = new URL(request.url());
  network.push({ method: request.method(), origin: url.origin, path: url.pathname });
  if (request.method() === "POST" && url.pathname.endsWith("/encrypted-ballots")) {
    submittedArtifacts.push(JSON.parse(request.postData()));
  }
});

const results = {
  browser_to_ledger: {},
  native_verification: {},
  exact_bytes_and_digest: {},
  mutation_rejection: {},
  revote_preparation: {},
  privacy_isolation: {},
  network_boundary: {},
  public_status: {},
};

async function prepareAndSubmit(label) {
  await page.getByLabel(label, { exact: true }).check();
  await page.getByRole("button", { name: "Encrypt and verify in browser" }).click();
  await page.getByText("Encrypted ballot prepared and locally verified. Ready to submit.", { exact: true }).waitFor({ timeout: 120000 });
  await page.getByRole("button", { name: "Submit encrypted ballot" }).click();
  await page.getByText(/Accepted submission; not yet final or counted\. Receipt:/u).waitFor({ timeout: 120000 });
  return page.locator("#status").getAttribute("data-receipt");
}

try {
  const navigation = await page.goto(`${clientOrigin}/`, { waitUntil: "networkidle" });
  assert.ok(navigation);
  assert.match(navigation.headers()["content-security-policy"], /default-src 'none'/u);
  const firstDigest = await prepareAndSubmit("Yes");
  const firstArtifact = submittedArtifacts.at(-1);
  assert.equal(firstDigest, firstArtifact.ballot_digest);
  assert.equal(firstArtifact.ballot_digest, ballotDigest(fixtures.a.context, firstArtifact.encrypted_ballot));
  assert.deepEqual(await store.exactBallotBytes(fixtures.a.context.election_instance_id, firstDigest), Buffer.from(firstArtifact.encrypted_ballot, "base64url"));
  const firstStatusResponse = await fetch(`${fixtures.a.context.receiver_url.replace("/encrypted-ballots", `/ballots/${firstDigest}`)}`, { headers: { origin: clientOrigin } });
  assert.equal(firstStatusResponse.status, 200);
  const firstStatus = await firstStatusResponse.json();
  assert.equal(firstStatus.status, "ACCEPTED");
  assert.equal(firstStatus.finality_claim, "NOT_FINAL_NOT_COUNTED");
  assert.equal(JSON.stringify(firstStatus).includes("lifecycle"), false);

  await page.getByLabel("Abstain", { exact: true }).check();
  await page.getByRole("button", { name: "Encrypt and verify in browser" }).click();
  await page.getByText("Encrypted ballot prepared and locally verified. Ready to submit.", { exact: true }).waitFor({ timeout: 120000 });
  await page.route(/\/encrypted-ballots$/u, async (route) => {
    const artifact = JSON.parse(route.request().postData());
    const raw = Buffer.from(artifact.encrypted_ballot, "base64url").toString("utf8");
    artifact.encrypted_ballot = Buffer.from(mutateRawBallot(raw, "proof-response"), "utf8").toString("base64url");
    artifact.ballot_digest = ballotDigest(fixtures.a.context, artifact.encrypted_ballot);
    await route.continue({ postData: canonicalize(artifact), headers: { ...route.request().headers(), "content-type": "application/json" } });
  });
  await page.getByRole("button", { name: "Submit encrypted ballot" }).click();
  await page.getByText(/INVALID_ENCRYPTED_BALLOT/u).waitFor({ timeout: 120000 });
  await page.unroute(/\/encrypted-ballots$/u);
  assert.equal((await store.counts(fixtures.a.context.election_instance_id)).submissions, 1);

  const secondDigest = await prepareAndSubmit("No");
  assert.notEqual(secondDigest, firstDigest);
  assert.equal((await store.counts(fixtures.a.context.election_instance_id)).submissions, 2);
  const firstPublic = await store.lookupStatus(fixtures.a.context.election_instance_id, firstDigest);
  const secondPublic = await store.lookupStatus(fixtures.a.context.election_instance_id, secondDigest);
  const privateFirst = await store.privateLifecycleForSubmission(firstPublic.submission_id);
  const privateSecond = await store.privateLifecycleForSubmission(secondPublic.submission_id);
  assert.equal(privateFirst.lifecycle_handle, privateSecond.lifecycle_handle);
  assert.equal((await store.privateLifecycleMembers(fixtures.a.context.election_instance_id, privateFirst.lifecycle_handle)).length, 2);
  const manifest = await store.exportAcceptedManifest(fixtures.a.context.election_instance_id);
  assert.equal(JSON.stringify(manifest).includes(privateFirst.lifecycle_handle), false);
  assert.deepEqual(manifest.accepted_ballot_digests, [firstDigest, secondDigest].sort());

  const storageState = await page.evaluate(() => ({ local: localStorage.length, session: sessionStorage.length, cookie: document.cookie }));
  const cookies = await browserContext.cookies();
  assert.deepEqual(storageState, { local: 0, session: 0, cookie: "" });
  assert.equal(cookies.length, 0);
  assert.ok(network.every((entry) => [clientOrigin, `http://127.0.0.1:${receiverPort}`].includes(entry.origin)));
  for (const artifact of submittedArtifacts) {
    assert.deepEqual(Object.keys(artifact).sort(), [
      "ballot_digest",
      "client_crypto_build_id",
      "crypto_profile",
      "election_instance_id",
      "encrypted_ballot",
      "schema_version",
      "tally_function_id",
      "upstream_ballot_format_version",
    ]);
    assert.equal(Object.hasOwn(artifact, "choice"), false);
    assert.equal(Object.hasOwn(artifact, "scoped_credential"), false);
  }

  results.browser_to_ledger = { status: "PASS", browser: browser.version(), playwright: "1.62.1", receipt_shown: true, storage_backend: postgresMode ? "PostgreSQL 16.10" : "SQLite local adapter" };
  results.native_verification = { status: "PASS", verifier: "Belenios 3.3.0 native", invocations: String(verifierCalls) };
  results.exact_bytes_and_digest = { status: "PASS", first_ballot_digest: firstDigest, exact_bytes_preserved: true, unchanged_i01_digest: true };
  results.mutation_rejection = { status: "PASS", proof_response_mutation: "INVALID_ENCRYPTED_BALLOT", persisted_after_rejection: "1" };
  results.revote_preparation = { status: "PASS", accepted_submissions: "2", same_private_lifecycle: true, public_linkage_exposed: false, supersession_decided: false };
  results.privacy_isolation = { status: "PASS", local_storage: "0", session_storage: "0", cookies: "0", plaintext_vote_in_request_object: false };
  results.network_boundary = { status: "PASS", allowed_origins: [clientOrigin, `http://127.0.0.1:${receiverPort}`], member_cookies: false, analytics: false };
  results.public_status = { status: "PASS", lifecycle_handle_exposed: false, finality_claim: "NOT_FINAL_NOT_COUNTED" };

  await writeFile(join(root, "evidence/results/browser-to-ledger-e2e.json"), `${JSON.stringify(results, null, 2)}\n`);
  await writeFile(join(root, "evidence/results/browser-produced-i03-submission.json"), `${canonicalize(firstArtifact)}\n`);
  process.stdout.write(`${JSON.stringify(results, null, 2)}\n`);
} finally {
  await browserContext.close();
  await browser.close();
  await new Promise((resolveClose) => client.close(resolveClose));
  await new Promise((resolveClose) => receiver.close(resolveClose));
  await store.close();
  await rm(temporary, { recursive: true, force: true });
}
