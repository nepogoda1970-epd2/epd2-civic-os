import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { canonicalize } from "../src/i02_accepted/shared/profile.mjs";
import { verifyPublicFinalEvidence } from "../src/i04/finalization.mjs";
import { REVOTE_POLICY } from "../src/i04/constants.mjs";
import { verifyI04PublicEvidence } from "../verifier/i04_verifier_b.mjs";
import { createPostgresHarness } from "./postgres_helpers.mjs";
import { createI04Harness } from "./i04_postgres_helpers.mjs";
import {
  allowedOrigin,
  postArtifact,
  realBrowserArtifact,
  root,
  realVectorArtifact,
  submissionHeaders,
} from "./helpers.mjs";

async function realBrowserRevoteArtifact() {
  return JSON.parse(await readFile(`${root}/test-vectors/i04-generated/browser-ballot-2.json`, "utf8"));
}

async function accept(h, artifact, key, token = h.token) {
  const response = await fetch(`${h.baseUrl}/v1/elections/${h.fixtures.a.context.election_instance_id}/encrypted-ballots`, {
    method: "POST",
    headers: submissionHeaders(token, key),
    body: canonicalize(artifact),
  });
  const body = await response.json();
  assert.equal(response.status, 201, JSON.stringify(body));
  return body;
}

test("I04 real I03 revote E2E selects latest valid, preserves history and exact bytes", async (t) => {
  const i03 = await createPostgresHarness();
  t.after(i03.cleanup);
  const ballotA = await realBrowserArtifact();
  const ballotB = await realVectorArtifact(i03.fixtures.a.context, "I02-P02.json");
  const receiptA = await accept(i03, ballotA, "i04-real-browser-a-0001");
  const receiptB = await accept(i03, ballotB, "i04-real-browser-b-0001");

  const i04 = await createI04Harness({ startServer: true });
  t.after(i04.cleanup);
  const electionId = i03.fixtures.a.context.election_instance_id;
  const preview = await i04.store.previewClosure(electionId);
  const authorization = await i04.authorizePreview(electionId, preview);
  const finalizeResponse = await fetch(`${i04.baseUrl}/v1/elections/${electionId}/finalize`, {
    method: "POST",
    headers: { origin: allowedOrigin, "content-type": "application/json" },
    body: canonicalize(authorization),
  });
  assert.equal(finalizeResponse.status, 201);
  const result = await finalizeResponse.json();
  assert.equal(result.finalization_state, "FINALIZED");

  const evidenceResponse = await fetch(`${i04.baseUrl}/v1/elections/${electionId}/final-set-evidence`, {
    headers: { origin: allowedOrigin },
  });
  assert.equal(evidenceResponse.status, 200);
  const evidence = await evidenceResponse.json();
  assert.deepEqual(evidence.cset_final.ordered_ballot_digests, [ballotB.ballot_digest]);
  assert.equal(evidence.revote_policy_version, REVOTE_POLICY);
  assert.equal(evidence.accepted_manifest_at_closure.accepted_ballot_digests.includes(ballotA.ballot_digest), true);
  assert.equal(evidence.accepted_manifest_at_closure.accepted_ballot_digests.includes(ballotB.ballot_digest), true);
  assert.equal(JSON.stringify(evidence).includes("lifecycle_handle"), false);
  assert.equal(verifyPublicFinalEvidence(evidence, { authorizationVerifier: i04.authorizationVerifier }).valid, true);
  assert.equal(verifyI04PublicEvidence(evidence, { closurePublicKeys: new Map([[i04.keyId, i04.publicKey]]) }).status, "PASS");

  const audit = await i04.store.privateResolutionAudit(electionId);
  assert.equal(audit.length, 1);
  assert.deepEqual(audit[0].candidate_submission_ids, [receiptA.submission_id, receiptB.submission_id]);
  assert.equal(audit[0].effective_submission_id, receiptB.submission_id);
  const exact = await i04.store.exactFinalBallotBytes(electionId);
  assert.equal(exact.length, 1);
  assert.equal(exact[0].ballot_digest, ballotB.ballot_digest);
  assert.deepEqual(exact[0].encrypted_ballot_bytes, Buffer.from(ballotB.encrypted_ballot, "base64url"));

  const replay = await i04.store.finalize({
    electionInstanceId: electionId,
    authorizationEvidence: authorization,
    authorizationVerifier: i04.authorizationVerifier,
  });
  assert.equal(replay.replay, true);
  assert.equal(replay.f_final, result.f_final);
  assert.equal((await i04.store.recompute(electionId, { authorizationVerifier: i04.authorizationVerifier })).status, "PASS");
});

test("I04 multi-lifecycle resolution yields A2, B1 and C3 in I01 digest order", async (t) => {
  const i03 = await createPostgresHarness();
  t.after(i03.cleanup);
  const vectors = await Promise.all([
    realVectorArtifact(i03.fixtures.a.context, "I02-P01.json"),
    realVectorArtifact(i03.fixtures.a.context, "I02-P02.json"),
    realVectorArtifact(i03.fixtures.a.context, "I02-P03.json"),
    realBrowserArtifact(),
    JSON.parse(await readFile(`${root}/test-vectors/i04-generated/browser-ballot-1.json`, "utf8")),
    realBrowserRevoteArtifact(),
  ]);
  const auth2 = i03.credentialAuthority.issue({
    electionInstanceId: i03.fixtures.a.context.election_instance_id,
    lifecycleNonce: "1123456789abcdef0123456789abcdef",
    expiresAt: "2030-01-01T00:00:00Z",
    revoteAllowed: true,
  });
  const auth3 = i03.credentialAuthority.issue({
    electionInstanceId: i03.fixtures.a.context.election_instance_id,
    lifecycleNonce: "2123456789abcdef0123456789abcdef",
    expiresAt: "2030-01-01T00:00:00Z",
    revoteAllowed: true,
  });
  await accept(i03, vectors[0], "i04-multi-a1-0001");
  await accept(i03, vectors[1], "i04-multi-a2-0001");
  await accept(i03, vectors[2], "i04-multi-b1-0001", auth2.scoped_credential.secret);
  await accept(i03, vectors[3], "i04-multi-c1-0001", auth3.scoped_credential.secret);
  await accept(i03, vectors[4], "i04-multi-c2-0001", auth3.scoped_credential.secret);
  await accept(i03, vectors[5], "i04-multi-c3-0001", auth3.scoped_credential.secret);

  const i04 = await createI04Harness();
  t.after(i04.cleanup);
  const electionId = i03.fixtures.a.context.election_instance_id;
  const preview = await i04.store.previewClosure(electionId);
  const authorization = await i04.authorizePreview(electionId, preview);
  const finalized = await i04.store.finalize({ electionInstanceId: electionId, authorizationEvidence: authorization, authorizationVerifier: i04.authorizationVerifier });
  const expected = [vectors[1].ballot_digest, vectors[2].ballot_digest, vectors[5].ballot_digest]
    .sort((a, b) => Buffer.from(a, "hex").compare(Buffer.from(b, "hex")));
  assert.deepEqual(finalized.cset_final.ordered_ballot_digests, expected);
  assert.equal((await i04.store.privateResolutionAudit(electionId)).length, 3);
});

test("I04 empty election finalizes deterministically", async (t) => {
  const i03 = await createPostgresHarness();
  t.after(i03.cleanup);
  const i04 = await createI04Harness();
  t.after(i04.cleanup);
  const electionId = i03.fixtures.a.context.election_instance_id;
  const preview = await i04.store.previewClosure(electionId);
  const authorization = await i04.authorizePreview(electionId, preview);
  const finalized = await i04.store.finalize({ electionInstanceId: electionId, authorizationEvidence: authorization, authorizationVerifier: i04.authorizationVerifier });
  assert.deepEqual(finalized.cset_final.ordered_ballot_digests, []);
  assert.match(finalized.cset_root, /^[0-9a-f]{64}$/u);
  assert.match(finalized.f_final, /^[0-9a-f]{64}$/u);
});
