import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { root, toolPath } from './helpers.mjs';
import { BeleniosThresholdAdapter } from '../src/i06/belenios_threshold.mjs';
import { partialDecryptionShareDigest } from '../src/i06/hashes.mjs';
import { verifyGuardianCeremonyRecord, verifyShareArtifact, verifyThresholdDecryptionRecord } from '../src/i06/records.mjs';
const baseVector=JSON.parse(await readFile(join(root,'test-vectors/i06/vectors/I06-V01.json'),'utf8'));
const idx=JSON.parse(await readFile(join(root,'test-vectors/i06/mutations/index.json'),'utf8'));
const tally={...baseVector.i05_authorized_tally_reference,aggregate_ciphertext_bytes:Buffer.from(baseVector.i05_authorized_tally_reference.aggregate_ciphertext_base64url,'base64url')};delete tally.aggregate_ciphertext_base64url;
const adapter=new BeleniosThresholdAdapter({toolPath,templatePath:join(root,'evidence/fixtures/i06-election-n3t2/template.json')});
const archive=join(root,'test-vectors/i06/fixtures/n3-t2/decryption-base.bel');
function clone(x){return structuredClone(x);}
function resealShare(s){const {share_digest,...without}=s;s.share_digest=partialDecryptionShareDigest(without);return s;}
function rawShare(s){return Buffer.from(s.belenios_partial_decryption_base64url,'base64url');}
for(const item of idx.vectors){
 test(`${item.vector_id} frozen mutation vector rejects`,async()=>{
  const mv=JSON.parse(await readFile(join(root,item.path),'utf8'));assert.equal(mv.expected,'REJECT');const m=mv.mutation;
  if(m.kind==='share-field-resealed'){
    const s=clone(baseVector.partial_decryption_shares[0]);s[m.field]=m.value;resealShare(s);
    assert.throws(()=>verifyShareArtifact(s,{ceremony:baseVector.guardian_ceremony_record,tally}),e=>e.code===mv.expected_error_or_class);
  } else if(m.kind==='duplicate-guardian'){
    const s=baseVector.partial_decryption_shares[0],raw=rawShare(s);
    await assert.rejects(adapter.computeVerifiedResult({baseArchivePath:archive,shares:[{guardian_index:1,share_bytes:raw},{guardian_index:1,share_bytes:raw}]}));
  } else if(m.kind==='belenios-share-resealed'){
    const good=baseVector.partial_decryption_shares[0],bad=clone(baseVector.partial_decryption_shares[m.guardian_index-1]);
    const raw=JSON.parse(rawShare(bad).toString('utf8'));
    if(m.component.startsWith('decryption_proofs')) raw.decryption_proofs[0][0].challenge=m.value;
    else {const x=raw.decryption_factors[0][0];raw.decryption_factors[0][0]=`${x[0]==='0'?'1':'0'}${x.slice(1)}`;}
    bad.belenios_partial_decryption_base64url=Buffer.from(JSON.stringify(raw)).toString('base64url');resealShare(bad);
    assert.equal(verifyShareArtifact(bad,{ceremony:baseVector.guardian_ceremony_record,tally}).valid,true);
    await assert.rejects(adapter.computeVerifiedResult({baseArchivePath:archive,shares:[{guardian_index:1,share_bytes:rawShare(good)},{guardian_index:m.guardian_index,share_bytes:rawShare(bad)}]}));
  } else if(m.kind==='ceremony-field'){
    const c=clone(baseVector.guardian_ceremony_record);c[m.field]=m.value;assert.throws(()=>verifyGuardianCeremonyRecord(c),e=>e.code===mv.expected_error_or_class);
  } else if(m.kind==='decryption-record-field'){
    const r=clone(baseVector.threshold_decryption_record);r[m.field]=m.value??m.value_base64url;assert.throws(()=>verifyThresholdDecryptionRecord(r,{ceremony:baseVector.guardian_ceremony_record,tally}),e=>e.code===mv.expected_error_or_class);
  } else assert.fail(`unknown mutation kind ${m.kind}`);
 });
}
