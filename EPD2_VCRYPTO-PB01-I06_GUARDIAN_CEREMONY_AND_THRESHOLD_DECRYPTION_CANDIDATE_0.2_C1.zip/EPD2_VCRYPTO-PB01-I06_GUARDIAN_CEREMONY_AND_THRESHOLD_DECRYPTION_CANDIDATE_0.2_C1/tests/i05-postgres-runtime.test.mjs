// PB01-I05 0.2_C1 — real PostgreSQL production-runtime acceptance.
// Every store in this file is the production PostgreSQL implementation.
// No MemStore / FinalStore doubles are used for any assertion here.
import assert from 'node:assert/strict';
import test from 'node:test';
import { adminPool } from './postgres_helpers.mjs';
import { engineFor, finalizedFixture, tallyStore } from './i05_postgres_helpers.mjs';
import { verifyTallyEvidence } from '../src/i05/tally.mjs';
import { aggregateCiphertextDigest, tallyRecordDigest } from '../src/i05/hashes.mjs';

async function countRows(table) {
  const pool = await adminPool();
  try { return Number((await pool.query(`SELECT count(*)::bigint AS n FROM pb01_i05.${table}`)).rows[0].n); }
  finally { await pool.end(); }
}

test('I05/PG exact finalized I04 set becomes the tally input and native Belenios re-verification runs per ballot', async (t) => {
  const { i03, i04, eid, fin } = await finalizedFixture(t);
  const store = tallyStore();
  t.after(() => store.close());
  const invocations = [];
  const engine = engineFor({ i03, i04, store, onInvocation: (kind) => invocations.push(kind) });

  const authorizedSet = await i04.store.authorizedFinalBallotSet(eid);
  const result = await engine.execute(eid);

  // Exact finalized-set consumption: the tally is bound to the authoritative I04 f_final and set.
  assert.equal(result.f_final, fin.f_final);
  assert.equal(result.cset_root, fin.cset_root);
  assert.equal(result.ballot_count_decimal, String(authorizedSet.ordered_ballot_digests.length));
  assert.deepEqual(result.tally_input_manifest.ordered_ballot_digests, authorizedSet.ordered_ballot_digests);
  assert.equal(result.tally_input_manifest.f_final, fin.f_final);
  assert.equal(result.replay, false);

  // Native Belenios 3.3.0 re-verification actually executed, once per exact ballot, before aggregation.
  const ballots = authorizedSet.ordered_ballot_digests.length;
  assert.equal(invocations.filter((x) => x === 'verify-ballot').length, ballots);
  assert.equal(invocations.filter((x) => x === 'compute-encrypted-tally').length, 1);
  assert.equal(invocations.indexOf('verify-ballot') < invocations.indexOf('compute-encrypted-tally'), true);

  // Persisted evidence is self-consistent and byte-exact against the stored aggregate.
  assert.equal(verifyTallyEvidence(result.tally_evidence_bundle).valid, true);
  assert.equal(aggregateCiphertextDigest(result.aggregate_ciphertext_bytes), result.aggregate_ciphertext_digest);
  const { tally_record_digest: recordDigest, ...recordBody } = result.homomorphic_tally_record;
  assert.equal(tallyRecordDigest(recordBody), recordDigest);
  assert.equal(recordDigest, result.tally_record_digest);
  assert.equal(await countRows('tally_records'), 1);
  assert.equal(await countRows('aggregates'), 1);
});

test('I05/PG idempotent retry replays one physical tally without recomputing a second record', async (t) => {
  const { i03, i04, eid } = await finalizedFixture(t);
  const store = tallyStore();
  t.after(() => store.close());
  const engine = engineFor({ i03, i04, store });

  const first = await engine.execute(eid);
  const second = await engine.execute(eid);
  const third = await engine.execute(eid);

  assert.equal(first.replay, false);
  assert.equal(second.replay, true);
  assert.equal(third.replay, true);
  for (const later of [second, third]) {
    assert.equal(later.tally_record_digest, first.tally_record_digest);
    assert.equal(later.aggregate_ciphertext_digest, first.aggregate_ciphertext_digest);
    assert.equal(later.tally_input_digest, first.tally_input_digest);
    assert.equal(later.f_final, first.f_final);
    assert.deepEqual(later.aggregate_ciphertext_bytes, first.aggregate_ciphertext_bytes);
  }
  assert.equal(await countRows('tally_records'), 1);
  assert.equal(await countRows('aggregates'), 1);
});

test('I05/PG concurrent tally executions never diverge and every caller converges on one identical tally', async (t) => {
  const { i03, i04, eid, fin } = await finalizedFixture(t);
  const store = tallyStore({ max: 8 });
  t.after(() => store.close());

  const engines = [0, 1, 2, 3].map(() => engineFor({ i03, i04, store }));
  const settled = await Promise.allSettled(engines.map((engine) => engine.execute(eid)));
  const committed = settled.filter((x) => x.status === 'fulfilled').map((x) => x.value);
  const rejected = settled.filter((x) => x.status === 'rejected').map((x) => x.reason);

  // At least one caller must succeed, and no caller may fail for a non-transient reason.
  // PostgreSQL SERIALIZABLE may abort a concurrent writer with 40001; that is a retryable
  // transport-level outcome, never a divergent tally.
  assert.ok(committed.length >= 1, 'at least one concurrent execution must commit');
  for (const error of rejected) {
    assert.equal(error.code, '40001', `only serialization failures are tolerable, got ${error.code ?? error.message}`);
  }

  // The safety property: exactly one tally exists and all successful callers saw it.
  assert.equal(new Set(committed.map((r) => r.tally_record_digest)).size, 1);
  assert.equal(new Set(committed.map((r) => r.aggregate_ciphertext_digest)).size, 1);
  assert.equal(committed.filter((r) => r.replay === false).length, 1);
  assert.equal(await countRows('tally_records'), 1);
  assert.equal(await countRows('aggregates'), 1);

  const persisted = await store.read(eid);
  assert.equal(persisted.tally_record_digest, committed[0].tally_record_digest);
  assert.equal(persisted.f_final, fin.f_final);

  // Every caller that hit a serialization failure converges on the identical tally when retried.
  for (let i = 0; i < rejected.length; i += 1) {
    const retried = await engines[i].execute(eid);
    assert.equal(retried.replay, true);
    assert.equal(retried.tally_record_digest, persisted.tally_record_digest);
    assert.equal(retried.f_final, fin.f_final);
  }
});

test('I05/PG rejects a conflicting F_final and a conflicting tally record against the same election', async (t) => {
  const { i03, i04, eid, fin } = await finalizedFixture(t);
  const store = tallyStore();
  t.after(() => store.close());
  const engine = engineFor({ i03, i04, store });
  const computed = await engine.compute(eid);

  // (a) F_final that does not match the authoritative finalized I04 record is refused before any write.
  await assert.rejects(
    store.commit({ electionInstanceId: eid, fFinal: 'a'.repeat(64), artifacts: computed.artifacts, aggregate: computed.aggregate }),
    (error) => error.code === 'TALLY_CONFLICT',
  );
  assert.equal(await countRows('aggregates'), 0);
  assert.equal(await countRows('tally_records'), 0);
  assert.equal(await store.read(eid), null);

  // The honest tally still commits afterwards.
  const committed = await engine.execute(eid);
  assert.equal(committed.f_final, fin.f_final);

  // (b) A second, different tally record for an already-tallied election is refused.
  const divergent = {
    ...computed.artifacts,
    tallyRecordDigest: 'b'.repeat(64),
    homomorphicTallyRecord: { ...computed.artifacts.homomorphicTallyRecord, tally_record_digest: 'b'.repeat(64) },
  };
  await assert.rejects(
    store.commit({ electionInstanceId: eid, fFinal: fin.f_final, artifacts: divergent, aggregate: computed.aggregate }),
    (error) => error.code === 'TALLY_CONFLICT',
  );

  // (c) Conflicting F_final against an already-tallied election is also refused.
  await assert.rejects(
    store.commit({ electionInstanceId: eid, fFinal: 'c'.repeat(64), artifacts: computed.artifacts, aggregate: computed.aggregate }),
    (error) => error.code === 'TALLY_CONFLICT',
  );

  // Exactly one tally survives, unchanged.
  assert.equal(await countRows('tally_records'), 1);
  assert.equal(await countRows('aggregates'), 1);
  const persisted = await store.read(eid);
  assert.equal(persisted.tally_record_digest, committed.tally_record_digest);
  assert.equal(persisted.f_final, fin.f_final);
});

test('I05/PG recompute reproduces the committed tally byte-for-byte from PostgreSQL state', async (t) => {
  const { i03, i04, eid, fin } = await finalizedFixture(t);
  const store = tallyStore();
  t.after(() => store.close());
  const engine = engineFor({ i03, i04, store });
  const committed = await engine.execute(eid);

  const recomputed = await engine.recompute(eid);
  assert.equal(recomputed.status, 'PASS');
  assert.equal(recomputed.f_final, fin.f_final);
  assert.equal(recomputed.tally_record_digest, committed.tally_record_digest);
  assert.equal(recomputed.aggregate_ciphertext_digest, committed.aggregate_ciphertext_digest);

  // A second independent recompute is stable.
  assert.equal((await engineFor({ i03, i04, store }).recompute(eid)).status, 'PASS');
});
