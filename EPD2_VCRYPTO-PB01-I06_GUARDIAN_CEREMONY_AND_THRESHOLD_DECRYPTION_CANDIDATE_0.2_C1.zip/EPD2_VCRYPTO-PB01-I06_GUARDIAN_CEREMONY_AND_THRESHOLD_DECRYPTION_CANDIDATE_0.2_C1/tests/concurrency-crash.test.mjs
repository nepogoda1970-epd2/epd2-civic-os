import assert from "node:assert/strict";
import { request as httpRequest } from "node:http";
import test from "node:test";
import { canonicalize } from "../src/i02_accepted/shared/profile.mjs";
import { startI03Service } from "../src/i03/http_service.mjs";
import { NativeBeleniosVerifier } from "../src/i03/native_verifier.mjs";
import { SqliteSubmissionStore } from "../src/i03/sqlite_store.mjs";
import {
  allowedOrigin,
  createHarness,
  postArtifact,
  realBrowserArtifact,
  realVectorArtifact,
  submissionHeaders,
  toolPath,
} from "./helpers.mjs";

test("concurrent same idempotency key and raw digest create one logical acceptance", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();
  const sameKey = await Promise.all([
    postArtifact(h, artifact, "idem-concurrent-same01"),
    postArtifact(h, artifact, "idem-concurrent-same01"),
  ]);
  assert.deepEqual(sameKey.map((response) => response.status).sort(), [200, 201]);
  const receipts = await Promise.all(sameKey.map((response) => response.json()));
  assert.deepEqual(receipts[0], receipts[1]);
  assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).submissions, 1);
  assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).ledger_events, 1);
});

test("different valid revotes concurrently coexist under one private lifecycle", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  const first = await realBrowserArtifact();
  const second = await realVectorArtifact(h.fixtures.a.context, "I02-P02.json");
  const responses = await Promise.all([
    postArtifact(h, first, "idem-concurrent-revote1"),
    postArtifact(h, second, "idem-concurrent-revote2"),
  ]);
  assert.deepEqual(responses.map((response) => response.status).sort(), [201, 201]);
  const receipts = await Promise.all(responses.map((response) => response.json()));
  const privateA = h.store.privateLifecycleForSubmission(receipts[0].submission_id);
  const privateB = h.store.privateLifecycleForSubmission(receipts[1].submission_id);
  assert.equal(privateA.lifecycle_handle, privateB.lifecycle_handle);
  assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).submissions, 2);
  assert.equal(h.store.verifyLedger(h.fixtures.a.context.election_instance_id).valid, true);
});

test("CRASH-01 after crypto before transaction leaves no accepted state", async (t) => {
  let armed = true;
  const h = await createHarness({ failpoint: async (point) => {
    if (armed && point === "after_crypto_before_transaction") {
      armed = false;
      throw new Error("SIMULATED_CRASH");
    }
  } });
  t.after(h.cleanup);
  const response = await postArtifact(h, await realBrowserArtifact(), "idem-crash-beforetxn1");
  assert.equal(response.status, 503);
  assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).submissions, 0);
});

test("CRASH-02 after commit before response and CRASH-04 restart retry recover same receipt", async (t) => {
  let armed = true;
  const h = await createHarness({ failpoint: async (point) => {
    if (armed && point === "after_commit_before_response") {
      armed = false;
      throw new Error("SIMULATED_RESPONSE_LOSS");
    }
  } });
  const artifact = await realBrowserArtifact();
  const key = "idem-crash-aftercommit1";
  const lost = await postArtifact(h, artifact, key);
  assert.equal(lost.status, 503);
  assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).submissions, 1);
  await new Promise((resolveClose) => h.server.close(resolveClose));
  h.store.close();

  const reopened = new SqliteSubmissionStore(h.databasePath);
  const verifier = new NativeBeleniosVerifier({ toolPath });
  const restarted = await startI03Service({
    store: reopened,
    electionFixtures: new Map([
      [h.fixtures.a.context.election_instance_id, h.fixtures.a],
      [h.fixtures.b.context.election_instance_id, h.fixtures.b],
    ]),
    verifier,
    credentialAuthority: h.credentialAuthority,
    receiptSigner: h.receiptSigner,
    idempotencySecret: Buffer.alloc(32, 0x43),
    allowedOrigin,
    port: 0,
    developmentHttp: true,
  });
  t.after(async () => {
    await new Promise((resolveClose) => restarted.close(resolveClose));
    reopened.close();
    await (await import("node:fs/promises")).rm(h.temporary, { recursive: true, force: true });
  });
  h.baseUrl = `http://127.0.0.1:${restarted.address().port}`;
  const retry = await postArtifact(h, artifact, key);
  assert.equal(retry.status, 200);
  const receipt = await retry.json();
  assert.equal(receipt.ballot_digest, artifact.ballot_digest);
  assert.equal(reopened.counts(h.fixtures.a.context.election_instance_id).submissions, 1);
});

test("CRASH-03 client disconnect after request body does not lose committed ballot", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();
  const body = canonicalize(artifact);
  const url = new URL(`${h.baseUrl}/v1/elections/${h.fixtures.a.context.election_instance_id}/encrypted-ballots`);
  await new Promise((resolve) => {
    const req = httpRequest({
      hostname: url.hostname,
      port: url.port,
      path: url.pathname,
      method: "POST",
      headers: { ...submissionHeaders(h.token, "idem-disconnect-000001"), "content-length": Buffer.byteLength(body) },
    });
    req.on("error", () => resolve());
    req.end(body, () => setTimeout(() => { req.destroy(); resolve(); }, 25));
  });
  for (let attempt = 0; attempt < 80 && h.store.counts(h.fixtures.a.context.election_instance_id).submissions === 0; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 25));
  }
  assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).submissions, 1);
  const retry = await postArtifact(h, artifact, "idem-disconnect-000001");
  assert.equal(retry.status, 200);
});
