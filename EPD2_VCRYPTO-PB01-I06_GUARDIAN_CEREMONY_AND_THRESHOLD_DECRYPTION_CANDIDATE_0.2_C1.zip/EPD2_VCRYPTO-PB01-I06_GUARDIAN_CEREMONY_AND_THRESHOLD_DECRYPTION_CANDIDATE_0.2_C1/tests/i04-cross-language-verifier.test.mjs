import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

test("I04 independent cross-language Verifier B consumes all frozen vectors and rejects required mutations", async () => {
  const run = spawnSync("go", [
    "run", ".",
    "--vectors", "../../test-vectors/i04-verifier-b",
    "--out", "../../evidence/results/i04-cross-language-verifier.json",
  ], {
    cwd: resolve(root, "verifier/reference-go"),
    encoding: "utf8",
  });
  assert.equal(run.status, 0, `${run.stdout}\n${run.stderr}`);
  const report = JSON.parse(await readFile(resolve(root, "evidence/results/i04-cross-language-verifier.json"), "utf8"));
  assert.equal(report.status, "PASS");
  assert.equal(report.producer_code_imports, false);
  assert.equal(report.byte_for_byte_agreement, true);
  assert.deepEqual(report.vectors.map((v) => [v.case, v.status, v.byte_for_byte_agreement]), [
    ["one-lifecycle-one-ballot", "PASS", true],
    ["one-lifecycle-two-revotes", "PASS", true],
    ["three-lifecycles-mixed-revotes", "PASS", true],
    ["empty-final-set", "PASS", true],
  ]);
  assert.deepEqual(report.mutations.map((m) => [m.name, m.expected, m.observed]), [
    ["MUT-I04-CHECKPOINT", "REJECT", "REJECT"],
    ["MUT-I04-ACCEPTED-SET", "REJECT", "REJECT"],
    ["MUT-I04-CSET-ORDER", "REJECT", "REJECT"],
    ["MUT-I04-CLOSURE-SIGNATURE", "REJECT", "REJECT"],
    ["MUT-I04-FINAL-SET-ENVELOPE", "REJECT", "REJECT"],
    ["MUT-I04-F-FINAL", "REJECT", "REJECT"],
  ]);
});

test("independent verifier source does not import producer hashing/canonicalization modules", async () => {
  const goSource = await readFile(resolve(root, "verifier/reference-go/main.go"), "utf8");
  const rustSource = await readFile(resolve(root, "verifier/rust/src/main.rs"), "utf8");
  for (const source of [goSource, rustSource]) {
    assert.doesNotMatch(source, /src\/i0[1-4]|pb01_profile\.mjs|finalization\.mjs|hashes\.mjs/u);
  }
});
