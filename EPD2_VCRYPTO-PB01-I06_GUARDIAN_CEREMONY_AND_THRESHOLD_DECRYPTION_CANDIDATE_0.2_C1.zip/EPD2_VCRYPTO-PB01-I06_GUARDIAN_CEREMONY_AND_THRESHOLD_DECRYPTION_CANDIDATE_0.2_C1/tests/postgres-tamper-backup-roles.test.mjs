import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";
import test from "node:test";
import pg from "pg";
import { PostgresSubmissionStore } from "../src/i03/postgres_store.mjs";
import { postArtifact, realBrowserArtifact, realVectorArtifact } from "./helpers.mjs";
import {
  adminPool,
  adminUrl,
  createPostgresHarness,
  createdbPath,
  dropdbPath,
  evidenceUrl,
  pgRestorePath,
  runtimeUrl,
} from "./postgres_helpers.mjs";

const { Pool } = pg;
const execFileAsync = promisify(execFile);

async function withTamperTransaction(electionId, mutate, check) {
  const pool = await adminPool();
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SET LOCAL session_replication_role = replica");
    await mutate(client);
    const transactionView = new PostgresSubmissionStore({ pool: client });
    await check(transactionView);
    await client.query("ROLLBACK");
  } catch (error) {
    try { await client.query("ROLLBACK"); } catch { /* transaction already ended */ }
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

test("PG append-only triggers and hash-chain checkpoint detect privileged tampering", async (t) => {
  const h = await createPostgresHarness();
  t.after(h.cleanup);
  const first = await realBrowserArtifact();
  const second = await realVectorArtifact(h.fixtures.a.context, "I02-P02.json");
  const firstResponse = await postArtifact(h, first, "pg-tamper-source-0001");
  const firstReceipt = await firstResponse.json();
  assert.equal((await postArtifact(h, second, "pg-tamper-source-0002")).status, 201);
  const electionId = h.fixtures.a.context.election_instance_id;
  const checkpoint = await h.store.checkpoint(electionId);
  assert.equal((await h.store.verifyLedger(electionId, checkpoint)).valid, true);

  const admin = await adminPool();
  await assert.rejects(
    admin.query("UPDATE pb01_i03.encrypted_submissions SET accepted_at = now() WHERE submission_id = $1", [firstReceipt.submission_id]),
    /APPEND_ONLY_VIOLATION/u,
  );
  await assert.rejects(
    admin.query("DELETE FROM pb01_i03.submission_ledger_events WHERE submission_id = $1", [firstReceipt.submission_id]),
    /APPEND_ONLY_VIOLATION/u,
  );
  await admin.end();

  await withTamperTransaction(electionId, async (client) => {
    await client.query("UPDATE pb01_i03.submission_ledger_events SET ballot_digest = $1 WHERE ledger_seq = 1", ["f".repeat(64)]);
  }, async (view) => {
    assert.match((await view.verifyLedger(electionId, checkpoint)).reason, /ROW_EVENT_MISMATCH|EVENT_HASH_MISMATCH/u);
  });

  await withTamperTransaction(electionId, async (client) => {
    await client.query("DELETE FROM pb01_i03.submission_ledger_events WHERE ledger_seq = 2");
  }, async (view) => {
    assert.equal((await view.verifyLedger(electionId, checkpoint)).reason, "CHECKPOINT_CONFLICT");
  });

  await withTamperTransaction(electionId, async (client) => {
    await client.query("UPDATE pb01_i03.submission_ledger_events SET ledger_seq = 99 WHERE ledger_seq = 1");
    await client.query("UPDATE pb01_i03.submission_ledger_events SET ledger_seq = 1 WHERE ledger_seq = 2");
    await client.query("UPDATE pb01_i03.submission_ledger_events SET ledger_seq = 2 WHERE ledger_seq = 99");
  }, async (view) => {
    assert.equal((await view.verifyLedger(electionId, checkpoint)).reason, "CHAIN_ORDER_OR_LINK_MISMATCH");
  });

  const conflicting = { ...checkpoint, ledger_event_hash: "e".repeat(64) };
  assert.equal((await h.store.verifyLedger(electionId, conflicting)).reason, "CHECKPOINT_CONFLICT");
});

test("PG backup/restore preserves exact bytes, receipt state, ledger and private/public split", async (t) => {
  const h = await createPostgresHarness();
  t.after(h.cleanup);
  const temporary = await mkdtemp(join(tmpdir(), "epd2-i03-pg-backup-"));
  t.after(() => rm(temporary, { recursive: true, force: true }));
  const artifact = await realBrowserArtifact();
  const response = await postArtifact(h, artifact, "pg-backup-source-0001");
  const receipt = await response.json();
  const dumpPath = join(temporary, "pb01-i03.dump");
  await h.store.backupTo(dumpPath);
  assert.ok((await readFile(dumpPath)).length > 0);

  const admin = new URL(adminUrl);
  const restoreDatabase = "epd2_i03_restore_test";
  const common = ["--host", admin.hostname, "--port", admin.port, "--username", admin.username];
  await execFileAsync(dropdbPath, [...common, "--if-exists", restoreDatabase]);
  await execFileAsync(createdbPath, [...common, restoreDatabase]);
  await execFileAsync(pgRestorePath, [...common, "--no-owner", "--no-privileges", "--dbname", restoreDatabase, dumpPath]);
  const restoredUrl = new URL(adminUrl);
  restoredUrl.pathname = `/${restoreDatabase}`;
  const restored = new PostgresSubmissionStore({ connectionString: restoredUrl.toString(), ssl: false, max: 3 });
  t.after(() => restored.close());
  assert.deepEqual(
    await restored.exactBallotBytes(h.fixtures.a.context.election_instance_id, artifact.ballot_digest),
    Buffer.from(artifact.encrypted_ballot, "base64url"),
  );
  assert.equal((await restored.lookupStatus(h.fixtures.a.context.election_instance_id, artifact.ballot_digest)).submission_id, receipt.submission_id);
  assert.equal((await restored.verifyLedger(h.fixtures.a.context.election_instance_id)).valid, true);
  assert.equal(JSON.stringify(await restored.exportAcceptedManifest(h.fixtures.a.context.election_instance_id)).includes("lifecycle_handle"), false);
  const lifecycle = await restored.privateLifecycleForSubmission(receipt.submission_id);
  assert.equal(lifecycle.lifecycle_handle.length, 64);
});

test("PG submission runtime and evidence reader have no DDL or mutation authority", async (t) => {
  const h = await createPostgresHarness();
  t.after(h.cleanup);
  assert.equal(h.privilegeEvidence.validation, "PASS_NO_RUNTIME_DDL");
  assert.equal(h.privilegeEvidence.rolsuper, false);
  assert.equal(h.privilegeEvidence.rolcreatedb, false);
  assert.equal(h.privilegeEvidence.rolcreaterole, false);
  assert.equal(h.privilegeEvidence.schema_create, false);
  assert.equal(h.privilegeEvidence.public_schema_create, false);
  assert.equal(h.privilegeEvidence.database_temp, false);
  assert.equal(h.privilegeEvidence.submissions_update, false);
  assert.equal(h.privilegeEvidence.submissions_delete, false);
  assert.equal(h.privilegeEvidence.submissions_truncate, false);

  const runtime = new Pool({ connectionString: runtimeUrl, ssl: false, max: 2 });
  t.after(() => runtime.end());
  await assert.rejects(runtime.query("CREATE TABLE pb01_i03.forbidden_runtime_ddl(id int)"), /permission denied/u);
  await assert.rejects(runtime.query("CREATE TEMP TABLE forbidden_temp(id int)"), /permission denied/u);
  await assert.rejects(runtime.query("ALTER TABLE pb01_i03.encrypted_submissions ADD COLUMN forbidden int"), /must be owner|permission denied/u);
  await assert.rejects(runtime.query("TRUNCATE pb01_i03.encrypted_submissions"), /permission denied/u);
  await assert.rejects(runtime.query("UPDATE pb01_i03.elections SET election_state = 'CLOSED'"), /permission denied/u);
  await assert.rejects(runtime.query("DROP SCHEMA pb01_i03 CASCADE"), /must be owner|permission denied/u);

  const evidence = new Pool({ connectionString: evidenceUrl, ssl: false, max: 2 });
  t.after(() => evidence.end());
  await evidence.query("SELECT count(*) FROM pb01_i03.encrypted_submissions");
  await assert.rejects(evidence.query("INSERT INTO pb01_i03.security_audit_events(audit_event_id,event_code,occurred_at,detail_json) VALUES (gen_random_uuid(),'X',now(),'{}')"), /permission denied/u);
  await assert.rejects(evidence.query("DELETE FROM pb01_i03.encrypted_submissions"), /permission denied/u);
});
