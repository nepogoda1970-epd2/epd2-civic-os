import assert from "node:assert/strict";
import test from "node:test";
import { canonicalize, ballotDigest } from "../src/i02_accepted/shared/profile.mjs";
import { mutateRawBallot } from "../src/i02_accepted/shared/mutations.mjs";
import { verifyReceipt } from "../src/i03/receipt.mjs";
import {
  allowedOrigin,
  createHarness,
  postArtifact,
  realBrowserArtifact,
  realVectorArtifact,
  statusLookup,
  submissionHeaders,
} from "./helpers.mjs";

function mutatedArtifact(artifact, context, kind) {
  const raw = Buffer.from(artifact.encrypted_ballot, "base64url").toString("utf8");
  const changed = Buffer.from(mutateRawBallot(raw, kind), "utf8").toString("base64url");
  return { ...artifact, encrypted_ballot: changed, ballot_digest: ballotDigest(context, changed) };
}

async function rawPost(harness, body, key = "idem-raw-0000000001", headers = {}) {
  return fetch(`${harness.baseUrl}/v1/elections/${harness.fixtures.a.context.election_instance_id}/encrypted-ballots`, {
    method: "POST",
    headers: { ...submissionHeaders(harness.token, key), ...headers },
    body,
  });
}

test("I03-P01..P10 real I02 ballot acceptance path", async (t) => {
  let verifierCalls = 0;
  const h = await createHarness({ verifierInvocation: () => { verifierCalls += 1; } });
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();

  const accepted = await postArtifact(h, artifact, "idem-positive-000001");
  assert.equal(accepted.status, 201);
  const receipt = await accepted.json();
  assert.equal(receipt.ballot_digest, artifact.ballot_digest);
  assert.equal(receipt.acceptance_claim, "ACCEPTED_NOT_FINAL_NOT_COUNTED");
  assert.equal(verifyReceipt(receipt, h.receiptPublicKey), true);
  assert.equal(verifierCalls, 1);
  assert.deepEqual(h.store.exactBallotBytes(h.fixtures.a.context.election_instance_id, artifact.ballot_digest), Buffer.from(artifact.encrypted_ballot, "base64url"));

  const replay = await postArtifact(h, artifact, "idem-positive-000001");
  assert.equal(replay.status, 200);
  assert.deepEqual(await replay.json(), receipt);
  assert.deepEqual(h.store.counts(h.fixtures.a.context.election_instance_id), {
    submissions: 1,
    lifecycle_bindings: 1,
    ledger_events: 1,
    idempotency_records: 1,
  });

  const revote = await realVectorArtifact(h.fixtures.a.context, "I02-P02.json");
  const revoteResponse = await postArtifact(h, revote, "idem-positive-000002");
  assert.equal(revoteResponse.status, 201);
  const revoteReceipt = await revoteResponse.json();
  assert.notEqual(revoteReceipt.submission_id, receipt.submission_id);
  const privateA = h.store.privateLifecycleForSubmission(receipt.submission_id);
  const privateB = h.store.privateLifecycleForSubmission(revoteReceipt.submission_id);
  assert.equal(privateA.lifecycle_handle, privateB.lifecycle_handle);
  assert.equal(h.store.privateLifecycleMembers(h.fixtures.a.context.election_instance_id, privateA.lifecycle_handle).length, 2);

  const status = await statusLookup(h, artifact.ballot_digest);
  assert.equal(status.status, 200);
  const publicStatus = await status.json();
  assert.equal(publicStatus.status, "ACCEPTED");
  assert.equal(publicStatus.finality_claim, "NOT_FINAL_NOT_COUNTED");
  assert.equal(Object.hasOwn(publicStatus, "lifecycle_handle"), false);

  const manifestResponse = await fetch(`${h.baseUrl}/v1/elections/${h.fixtures.a.context.election_instance_id}/accepted-submission-manifest`, { headers: { origin: allowedOrigin } });
  assert.equal(manifestResponse.status, 200);
  const manifest = await manifestResponse.json();
  assert.deepEqual(manifest.accepted_ballot_digests, [artifact.ballot_digest, revote.ballot_digest].sort());
  assert.equal(manifest.semantic_claim, "ACCEPTED_SUBMISSIONS_NOT_FINAL_SET_NOT_COUNTED");
  assert.equal(canonicalize(h.store.exportAcceptedManifest(h.fixtures.a.context.election_instance_id)), canonicalize(manifest));
  assert.equal(h.store.verifyLedger(h.fixtures.a.context.election_instance_id).valid, true);
});

test("I03-N01..N10 schema, context, proof, digest, credential and size failures", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();

  const cases = [];
  cases.push(["N01 unknown schema", { ...artifact, schema_version: "unknown/9" }, "INVALID_SUBMISSION_SCHEMA"]);
  cases.push(["N02 unknown profile", { ...artifact, crypto_profile: "unknown/9" }, "UNSUPPORTED_CRYPTO_PROFILE"]);
  cases.push(["N06 wrong digest", { ...artifact, ballot_digest: "0".repeat(64) }, "BALLOT_DIGEST_MISMATCH"]);
  cases.push(["N04 mutated ciphertext", mutatedArtifact(artifact, h.fixtures.a.context, "ciphertext"), "INVALID_ENCRYPTED_BALLOT"]);
  cases.push(["N05 mutated proof challenge", mutatedArtifact(artifact, h.fixtures.a.context, "proof-challenge"), "INVALID_ENCRYPTED_BALLOT"]);
  cases.push(["N05 mutated proof", mutatedArtifact(artifact, h.fixtures.a.context, "proof-response"), "INVALID_ENCRYPTED_BALLOT"]);
  cases.push(["N05 mutated signature proof", mutatedArtifact(artifact, h.fixtures.a.context, "signature-response"), "INVALID_ENCRYPTED_BALLOT"]);
  cases.push(["N01 unexpected field", { ...artifact, unexpected: "field" }, "INVALID_SUBMISSION_SCHEMA"]);
  for (const [name, input, expected] of cases) {
    await t.test(name, async () => {
      const response = await postArtifact(h, input, `idem-${name.replace(/\W/gu, "").padEnd(20, "0")}`);
      assert.equal((await response.json()).error, expected);
      assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).submissions, 0);
    });
  }

  await t.test("N03 foreign election", async () => {
    const raw = JSON.parse(Buffer.from(artifact.encrypted_ballot, "base64url").toString("utf8"));
    raw.election_uuid = h.fixtures.b.context.belenios_election_uuid;
    raw.election_hash = h.fixtures.b.context.belenios_election_fingerprint;
    const encoded = Buffer.from(JSON.stringify(raw), "utf8").toString("base64url");
    const foreign = { ...artifact, encrypted_ballot: encoded, ballot_digest: ballotDigest(h.fixtures.a.context, encoded) };
    const response = await postArtifact(h, foreign, "idem-foreign-00000001");
    assert.equal((await response.json()).error, "FOREIGN_ELECTION_BALLOT");
  });

  await t.test("N07 invalid credential", async () => {
    const response = await postArtifact(h, artifact, "idem-invalidcred-0001", { authorization: "EPD2-Scoped invalid.invalid" });
    assert.equal(response.status, 401);
    assert.equal((await response.json()).error, "INVALID_SCOPED_CREDENTIAL");
  });

  await t.test("N08 expired credential", async () => {
    const expired = h.credentialAuthority.issue({
      electionInstanceId: h.fixtures.a.context.election_instance_id,
      lifecycleNonce: "abcdefabcdefabcdefabcdefabcdefab",
      expiresAt: "2020-01-01T00:00:00Z",
    });
    const response = await postArtifact(h, artifact, "idem-expired-00000001", { authorization: `EPD2-Scoped ${expired.scoped_credential.secret}` });
    assert.equal(response.status, 401);
    assert.equal((await response.json()).error, "EXPIRED_SCOPED_CREDENTIAL");
  });

  await t.test("N10 oversized request rejected before crypto", async () => {
    const response = await rawPost(h, "x".repeat(1_500_001), "idem-oversize-0000001");
    assert.equal(response.status, 413);
    assert.equal((await response.json()).error, "REQUEST_TOO_LARGE");
  });

  await t.test("duplicate JSON member rejected", async () => {
    const canonical = canonicalize(artifact);
    const duplicate = canonical.replace("{", `{"schema_version":"${artifact.schema_version}",`);
    const response = await rawPost(h, duplicate, "idem-duplicatejson-001");
    assert.equal((await response.json()).error, "INVALID_SUBMISSION_SCHEMA");
  });
});

test("I03-N09 and N11..N15 conflict, duplicate, storage, immutability and enumeration", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();
  const revote = await realVectorArtifact(h.fixtures.a.context, "I02-P02.json");

  const first = await postArtifact(h, artifact, "idem-conflict-0000001");
  assert.equal(first.status, 201);
  const firstReceipt = await first.json();

  const conflict = await postArtifact(h, revote, "idem-conflict-0000001");
  assert.equal(conflict.status, 409);
  assert.equal((await conflict.json()).error, "IDEMPOTENCY_CONFLICT");

  const duplicate = await Promise.all([
    postArtifact(h, artifact, "idem-duplicate-000001"),
    postArtifact(h, artifact, "idem-duplicate-000002"),
  ]);
  assert.deepEqual(duplicate.map((response) => response.status).sort(), [200, 200]);
  assert.equal(h.store.counts(h.fixtures.a.context.election_instance_id).submissions, 1);

  const overwrite = await fetch(`${h.baseUrl}/v1/elections/${h.fixtures.a.context.election_instance_id}/ballots/${artifact.ballot_digest}`, {
    method: "PUT",
    headers: { origin: allowedOrigin },
  });
  assert.equal(overwrite.status, 405);
  const deletion = await fetch(`${h.baseUrl}/v1/elections/${h.fixtures.a.context.election_instance_id}/ballots/${artifact.ballot_digest}`, {
    method: "DELETE",
    headers: { origin: allowedOrigin },
  });
  assert.equal(deletion.status, 405);

  assert.throws(() => h.store.db.prepare("UPDATE encrypted_submissions SET accepted_at = ? WHERE submission_id = ?").run("1999-01-01T00:00:00Z", firstReceipt.submission_id), /APPEND_ONLY_VIOLATION/u);
  assert.throws(() => h.store.db.prepare("DELETE FROM encrypted_submissions WHERE submission_id = ?").run(firstReceipt.submission_id), /APPEND_ONLY_VIOLATION/u);

  const lifecycle = h.store.privateLifecycleForSubmission(firstReceipt.submission_id).lifecycle_handle;
  const enumeration = await fetch(`${h.baseUrl}/v1/elections/${h.fixtures.a.context.election_instance_id}/lifecycles/${lifecycle}`, { headers: { origin: allowedOrigin } });
  assert.equal(enumeration.status, 404);
  assert.equal((await enumeration.text()).includes(lifecycle), false);
});

test("I03-N12 storage failure returns stable taxonomy and stores nothing", async (t) => {
  const h = await createHarness();
  t.after(async () => {
    await new Promise((resolveClose) => h.server.close(resolveClose));
    await (await import("node:fs/promises")).rm(h.temporary, { recursive: true, force: true });
  });
  const artifact = await realBrowserArtifact();
  h.store.close();
  const response = await postArtifact(h, artifact, "idem-storagefail-00001");
  assert.equal(response.status, 503);
  assert.equal((await response.json()).error, "SUBMISSION_STORAGE_FAILED");
});
