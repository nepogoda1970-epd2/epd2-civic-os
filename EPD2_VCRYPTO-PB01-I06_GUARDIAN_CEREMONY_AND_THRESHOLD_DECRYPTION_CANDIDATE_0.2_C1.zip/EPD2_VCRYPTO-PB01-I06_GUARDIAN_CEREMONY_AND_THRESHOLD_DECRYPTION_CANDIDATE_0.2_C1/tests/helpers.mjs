import { generateKeyPairSync } from "node:crypto";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { ScopedCredentialAuthority } from "../src/i03/credential.mjs";
import { startI03Service } from "../src/i03/http_service.mjs";
import { NativeBeleniosVerifier } from "../src/i03/native_verifier.mjs";
import { ReceiptSigner } from "../src/i03/receipt.mjs";
import { SqliteSubmissionStore } from "../src/i03/sqlite_store.mjs";
import { loadFixture } from "../src/i02_accepted/shared/load_fixture.mjs";
import { buildSubmissionArtifact, canonicalize } from "../src/i02_accepted/shared/profile.mjs";

export const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
export const toolPath = join(root, "evidence/build/belenios-tool-3.3.0-linux-x86_64");
export const allowedOrigin = "http://127.0.0.1:32901";

export async function loadFixtures(receiverPort = 32902) {
  const a = await loadFixture(root, "election-a");
  const b = await loadFixture(root, "election-b");
  a.context = structuredClone(a.context);
  b.context = structuredClone(b.context);
  a.context.receiver_url = `http://127.0.0.1:${receiverPort}/v1/elections/${a.context.election_instance_id}/encrypted-ballots`;
  b.context.receiver_url = `http://127.0.0.1:${receiverPort}/v1/elections/${b.context.election_instance_id}/encrypted-ballots`;
  return { a, b };
}

export async function realBrowserArtifact() {
  return JSON.parse(await readFile(join(root, "test-vectors/real-i02/browser-produced-submission.json"), "utf8"));
}

export async function realVectorArtifact(context, name = "I02-P02.json") {
  const vector = JSON.parse(await readFile(join(root, "test-vectors/i02-accepted/positive", name), "utf8"));
  return buildSubmissionArtifact(context, vector.encrypted_ballot_base64url, "PASS");
}

export function testAuthorities() {
  const credentialAuthority = new ScopedCredentialAuthority({
    capabilityKey: Buffer.alloc(32, 0x41),
    lifecycleKey: Buffer.alloc(32, 0x42),
    issuer: "epd2-i03-test-ws03",
  });
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const receiptSigner = new ReceiptSigner({ privateKey, keyId: "epd2-i03-test-receipt-key-1" });
  return { credentialAuthority, receiptSigner, receiptPublicKey: publicKey };
}

export async function createHarness({ failpoint = null, verifierInvocation = null } = {}) {
  const temporary = await mkdtemp(join(tmpdir(), "epd2-i03-test-"));
  const databasePath = join(temporary, "i03.sqlite");
  const fixtures = await loadFixtures();
  const store = new SqliteSubmissionStore(databasePath);
  store.migrate();
  store.registerElection(fixtures.a.context, "2026-08-17T00:00:00Z");
  store.registerElection(fixtures.b.context, "2026-08-17T00:00:00Z");
  const authorities = testAuthorities();
  const authorization = authorities.credentialAuthority.issue({
    electionInstanceId: fixtures.a.context.election_instance_id,
    lifecycleNonce: "0123456789abcdef0123456789abcdef",
    expiresAt: "2030-01-01T00:00:00Z",
    revoteAllowed: true,
  });
  const verifier = new NativeBeleniosVerifier({ toolPath, onInvocation: verifierInvocation });
  const server = await startI03Service({
    store,
    electionFixtures: new Map([
      [fixtures.a.context.election_instance_id, fixtures.a],
      [fixtures.b.context.election_instance_id, fixtures.b],
    ]),
    verifier,
    credentialAuthority: authorities.credentialAuthority,
    receiptSigner: authorities.receiptSigner,
    idempotencySecret: Buffer.alloc(32, 0x43),
    allowedOrigin,
    port: 0,
    developmentHttp: true,
    failpoint,
  });
  const port = server.address().port;
  const baseUrl = `http://127.0.0.1:${port}`;
  const token = authorization.scoped_credential.secret;
  const cleanup = async () => {
    await new Promise((resolveClose) => server.close(resolveClose));
    try { store.close(); } catch { /* already closed by a failure test */ }
    await rm(temporary, { recursive: true, force: true });
  };
  return { temporary, databasePath, fixtures, store, server, baseUrl, token, authorization, ...authorities, cleanup };
}

export function submissionHeaders(token, idempotencyKey) {
  return {
    origin: allowedOrigin,
    authorization: `EPD2-Scoped ${token}`,
    "content-type": "application/json",
    "idempotency-key": idempotencyKey,
  };
}

export async function postArtifact(harness, artifact, idempotencyKey = "idem-0000000000000001", extraHeaders = {}) {
  const url = `${harness.baseUrl}/v1/elections/${harness.fixtures.a.context.election_instance_id}/encrypted-ballots`;
  return fetch(url, {
    method: "POST",
    headers: { ...submissionHeaders(harness.token, idempotencyKey), ...extraHeaders },
    body: canonicalize(artifact),
  });
}

export async function statusLookup(harness, digest) {
  return fetch(`${harness.baseUrl}/v1/elections/${harness.fixtures.a.context.election_instance_id}/ballots/${digest}`, {
    headers: { origin: allowedOrigin },
  });
}
