// PB01-I05 0.2_C1 — CRASH-01..04 and restart persistence against real PostgreSQL.
// The failpoints are driven through the production PostgresTallyStore transaction,
// not through an in-memory store.
import assert from 'node:assert/strict';
import test from 'node:test';
import { PostgresFinalizationStore } from '../src/i04/postgres_finalization_store.mjs';
import { adminPool } from './postgres_helpers.mjs';
import { finalizerUrl } from './i04_postgres_helpers.mjs';
import {
  applyI05Migrations, crashRestartPostgres, engineFor, finalizedFixture, tallyStore,
} from './i05_postgres_helpers.mjs';

const STAGES = {
  'CRASH-01': 'after_finalization_verification_before_aggregation',
  'CRASH-02': 'during_aggregate_construction',
  'CRASH-03': 'after_aggregate_persistence_before_tally_record_commit',
  'CRASH-04': 'after_commit_before_response',
};

async function counts() {
  const pool = await adminPool();
  try {
    const r = await pool.query(`SELECT
      (SELECT count(*)::bigint FROM pb01_i05.aggregates) AS aggregates,
      (SELECT count(*)::bigint FROM pb01_i05.tally_records) AS tally_records,
      (SELECT count(*)::bigint FROM pb01_i05.tally_audit_events) AS audit_events`);
    return { aggregates: Number(r.rows[0].aggregates), tally_records: Number(r.rows[0].tally_records), audit_events: Number(r.rows[0].audit_events) };
  } finally { await pool.end(); }
}

test('I05/PG CRASH-01..04 leave no partial tally state and every retry converges on one identical tally', async (t) => {
  const { i03, i04, eid, fin } = await finalizedFixture(t);

  for (const [label, stage] of Object.entries(STAGES)) {
    await applyI05Migrations();
    const store = tallyStore({ max: 4 });
    let armed = true;
    const engine = engineFor({
      i03, i04, store,
      failpoint: async (reached) => { if (armed && reached === stage) { armed = false; throw new Error(`SIMULATED_${label}`); } },
    });

    await assert.rejects(engine.execute(eid), new RegExp(`SIMULATED_${label}`, 'u'), `${label} must surface the crash`);

    const afterCrash = await counts();
    if (label === 'CRASH-04') {
      // The transaction had already committed; the crash is strictly post-commit.
      assert.equal(afterCrash.aggregates, 1, `${label} aggregate must be durable`);
      assert.equal(afterCrash.tally_records, 1, `${label} tally record must be durable`);
    } else {
      // CRASH-03 is the load-bearing case: the aggregate INSERT must be rolled back
      // together with the (never reached) tally-record commit.
      assert.equal(afterCrash.aggregates, 0, `${label} must leave no orphan aggregate row`);
      assert.equal(afterCrash.tally_records, 0, `${label} must leave no tally record`);
      assert.equal(afterCrash.audit_events, 0, `${label} must leave no audit event`);
      assert.equal(await store.read(eid), null, `${label} must leave no readable tally`);
    }

    const retried = await engine.execute(eid);
    assert.equal(retried.f_final, fin.f_final, `${label} retry must bind the authoritative f_final`);
    assert.equal(retried.replay, label === 'CRASH-04', `${label} retry replay flag`);

    const afterRetry = await counts();
    assert.equal(afterRetry.aggregates, 1, `${label} retry must yield exactly one aggregate`);
    assert.equal(afterRetry.tally_records, 1, `${label} retry must yield exactly one tally record`);

    // A further retry after the crash-and-recover cycle stays idempotent.
    const again = await engine.execute(eid);
    assert.equal(again.replay, true);
    assert.equal(again.tally_record_digest, retried.tally_record_digest);
    await store.close();
  }
});

test('I05/PG committed tally survives an immediate-mode server crash and restart with identical bytes and digests', async (t) => {
  const { i03, i04, eid, fin } = await finalizedFixture(t);
  const store = tallyStore();
  const engine = engineFor({ i03, i04, store });
  const committed = await engine.execute(eid);
  const before = await store.read(eid);
  await store.close();

  // Pools that outlive the crash will see their sockets torn down; that is expected and
  // must not be confused with a persistence failure.
  for (const pool of [i03.store.pool, i04.store.pool]) pool.on('error', () => {});

  // Hard crash: immediate shutdown performs no clean checkpoint; recovery must replay WAL.
  await crashRestartPostgres();

  const restartedStore = tallyStore();
  t.after(() => restartedStore.close());
  const after = await restartedStore.read(eid);

  assert.notEqual(after, null, 'tally must survive restart');
  assert.equal(after.f_final, fin.f_final);
  assert.equal(after.tally_record_digest, committed.tally_record_digest);
  assert.equal(after.aggregate_ciphertext_digest, committed.aggregate_ciphertext_digest);
  assert.equal(after.tally_input_digest, committed.tally_input_digest);
  assert.equal(after.tally_evidence_digest, committed.tally_evidence_digest);
  assert.equal(after.ballot_count_decimal, before.ballot_count_decimal);
  assert.deepEqual(after.aggregate_ciphertext_bytes, before.aggregate_ciphertext_bytes);
  assert.deepEqual(after.upstream_sized_tally_bytes, before.upstream_sized_tally_bytes);
  assert.deepEqual(after.homomorphic_tally_record, before.homomorphic_tally_record);
  assert.deepEqual(after.tally_evidence_bundle, before.tally_evidence_bundle);

  // Recompute still passes after recovery, using a freshly connected finalization store.
  const finalizationStore = new PostgresFinalizationStore({ connectionString: finalizerUrl, ssl: false, max: 4 });
  t.after(() => finalizationStore.close());
  const restartedEngine = engineFor({ i03, i04, store: restartedStore, finalizationStore });
  assert.equal((await restartedEngine.recompute(eid)).status, 'PASS');

  // And the tally remains idempotent after recovery.
  assert.equal((await restartedEngine.execute(eid)).replay, true);
});
