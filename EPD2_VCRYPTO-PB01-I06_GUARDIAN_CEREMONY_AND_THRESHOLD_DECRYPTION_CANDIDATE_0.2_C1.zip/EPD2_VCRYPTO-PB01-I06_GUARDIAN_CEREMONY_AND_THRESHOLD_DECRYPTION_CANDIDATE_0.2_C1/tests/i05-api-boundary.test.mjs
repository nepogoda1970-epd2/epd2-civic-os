import test from 'node:test'; import assert from 'node:assert/strict';
import { startI05Service } from '../src/i05/http_service.mjs';
const eid='ei1_11112222333344445555666677778888';
async function req(port,path,{method='GET',body}={}){return await new Promise((resolve,reject)=>{const r=fetch(`http://127.0.0.1:${port}${path}`,{method,body}).then(async x=>resolve({status:x.status,json:await x.json()}),reject);void r;});}
test('tally API accepts only election reference in path and rejects caller ballot arrays',async()=>{
 const engine={execute:async()=>({f_final:'a'.repeat(64),tally_record_digest:'b'.repeat(64),aggregate_ciphertext_digest:'c'.repeat(64),replay:false})};
 const tallyStore={exportEvidence:async()=>({schema_version:'test'})};
 const denied=await startI05Service({engine,tallyStore,authorizeTally:async()=>false}); try{const p=denied.address().port; const r=await req(p,`/v1/elections/${eid}/tally`,{method:'POST'}); assert.equal(r.status,403); assert.equal(r.json.error,'TALLY_NOT_AUTHORIZED');} finally {await new Promise(r=>denied.close(r));}
 const s=await startI05Service({engine,tallyStore,authorizeTally:async()=>true}); try{const p=s.address().port;
  const bad=await req(p,`/v1/elections/${eid}/tally`,{method:'POST',body:JSON.stringify({ballots:['x']})}); assert.equal(bad.status,400); assert.equal(bad.json.error,'TALLY_NOT_AUTHORIZED');
  const ok=await req(p,`/v1/elections/${eid}/tally`,{method:'POST'}); assert.equal(ok.status,200); assert.equal(ok.json.status,'AGGREGATED');
 }finally{await new Promise(r=>s.close(r));}
});
