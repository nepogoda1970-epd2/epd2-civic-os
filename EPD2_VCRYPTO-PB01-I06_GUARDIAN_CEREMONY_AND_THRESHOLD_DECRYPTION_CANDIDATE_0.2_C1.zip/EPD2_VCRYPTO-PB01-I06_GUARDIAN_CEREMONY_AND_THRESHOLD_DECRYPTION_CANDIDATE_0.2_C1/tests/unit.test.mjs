import assert from "node:assert/strict";
import { generateKeyPairSync } from "node:crypto";
import test from "node:test";
import { ScopedCredentialAuthority } from "../src/i03/credential.mjs";
import { ledgerEventHash } from "../src/i03/hashes.mjs";
import { ReceiptSigner, verifyReceipt } from "../src/i03/receipt.mjs";
import { parseStrictJson } from "../src/i03/strict_json.mjs";

test("strict parser accepts canonical JSON and rejects duplicate members", () => {
  assert.deepEqual(parseStrictJson(Buffer.from('{"a":"1","b":"2"}')).value, { a: "1", b: "2" });
  assert.throws(() => parseStrictJson(Buffer.from('{"a":"1","a":"2"}')), /INVALID_SUBMISSION_SCHEMA/u);
  assert.throws(() => parseStrictJson(Buffer.from("\xef\xbb\xbf{}", "binary")), /INVALID_SUBMISSION_SCHEMA/u);
  assert.throws(() => parseStrictJson(Buffer.from([0x7b, 0xff, 0x7d])), /INVALID_SUBMISSION_SCHEMA/u);
});

test("ledger domain is deterministic and commits order/link fields", () => {
  const event = {
    event_version: "epd2.pb01.submission-accepted/1",
    ledger_event_id: "11111111-1111-4111-8111-111111111111",
    ledger_seq: "1",
    submission_id: "22222222-2222-4222-8222-222222222222",
    election_instance_id: "ei1_00112233445566778899aabbccddeeff",
    ballot_digest: "a".repeat(64),
    accepted_at: "2026-08-17T00:00:00Z",
    previous_event_hash: "0".repeat(64),
  };
  assert.equal(ledgerEventHash(event), "62cf94ed50676bd3926a896202a29bfead9f6cf2a0038767d284a26f62cf79be");
  assert.equal(ledgerEventHash(event), ledgerEventHash(structuredClone(event)));
  assert.notEqual(ledgerEventHash(event), ledgerEventHash({ ...event, ledger_seq: "2" }));
});

test("scoped capability is election-bound, expiring and yields opaque lifecycle handle", () => {
  const authority = new ScopedCredentialAuthority({ capabilityKey: Buffer.alloc(32, 1), lifecycleKey: Buffer.alloc(32, 2), issuer: "test" });
  const issued = authority.issue({
    electionInstanceId: "ei1_00112233445566778899aabbccddeeff",
    lifecycleNonce: "0123456789abcdef0123456789abcdef",
    expiresAt: "2030-01-01T00:00:00Z",
  });
  const accepted = authority.verify(`EPD2-Scoped ${issued.scoped_credential.secret}`, "ei1_00112233445566778899aabbccddeeff", new Date("2026-08-17T00:00:00Z"));
  assert.match(accepted.lifecycle_handle, /^[0-9a-f]{64}$/u);
  assert.equal(accepted.lifecycle_handle.includes("012345"), false);
  assert.throws(() => authority.verify(`EPD2-Scoped ${issued.scoped_credential.secret}`, "ei1_ffeeddccbbaa99887766554433221100", new Date("2026-08-17T00:00:00Z")), /INVALID_SCOPED_CREDENTIAL/u);
  assert.throws(() => authority.verify(`EPD2-Scoped ${issued.scoped_credential.secret}`, "ei1_00112233445566778899aabbccddeeff", new Date("2031-01-01T00:00:00Z")), /EXPIRED_SCOPED_CREDENTIAL/u);
});

test("receipt uses independent Ed25519 key and verifies", () => {
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const signer = new ReceiptSigner({ privateKey, keyId: "test-receipt-key" });
  const receipt = signer.issue({
    submission_id: "22222222-2222-4222-8222-222222222222",
    election_instance_id: "ei1_00112233445566778899aabbccddeeff",
    ballot_digest: "a".repeat(64),
    accepted_at: "2026-08-17T00:00:00Z",
    ledger_event_id: "11111111-1111-4111-8111-111111111111",
    ledger_event_hash: "b".repeat(64),
    acceptance_claim: "ACCEPTED_NOT_FINAL_NOT_COUNTED",
  });
  assert.equal(verifyReceipt(receipt, publicKey), true);
  assert.equal(verifyReceipt({ ...receipt, ballot_digest: "c".repeat(64) }, publicKey), false);
});
