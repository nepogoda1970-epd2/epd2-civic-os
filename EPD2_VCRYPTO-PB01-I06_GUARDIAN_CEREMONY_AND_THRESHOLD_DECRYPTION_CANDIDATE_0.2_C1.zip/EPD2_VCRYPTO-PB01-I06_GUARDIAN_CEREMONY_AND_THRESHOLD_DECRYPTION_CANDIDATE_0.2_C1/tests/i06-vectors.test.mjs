import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { root, toolPath } from './helpers.mjs';
import { BeleniosThresholdAdapter } from '../src/i06/belenios_threshold.mjs';
import { verifyGuardianCeremonyRecord, verifyShareArtifact, verifyThresholdDecryptionRecord } from '../src/i06/records.mjs';
import { aggregateCiphertextDigest } from '../src/i05/hashes.mjs';

const index=JSON.parse(await readFile(join(root,'test-vectors/i06/index.json'),'utf8'));
const adapter=new BeleniosThresholdAdapter({toolPath,templatePath:join(root,'evidence/fixtures/i06-election-n3t2/template.json')});
for(const item of index.vectors){
 test(`${item.vector_id} real Belenios threshold vector verifies`,async()=>{
  const v=JSON.parse(await readFile(join(root,item.path),'utf8'));
  const tally={...v.i05_authorized_tally_reference,aggregate_ciphertext_bytes:Buffer.from(v.i05_authorized_tally_reference.aggregate_ciphertext_base64url,'base64url')};
  delete tally.aggregate_ciphertext_base64url;
  assert.equal(aggregateCiphertextDigest(tally.aggregate_ciphertext_bytes),v.expected.aggregate_ciphertext_digest);
  const cv=verifyGuardianCeremonyRecord(v.guardian_ceremony_record);assert.equal(cv.threshold,Number(v.guardian_ceremony_record.threshold_decimal));
  for(const s of v.partial_decryption_shares)assert.equal(verifyShareArtifact(s,{ceremony:v.guardian_ceremony_record,tally}).valid,true);
  assert.equal(verifyThresholdDecryptionRecord(v.threshold_decryption_record,{ceremony:v.guardian_ceremony_record,tally}).valid,true);
  const fixture=join(root,'test-vectors/i06/fixtures',v.fixture);
  await adapter.verifyArchiveAggregate({baseArchivePath:join(fixture,'decryption-base.bel'),expectedAggregateBytes:tally.aggregate_ciphertext_bytes});
  const shares=v.threshold_forming_guardian_indices.map(x=>{const s=v.partial_decryption_shares[Number(x)-1];return {guardian_index:Number(x),share_bytes:Buffer.from(s.belenios_partial_decryption_base64url,'base64url')}});
  const r=await adapter.computeVerifiedResult({baseArchivePath:join(fixture,'decryption-base.bel'),shares});
  assert.equal(r.plaintext_bytes.toString('base64url'),v.threshold_decryption_record.plaintext_tally_base64url);
 });
}

test('N=5 T=3 different valid threshold subsets and all five give identical plaintext',async()=>{
 const v=JSON.parse(await readFile(join(root,'test-vectors/i06/vectors/I06-V03.json'),'utf8'));
 const base=join(root,'test-vectors/i06/fixtures/n5-t3/decryption-base.bel');
 const mk=(ids)=>ids.map(i=>({guardian_index:i,share_bytes:Buffer.from(v.partial_decryption_shares[i-1].belenios_partial_decryption_base64url,'base64url')}));
 const [a,b,c]=await Promise.all([
   adapter.computeVerifiedResult({baseArchivePath:base,shares:mk([1,2,3])}),
   adapter.computeVerifiedResult({baseArchivePath:base,shares:mk([3,4,5])}),
   adapter.computeVerifiedResult({baseArchivePath:base,shares:mk([1,2,3,4,5])}),
 ]);
 assert.deepEqual(a.plaintext_bytes,b.plaintext_bytes);assert.deepEqual(a.plaintext_bytes,c.plaintext_bytes);
});
