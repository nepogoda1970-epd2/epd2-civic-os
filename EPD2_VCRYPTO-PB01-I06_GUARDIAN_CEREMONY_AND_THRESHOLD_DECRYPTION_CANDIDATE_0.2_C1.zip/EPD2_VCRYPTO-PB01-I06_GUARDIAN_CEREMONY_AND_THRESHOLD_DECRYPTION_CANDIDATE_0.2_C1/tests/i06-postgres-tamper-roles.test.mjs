import assert from 'node:assert/strict';
import test from 'node:test';
import { canonicalize } from '../src/i01_reference/pb01_profile.mjs';
import { adminPool } from './postgres_helpers.mjs';
import {
  createThresholdChain,
  freezeN3T2,
  shareBytes,
  rolePool,
  coordinatorUrl,
  ingesterUrl,
  decryptionFinalizerUrl,
  readerUrl,
} from './i06_postgres_helpers.mjs';

async function completed(t) {
  const c = await createThresholdChain(t);
  await freezeN3T2(c);
  await c.engine.submitShare(c.eid, 'g0001', await shareBytes(1));
  await c.engine.submitShare(c.eid, 'g0002', await shareBytes(2));
  return c;
}

async function privilegedUpdate(t, c, table, trigger, sql, params = []) {
  const p = await adminPool();
  t.after(() => p.end());
  await p.query(`ALTER TABLE ${table} DISABLE TRIGGER ${trigger}`);
  try {
    await p.query(sql, [c.eid, ...params]);
  } finally {
    await p.query(`ALTER TABLE ${table} ENABLE TRIGGER ${trigger}`);
  }
}

async function mutateAcceptedArtifact(t, c, mutate, { mutateDigestColumn = false } = {}) {
  const p = await adminPool();
  t.after(() => p.end());
  const q = await p.query(
    `SELECT guardian_index, share_digest, share_artifact_canonical
       FROM pb01_i06.accepted_shares
      WHERE election_instance_id=$1
      ORDER BY guardian_index
      LIMIT 1`,
    [c.eid],
  );
  assert.equal(q.rowCount, 1);
  const row = q.rows[0];
  const artifact = JSON.parse(row.share_artifact_canonical);
  mutate(artifact);
  await p.query('ALTER TABLE pb01_i06.accepted_shares DISABLE TRIGGER no_mutate_accepted_shares');
  try {
    if (mutateDigestColumn) {
      await p.query(
        `UPDATE pb01_i06.accepted_shares
            SET share_digest=$3, share_artifact_canonical=$4
          WHERE election_instance_id=$1 AND guardian_index=$2`,
        [c.eid, row.guardian_index, '0'.repeat(64), canonicalize(artifact)],
      );
    } else {
      await p.query(
        `UPDATE pb01_i06.accepted_shares
            SET share_artifact_canonical=$3
          WHERE election_instance_id=$1 AND guardian_index=$2`,
        [c.eid, row.guardian_index, canonicalize(artifact)],
      );
    }
  } finally {
    await p.query('ALTER TABLE pb01_i06.accepted_shares ENABLE TRIGGER no_mutate_accepted_shares');
  }
}

function mutateBeleniosShare(artifact, which) {
  const raw = Buffer.from(artifact.belenios_partial_decryption_base64url, 'base64url');
  const share = JSON.parse(raw.toString('utf8'));
  if (which === 'factor') {
    const x = share.decryption_factors[0][0];
    share.decryption_factors[0][0] = `${x[0] === '0' ? '1' : '0'}${x.slice(1)}`;
  } else {
    share.decryption_proofs[0][0].challenge = share.decryption_proofs[0][0].challenge === '1' ? '2' : '1';
  }
  artifact.belenios_partial_decryption_base64url = Buffer.from(canonicalize(share)).toString('base64url');
}

test('I06/PG mandatory I05 corrective detects privileged aggregate-byte-only rewrite and decryption refuses', async t => {
  const c = await completed(t);
  const p = await adminPool();
  t.after(() => p.end());
  const original = (await p.query(
    'SELECT aggregate_ciphertext_bytes FROM pb01_i05.aggregates WHERE election_instance_id=$1',
    [c.eid],
  )).rows[0].aggregate_ciphertext_bytes;
  await p.query('ALTER TABLE pb01_i05.aggregates DISABLE TRIGGER USER');
  await p.query(
    "UPDATE pb01_i05.aggregates SET aggregate_ciphertext_bytes=aggregate_ciphertext_bytes||'\\x20'::bytea WHERE election_instance_id=$1",
    [c.eid],
  );
  await p.query('ALTER TABLE pb01_i05.aggregates ENABLE TRIGGER USER');
  await assert.rejects(c.i05Engine.recompute(c.eid), e => e.code === 'TALLY_RECOMPUTE_MISMATCH');
  await assert.rejects(c.engine.recompute(c.eid), e => e.code === 'I05_INTEGRITY_FAILURE');
  await p.query('ALTER TABLE pb01_i05.aggregates DISABLE TRIGGER USER');
  await p.query(
    'UPDATE pb01_i05.aggregates SET aggregate_ciphertext_bytes=$2 WHERE election_instance_id=$1',
    [c.eid, original],
  );
  await p.query('ALTER TABLE pb01_i05.aggregates ENABLE TRIGGER USER');
  assert.equal((await c.engine.recompute(c.eid)).status, 'PASS');
});

test('I06/PG privileged tamper: guardian public key after freeze is detected', async t => {
  const c = await completed(t);
  await privilegedUpdate(
    t, c, 'pb01_i06.guardians', 'guardian_freeze_guard',
    `UPDATE pb01_i06.guardians SET public_key=repeat('0',64) WHERE election_instance_id=$1 AND guardian_index=1`,
  );
  await assert.rejects(c.engine.recompute(c.eid), e => e.code === 'CEREMONY_INTEGRITY_FAILURE');
});

test('I06/PG privileged tamper: threshold after ceremony freeze is detected', async t => {
  const c = await completed(t);
  await privilegedUpdate(
    t, c, 'pb01_i06.guardian_ceremonies', 'guardian_ceremony_freeze_guard',
    `UPDATE pb01_i06.guardian_ceremonies SET threshold=3 WHERE election_instance_id=$1`,
  );
  await assert.rejects(c.engine.recompute(c.eid), e => e.code === 'CEREMONY_INTEGRITY_FAILURE');
});

test('I06/PG privileged tamper: frozen guardian-set member replacement is detected', async t => {
  const c = await completed(t);
  await privilegedUpdate(
    t, c, 'pb01_i06.guardians', 'guardian_freeze_guard',
    `UPDATE pb01_i06.guardians SET guardian_id='g9999' WHERE election_instance_id=$1 AND guardian_index=1`,
  );
  await assert.rejects(c.engine.recompute(c.eid), e => e.code === 'CEREMONY_INTEGRITY_FAILURE');
});

test('I06/PG privileged tamper: partial-decryption factor bytes are detected', async t => {
  const c = await completed(t);
  await mutateAcceptedArtifact(t, c, a => mutateBeleniosShare(a, 'factor'));
  await assert.rejects(c.engine.recompute(c.eid));
});

test('I06/PG privileged tamper: partial-decryption proof bytes are detected', async t => {
  const c = await completed(t);
  await mutateAcceptedArtifact(t, c, a => mutateBeleniosShare(a, 'proof'));
  await assert.rejects(c.engine.recompute(c.eid));
});

test('I06/PG privileged tamper: accepted share digest column is detected', async t => {
  const c = await completed(t);
  await mutateAcceptedArtifact(t, c, () => {}, { mutateDigestColumn: true });
  await assert.rejects(c.engine.recompute(c.eid), e => e.code === 'DECRYPTION_RECORD_INTEGRITY_FAILURE');
});

test('I06/PG privileged tamper: aggregate digest alone is detected', async t => {
  const c = await completed(t);
  await privilegedUpdate(
    t, c, 'pb01_i05.aggregates', 'no_mutate_aggregates',
    `UPDATE pb01_i05.aggregates SET aggregate_ciphertext_digest=repeat('0',64) WHERE election_instance_id=$1`,
  );
  assert.equal((await c.i05Engine.recompute(c.eid)).status, 'PASS'); // committed I05 record/evidence still bind the correct digest
  await assert.rejects(c.engine.recompute(c.eid), e => e.code === 'I05_INTEGRITY_FAILURE'); // I06 also authenticates the redundant aggregate-row digest
});

test('I06/PG privileged tamper: final plaintext bytes are detected', async t => {
  const c = await completed(t);
  await privilegedUpdate(
    t, c, 'pb01_i06.decryption_records', 'no_mutate_decryption_records',
    `UPDATE pb01_i06.decryption_records SET plaintext_tally_bytes='{}'::bytea WHERE election_instance_id=$1`,
  );
  await assert.rejects(c.engine.recompute(c.eid));
});

test('I06/PG privileged tamper: final decryption-record digest is detected', async t => {
  const c = await completed(t);
  await privilegedUpdate(
    t, c, 'pb01_i06.decryption_records', 'no_mutate_decryption_records',
    `UPDATE pb01_i06.decryption_records SET decryption_record_digest=repeat('0',64) WHERE election_instance_id=$1`,
  );
  await assert.rejects(c.engine.recompute(c.eid));
});

test('I06/PG roles enforce coordinator/ingester/finalizer/runtime separation', async t => {
  const c = await completed(t);
  const pools = [
    ['coordinator', await rolePool(coordinatorUrl)],
    ['ingester', await rolePool(ingesterUrl)],
    ['finalizer', await rolePool(decryptionFinalizerUrl)],
    ['reader', await rolePool(readerUrl)],
  ];
  t.after(() => Promise.all(pools.map(x => x[1].end())));
  for (const [name, p] of pools) {
    const s = await p.query(
      "SELECT rolsuper,rolcreatedb,rolcreaterole,rolreplication,rolbypassrls,has_database_privilege(current_user,current_database(),'TEMP') temp FROM pg_roles WHERE rolname=current_user",
    );
    assert.deepEqual(s.rows[0], {
      rolsuper: false, rolcreatedb: false, rolcreaterole: false,
      rolreplication: false, rolbypassrls: false, temp: false,
    }, name);
    await assert.rejects(p.query(
      "UPDATE pb01_i05.tally_records SET f_final=repeat('0',64) WHERE election_instance_id=$1",
      [c.eid],
    ));
  }
  await assert.rejects(pools[0][1].query(
    'INSERT INTO pb01_i06.decryption_records(election_instance_id) VALUES($1)', [c.eid],
  ));
  await assert.rejects(pools[1][1].query(
    'UPDATE pb01_i06.guardian_ceremonies SET threshold=3 WHERE election_instance_id=$1', [c.eid],
  ));
  await assert.rejects(pools[3][1].query(
    'INSERT INTO pb01_i06.share_inbox(share_submission_id) VALUES(gen_random_uuid())',
  ));
});
