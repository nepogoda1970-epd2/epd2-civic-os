import assert from "node:assert/strict";
import test from "node:test";
import { verifyReceipt } from "../src/i03/receipt.mjs";
import {
  postArtifact,
  realBrowserArtifact,
  realVectorArtifact,
  statusLookup,
} from "./helpers.mjs";
import { createPostgresHarness } from "./postgres_helpers.mjs";

test("PG-I03-P01 real I02 ballot follows native verification and PostgreSQL acceptance", async (t) => {
  let nativeInvocations = 0;
  const h = await createPostgresHarness({ verifierInvocation: () => { nativeInvocations += 1; } });
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();
  const expectedBytes = Buffer.from(artifact.encrypted_ballot, "base64url");

  const accepted = await postArtifact(h, artifact, "pg-idem-positive-0001");
  assert.equal(accepted.status, 201);
  const receipt = await accepted.json();
  assert.equal(nativeInvocations, 1);
  assert.equal(receipt.ballot_digest, artifact.ballot_digest);
  assert.equal(receipt.acceptance_claim, "ACCEPTED_NOT_FINAL_NOT_COUNTED");
  assert.equal(verifyReceipt(receipt, h.receiptPublicKey), true);
  assert.deepEqual(await h.store.exactBallotBytes(h.fixtures.a.context.election_instance_id, artifact.ballot_digest), expectedBytes);
  assert.deepEqual(await h.store.counts(h.fixtures.a.context.election_instance_id), {
    submissions: 1,
    lifecycle_bindings: 1,
    ledger_events: 1,
    idempotency_records: 1,
  });
  assert.equal((await h.store.verifyLedger(h.fixtures.a.context.election_instance_id)).valid, true);

  const status = await statusLookup(h, artifact.ballot_digest);
  assert.equal(status.status, 200);
  const body = await status.json();
  assert.equal(body.finality_claim, "NOT_FINAL_NOT_COUNTED");
  assert.equal(Object.hasOwn(body, "lifecycle_handle"), false);
});

test("PG-I03-P02 idempotent retry returns same receipt; same key with different ballot conflicts", async (t) => {
  const h = await createPostgresHarness();
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();
  const first = await postArtifact(h, artifact, "pg-idem-retry-0000001");
  assert.equal(first.status, 201);
  const firstReceipt = await first.json();
  const retry = await postArtifact(h, artifact, "pg-idem-retry-0000001");
  assert.equal(retry.status, 200);
  assert.deepEqual(await retry.json(), firstReceipt);

  const revote = await realVectorArtifact(h.fixtures.a.context, "I02-P02.json");
  const conflict = await postArtifact(h, revote, "pg-idem-retry-0000001");
  assert.equal(conflict.status, 409);
  assert.deepEqual(await conflict.json(), { error: "IDEMPOTENCY_CONFLICT" });
  assert.equal((await h.store.counts(h.fixtures.a.context.election_instance_id)).submissions, 1);
});
