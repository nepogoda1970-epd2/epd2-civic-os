import assert from "node:assert/strict";
import { copyFile } from "node:fs/promises";
import { join } from "node:path";
import test from "node:test";
import { DatabaseSync } from "node:sqlite";
import { SqliteSubmissionStore } from "../src/i03/sqlite_store.mjs";
import { createHarness, postArtifact, realBrowserArtifact, realVectorArtifact } from "./helpers.mjs";

async function withTamperedCopy(basePath, targetPath, mutate, verify) {
  await copyFile(basePath, targetPath);
  const raw = new DatabaseSync(targetPath);
  raw.exec("PRAGMA foreign_keys=OFF;");
  mutate(raw);
  raw.close();
  const store = new SqliteSubmissionStore(targetPath);
  try { verify(store); } finally { store.close(); }
}

test("ledger detects modification, deletion, reordering and conflicting checkpoint", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  const a = await realBrowserArtifact();
  const b = await realVectorArtifact(h.fixtures.a.context, "I02-P02.json");
  assert.equal((await postArtifact(h, a, "idem-tamper-source-001")).status, 201);
  assert.equal((await postArtifact(h, b, "idem-tamper-source-002")).status, 201);
  const electionId = h.fixtures.a.context.election_instance_id;
  const checkpoint = h.store.checkpoint(electionId);
  assert.equal(h.store.verifyLedger(electionId, checkpoint).valid, true);
  const backupPath = join(h.temporary, "clean-backup.sqlite");
  await h.store.backupTo(backupPath);

  await withTamperedCopy(backupPath, join(h.temporary, "modified.sqlite"), (db) => {
    db.exec("DROP TRIGGER no_update_submission_ledger;");
    db.prepare("UPDATE submission_ledger_events SET ballot_digest = ? WHERE ledger_seq = 1").run("f".repeat(64));
  }, (store) => {
    assert.equal(store.verifyLedger(electionId, checkpoint).valid, false);
    assert.match(store.verifyLedger(electionId, checkpoint).reason, /ROW_EVENT_MISMATCH|EVENT_HASH_MISMATCH/u);
  });

  await withTamperedCopy(backupPath, join(h.temporary, "deleted.sqlite"), (db) => {
    db.exec("DROP TRIGGER no_delete_submission_ledger;");
    db.prepare("DELETE FROM submission_ledger_events WHERE ledger_seq = 2").run();
  }, (store) => {
    const result = store.verifyLedger(electionId, checkpoint);
    assert.equal(result.valid, false);
    assert.equal(result.reason, "CHECKPOINT_CONFLICT");
  });

  await withTamperedCopy(backupPath, join(h.temporary, "reordered.sqlite"), (db) => {
    db.exec("DROP TRIGGER no_update_submission_ledger; BEGIN IMMEDIATE;");
    db.prepare("UPDATE submission_ledger_events SET ledger_seq = 99 WHERE ledger_seq = 1").run();
    db.prepare("UPDATE submission_ledger_events SET ledger_seq = 1 WHERE ledger_seq = 2").run();
    db.prepare("UPDATE submission_ledger_events SET ledger_seq = 2 WHERE ledger_seq = 99").run();
    db.exec("COMMIT;");
  }, (store) => {
    const result = store.verifyLedger(electionId, checkpoint);
    assert.equal(result.valid, false);
    assert.equal(result.reason, "CHAIN_ORDER_OR_LINK_MISMATCH");
  });

  const conflict = { ...checkpoint, ledger_event_hash: "e".repeat(64) };
  assert.equal(h.store.verifyLedger(electionId, conflict).valid, false);
  assert.equal(h.store.verifyLedger(electionId, conflict).reason, "CHECKPOINT_CONFLICT");
});

test("backup/restore preserves exact ballot bytes, ledger and private/public separation", async (t) => {
  const h = await createHarness();
  t.after(h.cleanup);
  const artifact = await realBrowserArtifact();
  const response = await postArtifact(h, artifact, "idem-backup-restore001");
  const receipt = await response.json();
  const backupPath = join(h.temporary, "restore.sqlite");
  await h.store.backupTo(backupPath);
  const restored = new SqliteSubmissionStore(backupPath);
  t.after(() => restored.close());
  assert.deepEqual(restored.exactBallotBytes(h.fixtures.a.context.election_instance_id, artifact.ballot_digest), Buffer.from(artifact.encrypted_ballot, "base64url"));
  assert.equal(restored.lookupStatus(h.fixtures.a.context.election_instance_id, artifact.ballot_digest).submission_id, receipt.submission_id);
  assert.equal(restored.verifyLedger(h.fixtures.a.context.election_instance_id).valid, true);
  const publicManifest = restored.exportAcceptedManifest(h.fixtures.a.context.election_instance_id);
  assert.equal(JSON.stringify(publicManifest).includes("lifecycle_handle"), false);
});
