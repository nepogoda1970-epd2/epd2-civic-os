import { createHash, generateKeyPairSync } from "node:crypto";
import { performance } from "node:perf_hooks";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import {
  buildAcceptedManifestAtCheckpoint,
  buildClosureCheckpoint,
  buildFinalArtifacts,
  resolveLatestValid,
  verifyPublicFinalEvidence,
} from "../src/i04/finalization.mjs";
import { buildClosureAuthorizationStatement, issueClosureAuthorization } from "../src/i04/closure_authority.mjs";
import { root } from "./helpers.mjs";

const election = {
  election_instance_id: "ei1_0123456789abcdef0123456789abcdef",
  crypto_profile: "epd2.belenios-homomorphic/1",
  tally_function_id: "epd2.pb01.tally.single-choice.v1",
  belenios_election_uuid: "123456789ABCDEFG",
  belenios_election_hash: "A".repeat(43),
};
const closedAt = "2026-08-17T22:00:00Z";
const { privateKey } = generateKeyPairSync("ed25519");

function hex(value) {
  return createHash("sha256").update(value).digest("hex");
}

function rows(size) {
  return Array.from({ length: size }, (_, index) => ({
    submission_id: `${String(index + 1).padStart(8, "0")}-0000-4000-8000-${String(index + 1).padStart(12, "0")}`,
    ballot_digest: hex(`ballot-${index}`),
    ledger_seq: String(index + 1),
    event_hash: hex(`event-${index}`),
    accepted_at: closedAt,
    lifecycle_handle: hex(`lifecycle-${index}`),
    lifecycle_election_instance_id: election.election_instance_id,
  }));
}

const samples = [];
for (const size of [100, 1000, 10000]) {
  const ledgerRows = rows(size);
  const startedResolution = performance.now();
  const resolutions = resolveLatestValid({ electionInstanceId: election.election_instance_id, rows: ledgerRows, resolvedAt: closedAt });
  const resolutionMs = performance.now() - startedResolution;
  const acceptedManifest = buildAcceptedManifestAtCheckpoint({ election, ledgerRows, checkpointTime: closedAt });
  const { checkpoint } = buildClosureCheckpoint({ electionInstanceId: election.election_instance_id, acceptedManifest });
  const statement = buildClosureAuthorizationStatement({ electionInstanceId: election.election_instance_id, checkpoint, closedAt });
  const authorization = issueClosureAuthorization({ statement, privateKey, keyId: "epd2-i04-performance-key" });
  const startedArtifacts = performance.now();
  const artifacts = buildFinalArtifacts({ election, acceptedManifest, authorizationEvidence: authorization, resolutionRecords: resolutions });
  const artifactMs = performance.now() - startedArtifacts;
  const startedExport = performance.now();
  const exportedBytes = Buffer.byteLength(JSON.stringify(artifacts.publicEvidence));
  const exportMs = performance.now() - startedExport;
  const startedVerify = performance.now();
  verifyPublicFinalEvidence(artifacts.publicEvidence);
  const verifyMs = performance.now() - startedVerify;
  samples.push({
    accepted_submissions: String(size),
    lifecycles: String(size),
    resolution_ms: Number(resolutionMs.toFixed(3)),
    final_artifact_ms: Number(artifactMs.toFixed(3)),
    export_ms: Number(exportMs.toFixed(3)),
    recomputation_verification_ms: Number(verifyMs.toFixed(3)),
    public_evidence_bytes: String(exportedBytes),
  });
}

const result = {
  status: "PASS",
  environment: { node: process.version, cpu_parallelism_used: "1", storage: "in-memory deterministic composition benchmark" },
  samples,
  note: "PostgreSQL transactional and recomputation paths are measured separately by the real I04 integration battery.",
};
await writeFile(join(root, "evidence/results/i04-performance.json"), `${JSON.stringify(result, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
