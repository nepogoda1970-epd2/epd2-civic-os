import { generateKeyPairSync } from "node:crypto";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import pg from "pg";
import { ScopedCredentialAuthority } from "../src/i03/credential.mjs";
import { startI03Service } from "../src/i03/http_service.mjs";
import { NativeBeleniosVerifier } from "../src/i03/native_verifier.mjs";
import { PostgresSubmissionStore } from "../src/i03/postgres_store.mjs";
import { ReceiptSigner } from "../src/i03/receipt.mjs";
import {
  allowedOrigin,
  loadFixtures,
  root,
  toolPath,
} from "./helpers.mjs";

const { Pool } = pg;

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`required PostgreSQL test environment missing: ${name}`);
  return value;
}

export const adminUrl = required("EPD2_I03_PG_ADMIN_URL");
export const runtimeUrl = required("EPD2_I03_PG_RUNTIME_URL");
export const evidenceUrl = required("EPD2_I03_PG_EVIDENCE_URL");
export const pgDumpPath = required("EPD2_I03_PG_DUMP_PATH");
export const pgRestorePath = required("EPD2_I03_PG_RESTORE_PATH");
export const createdbPath = required("EPD2_I03_PG_CREATEDB_PATH");
export const dropdbPath = required("EPD2_I03_PG_DROPDB_PATH");

export async function adminPool(connectionString = adminUrl) {
  const pool = new Pool({ connectionString, ssl: false, max: 4, application_name: "epd2-i03-pg-test-admin" });
  await pool.query("SELECT 1");
  return pool;
}

export async function resetPostgresSchema() {
  const pool = await adminPool();
  try {
    await pool.query("DROP SCHEMA IF EXISTS pb01_i03 CASCADE");
    const migration1 = await readFile(join(root, "migrations/postgresql/001_i03_submission_ledger.sql"), "utf8");
    const migration2 = await readFile(join(root, "migrations/postgresql/002_i03_roles.sql"), "utf8");
    await pool.query(migration1);
    await pool.query(migration2);
  } finally {
    await pool.end();
  }
}

export function pgTestAuthorities() {
  const credentialAuthority = new ScopedCredentialAuthority({
    capabilityKey: Buffer.alloc(32, 0x41),
    lifecycleKey: Buffer.alloc(32, 0x42),
    issuer: "epd2-i03-postgres-test-ws03",
  });
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const receiptSigner = new ReceiptSigner({ privateKey, keyId: "epd2-i03-test-receipt-key-1" });
  return { credentialAuthority, receiptSigner, receiptPublicKey: publicKey };
}

export async function createPostgresHarness({ failpoint = null, verifierInvocation = null, reset = true } = {}) {
  if (reset) await resetPostgresSchema();
  const fixtures = await loadFixtures();
  const setupStore = new PostgresSubmissionStore({ connectionString: adminUrl, ssl: false, max: 2 });
  await setupStore.registerElection(fixtures.a.context, "2026-08-17T00:00:00Z");
  await setupStore.registerElection(fixtures.b.context, "2026-08-17T00:00:00Z");
  await setupStore.close();

  const store = new PostgresSubmissionStore({
    connectionString: runtimeUrl,
    ssl: false,
    max: 12,
    application_name: "epd2-pb01-i03-postgres-test-runtime",
    backup: {
      pgDumpPath,
      host: "127.0.0.1",
      port: Number(process.env.EPD2_I03_PG_PORT || "55432"),
      database: new URL(runtimeUrl).pathname.slice(1),
      user: new URL(runtimeUrl).username,
      password: decodeURIComponent(new URL(runtimeUrl).password),
    },
  });
  const privilegeEvidence = await store.assertRuntimePrivileges();
  const authorities = pgTestAuthorities();
  const authorization = authorities.credentialAuthority.issue({
    electionInstanceId: fixtures.a.context.election_instance_id,
    lifecycleNonce: "0123456789abcdef0123456789abcdef",
    expiresAt: "2030-01-01T00:00:00Z",
    revoteAllowed: true,
  });
  const verifier = new NativeBeleniosVerifier({ toolPath, onInvocation: verifierInvocation });
  const server = await startI03Service({
    store,
    electionFixtures: new Map([
      [fixtures.a.context.election_instance_id, fixtures.a],
      [fixtures.b.context.election_instance_id, fixtures.b],
    ]),
    verifier,
    credentialAuthority: authorities.credentialAuthority,
    receiptSigner: authorities.receiptSigner,
    idempotencySecret: Buffer.alloc(32, 0x43),
    allowedOrigin,
    port: 0,
    developmentHttp: true,
    failpoint,
  });
  const baseUrl = `http://127.0.0.1:${server.address().port}`;
  const token = authorization.scoped_credential.secret;
  const cleanup = async () => {
    await new Promise((resolveClose) => server.close(resolveClose));
    await store.close();
  };
  return {
    fixtures,
    store,
    server,
    baseUrl,
    token,
    authorization,
    privilegeEvidence,
    ...authorities,
    cleanup,
  };
}
