import test from 'node:test'; import assert from 'node:assert/strict'; import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path'; import { fileURLToPath } from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
async function walk(d){let out=[];for(const e of await readdir(d,{withFileTypes:true})){const p=join(d,e.name); if(e.isDirectory())out.push(...await walk(p));else out.push(p);}return out;}
test('I05 adds no decryption/guardian secret material and SQL enforces role separation',async()=>{
 const files=[...await walk(join(root,'src/i05')),...await walk(join(root,'server')), ...await walk(join(root,'evidence/fixtures/i05-election'))];
 const joined=(await Promise.all(files.filter(x=>!x.endsWith('.bel')).map(x=>readFile(x,'utf8').catch(()=>'')))).join('\n').toLowerCase();
 for(const forbidden of ['trustee_private','guardian_secret','secret_share','plaintext_tally','/decrypt','decrypt endpoint']) assert.ok(!joined.includes(forbidden),forbidden);
 const roles=await readFile(join(root,'migrations/postgresql/006_i05_roles.sql'),'utf8');
 assert.match(roles,/REVOKE ALL ON ALL TABLES IN SCHEMA pb01_i05 FROM epd2_pb01_submission_runtime, epd2_pb01_finalization_runtime/);
 assert.match(roles,/REVOKE UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA pb01_i03, pb01_i04, pb01_i05 FROM epd2_pb01_tally_runtime/);
 assert.match(roles,/REVOKE INSERT ON ALL TABLES IN SCHEMA pb01_i03, pb01_i04 FROM epd2_pb01_tally_runtime/);
});
