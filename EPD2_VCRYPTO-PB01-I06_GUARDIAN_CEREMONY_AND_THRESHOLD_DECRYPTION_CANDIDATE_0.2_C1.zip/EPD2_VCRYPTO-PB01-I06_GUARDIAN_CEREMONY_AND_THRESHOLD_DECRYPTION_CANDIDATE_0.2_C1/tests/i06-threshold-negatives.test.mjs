import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { root, toolPath } from './helpers.mjs';
import { BeleniosThresholdAdapter } from '../src/i06/belenios_threshold.mjs';
import { verifyGuardianCeremonyRecord, verifyShareArtifact, verifyThresholdDecryptionRecord } from '../src/i06/records.mjs';
const v=JSON.parse(await readFile(join(root,'test-vectors/i06/vectors/I06-V01.json'),'utf8'));
const tally={...v.i05_authorized_tally_reference,aggregate_ciphertext_bytes:Buffer.from(v.i05_authorized_tally_reference.aggregate_ciphertext_base64url,'base64url')}; delete tally.aggregate_ciphertext_base64url;
const adapter=new BeleniosThresholdAdapter({toolPath,templatePath:join(root,'evidence/fixtures/i06-election-n3t2/template.json')});
const base=join(root,'test-vectors/i06/fixtures/n3-t2/decryption-base.bel');
function clone(x){return structuredClone(x);} function reject(fn,code){assert.throws(fn,e=>e.code===code||e.code==='SHARE_INTEGRITY_FAILURE'||e.code==='CEREMONY_INTEGRITY_FAILURE'||e.code==='DECRYPTION_RECORD_INTEGRITY_FAILURE');}
test('mutation negatives: wrong aggregate/election/guardian/digests/plaintext/record fail closed',()=>{
 let s=clone(v.partial_decryption_shares[0]);s.aggregate_ciphertext_digest='0'.repeat(64);reject(()=>verifyShareArtifact(s,{ceremony:v.guardian_ceremony_record,tally}),'WRONG_AGGREGATE_SHARE');
 s=clone(v.partial_decryption_shares[0]);s.election_instance_id='ei1_99999999999999999999999999999999';reject(()=>verifyShareArtifact(s,{ceremony:v.guardian_ceremony_record,tally}),'FOREIGN_ELECTION_SHARE');
 s=clone(v.partial_decryption_shares[0]);s.guardian_id='g9999';reject(()=>verifyShareArtifact(s,{ceremony:v.guardian_ceremony_record,tally}),'FOREIGN_GUARDIAN');
 let c=clone(v.guardian_ceremony_record);c.guardian_ceremony_digest='0'.repeat(64);reject(()=>verifyGuardianCeremonyRecord(c),'CEREMONY_INTEGRITY_FAILURE');
 let r=clone(v.threshold_decryption_record);r.plaintext_tally_base64url=Buffer.from('{"result":[[99,0,0]]}').toString('base64url');reject(()=>verifyThresholdDecryptionRecord(r,{ceremony:v.guardian_ceremony_record,tally}),'DECRYPTION_RECORD_INTEGRITY_FAILURE');
 r=clone(v.threshold_decryption_record);r.decryption_record_digest='f'.repeat(64);reject(()=>verifyThresholdDecryptionRecord(r,{ceremony:v.guardian_ceremony_record,tally}),'DECRYPTION_RECORD_INTEGRITY_FAILURE');
});
test('T-1 share has no Belenios plaintext result',async()=>{
 const s=v.partial_decryption_shares[0];
 await assert.rejects(adapter.computeVerifiedResult({baseArchivePath:base,shares:[{guardian_index:1,share_bytes:Buffer.from(s.belenios_partial_decryption_base64url,'base64url')}]}));
});
test('invalid proof among threshold shares is rejected by pinned upstream Belenios',async()=>{
 const a=v.partial_decryption_shares[0], b=clone(v.partial_decryption_shares[1]);
 const raw=JSON.parse(Buffer.from(b.belenios_partial_decryption_base64url,'base64url').toString('utf8')); raw.decryption_proofs[0][0].challenge='1';
 await assert.rejects(adapter.computeVerifiedResult({baseArchivePath:base,shares:[{guardian_index:1,share_bytes:Buffer.from(a.belenios_partial_decryption_base64url,'base64url')},{guardian_index:2,share_bytes:Buffer.from(JSON.stringify(raw))}]}));
});
test('duplicate guardian cannot form threshold',async()=>{
 const s=v.partial_decryption_shares[0]; const raw=Buffer.from(s.belenios_partial_decryption_base64url,'base64url');
 await assert.rejects(adapter.computeVerifiedResult({baseArchivePath:base,shares:[{guardian_index:1,share_bytes:raw},{guardian_index:1,share_bytes:raw}]}));
});
