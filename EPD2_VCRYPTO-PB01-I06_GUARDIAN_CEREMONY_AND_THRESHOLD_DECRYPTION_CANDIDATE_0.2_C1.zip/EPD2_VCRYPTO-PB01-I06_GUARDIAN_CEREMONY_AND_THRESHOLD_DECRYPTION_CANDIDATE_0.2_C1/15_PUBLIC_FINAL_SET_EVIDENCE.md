# Public final-set evidence

Exports profile, signed closure, checkpoint, accepted manifest, policy, CSet_final, cset_root, FinalSetEnvelope, F_final and public-evidence digest. It proves every effective digest was accepted by the closure prefix without publishing lifecycle relations.
