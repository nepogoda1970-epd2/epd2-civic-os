# Database migrations

`migrations/001_i03_sqlite.sql` initializes the optional local conformance
store with WAL/FULL durability, constraints, indexes and append-only triggers.
It is applied only by `scripts/migrate_sqlite.mjs`, never implicitly on service
startup.

`migrations/postgresql/001_i03_submission_ledger.sql` is the production schema;
`002_i03_roles.sql` grants separate submission and evidence-reader privileges
without destructive DML/DDL, schema CREATE or database TEMP. It transfers
schema ownership to the non-login migrator role and leaves the runtime unable
to run migrations. `rollback.sql` is an explicit pre-production
rollback. Election registration is a separate governed setup action.

`scripts/migrate_postgres.mjs` is the explicit governed bootstrap path.
`server/i03-receiver.mjs` performs no DDL and fails closed when runtime
privileges are broader than the required profile.
