# PB01-I06 Acceptance Report — C1

## Mandatory developer report

- Candidate filename: `EPD2_VCRYPTO-PB01-I06_GUARDIAN_CEREMONY_AND_THRESHOLD_DECRYPTION_CANDIDATE_0.2_C1.zip`
- Archive SHA-256: reported with final delivery after packaging.
- Base for C1: `EPD2_VCRYPTO-PB01-I06_GUARDIAN_CEREMONY_AND_THRESHOLD_DECRYPTION_CANDIDATE_0.1.zip`.
- Accepted predecessor chain: I01–I05 unchanged; I05 base remains `EPD2_VCRYPTO-PB01-I05_HOMOMORPHIC_TALLY_AND_EXACT_FINAL_SET_CONSUMPTION_CANDIDATE_0.2_C1.zip`.
- C1 source mismatch: trailing transport LF in persisted threshold-election fixture generated the wrong Belenios election fingerprint; fixed at canonical fixture/context persistence boundary.
- `FOREIGN_ELECTION_BALLOT`: **unchanged**, not weakened.
- I05 mandatory aggregate-byte recomputation corrective: **PASS**, including privileged PostgreSQL byte-only mutation and I06 refusal.
- Guardian configurations: N=3/T=2; N=5/T=3; N=3/T=2 empty authorized tally.
- Belenios: pinned **3.3.0**, crypto patch count 0.
- PostgreSQL: **16.14 real runtime**, fresh `initdb` per acceptance class, migrations 001–008 from zero.
- PostgreSQL test result: **22/22 PASS**.
- Concurrency: PASS, including threshold-forming share race and same-guardian duplicate race.
- CRASH-01..04: **4/4 PASS**.
- Hard restart: **PASS**.
- Backup/restore: **PASS**.
- Privileged tamper: **10/10 declared classes PASS/detected as required**.
- Role separation: **PASS**.
- Local I06 gate: **23/23 PASS**.
- Frozen mutation vectors: **9/9 REJECT**.
- Verifier A: **4/4 PASS**, 6/6 independent mutations rejected.
- Verifier B: **Go reference, 4/4 PASS**, independent of producer canonicalization and not a Verifier A wrapper.
- Cross-language byte agreement: **true** for ceremony digest, aggregate reference digest, share digests, plaintext tally digest, and final decryption-record digest.
- Frozen I06 vectors and verifier tree: **byte-for-byte unchanged from I06 0.1**.
- Accepted I01–I05 source/schema/migrations: **byte-for-byte unchanged from I06 0.1**.
- I05 local Node regression: **8/8 PASS**.
- Carried debts: `PB01-DEBT-VERIFIER-RUST-LOCK-01` and `PB01-DEBT-RUST-NEGATIVES-01` remain explicitly carried to I08; C1 does not silently close them.

## Per-class evidence

| Acceptance class | Result |
|---|---:|
| I06 local tests | 23/23 PASS |
| Real PostgreSQL tamper + roles | 11/11 PASS |
| Real PostgreSQL concurrency + CRASH | 6/6 PASS |
| Real PostgreSQL ceremony + threshold | 3/3 PASS |
| Real PostgreSQL restart + backup/restore | 2/2 PASS |
| **Real PostgreSQL total** | **22/22 PASS** |
| Frozen I06 vectors | 4/4 PASS |
| Frozen I06 mutations | 9/9 REJECT |
| Verifier A | 4/4 PASS + 6/6 mutations REJECT |
| Verifier B | 4/4 PASS |
| Cross-language digest agreement | true |
| I05 local Node regression | 8/8 PASS |

## Classification

`Outcome A — I06 ESTABLISHED`

C1 closes the production PostgreSQL election/ballot binding defect while retaining fail-closed foreign-election validation and all frozen cryptographic evidence semantics.
