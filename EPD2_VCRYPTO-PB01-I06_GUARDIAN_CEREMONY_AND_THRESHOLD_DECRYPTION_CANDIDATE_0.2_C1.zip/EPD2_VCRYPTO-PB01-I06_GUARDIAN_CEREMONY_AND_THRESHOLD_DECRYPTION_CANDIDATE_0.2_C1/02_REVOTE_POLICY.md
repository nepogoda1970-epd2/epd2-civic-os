# Revote policy

Frozen identifier: `epd2.pb01.revote.latest-valid.v1`. For every valid I03 private lifecycle, select the ACCEPTED submission with maximal I03 `ledger_seq` at or before the authorized closure checkpoint. Rejected submissions never enter I03 and cannot displace a prior accepted ballot. Historical submissions remain immutable and accepted-but-not-effective is not invalid.
