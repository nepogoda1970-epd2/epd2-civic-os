# Independent Verifier B Extension

`verifier/reference-go-i05/main.go` is a Go stdlib implementation that does not import producer code. It independently implements restricted canonicalization/domain hashing, Ed25519 I04 closure verification and I04 evidence checks, I05 manifest/record/evidence digests, exact ballot digest recomputation, exact-set/order checks, and calls pinned upstream Belenios in its own temporary archive to recompute aggregate bytes.
