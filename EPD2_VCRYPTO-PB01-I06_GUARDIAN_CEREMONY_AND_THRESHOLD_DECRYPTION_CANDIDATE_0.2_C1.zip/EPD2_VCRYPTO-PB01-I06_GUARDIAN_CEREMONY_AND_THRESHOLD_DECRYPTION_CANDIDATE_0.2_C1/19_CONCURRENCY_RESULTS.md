# Concurrency results

PASS: identical concurrent finalizers converge to one row and one F_final; conflicting evidence receives FINALIZATION_CONFLICT. Concurrent accepted revotes are ordered by I03 ledger_seq; synthetic permutation battery repeated selection 50 times.
