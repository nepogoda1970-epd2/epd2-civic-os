# Finalization transaction

PostgreSQL `SERIALIZABLE` plus election-scoped advisory transaction lock covers authorization verification, ledger integrity, prefix resolution, all I04 inserts and OPEN→CLOSED transition. CRASH-01..03 roll back; CRASH-04 commits and retry returns the same artifacts.
