# Backup and restore results

PASS: custom-format pg_dump/pg_restore preserved I03 history, exact encrypted bytes, lifecycle mappings and every I04 artifact. Restored F_final, cset_root and public-evidence digest were identical. Private lifecycle data is excluded from public export, not from governed private backup.
