# PostgreSQL schema and roles

Migrations 003/004 add closure records, private resolutions, effective references, finalizations and audit events. Roles: submission runtime, finalization runtime, evidence reader, private auditor and migrator. Finalizer has I03 read plus election_state-only update and append-only I04 inserts; no DDL, accepted-ballot mutation or final-evidence mutation.
