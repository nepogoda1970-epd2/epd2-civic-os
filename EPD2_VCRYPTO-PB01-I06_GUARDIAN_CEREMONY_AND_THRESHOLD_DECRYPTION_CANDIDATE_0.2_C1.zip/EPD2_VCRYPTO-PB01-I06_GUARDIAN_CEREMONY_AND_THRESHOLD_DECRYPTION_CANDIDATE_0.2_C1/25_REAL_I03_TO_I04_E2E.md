# Real I03 to I04 E2E

PASS: browser-produced Belenios ballot A and browser/vector ballot B were native-verified and accepted by I03 PostgreSQL under one lifecycle. Closure selected B only; A remained in accepted evidence/history. Exact bytes for B were retrieved unchanged through the I05 contract.
