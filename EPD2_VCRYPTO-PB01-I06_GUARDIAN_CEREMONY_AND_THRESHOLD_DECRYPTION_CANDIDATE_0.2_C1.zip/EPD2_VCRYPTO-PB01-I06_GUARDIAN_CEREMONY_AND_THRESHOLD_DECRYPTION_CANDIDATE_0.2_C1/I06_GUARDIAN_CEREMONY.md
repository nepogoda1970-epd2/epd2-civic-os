# Guardian Ceremony

State machine:

`CREATED → GUARDIANS_REGISTERED → PUBLIC_KEYS_SUBMITTED → CEREMONY_VERIFIED → CEREMONY_FROZEN`

Policy requires `N >= T >= 2`. Guardian IDs are election-local (`g0001`, `g0002`, …) and ordered by explicit guardian index, never insertion order.

Before freeze, the candidate independently reconstructs Belenios `trustees.json` and `election.json` from the submitted public threshold parameters with pinned Belenios 3.3.0 and requires byte-for-byte equality with the ceremony artifacts. The derived election public key must equal the election cryptographic context used for ballot encryption.

Once frozen, PostgreSQL guards reject changes to guardian count, threshold, guardian membership/public keys, derived election public key, ceremony digest, and canonical record. Re-verification of the canonical record provides a cryptographic/evidence check beyond database triggers for single-field privileged tampering.

No private guardian key or decryption key is stored in application PostgreSQL. The frozen vectors contain only public threshold parameters, public trustee/election artifacts, aggregate data, and public decryption shares/proofs.


## Guardian-side key generation boundary

`guardian-side/reference_threshold_ceremony.sh` is a reference guardian-side wrapper over Belenios 3.3.0 `generate-trustee-key-threshold`. It executes the six upstream threshold-ceremony steps and writes `.key/.dkey` only into a caller-owned custody directory. A real N=3/T=2 key-generation check was executed in a temporary directory and that directory was deleted after the public `threshold.json` existence check. The candidate contains no generated private material.

The application-side coordinator never invokes this private-key generator. It accepts only public guardian contributions and verifies/reconstructs the frozen Belenios public threshold context. This keeps operational application capability separate from guardian decryption authority.
