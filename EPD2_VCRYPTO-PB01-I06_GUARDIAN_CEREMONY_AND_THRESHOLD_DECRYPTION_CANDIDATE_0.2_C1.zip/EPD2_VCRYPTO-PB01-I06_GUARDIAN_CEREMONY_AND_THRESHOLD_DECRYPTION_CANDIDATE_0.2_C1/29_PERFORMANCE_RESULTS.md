# Performance results

Environment: Node 24.19.0, Linux x64, AMD EPYC 9V74, PostgreSQL 16.10 with
`fsync=on`, `synchronous_commit=on` and `full_page_writes=on`. Twenty real
Belenios samples were used per reported category.

| Measure | Median | p95 | Max |
| --- | ---: | ---: | ---: |
| native verification | 14.462 ms | 20.430 ms | 27.219 ms |
| total concurrent acceptance latency | 291.858 ms | 326.199 ms | 329.010 ms |
| DB transaction | 61.517 ms | 96.584 ms | 100.991 ms |

Twenty concurrent unique acceptances completed in 340.094 ms
(58.807/s) with verification concurrency capped at four. These numbers are
environment observations, not production capacity promises. Security
correctness takes priority over throughput.
