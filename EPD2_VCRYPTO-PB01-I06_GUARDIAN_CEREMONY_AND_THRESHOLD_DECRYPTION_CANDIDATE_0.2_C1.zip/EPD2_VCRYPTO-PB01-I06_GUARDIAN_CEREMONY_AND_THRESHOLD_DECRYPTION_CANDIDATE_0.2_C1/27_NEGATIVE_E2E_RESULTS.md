# Negative E2E results

PASS: bad closure signature, unknown policy, conflicting checkpoint, tampered ledger, changed public digest and lifecycle anomaly fail closed. Post-checkpoint accepted data is excluded. Public export scan found no lifecycle handle or identity linkage.
