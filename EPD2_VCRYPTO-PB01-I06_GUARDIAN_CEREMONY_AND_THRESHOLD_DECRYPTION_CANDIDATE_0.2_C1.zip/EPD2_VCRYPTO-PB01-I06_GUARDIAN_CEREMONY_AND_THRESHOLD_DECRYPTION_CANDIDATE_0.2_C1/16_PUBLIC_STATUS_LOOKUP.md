# Public status lookup

Lookup by the high-entropy `BallotDigest` returns only acceptance state,
submission/event references, accepted time and the non-finality claim. It never
returns ciphertext, identity, credential, lifecycle handle or revote linkage.

There is no list-voters/list-credentials/list-lifecycles endpoint. Exact-origin
CORS and bounded lookup rate limits reduce enumeration abuse; URL secrecy is
not treated as authorization. Operational deployments should share rate-limit
state at the edge when running multiple instances.
