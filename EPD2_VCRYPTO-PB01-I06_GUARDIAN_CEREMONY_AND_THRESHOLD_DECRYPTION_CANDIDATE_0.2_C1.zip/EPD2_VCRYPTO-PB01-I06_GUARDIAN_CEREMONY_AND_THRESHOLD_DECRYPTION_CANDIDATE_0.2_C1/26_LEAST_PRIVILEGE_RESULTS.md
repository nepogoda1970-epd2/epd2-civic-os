# Least Privilege Results

Executed live against PostgreSQL 16.14 with real login roles created from the shipped migration roles.

- `PostgresTallyStore.assertRuntimePrivileges()` returns `PASS_TALLY_LEAST_PRIVILEGE`.
- **Tally runtime cannot mutate I03/I04:** it holds `SELECT` on `pb01_i04.finalizations` but no `INSERT/UPDATE/DELETE/TRUNCATE` on `pb01_i03.encrypted_submissions`, `pb01_i03.submission_ledger_events`, `pb01_i04.finalizations` or `pb01_i04.effective_submissions`; live mutation attempts are rejected.
- **Submission, finalizer and I04 evidence roles cannot mutate I05:** no write privilege and no `CREATE` on `pb01_i05`; live `UPDATE`, `DELETE` and audit-`INSERT` attempts are rejected. Privileges are evaluated through the administrative connection because a role without `USAGE` on `pb01_i05` cannot resolve the table name to ask the question itself.
- **Evidence reader** can read `pb01_i05.public_tallies` and nothing else; `tally_audit_events` is denied.
- **No runtime DDL or TEMP:** for both the tally and evidence roles, `rolsuper`, `rolcreatedb`, `rolcreaterole`, `rolreplication`, `rolbypassrls`, database `TEMP` and `CREATE` on `pb01_i03`, `pb01_i04`, `pb01_i05` and `public` are all false, and live `CREATE TABLE` / `CREATE TEMP TABLE` attempts are rejected.
