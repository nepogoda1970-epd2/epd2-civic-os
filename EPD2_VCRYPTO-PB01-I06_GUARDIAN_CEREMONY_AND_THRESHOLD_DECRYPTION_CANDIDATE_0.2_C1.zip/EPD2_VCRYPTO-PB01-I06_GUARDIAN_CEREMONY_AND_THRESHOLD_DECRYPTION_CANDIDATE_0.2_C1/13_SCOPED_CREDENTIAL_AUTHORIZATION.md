# Scoped credential authorization

I03 adds a submission-authorization capability alongside, not inside, the
accepted I02 ballot schema. It retains the I02 `ScopedVotingCredential` shape
(`kind`, `secret`) but does not send the Belenios private credential to the
receiver.

The fixture capability is HMAC-SHA-256 authenticated, short-lived,
election-scoped and revote-policy scoped. Capability and lifecycle HMAC keys are
independently injected; no source secret is present. Invalid, expired and
cross-election capabilities fail before transaction. Membership name, email
and universal user ID are unnecessary.
