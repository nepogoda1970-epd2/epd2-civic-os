# Backup and restore

Accepted bytes, ledger, idempotency records and private lifecycle mappings must
be captured in one database-consistent encrypted backup. Executed PostgreSQL
`pg_dump`/`pg_restore` testing preserves exact `bytea`, receipt/status, private
lifecycle binding and chain/checkpoint integrity. SQLite backup remains only a
local adapter regression.

Production minimum: encrypted volume/database, encrypted backups, independent
key management, access logging, retention policy and scheduled restore tests.
Full operational backup is private and contains lifecycle data; the public
evidence export is a separate artifact and never contains that table.

At-rest encryption is defense in depth and never replaces Belenios ballot
encryption. I03 has no decrypt-before-storage path.
