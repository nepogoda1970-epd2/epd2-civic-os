# F_final Binding

`HomomorphicTallyRecord.f_final`, `TallyInputManifest.f_final`, evidence `f_final`, and the current authoritative I04 `f_final` must match exactly. I05 never interprets `F_final` as a decryption key/capability. Verifier A and independent Verifier B both reject altered or stale anchors.
