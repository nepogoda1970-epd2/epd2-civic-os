# API contract

## Submission

`POST /v1/elections/{ElectionInstanceId}/encrypted-ballots`

Required headers: exact permitted `Origin`, `Content-Type: application/json`,
`Authorization: EPD2-Scoped <capability>`, and `Idempotency-Key` (16–128 safe
ASCII characters). The body is the accepted I02 `EncryptedSubmissionArtifact`.
Success is `201`; an identical idempotent replay is `200` with the byte-equivalent
receipt. Same key/different semantic request is `409 IDEMPOTENCY_CONFLICT`.

## Public reads

- `GET /v1/elections/{id}/ballots/{BallotDigest}`
- `GET /v1/elections/{id}/accepted-submission-manifest`

There is no public voter, credential or lifecycle listing. `PUT`, `PATCH` and
`DELETE` receive `405 METHOD_NOT_ALLOWED`.

Stable errors are implemented for invalid schema/profile/tally function,
unknown/foreign election, digest mismatch, invalid ballot/proof, invalid or
expired scoped credential, idempotency conflict, oversized request, rate limit
and storage failure. Cryptographic internals are not returned.
