# I07 Public Evidence Handoff

I06 defines but does not publish the versioned `epd2.pb01.i07-decryption-evidence-handoff/1` artifact.

It contains only public verification material:

- frozen guardian ceremony record and guardian public keys;
- threshold;
- accepted I05 tally record reference, `F_final`, aggregate bytes and aggregate digest;
- accepted public partial-decryption shares and proofs;
- threshold decryption record;
- final plaintext tally and its digest;
- decryption record digest and I07 handoff digest.

It contains no guardian private key/share, member identity, lifecycle handle, internal HMAC secret, credential, or publication/legal authority assertion.

Semantic claim: `PUBLIC_CRYPTOGRAPHIC_DECRYPTION_EVIDENCE_NOT_PUBLICATION_AUTHORITY`.

I07 publication UI/portal is deliberately not implemented in this gate.
