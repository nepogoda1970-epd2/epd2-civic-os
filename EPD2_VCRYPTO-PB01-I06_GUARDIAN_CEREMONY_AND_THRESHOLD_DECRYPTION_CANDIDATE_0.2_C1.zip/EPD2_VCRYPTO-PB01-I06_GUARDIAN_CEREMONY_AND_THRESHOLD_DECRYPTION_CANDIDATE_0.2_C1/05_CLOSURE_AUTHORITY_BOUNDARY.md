# Closure authority boundary

The finalizer cannot mint authority. It accepts a closed-schema `ClosureAuthorizationEvidence` signed with Ed25519 by an injected governed key. The signed statement commits election, checkpoint, closed-at time, revote policy and finalization process. The authority key is separate from Belenios election keys.
