# Private audit evidence

A separately privileged auditor can inspect each lifecycle's candidate sequence and selected row and verify the resolution digest. This table/view is not granted to the public evidence reader.
