# Deterministic ordering

Private selection order: `(ledger_seq ASC, submission_id ASC)`; maximal tuple wins. I03 guarantees monotonically assigned per-election `ledger_seq`, so timestamps are never authoritative. Public `CSet_final` order is I01 bytewise ascending 32-byte digest order, independent of lifecycle and time. Fifty input permutations produced one result.
