# Open Gaps

The load-bearing PostgreSQL runtime gap from `0.1` is closed: migrations, roles, production transaction concurrency, crash/restart persistence, privileged-role negatives, tamper detection and backup/restore are all executed against PostgreSQL 16.14 with 15/15 passing.

Remaining gaps, none of which affects a committed tally value:

- Serialization-failure retry is absent from the tally commit path (`PB01-DEBT-I05-PG-SERIALIZATION-RETRY-01`).
- `recompute()` does not re-hash the stored aggregate byte column (`PB01-DEBT-I05-RECOMPUTE-AGGREGATE-BYTES-01`).
- `tests/security.test.mjs` carries a pre-existing I03-era assertion that conflicts with the legitimate I05 `/tally` route (`PB01-DEBT-I03-SECURITY-TEST-TALLY-ROUTE-01`).
- Production-scale native Belenios performance at 1k/10k ballots is still not claimed.
- The two accepted Rust verifier debts remain carried forward.
