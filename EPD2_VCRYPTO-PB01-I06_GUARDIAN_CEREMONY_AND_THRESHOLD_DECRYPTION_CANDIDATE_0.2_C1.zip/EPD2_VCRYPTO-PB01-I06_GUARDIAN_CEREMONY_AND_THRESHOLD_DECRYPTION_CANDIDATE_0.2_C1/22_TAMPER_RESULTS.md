# Tamper results

PASS: changed/deleted/added/reordered effective digests, checkpoint, policy, cset_root, envelope and F_final are detected. A modified I03 historical ledger hash blocks preview/finalization. Runtime DB triggers/privileges block update/delete.
