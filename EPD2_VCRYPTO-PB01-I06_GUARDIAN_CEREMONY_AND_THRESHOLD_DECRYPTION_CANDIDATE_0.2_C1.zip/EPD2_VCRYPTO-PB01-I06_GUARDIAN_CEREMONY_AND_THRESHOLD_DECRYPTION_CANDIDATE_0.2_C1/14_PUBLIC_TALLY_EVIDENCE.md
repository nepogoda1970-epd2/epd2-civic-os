# Public Tally Evidence

`TallyEvidenceBundle` publishes FinalSetEnvelope, `F_final`, cset root, canonical ordered ballot digests, TallyInputManifest/digest, exact aggregate object/bytes/digest, HomomorphicTallyRecord/digest and an outer evidence digest. It exposes no private lifecycle mapping, credential, vote plaintext, guardian share, or secret key.
