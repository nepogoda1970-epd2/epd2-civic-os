import { createPublicKey } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ClosureAuthorizationVerifier } from '../src/i04/closure_authority.mjs';
import { PostgresFinalizationStore } from '../src/i04/postgres_finalization_store.mjs';
import { BeleniosHomomorphicAggregator } from '../src/i05/belenios_aggregator.mjs';
import { PostgresTallyStore } from '../src/i05/postgres_tally_store.mjs';
import { TallyEngine } from '../src/i05/tally.mjs';

const root=resolve(fileURLToPath(new URL('..',import.meta.url)));
function required(n){const v=process.env[n];if(!v)throw new Error(`required environment variable missing: ${n}`);return v;}
const electionInstanceId=process.argv[2];
if(!/^ei1_[0-9a-f]{32}$/u.test(electionInstanceId??'')) throw new Error('usage: node server/recompute-tally.mjs ei1_<32hex>');
const development=process.env.EPD2_I05_DEVELOPMENT_HTTP==='1';
const allowPlain=development&&process.env.EPD2_I05_POSTGRES_ALLOW_PLAINTEXT_LOCAL==='1';
let ssl=false;if(!allowPlain)ssl={ca:await readFile(required('EPD2_I05_POSTGRES_TLS_CA_PATH'),'utf8'),rejectUnauthorized:true};
const cfg={connectionString:required('EPD2_I05_POSTGRES_URL'),ssl};
const finalizationStore=new PostgresFinalizationStore({...cfg,application_name:'epd2-pb01-i05-recompute-finalization-read'});
const tallyStore=new PostgresTallyStore({...cfg,application_name:'epd2-pb01-i05-recompute'});
try{
 await tallyStore.assertRuntimePrivileges();
 const keyId=required('EPD2_I05_CLOSURE_KEY_ID');
 const pub=createPublicKey(await readFile(required('EPD2_I05_CLOSURE_PUBLIC_KEY_PATH')));
 const authorizationVerifier=new ClosureAuthorizationVerifier(new Map([[keyId,pub]]));
 const aggregator=new BeleniosHomomorphicAggregator({toolPath:join(root,'evidence/build/belenios-tool-3.3.0-linux-x86_64'),baseElectionArchivePath:required('EPD2_I05_BELENIOS_ARCHIVE')});
 const engine=new TallyEngine({finalizationStore,tallyStore,aggregator,electionDir:required('EPD2_I05_BELENIOS_ELECTION_DIR'),authorizationVerifier});
 const result=await engine.recompute(electionInstanceId);
 process.stdout.write(`${JSON.stringify(result)}\n`);
}finally{await Promise.allSettled([finalizationStore.close(),tallyStore.close()]);}
