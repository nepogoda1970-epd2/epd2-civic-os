import { createPrivateKey } from "node:crypto";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { ScopedCredentialAuthority } from "../src/i03/credential.mjs";
import { startI03Service } from "../src/i03/http_service.mjs";
import { NativeBeleniosVerifier } from "../src/i03/native_verifier.mjs";
import { PostgresSubmissionStore } from "../src/i03/postgres_store.mjs";
import { ReceiptSigner } from "../src/i03/receipt.mjs";
import { loadFixture } from "../src/i02_accepted/shared/load_fixture.mjs";

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`required environment variable missing: ${name}`);
  return value;
}

function key(name) {
  const value = Buffer.from(required(name), "base64url");
  if (value.length < 32) throw new Error(`${name} must decode to at least 32 bytes`);
  return value;
}

export async function launchFromEnvironment() {
  const candidateRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
  const fixtureNames = required("EPD2_I03_ELECTION_FIXTURES").split(",").filter(Boolean);
  const fixtures = await Promise.all(fixtureNames.map((name) => loadFixture(candidateRoot, name)));
  const development = process.env.EPD2_I03_DEVELOPMENT_HTTP === "1";
  const allowLocalPlaintext = development && process.env.EPD2_I03_POSTGRES_ALLOW_PLAINTEXT_LOCAL === "1";
  let ssl = false;
  if (!allowLocalPlaintext) {
    const ca = await readFile(required("EPD2_I03_POSTGRES_TLS_CA_PATH"), "utf8");
    ssl = { ca, rejectUnauthorized: true };
  }
  const store = new PostgresSubmissionStore({
    connectionString: required("EPD2_I03_POSTGRES_URL"),
    ssl,
    max: Number(process.env.EPD2_I03_POSTGRES_POOL_MAX || "10"),
    application_name: "epd2-pb01-i03-submission-runtime",
  });
  await store.assertRuntimePrivileges();
  for (const fixture of fixtures) {
    if (!await store.getElection(fixture.context.election_instance_id)) throw new Error(`election not registered by governed setup: ${fixture.context.election_instance_id}`);
  }
  const credentialAuthority = new ScopedCredentialAuthority({
    capabilityKey: key("EPD2_I03_CAPABILITY_KEY_B64URL"),
    lifecycleKey: key("EPD2_I03_LIFECYCLE_KEY_B64URL"),
    issuer: required("EPD2_I03_CAPABILITY_ISSUER"),
  });
  const privateKey = createPrivateKey(await readFile(required("EPD2_I03_RECEIPT_PRIVATE_KEY_PATH")));
  const receiptSigner = new ReceiptSigner({ privateKey, keyId: required("EPD2_I03_RECEIPT_KEY_ID") });
  const verifier = new NativeBeleniosVerifier({ toolPath: required("EPD2_I03_BELENIOS_TOOL_PATH") });
  const server = await startI03Service({
    store,
    electionFixtures: new Map(fixtures.map((fixture) => [fixture.context.election_instance_id, fixture])),
    verifier,
    credentialAuthority,
    receiptSigner,
    idempotencySecret: key("EPD2_I03_IDEMPOTENCY_KEY_B64URL"),
    allowedOrigin: required("EPD2_I03_ALLOWED_VOTING_ORIGIN"),
    host: process.env.EPD2_I03_HOST || "127.0.0.1",
    port: Number(process.env.EPD2_I03_PORT || "32902"),
    developmentHttp: development,
  });
  const close = () => server.close(async () => { await store.close(); process.exit(0); });
  process.once("SIGINT", close);
  process.once("SIGTERM", close);
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  await launchFromEnvironment();
}
