import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { startI03BrowserClientServer } from "../src/i03/browser_client_server.mjs";

async function readJson(path) {
  if (!path) throw new Error("EPD2_I03_SUBMISSION_AUTHORIZATION_PATH is required");
  return JSON.parse(await readFile(path, "utf8"));
}

export async function launchBrowserClientFromEnvironment() {
  const candidateRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
  const context = await readJson(process.env.EPD2_I03_CONTEXT_PATH || resolve(candidateRoot, "evidence/fixtures/election-a/context.json"));
  const handoff = await readJson(process.env.EPD2_I03_HANDOFF_PATH || resolve(candidateRoot, "evidence/fixtures/election-a/handoff.fixture.json"));
  const submissionAuthorization = await readJson(process.env.EPD2_I03_SUBMISSION_AUTHORIZATION_PATH);
  return startI03BrowserClientServer({
    clientDir: resolve(candidateRoot, "client"),
    context,
    handoff,
    submissionAuthorization,
    host: process.env.EPD2_I03_CLIENT_HOST || "127.0.0.1",
    port: Number(process.env.EPD2_I03_CLIENT_PORT || "32901"),
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  await launchBrowserClientFromEnvironment();
}
