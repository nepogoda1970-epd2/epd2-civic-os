import { createPublicKey } from "node:crypto";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { ClosureAuthorizationVerifier } from "../src/i04/closure_authority.mjs";
import { startI04Service } from "../src/i04/http_service.mjs";
import { PostgresFinalizationStore } from "../src/i04/postgres_finalization_store.mjs";

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`required environment variable missing: ${name}`);
  return value;
}

export async function launchFromEnvironment() {
  const development = process.env.EPD2_I04_DEVELOPMENT_HTTP === "1";
  const allowLocalPlaintext = development && process.env.EPD2_I04_POSTGRES_ALLOW_PLAINTEXT_LOCAL === "1";
  let ssl = false;
  if (!allowLocalPlaintext) {
    const ca = await readFile(required("EPD2_I04_POSTGRES_TLS_CA_PATH"), "utf8");
    ssl = { ca, rejectUnauthorized: true };
  }
  const store = new PostgresFinalizationStore({
    connectionString: required("EPD2_I04_POSTGRES_URL"),
    ssl,
    max: Number(process.env.EPD2_I04_POSTGRES_POOL_MAX || "8"),
    application_name: "epd2-pb01-i04-finalization-runtime",
  });
  await store.assertFinalizerPrivileges();
  const keyId = required("EPD2_I04_CLOSURE_KEY_ID");
  const publicKey = createPublicKey(await readFile(required("EPD2_I04_CLOSURE_PUBLIC_KEY_PATH")));
  const authorizationVerifier = new ClosureAuthorizationVerifier(new Map([[keyId, publicKey]]));
  const server = await startI04Service({
    store,
    authorizationVerifier,
    allowedOperatorOrigin: required("EPD2_I04_ALLOWED_OPERATOR_ORIGIN"),
    host: process.env.EPD2_I04_HOST || "127.0.0.1",
    port: Number(process.env.EPD2_I04_PORT || "32904"),
    developmentHttp: development,
  });
  const close = () => server.close(async () => { await store.close(); process.exit(0); });
  process.once("SIGINT", close);
  process.once("SIGTERM", close);
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  await launchFromEnvironment();
}

