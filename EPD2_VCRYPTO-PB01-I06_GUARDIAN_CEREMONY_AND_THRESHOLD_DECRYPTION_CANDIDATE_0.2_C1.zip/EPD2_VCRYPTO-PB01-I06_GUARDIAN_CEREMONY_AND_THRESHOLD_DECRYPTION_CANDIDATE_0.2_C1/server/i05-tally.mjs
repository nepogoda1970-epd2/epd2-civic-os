import { createHash, createPublicKey, timingSafeEqual } from "node:crypto";
import { readFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { ClosureAuthorizationVerifier } from "../src/i04/closure_authority.mjs";
import { PostgresFinalizationStore } from "../src/i04/postgres_finalization_store.mjs";
import { BeleniosHomomorphicAggregator } from "../src/i05/belenios_aggregator.mjs";
import { PostgresTallyStore } from "../src/i05/postgres_tally_store.mjs";
import { TallyEngine } from "../src/i05/tally.mjs";
import { startI05Service } from "../src/i05/http_service.mjs";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
function required(name) { const value = process.env[name]; if (!value) throw new Error(`required environment variable missing: ${name}`); return value; }
function tokenHash(value) { return createHash("sha256").update(value, "utf8").digest(); }

export async function launchFromEnvironment() {
  const development = process.env.EPD2_I05_DEVELOPMENT_HTTP === "1";
  const allowLocalPlaintext = development && process.env.EPD2_I05_POSTGRES_ALLOW_PLAINTEXT_LOCAL === "1";
  let ssl = false;
  if (!allowLocalPlaintext) ssl = { ca: await readFile(required("EPD2_I05_POSTGRES_TLS_CA_PATH"), "utf8"), rejectUnauthorized: true };
  const connectionString = required("EPD2_I05_POSTGRES_URL");
  const electionDir = required("EPD2_I05_BELENIOS_ELECTION_DIR");
  const archive = required("EPD2_I05_BELENIOS_ARCHIVE");
  const finalizationStore = new PostgresFinalizationStore({ connectionString, ssl, application_name: "epd2-pb01-i05-finalization-read" });
  const tallyStore = new PostgresTallyStore({ connectionString, ssl, application_name: "epd2-pb01-i05-tally-runtime" });
  await tallyStore.assertRuntimePrivileges();
  const keyId = required("EPD2_I05_CLOSURE_KEY_ID");
  const publicKey = createPublicKey(await readFile(required("EPD2_I05_CLOSURE_PUBLIC_KEY_PATH")));
  const authorizationVerifier = new ClosureAuthorizationVerifier(new Map([[keyId, publicKey]]));
  const configuredTokenHash = tokenHash(required("EPD2_I05_OPERATOR_TOKEN"));
  const authorizeTally = (req) => {
    const h = req.headers.authorization ?? "";
    if (!h.startsWith("Bearer ")) return false;
    const supplied = tokenHash(h.slice(7));
    return supplied.length === configuredTokenHash.length && timingSafeEqual(supplied, configuredTokenHash);
  };
  const aggregator = new BeleniosHomomorphicAggregator({ toolPath: join(root, "evidence/build/belenios-tool-3.3.0-linux-x86_64"), baseElectionArchivePath: archive });
  const engine = new TallyEngine({ finalizationStore, tallyStore, aggregator, electionDir, authorizationVerifier });
  const server = await startI05Service({ engine, tallyStore, authorizeTally, port: Number(process.env.EPD2_I05_PORT || "32905") });
  const close = () => server.close(async () => { await Promise.all([finalizationStore.close(), tallyStore.close()]); process.exit(0); });
  process.once("SIGINT", close); process.once("SIGTERM", close);
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) await launchFromEnvironment();
