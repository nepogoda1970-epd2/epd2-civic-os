# I04 / I05 Semantic Preservation

Of 50 compared predecessor semantic files, 49 are byte-identical. One file changed intentionally:

`src/i04/postgres_finalization_store.mjs` — `getElection()` additionally projects the existing `pb01_i03.elections.context_json` column (`bdf2a467…` → `5df66f4d…`).

This is digest-neutral. The column already exists and is `NOT NULL` in migration `001`. Every I04 consumer of the returned row — `previewClosure`, `recompute`, `authorizedFinalBallotSet`, `buildAcceptedManifestAtCheckpoint`, `buildAuthorizedFinalBallotSet` — reads named fields and never spreads the row, so no accepted I04 manifest, checkpoint, envelope, `cset_root` or `F_final` digest can shift. The projection restores parity with `src/i03/postgres_store.mjs::getElection()`, which already returned `context_json`.

Regression evidence: I04 PostgreSQL suite 15/15 pass, I03 PostgreSQL suite 10/10 pass, I04 Verifier B regression `PASS`. Within I05, `src/i05/postgres_tally_store.mjs` gains `backupTo()` mirroring the accepted I03/I04 stores; no tally, aggregation, `F_final` or evidence semantics are touched. The pinned Belenios executable remains byte-identical. Report: `evidence/results/i05/predecessor-preservation.json`.
