# Submission ledger

Every new accepted digest appends exactly one `SubmissionAccepted` event:

- event version and UUID;
- per-election sequence;
- submission UUID and `BallotDigest`;
- accepted timestamp;
- previous event hash.

The event is never rewritten when a later revote arrives. I03 stores both
submissions and deliberately records no `superseded` or `effective` decision.
Those semantics belong exclusively to I04.
