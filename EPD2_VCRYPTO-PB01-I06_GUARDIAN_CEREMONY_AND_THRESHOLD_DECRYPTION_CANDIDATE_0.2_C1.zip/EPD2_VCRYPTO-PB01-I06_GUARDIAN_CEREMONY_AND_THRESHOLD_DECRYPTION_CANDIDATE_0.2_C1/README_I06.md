# EPD² PB01-I06 — Guardian Ceremony, Threshold Decryption & Decryption Evidence

Candidate: `EPD2_VCRYPTO-PB01-I06_GUARDIAN_CEREMONY_AND_THRESHOLD_DECRYPTION_CANDIDATE_0.2_C1`

This C1 candidate closes the PostgreSQL election/ballot binding defect found in I06 0.1 without weakening `FOREIGN_ELECTION_BALLOT` and without changing accepted I01–I05 semantics.

## C1 closure

The production I06 threshold fixture had persisted the election JSON with a transport trailing LF byte. Belenios ballots bind `election_hash` to the exact election JSON bytes without that LF. The resulting fingerprints differed, so the unchanged I03 validator correctly rejected the otherwise intended I06 chain as `FOREIGN_ELECTION_BALLOT`.

C1 now persists and validates the exact 344-byte Belenios election artifact before election registration. `src/i06/election_binding.mjs` independently checks the exact bytes, SHA-256/Belenios fingerprint, base64url commitment, election UUID and election public key. No foreign-ballot acceptance rule is relaxed.

## Established chain

`I04 F_final → I05 Authorized Final Ballot Set → I05 Homomorphic Aggregate → I06 Guardian Threshold Decryption → Verified Plaintext Tally + Public Decryption Evidence`

Implemented and verified:

- mandatory I05 persisted aggregate-byte recomputation before I06 authorization;
- Belenios 3.3.0 Pedersen threshold ceremony and public-key derivation;
- immutable canonical guardian ceremony;
- election-local guardian membership and canonical ordering;
- aggregate-bound partial decryption shares and proofs;
- threshold completion with no plaintext before threshold;
- immutable threshold-decryption record;
- PostgreSQL role separation, concurrency, crash, restart, backup/restore and privileged-tamper checks;
- Verifier A and independent Go Verifier B;
- four frozen real Belenios threshold vectors, including empty authorized tally.

## Runtime acceptance

Real PostgreSQL **16.14** was used. `npm run test:i06:postgres` starts fresh PostgreSQL clusters, applies migrations 001–008 from zero, and executes the 22 production acceptance cases. Final result:

`PB01-I06 PostgreSQL acceptance: 22/22 PASS`

The test helper caches only repeated verification results for byte-identical public fixture ballots/aggregate within a test class after their first real pinned-Belenios verification. This is test-only process-bounding; production verification/aggregation code is unchanged.

Frozen `test-vectors/i06/**`, `verifier/**`, Verifier A result and Verifier B result are byte-for-byte unchanged from I06 0.1.

## Classification

`Outcome A — I06 ESTABLISHED`

See `I06_ACCEPTANCE_REPORT.md`, `I06_POSTGRESQL_RUNTIME_EVIDENCE.md`, and `I06_C1_POSTGRESQL_ELECTION_BALLOT_BINDING_CLOSURE.md`.
