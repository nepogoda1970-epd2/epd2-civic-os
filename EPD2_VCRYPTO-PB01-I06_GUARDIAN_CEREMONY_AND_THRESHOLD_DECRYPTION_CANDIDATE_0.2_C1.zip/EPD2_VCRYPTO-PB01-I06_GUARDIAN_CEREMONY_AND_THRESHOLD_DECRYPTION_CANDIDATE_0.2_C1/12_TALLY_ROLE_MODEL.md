# Tally Role Model

`epd2_pb01_tally_runtime` receives SELECT on required I03/I04 state and SELECT/INSERT only on I05 tally artifacts. It is explicitly denied mutation of I03/I04, update/delete/truncate of I05, schema creation, public schema creation, and database TEMP. Submission/finalization runtime roles are revoked from I05 tables; evidence reader receives only the public tally view. Static policy tests pass; live privilege tests remain PostgreSQL-runtime blocked.
