# FinalSetEnvelope

Uses unchanged I01 schema `epd2.pb01.final-set-envelope/1`: election/profile, canonicalization policy, Belenios context, closure-record digest, ordered digests, cset_root and tally-function identifier.
