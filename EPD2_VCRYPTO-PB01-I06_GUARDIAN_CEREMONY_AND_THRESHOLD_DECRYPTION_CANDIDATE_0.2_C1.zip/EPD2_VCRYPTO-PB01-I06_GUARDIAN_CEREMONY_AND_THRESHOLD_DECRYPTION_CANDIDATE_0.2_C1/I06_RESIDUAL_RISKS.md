# I06 Residual Risks

| Risk | I06 treatment | Residual |
|---|---|---|
| Malicious threshold quorum | public guardian set, share proofs, exact tally binding | a quorum controlling T valid secrets can collude; not claimed impossible |
| Guardian key compromise | no application DB/runtime custody; election-scoped public keys | guardian-side operational custody/HSM is outside I06 |
| Guardian availability loss | explicit N/T policy; any valid threshold subset reconstructs same result | fewer than T available guardians prevents decryption |
| DB-owner tamper | immutable triggers plus independent digest/recomputation paths | a fully coherent rewrite of DB and withheld/replaced external evidence remains infrastructure trust |
| Ceremony coordinator compromise | coordinator cannot supply private shares or write final result; derived key checked against Belenios context | compromised setup before public commitments are independently reviewed remains governance risk |
| Substituted aggregate | I05 persisted-byte digest corrective + Belenios aggregate recomputation | none accepted without defeating committed/external evidence chain |
| Duplicate-share attack | election+guardian uniqueness and threshold accounting | availability/DoS remains possible |
| Stale tally decryption | server resolves current accepted I05 state and reruns recomputation | governed supersession semantics remain outside I06 |
| Evidence withholding | immutable public-evidence objects prepared for I07 | publication availability is I07/operations responsibility |
| Partial guardian collusion (<T) | cannot reach threshold in tested Belenios model | traffic/operational side channels are outside this gate |

Rust Verifier B debts `PB01-DEBT-VERIFIER-RUST-LOCK-01` and `PB01-DEBT-RUST-NEGATIVES-01` remain carried to the previously allowed I08 deadline. Go 1.23.2 is used for I06 cross-language verification because Rust tooling is not installed in this build environment.
