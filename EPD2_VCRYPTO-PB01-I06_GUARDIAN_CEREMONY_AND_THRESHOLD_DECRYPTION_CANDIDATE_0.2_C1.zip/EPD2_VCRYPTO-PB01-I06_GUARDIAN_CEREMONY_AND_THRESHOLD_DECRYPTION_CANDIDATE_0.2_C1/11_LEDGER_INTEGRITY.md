# Ledger integrity

I03 uses a per-election SHA-256 hash chain, not a blockchain. The frozen new
domain is `epd2.pb01.submission-ledger-event.v1`; its input is the restricted-JCS
canonical `SubmissionAccepted` object including sequence and previous hash.

Database triggers reject ordinary update/delete. Verification detects altered
rows/events, middle deletion and reordering. Tail deletion and conflicting
views are detected relative to a retained manifest checkpoint. A party that
controls both database and every unpublished checkpoint can still create a
split view; future evidence publication must witness/sign checkpoints.

Tamper evidence demonstrates modified historical digest, deleted event,
reordered events and conflicting checkpoint rejection.
