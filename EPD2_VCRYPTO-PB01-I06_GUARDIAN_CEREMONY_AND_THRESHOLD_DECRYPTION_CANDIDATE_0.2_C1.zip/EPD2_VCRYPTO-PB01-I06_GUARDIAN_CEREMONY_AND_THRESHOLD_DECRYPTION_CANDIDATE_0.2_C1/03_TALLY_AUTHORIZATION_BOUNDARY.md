# Tally Authorization Boundary

Authority to request execution is separated from authority to choose input. `POST /v1/elections/{id}/tally` accepts an empty body only and requires an operator bearer token checked before execution. The service derives the current persisted I04 finalization and its exact ballot bytes itself. Caller-supplied ballots, aggregate, `F_final`, or envelope are rejected/not represented in the API.
