# Least privilege results

PASS: submission role cannot use/write I04; finalizer cannot insert/update/delete/truncate accepted submissions and has no DDL; evidence reader cannot mutate; migration ownership is separate. Runtime finalization tables are append-only.
