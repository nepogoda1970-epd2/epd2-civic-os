# Closure race results

PASS: submission and closure serialize on the same election advisory lock. The submission is either rejected after CLOSED or accepted outside the signed prefix and excluded. No timestamp decides inclusion.
