# I05 tally input contract

The only authorized input is `epd2.pb01.authorized-final-ballot-set/1`: election/profile/tally function, F_final, ordered effective digests and domain-separated exact-byte references resolved from immutable I03 storage. It is derivable only after finalized I04 state. Arbitrary ballot arrays are not accepted. No tally is implemented.
