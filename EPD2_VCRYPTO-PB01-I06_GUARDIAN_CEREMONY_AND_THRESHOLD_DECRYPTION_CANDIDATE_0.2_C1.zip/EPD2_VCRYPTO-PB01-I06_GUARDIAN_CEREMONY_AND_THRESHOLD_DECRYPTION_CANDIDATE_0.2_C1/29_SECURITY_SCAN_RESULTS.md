# Security scan results

Dependency, secret, prohibited-route, migration privilege and public-evidence privacy scans are recorded under `evidence/results`. No Belenios upgrade, decrypt/tally route, production secret, plaintext selection, randomness or stable member identity was introduced.
