# Open gaps

Non-I03-production-authorizing follow-ups:

- provision the validated PostgreSQL schema/role model in the governed product
  environment and perform deployment-specific capacity testing;
- configure shared edge rate limiting for multi-instance deployment;
- establish encrypted backup retention and recurring restore exercises;
- publish/witness ledger checkpoints to close database-controller split view;
- provision/rotate receipt, capability, lifecycle and idempotency keys;
- complete the separate AGPL deployment decision inherited from I01/I02.

These do not change accepted ballot bytes or I03 ledger semantics and do not
block the I04 implementation gate. They do block production election activation.

The former PostgreSQL implementation/execution gap is closed in `0.2_C1`.
