# Schema validation

`schemas/i03-encrypted-submission.schema.json` freezes the accepted I02 body and
forbids extra fields. The runtime additionally uses a bounded duplicate-aware
JSON parser, fatal UTF-8 decoding and canonical restricted-JCS comparison.

Rejected before persistence: duplicate members, BOM/invalid UTF-8, missing or
extra fields, numbers in the restricted profile, unknown schema/profile/tally
function, invalid base64url, excessive body/ballot size and excessive nesting.
The authoritative I02 validator is copied unchanged under `src/i02_accepted/`.
