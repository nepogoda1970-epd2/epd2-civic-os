# F_final

Computed with unchanged I01 domain `epd2.pb01.f-final.v1` over canonical FinalSetEnvelope bytes. It commits the authorized final encrypted set; it is not a tally or decryption capability.
