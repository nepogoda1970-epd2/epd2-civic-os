# I06 AuthorizedEncryptedTally Contract — Handoff Only

I05 defines, but does not implement I06. Schema `epd2.pb01.authorized-encrypted-tally/1` carries only `election_instance_id`, profile, tally function, `f_final`, tally record digest, exact aggregate ciphertext/bytes digest, and semantic claim. Future guardian/decryption code must resolve this authoritative I05 state and must not accept arbitrary aggregates. No guardian ceremony, shares, decryption, or plaintext result exists here.
