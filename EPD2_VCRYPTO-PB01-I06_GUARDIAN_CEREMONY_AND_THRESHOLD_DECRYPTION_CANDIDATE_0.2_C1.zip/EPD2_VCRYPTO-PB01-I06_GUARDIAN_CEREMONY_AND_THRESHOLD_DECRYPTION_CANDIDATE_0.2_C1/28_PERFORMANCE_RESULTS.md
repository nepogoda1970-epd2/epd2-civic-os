# Performance results

Representative 100/1,000/10,000-submission deterministic composition samples are in `evidence/results/i04-performance.json`; PostgreSQL transactional timings are captured in the test TAP/evidence. The resolver is O(n log n) from per-lifecycle ordering and canonical digest sorting, with no quadratic scan.
