# Exact Ballot Byte Resolution

For each canonical I04 digest, I05 resolves the exact immutable I03 `encrypted_ballot_bytes`. It verifies reference order, raw SHA-256, the governed exact-byte domain digest, byte length, and the PB01 ballot digest computed directly from those bytes. No parse/reserialize substitution is used before native verification or aggregation. Missing bytes fail the whole tally.
