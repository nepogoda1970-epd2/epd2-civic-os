# Tally API

`POST /v1/elections/{id}/tally` accepts no request body. Production requires a configured operation bearer token; the token authorizes execution only, never input selection. Response contains election ID, `f_final`, tally record digest, aggregate digest and replay flag. `GET /v1/elections/{id}/tally-evidence` exports public encrypted evidence.
