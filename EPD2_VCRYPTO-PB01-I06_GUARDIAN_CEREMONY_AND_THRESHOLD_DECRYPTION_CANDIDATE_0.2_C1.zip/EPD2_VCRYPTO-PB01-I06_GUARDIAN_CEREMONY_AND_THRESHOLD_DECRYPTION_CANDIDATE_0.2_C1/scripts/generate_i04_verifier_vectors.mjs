import { createHash, createPrivateKey, createPublicKey } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  buildAcceptedManifestAtCheckpoint,
  buildClosureCheckpoint,
  buildFinalArtifacts,
  resolveLatestValid,
} from "../src/i04/finalization.mjs";
import { buildClosureAuthorizationStatement, issueClosureAuthorization } from "../src/i04/closure_authority.mjs";
import { verifyI04PublicEvidence, verifierBCanonicalize } from "../verifier/i04_verifier_b.mjs";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const output = join(root, "test-vectors/i04-verifier-b");
await mkdir(output, { recursive: true });
const privateKey = createPrivateKey({
  key: {
    kty: "OKP",
    crv: "Ed25519",
    d: "nWEgI_aB8f5fC0Dvc1J0A6qHhJ7FZjS7d2H4sGyWf2A",
    x: "11qYAYdk9Jtu6g7u5z_4bW7pqa_nu57E-XZ-qa9qGEo",
  },
  format: "jwk",
});
const publicKey = createPublicKey(privateKey);
const election = {
  election_instance_id: "ei1_0123456789abcdef0123456789abcdef",
  crypto_profile: "epd2.belenios-homomorphic/1",
  tally_function_id: "epd2.pb01.tally.single-choice.v1",
  belenios_election_uuid: "123456789ABCDEFG",
  belenios_election_hash: "A".repeat(43),
};
const closedAt = "2026-08-17T22:15:00Z";

function hex(value) {
  return createHash("sha256").update(value).digest("hex");
}

function row(index, lifecycle) {
  return {
    submission_id: `${String(index).padStart(8, "0")}-0000-4000-8000-${String(index).padStart(12, "0")}`,
    ballot_digest: hex(`i04-vector-ballot-${index}`),
    ledger_seq: String(index),
    event_hash: hex(`i04-vector-event-${index}`),
    accepted_at: closedAt,
    lifecycle_handle: hex(`i04-vector-lifecycle-${lifecycle}`),
    lifecycle_election_instance_id: election.election_instance_id,
  };
}

const cases = {
  "one-lifecycle-one-ballot": [row(1, 1)],
  "one-lifecycle-two-revotes": [row(1, 1), row(2, 1)],
  "three-lifecycles-mixed-revotes": [row(1, 1), row(2, 1), row(3, 2), row(4, 3), row(5, 3), row(6, 3)],
  "empty-final-set": [],
};
const index = { schema_version: "epd2.pb01.i04-verifier-b-vector-index/1", key_id: "rfc8032-test-vector-key", public_jwk: publicKey.export({ format: "jwk" }), cases: [] };
for (const [name, ledgerRows] of Object.entries(cases)) {
  const acceptedManifest = buildAcceptedManifestAtCheckpoint({ election, ledgerRows, checkpointTime: closedAt });
  const { checkpoint } = buildClosureCheckpoint({ electionInstanceId: election.election_instance_id, acceptedManifest });
  const statement = buildClosureAuthorizationStatement({ electionInstanceId: election.election_instance_id, checkpoint, closedAt });
  const authorizationEvidence = issueClosureAuthorization({ statement, privateKey, keyId: index.key_id });
  const resolutionRecords = resolveLatestValid({ electionInstanceId: election.election_instance_id, rows: ledgerRows, resolvedAt: closedAt });
  const artifacts = buildFinalArtifacts({ election, acceptedManifest, authorizationEvidence, resolutionRecords });
  const verifier = verifyI04PublicEvidence(artifacts.publicEvidence, { closurePublicKeys: new Map([[index.key_id, publicKey]]) });
  const vector = {
    schema_version: "epd2.pb01.i04-verifier-b-vector/1",
    case: name,
    public_evidence: artifacts.publicEvidence,
    producer_canonical_public_evidence_utf8_base64url: Buffer.from(verifierBCanonicalize(artifacts.publicEvidence), "utf8").toString("base64url"),
    producer_result: { cset_root: artifacts.csetRoot, f_final: artifacts.fFinal, public_evidence_digest: artifacts.publicEvidenceDigest },
    verifier_b_result: verifier,
  };
  await writeFile(join(output, `${name}.json`), `${verifierBCanonicalize(vector)}\n`);
  index.cases.push({ name, file: `${name}.json`, effective_ballot_count: verifier.effective_ballot_count, f_final: verifier.f_final });
}
await writeFile(join(output, "index.json"), `${verifierBCanonicalize(index)}\n`);
process.stdout.write(`${JSON.stringify(index, null, 2)}\n`);
