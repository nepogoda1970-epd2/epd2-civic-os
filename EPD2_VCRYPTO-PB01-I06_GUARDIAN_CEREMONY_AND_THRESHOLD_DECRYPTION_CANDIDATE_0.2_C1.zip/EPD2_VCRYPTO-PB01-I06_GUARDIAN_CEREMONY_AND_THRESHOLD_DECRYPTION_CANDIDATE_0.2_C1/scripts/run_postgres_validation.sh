#!/usr/bin/env bash
set -euo pipefail

candidate_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
pg_bin="${EPD2_I03_PG_BIN:?set EPD2_I03_PG_BIN to a PostgreSQL 16.10 bin directory}"
work_root="$(mktemp -d "${TMPDIR:-/tmp}/epd2-i03-postgres.XXXXXX")"
pg_data="$work_root/data"
port="${EPD2_I03_PG_TEST_PORT:-55432}"
superuser="$(id -un)"

cleanup() {
  if [[ -n "${postgres_pid:-}" ]]; then
    kill -TERM "$postgres_pid" 2>/dev/null || true
    wait "$postgres_pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

"$pg_bin/initdb" -D "$pg_data" --no-locale --encoding=UTF8 --auth-local=trust --auth-host=trust > "$work_root/initdb.log"
"$pg_bin/postgres" -D "$pg_data" \
  -c listen_addresses=127.0.0.1 \
  -c port="$port" \
  -c unix_socket_directories='' \
  -c fsync=on \
  -c synchronous_commit=on \
  -c full_page_writes=on > "$work_root/postgres.log" 2>&1 &
postgres_pid=$!

for _ in $(seq 1 100); do
  if "$pg_bin/pg_isready" -h 127.0.0.1 -p "$port" -U "$superuser" >/dev/null 2>&1; then break; fi
  sleep 0.1
done

"$pg_bin/createdb" -h 127.0.0.1 -p "$port" -U "$superuser" epd2_i03_test
"$pg_bin/psql" -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$superuser" -d epd2_i03_test \
  -f "$candidate_root/migrations/postgresql/001_i03_submission_ledger.sql" >/dev/null
"$pg_bin/psql" -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$superuser" -d epd2_i03_test \
  -f "$candidate_root/migrations/postgresql/002_i03_roles.sql" >/dev/null
"$pg_bin/psql" -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$superuser" -d epd2_i03_test <<'SQL' >/dev/null
CREATE ROLE epd2_i03_runtime_test LOGIN PASSWORD 'runtime-test-only' IN ROLE epd2_pb01_submission_runtime;
CREATE ROLE epd2_i03_evidence_test LOGIN PASSWORD 'evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
SQL

export EPD2_I03_PG_ADMIN_URL="postgresql://$superuser@127.0.0.1:$port/epd2_i03_test"
export EPD2_I03_PG_RUNTIME_URL="postgresql://epd2_i03_runtime_test:runtime-test-only@127.0.0.1:$port/epd2_i03_test"
export EPD2_I03_PG_EVIDENCE_URL="postgresql://epd2_i03_evidence_test:evidence-test-only@127.0.0.1:$port/epd2_i03_test"
export EPD2_I03_PG_PORT="$port"
export EPD2_I03_PG_DUMP_PATH="$pg_bin/pg_dump"
export EPD2_I03_PG_RESTORE_PATH="$pg_bin/pg_restore"
export EPD2_I03_PG_CREATEDB_PATH="$pg_bin/createdb"
export EPD2_I03_PG_DROPDB_PATH="$pg_bin/dropdb"

cd "$candidate_root"
node --test --test-concurrency=1 \
  tests/postgres.integration.test.mjs \
  tests/postgres-crash-concurrency.test.mjs \
  tests/postgres-tamper-backup-roles.test.mjs
