import { resolve } from "node:path";
import { SqliteSubmissionStore } from "../src/i03/sqlite_store.mjs";

const databasePath = process.argv[2];
if (!databasePath) throw new Error("usage: node scripts/migrate_sqlite.mjs DATABASE_PATH");
const store = new SqliteSubmissionStore(resolve(databasePath));
try {
  store.migrate();
  process.stdout.write("I03 SQLite migration 001 applied\n");
} finally {
  store.close();
}
