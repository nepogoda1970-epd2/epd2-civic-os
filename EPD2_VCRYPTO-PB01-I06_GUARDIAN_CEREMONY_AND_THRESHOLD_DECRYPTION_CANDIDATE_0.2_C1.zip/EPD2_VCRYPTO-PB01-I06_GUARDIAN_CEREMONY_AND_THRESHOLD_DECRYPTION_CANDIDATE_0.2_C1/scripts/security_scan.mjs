import { readFile, readdir, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const roots = ["src/i03", "server", "client/app.mjs", "migrations"];

async function files(path) {
  const stat = await (await import("node:fs/promises")).stat(path);
  if (stat.isFile()) return [path];
  const result = [];
  for (const entry of await readdir(path, { withFileTypes: true })) {
    const child = join(path, entry.name);
    if (entry.isDirectory()) result.push(...await files(child));
    else result.push(child);
  }
  return result;
}

const scans = [
  { id: "PRIVATE_KEY", regex: /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/u },
  { id: "AWS_ACCESS_KEY", regex: /AKIA[0-9A-Z]{16}/u },
  { id: "JWT_LITERAL", regex: /eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}/u },
  { id: "PROHIBITED_ROUTE", regex: /\/(?:decrypt|tally|guardian|close-election)(?:\/|["'`])/iu },
  { id: "PLAINTEXT_COLUMN", regex: /(?:plaintext_vote|selected_choice|member_email|universal_user_id)/iu },
];
const findings = [];
for (const relative of roots) {
  for (const path of await files(join(root, relative))) {
    const text = await readFile(path, "utf8");
    for (const scan of scans) if (scan.regex.test(text)) findings.push({ id: scan.id, path: path.slice(root.length + 1) });
  }
}
const result = {
  status: findings.length === 0 ? "PASS" : "FAIL",
  scope: roots,
  findings,
  production_secrets_embedded: false,
  decrypt_tally_guardian_routes: false,
};
await writeFile(join(root, "evidence/results/security-scan.json"), `${JSON.stringify(result, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
if (findings.length) process.exitCode = 1;
