import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { BeleniosThresholdAdapter } from '../src/i06/belenios_threshold.mjs';
import { buildGuardianCeremonyRecord, buildShareArtifact, buildThresholdDecryptionRecord } from '../src/i06/records.mjs';
import { aggregateCiphertextDigest } from '../src/i05/hashes.mjs';

const here=dirname(fileURLToPath(import.meta.url));
const root=resolve(here,'..');
const tool=join(root,'evidence/build/belenios-tool-3.3.0-linux-x86_64');
const template=join(root,'evidence/fixtures/i06-election-n3t2/template.json');
const adapter=new BeleniosThresholdAdapter({toolPath:tool,templatePath:template});
const defs=[
 {id:'I06-V01',fixture:'n3-t2',eid:'ei1_66666666666666666666666666666666',selected:[1,2],accepted:[1,2],description:'N=3 T=2 exact threshold 2/3'},
 {id:'I06-V02',fixture:'n5-t3',eid:'ei1_77777777777777777777777777777777',selected:[1,2,3],accepted:[1,2,3],description:'N=5 T=3 exact threshold 3/5'},
 {id:'I06-V03',fixture:'n5-t3',eid:'ei1_77777777777777777777777777777777',selected:[1,2,3],accepted:[1,2,3,4,5],description:'N=5 T=3 all five valid shares; plaintext invariant'},
 {id:'I06-V04',fixture:'n3-t2-empty',eid:'ei1_88888888888888888888888888888888',selected:[1,2],accepted:[1,2],description:'N=3 T=2 empty authorized final set identity tally'},
];
function h(label,value){return createHash('sha256').update(label).update(Buffer.from([0])).update(value).digest('hex');}
function firstLine(b){const i=b.indexOf(10);return i<0?b:b.subarray(0,i);}
await mkdir(join(root,'test-vectors/i06/vectors'),{recursive:true});
const index={schema_version:'epd2.pb01.i06-vector-index/1',vectors:[]};
for(const d of defs){
 const dir=join(root,'test-vectors/i06/fixtures',d.fixture);
 const uuid=(await readFile(join(dir,'UUID.txt'),'utf8')).trim();
 const thresholdBytes=await readFile(join(dir,'threshold.json'));
 const trusteesBytes=await readFile(join(dir,'trustees.public.json'));
 const electionBytes=await readFile(join(dir,'election.public.json'));
 const upstream=await adapter.verifyCeremony({thresholdBytes,trusteesBytes,electionBytes,electionUuid:uuid});
 const ceremony=buildGuardianCeremonyRecord({electionInstanceId:d.eid,beleniosElectionUuid:uuid,guardianPublicKeys:upstream.guardian_public_keys,threshold:upstream.threshold,electionPublicKey:upstream.election_public_key,trusteesBytes,electionBytes});
 const tallyOut=await readFile(join(dir,'encrypted_tally.out')); const aggregate=firstLine(tallyOut);
 const tally={
   schema_version:'epd2.pb01.i06-frozen-i05-tally-reference/1',election_instance_id:d.eid,
   f_final:h('epd2.i06.vector.f-final',Buffer.from(`${d.fixture}:${uuid}`)),
   tally_record_digest:h('epd2.i06.vector.i05-record',Buffer.from(`${d.fixture}:${uuid}`)),
   aggregate_ciphertext_digest:aggregateCiphertextDigest(aggregate),
   aggregate_ciphertext_bytes:aggregate,
 };
 const allShares=[];
 for(let i=1;i<=upstream.guardian_count;i++){
   const raw=await readFile(join(dir,`share-${i}.json`));
   allShares.push(buildShareArtifact({ceremony,tally,guardianIndex:i,shareBytes:raw}));
 }
 const selected=d.selected.map(i=>({guardian_index:i,share_bytes:Buffer.from(allShares[i-1].belenios_partial_decryption_base64url,'base64url')}));
 const verified=await adapter.computeVerifiedResult({baseArchivePath:join(dir,'decryption-base.bel'),shares:selected});
 const record=buildThresholdDecryptionRecord({ceremony,tally,thresholdShares:d.selected.map(i=>allShares[i-1]),plaintextBytes:verified.plaintext_bytes});
 if(d.id==='I06-V03'){
   const all=await adapter.computeVerifiedResult({baseArchivePath:join(dir,'decryption-base.bel'),shares:d.accepted.map(i=>({guardian_index:i,share_bytes:Buffer.from(allShares[i-1].belenios_partial_decryption_base64url,'base64url')}))});
   const alt=await adapter.computeVerifiedResult({baseArchivePath:join(dir,'decryption-base.bel'),shares:[3,4,5].map(i=>({guardian_index:i,share_bytes:Buffer.from(allShares[i-1].belenios_partial_decryption_base64url,'base64url')}))});
   if(!all.plaintext_bytes.equals(verified.plaintext_bytes)||!alt.plaintext_bytes.equals(verified.plaintext_bytes))throw new Error('threshold subset plaintext mismatch');
 }
 const vector={
   schema_version:'epd2.pb01.i06-vector/1',vector_id:d.id,description:d.description,fixture:d.fixture,
   public_fixture_paths:{threshold_json:`test-vectors/i06/fixtures/${d.fixture}/threshold.json`,trustees_json:`test-vectors/i06/fixtures/${d.fixture}/trustees.public.json`,election_json:`test-vectors/i06/fixtures/${d.fixture}/election.public.json`,decryption_base_archive:`test-vectors/i06/fixtures/${d.fixture}/decryption-base.bel`},
   i05_authorized_tally_reference:{...tally,aggregate_ciphertext_bytes:undefined,aggregate_ciphertext_base64url:aggregate.toString('base64url')},
   guardian_ceremony_record:ceremony,
   partial_decryption_shares:allShares,
   threshold_forming_guardian_indices:d.selected.map(String),accepted_guardian_indices:d.accepted.map(String),
   threshold_decryption_record:record,
   expected:{guardian_ceremony_digest:ceremony.guardian_ceremony_digest,aggregate_ciphertext_digest:tally.aggregate_ciphertext_digest,share_digests:allShares.map(x=>x.share_digest),plaintext_tally_digest:record.plaintext_tally_digest,decryption_record_digest:record.decryption_record_digest,plaintext_tally:record.plaintext_tally},
 };
 const out=join(root,'test-vectors/i06/vectors',`${d.id}.json`); await writeFile(out,JSON.stringify(vector,null,2)+'\n');
 index.vectors.push({vector_id:d.id,path:`test-vectors/i06/vectors/${d.id}.json`,fixture:d.fixture});
}
await writeFile(join(root,'test-vectors/i06/index.json'),JSON.stringify(index,null,2)+'\n');
console.log(JSON.stringify({vectors:index.vectors.length,status:'PASS'}));
