import { readdir, readFile, writeFile } from "node:fs/promises";
import { dirname, extname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

async function files(directory) {
  const output = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (["node_modules", "vendor", ".git"].includes(entry.name)) continue;
    const path = join(directory, entry.name);
    if (entry.isDirectory()) output.push(...await files(path));
    else output.push(path);
  }
  return output;
}

const codeFiles = (await files(root)).filter((path) => [".mjs", ".js", ".sql", ".json", ".sh"].includes(extname(path)));
const findings = [];
for (const path of codeFiles) {
  const relative = path.slice(root.length + 1);
  if (relative.startsWith("evidence/predecessors/") || relative.startsWith("test-vectors/")) continue;
  const text = await readFile(path, "utf8");
  for (const [name, pattern] of [
    ["private-key-pem", /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/u],
    ["cloud-secret", /(?:AKIA|ASIA)[A-Z0-9]{16}/u],
    ["generic-secret-assignment", /(?:password|secret|api[_-]?key)\s*[:=]\s*["'][^"']{20,}["']/iu],
  ]) if (pattern.test(text)) findings.push({ relative, name });
}

const i04Source = await Promise.all([
  ...await files(join(root, "src/i04")),
  join(root, "server/i04-finalizer.mjs"),
].map((path) => readFile(path, "utf8")));
const routeCorpus = i04Source.join("\n");
const prohibitedRoutes = [...routeCorpus.matchAll(/\/v1\/[^\s"'`]*(?:decrypt|guardian|tally|result)[^\s"'`]*/giu)].map((match) => match[0]);
const migration = await readFile(join(root, "migrations/postgresql/004_i04_roles.sql"), "utf8");
const privilegeChecks = {
  submission_i04_revoke: /REVOKE ALL ON ALL TABLES IN SCHEMA pb01_i04 FROM epd2_pb01_submission_runtime/u.test(migration),
  finalizer_i03_destructive_revoke: /REVOKE UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA pb01_i03, pb01_i04/u.test(migration),
  evidence_mutation_absent: !/GRANT\s+(?:INSERT|UPDATE|DELETE|TRUNCATE)[^;]*epd2_pb01_evidence_reader/iu.test(migration),
  runtime_ddl_revoke: /REVOKE CREATE ON SCHEMA pb01_i03, pb01_i04, public/u.test(migration),
};
const result = {
  status: findings.length === 0 && prohibitedRoutes.length === 0 && Object.values(privilegeChecks).every(Boolean) ? "PASS" : "FAIL",
  scanned_code_files: String(codeFiles.length),
  secret_findings: findings,
  prohibited_i04_routes: prohibitedRoutes,
  migration_privilege_review: privilegeChecks,
  public_lifecycle_leakage_test: "PASS_BY_i04-tamper-backup-roles_and_i04-finalization.integration",
  dependency_mode: "PINNED_LOCAL_ARCHIVES_NO_RUNTIME_REGISTRY_RESOLUTION",
  belenios_profile_change: "NONE",
};
await writeFile(join(root, "evidence/results/i04-security-scan.json"), `${JSON.stringify(result, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
if (result.status !== "PASS") process.exitCode = 1;
