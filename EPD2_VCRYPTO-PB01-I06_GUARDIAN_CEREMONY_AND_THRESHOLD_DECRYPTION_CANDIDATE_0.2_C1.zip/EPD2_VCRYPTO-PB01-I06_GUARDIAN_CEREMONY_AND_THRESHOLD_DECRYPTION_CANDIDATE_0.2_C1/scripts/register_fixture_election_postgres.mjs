import { resolve } from "node:path";
import { PostgresSubmissionStore } from "../src/i03/postgres_store.mjs";
import { loadFixture } from "../src/i02_accepted/shared/load_fixture.mjs";

const candidateRoot = resolve(import.meta.dirname, "..");
const connectionString = process.env.EPD2_I03_POSTGRES_ELECTION_SETUP_URL;
if (!connectionString) throw new Error("EPD2_I03_POSTGRES_ELECTION_SETUP_URL is required");
const names = process.argv.slice(2);
if (names.length === 0) throw new Error("provide one or more fixture names");

const store = new PostgresSubmissionStore({ connectionString, max: 2, application_name: "epd2-pb01-i03-election-setup" });
try {
  for (const name of names) {
    const fixture = await loadFixture(candidateRoot, name);
    await store.registerElection(fixture.context);
    process.stdout.write(`${fixture.context.election_instance_id}\n`);
  }
} finally {
  await store.close();
}
