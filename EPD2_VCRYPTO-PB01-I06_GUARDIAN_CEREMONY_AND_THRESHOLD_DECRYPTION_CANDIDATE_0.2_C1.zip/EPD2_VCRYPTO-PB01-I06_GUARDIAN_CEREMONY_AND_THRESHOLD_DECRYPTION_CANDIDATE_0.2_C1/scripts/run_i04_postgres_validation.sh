#!/usr/bin/env bash
set -euo pipefail

candidate_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
pg_bin="${EPD2_I04_PG_BIN:?set EPD2_I04_PG_BIN to the PostgreSQL 16.10 bin directory}"
port="${EPD2_I04_PG_TEST_PORT:-55434}"

if [[ "$(id -u)" == "0" ]]; then
  pg_user="$(id -un)"
  as_pg=()
  export EPD2_PG_TEST_ALLOW_ROOT=1
  work_root="$(mktemp -d "${TMPDIR:-/tmp}/epd2-i04-postgres.XXXXXX")"
else
  pg_user="$(id -un)"
  as_pg=()
  work_root="$(mktemp -d "${TMPDIR:-/tmp}/epd2-i04-postgres.XXXXXX")"
fi
pg_data="$work_root/data"

cleanup() {
  if [[ -n "${postgres_pid:-}" ]]; then
    kill -TERM "$postgres_pid" 2>/dev/null || true
    wait "$postgres_pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

"${as_pg[@]}" "$pg_bin/initdb" -D "$pg_data" --no-locale --encoding=UTF8 --auth-local=trust --auth-host=trust > "$work_root/initdb.log"
"${as_pg[@]}" "$pg_bin/postgres" -D "$pg_data" \
  -c listen_addresses=127.0.0.1 \
  -c port="$port" \
  -c unix_socket_directories='' \
  -c fsync=on \
  -c synchronous_commit=on \
  -c full_page_writes=on > "$work_root/postgres.log" 2>&1 &
postgres_pid=$!

for _ in $(seq 1 200); do
  if "$pg_bin/pg_isready" -h 127.0.0.1 -p "$port" -U "$pg_user" >/dev/null 2>&1; then break; fi
  sleep 0.1
done

"$pg_bin/createdb" -h 127.0.0.1 -p "$port" -U "$pg_user" epd2_i04_test
"$pg_bin/psql" -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i04_test \
  -f "$candidate_root/migrations/postgresql/001_i03_submission_ledger.sql" >/dev/null
"$pg_bin/psql" -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i04_test \
  -f "$candidate_root/migrations/postgresql/002_i03_roles.sql" >/dev/null
"$pg_bin/psql" -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i04_test \
  -f "$candidate_root/migrations/postgresql/003_i04_finalization.sql" >/dev/null
"$pg_bin/psql" -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i04_test \
  -f "$candidate_root/migrations/postgresql/004_i04_roles.sql" >/dev/null
"$pg_bin/psql" -X -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i04_test <<'SQL' >/dev/null
CREATE ROLE epd2_i03_runtime_test LOGIN PASSWORD 'runtime-test-only' IN ROLE epd2_pb01_submission_runtime;
CREATE ROLE epd2_i03_evidence_test LOGIN PASSWORD 'evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
CREATE ROLE epd2_i04_finalizer_test LOGIN PASSWORD 'finalizer-test-only' IN ROLE epd2_pb01_finalization_runtime;
CREATE ROLE epd2_i04_evidence_test LOGIN PASSWORD 'i04-evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
SQL

export EPD2_I03_PG_ADMIN_URL="postgresql://$pg_user@127.0.0.1:$port/epd2_i04_test"
export EPD2_I03_PG_RUNTIME_URL="postgresql://epd2_i03_runtime_test:runtime-test-only@127.0.0.1:$port/epd2_i04_test"
export EPD2_I03_PG_EVIDENCE_URL="postgresql://epd2_i03_evidence_test:evidence-test-only@127.0.0.1:$port/epd2_i04_test"
export EPD2_I04_PG_FINALIZER_URL="postgresql://epd2_i04_finalizer_test:finalizer-test-only@127.0.0.1:$port/epd2_i04_test"
export EPD2_I04_PG_EVIDENCE_URL="postgresql://epd2_i04_evidence_test:i04-evidence-test-only@127.0.0.1:$port/epd2_i04_test"
export EPD2_I03_PG_PORT="$port"
export EPD2_I03_PG_DUMP_PATH="$pg_bin/pg_dump"
export EPD2_I03_PG_RESTORE_PATH="$pg_bin/pg_restore"
export EPD2_I03_PG_CREATEDB_PATH="$pg_bin/createdb"
export EPD2_I03_PG_DROPDB_PATH="$pg_bin/dropdb"

cd "$candidate_root"
node --test --test-concurrency=1 \
  tests/i04-policy.unit.test.mjs \
  tests/i04-finalization.integration.test.mjs \
  tests/i04-concurrency-crash.test.mjs \
  tests/i04-tamper-backup-roles.test.mjs
