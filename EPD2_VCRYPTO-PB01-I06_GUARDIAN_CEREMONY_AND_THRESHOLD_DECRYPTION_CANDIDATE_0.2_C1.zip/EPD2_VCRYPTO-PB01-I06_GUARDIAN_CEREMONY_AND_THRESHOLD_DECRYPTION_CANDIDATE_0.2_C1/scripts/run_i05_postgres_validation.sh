#!/usr/bin/env bash
# PB01-I05 PostgreSQL production-runtime acceptance harness.
# Usage: EPD2_I05_PG_BIN=/path/to/postgresql-16/bin bash scripts/run_i05_postgres_validation.sh
# Must be run as a non-root user (initdb refuses to run as root).
set -euo pipefail

candidate_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
pg_bin="${EPD2_I05_PG_BIN:?set EPD2_I05_PG_BIN to the PostgreSQL 16.x bin directory}"
port="${EPD2_I05_PG_TEST_PORT:-55435}"
pg_user="$(id -un)"
work_root="$(mktemp -d "${TMPDIR:-/tmp}/epd2-i05-postgres.XXXXXX")"
pg_data="$work_root/data"
start_options="-c listen_addresses=127.0.0.1 -c port=$port -c unix_socket_directories='' -c fsync=on -c synchronous_commit=on -c full_page_writes=on"

cleanup() {
  "$pg_bin/pg_ctl" -D "$pg_data" -m immediate stop >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

"$pg_bin/initdb" -D "$pg_data" --no-locale --encoding=UTF8 --auth-local=trust --auth-host=trust > "$work_root/initdb.log"
"$pg_bin/pg_ctl" -D "$pg_data" -o "$start_options" -l "$work_root/postgres.log" -w start
"$pg_bin/pg_isready" -h 127.0.0.1 -p "$port" -U "$pg_user"

"$pg_bin/createdb" -h 127.0.0.1 -p "$port" -U "$pg_user" epd2_i05_test
for migration in 001_i03_submission_ledger 002_i03_roles 003_i04_finalization 004_i04_roles 005_i05_tally 006_i05_roles; do
  "$pg_bin/psql" -X -q -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i05_test \
    -f "$candidate_root/migrations/postgresql/$migration.sql" >/dev/null
  echo "applied $migration.sql"
done

"$pg_bin/psql" -X -q -v ON_ERROR_STOP=1 -h 127.0.0.1 -p "$port" -U "$pg_user" -d epd2_i05_test >/dev/null <<'SQL'
CREATE ROLE epd2_i03_runtime_test LOGIN PASSWORD 'runtime-test-only' IN ROLE epd2_pb01_submission_runtime;
CREATE ROLE epd2_i03_evidence_test LOGIN PASSWORD 'evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
CREATE ROLE epd2_i04_finalizer_test LOGIN PASSWORD 'finalizer-test-only' IN ROLE epd2_pb01_finalization_runtime;
CREATE ROLE epd2_i04_evidence_test LOGIN PASSWORD 'i04-evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
CREATE ROLE epd2_i05_tally_test LOGIN PASSWORD 'tally-test-only' IN ROLE epd2_pb01_tally_runtime;
CREATE ROLE epd2_i05_evidence_test LOGIN PASSWORD 'i05-evidence-test-only' IN ROLE epd2_pb01_evidence_reader;
SQL

export EPD2_I03_PG_ADMIN_URL="postgresql://$pg_user@127.0.0.1:$port/epd2_i05_test"
export EPD2_I03_PG_RUNTIME_URL="postgresql://epd2_i03_runtime_test:runtime-test-only@127.0.0.1:$port/epd2_i05_test"
export EPD2_I03_PG_EVIDENCE_URL="postgresql://epd2_i03_evidence_test:evidence-test-only@127.0.0.1:$port/epd2_i05_test"
export EPD2_I04_PG_FINALIZER_URL="postgresql://epd2_i04_finalizer_test:finalizer-test-only@127.0.0.1:$port/epd2_i05_test"
export EPD2_I04_PG_EVIDENCE_URL="postgresql://epd2_i04_evidence_test:i04-evidence-test-only@127.0.0.1:$port/epd2_i05_test"
export EPD2_I05_PG_TALLY_URL="postgresql://epd2_i05_tally_test:tally-test-only@127.0.0.1:$port/epd2_i05_test"
export EPD2_I05_PG_EVIDENCE_URL="postgresql://epd2_i05_evidence_test:i05-evidence-test-only@127.0.0.1:$port/epd2_i05_test"
export EPD2_I03_PG_PORT="$port"
export EPD2_I03_PG_DUMP_PATH="$pg_bin/pg_dump"
export EPD2_I03_PG_RESTORE_PATH="$pg_bin/pg_restore"
export EPD2_I03_PG_CREATEDB_PATH="$pg_bin/createdb"
export EPD2_I03_PG_DROPDB_PATH="$pg_bin/dropdb"
export EPD2_I05_PG_CTL_PATH="$pg_bin/pg_ctl"
export EPD2_I05_PG_DATA_DIR="$pg_data"
export EPD2_I05_PG_START_OPTIONS="$start_options"

cd "$candidate_root"
node --test --test-concurrency=1 \
  tests/i05-postgres.integration.test.mjs \
  tests/i05-postgres-runtime.test.mjs \
  tests/i05-postgres-crash-restart.test.mjs \
  tests/i05-postgres-tamper-backup-roles.test.mjs
