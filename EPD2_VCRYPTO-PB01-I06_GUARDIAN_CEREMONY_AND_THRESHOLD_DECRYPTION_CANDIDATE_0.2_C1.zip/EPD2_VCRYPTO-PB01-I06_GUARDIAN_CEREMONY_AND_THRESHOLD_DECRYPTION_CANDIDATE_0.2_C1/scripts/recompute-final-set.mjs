import { createPublicKey } from "node:crypto";
import { readFile } from "node:fs/promises";
import { ClosureAuthorizationVerifier } from "../src/i04/closure_authority.mjs";
import { PostgresFinalizationStore } from "../src/i04/postgres_finalization_store.mjs";

const electionInstanceId = process.argv[2];
if (!/^ei1_[0-9a-f]{32}$/u.test(electionInstanceId ?? "")) throw new Error("usage: recompute-final-set.mjs <ElectionInstanceId>");
const connectionString = process.env.EPD2_I04_POSTGRES_URL;
if (!connectionString) throw new Error("EPD2_I04_POSTGRES_URL is required");
const keyId = process.env.EPD2_I04_CLOSURE_KEY_ID;
const keyPath = process.env.EPD2_I04_CLOSURE_PUBLIC_KEY_PATH;
if (!keyId || !keyPath) throw new Error("closure public key configuration required");
const publicKey = createPublicKey(await readFile(keyPath));
const verifier = new ClosureAuthorizationVerifier(new Map([[keyId, publicKey]]));
const store = new PostgresFinalizationStore({ connectionString, application_name: "epd2-pb01-i04-recompute" });
try {
  const result = await store.recompute(electionInstanceId, { authorizationVerifier: verifier });
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
} finally {
  await store.close();
}

