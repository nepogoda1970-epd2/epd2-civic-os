import { createHash } from "node:crypto";
import { readdir, readFile, stat, writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const base = process.env.EPD2_I03_BASE_DIR;
if (!base) throw new Error("EPD2_I03_BASE_DIR required");
const protectedPaths = [
  "src/i01_reference",
  "src/i02_accepted",
  "src/i03",
  "client",
  "server/i03-receiver.mjs",
  "schemas/i02-client-integration.cddl",
  "schemas/i02-client-integration.schema.json",
  "schemas/i03-encrypted-submission.schema.json",
  "schemas/i03-public-evidence.schema.json",
  "schemas/i03.cddl",
  "migrations/001_i03_sqlite.sql",
  "migrations/postgresql/001_i03_submission_ledger.sql",
  "migrations/postgresql/002_i03_roles.sql",
  "test-vectors/i02-accepted",
  "test-vectors/real-i02",
  "evidence/build/belenios-tool-3.3.0-linux-x86_64",
];

async function walk(path) {
  const info = await stat(path);
  if (info.isFile()) return [path];
  const output = [];
  for (const entry of await readdir(path)) output.push(...await walk(join(path, entry)));
  return output;
}

function digest(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

const mismatches = [];
let compared = 0;
for (const protectedPath of protectedPaths) {
  const basePath = join(base, protectedPath);
  for (const source of await walk(basePath)) {
    const path = join(root, protectedPath, relative(basePath, source));
    try {
      const [expected, actual] = await Promise.all([readFile(source), readFile(path)]);
      compared += 1;
      if (digest(expected) !== digest(actual)) mismatches.push({ path: relative(root, path), expected_sha256: digest(expected), actual_sha256: digest(actual) });
    } catch (error) {
      mismatches.push({ path: relative(root, path), error: error.code ?? String(error) });
    }
  }
}
const result = {
  status: mismatches.length === 0 ? "PASS" : "FAIL",
  accepted_i03_package_sha256: "8034c48673fd0ddd7a2ee65651887ba6ad16d6efc3a1e0949e839ed7ca5ce84a",
  compared_protected_files: String(compared),
  mismatches,
  i01_i02_i03_semantic_changes: mismatches.length === 0 ? "NONE" : "DETECTED",
};
await writeFile(join(root, "evidence/results/i04-predecessor-preservation.json"), `${JSON.stringify(result, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
if (result.status !== "PASS") process.exitCode = 1;
