import { createHash, createPrivateKey, createPublicKey } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { ballotDigest, canonicalize } from "../src/i02_accepted/shared/profile.mjs";
import { buildAcceptedManifestAtCheckpoint, buildAuthorizedFinalBallotSet, buildClosureCheckpoint, buildFinalArtifacts, resolveLatestValid } from "../src/i04/finalization.mjs";
import { buildClosureAuthorizationStatement, issueClosureAuthorization } from "../src/i04/closure_authority.mjs";
import { BeleniosHomomorphicAggregator } from "../src/i05/belenios_aggregator.mjs";
import { buildTallyArtifacts } from "../src/i05/tally.mjs";
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const fixtureDir = join(root, "evidence/fixtures/i05-election");
const uuid = (await readFile(join(fixtureDir,"UUID.txt"),"utf8")).trim();
const context = JSON.parse(await readFile(join(fixtureDir,"context.json"),"utf8"));
const toolPath = join(root,"evidence/build/belenios-tool-3.3.0-linux-x86_64");
const archivePath = join(fixtureDir,`${uuid}.bel`);
const aggregator = new BeleniosHomomorphicAggregator({ toolPath, baseElectionArchivePath: archivePath });
const fixturePrivateJwk = process.env.EPD2_I05_FIXTURE_CLOSURE_PRIVATE_JWK;
if (!fixturePrivateJwk) throw new Error("EPD2_I05_FIXTURE_CLOSURE_PRIVATE_JWK required to regenerate signed test vectors");
const privateKey = createPrivateKey({key:JSON.parse(fixturePrivateJwk),format:"jwk"});
const publicKey = createPublicKey(privateKey);
const keyId="rfc8032-test-vector-key";
const closedAt="2026-08-18T00:30:00Z";
const election={election_instance_id:context.election_instance_id,crypto_profile:context.crypto_profile,tally_function_id:context.tally_function_id,belenios_election_uuid:context.belenios_election_uuid,belenios_election_hash:context.belenios_election_fingerprint,context_json:context,created_at:"2026-08-18T00:00:00Z"};
const names=["A1","A2","B1","C1","C2","C3","D1"];
const ballots=new Map();
for(const name of names){const bytes=await readFile(join(root,"test-vectors/i05/ballots",`${name}.json`)); const digest=ballotDigest(context,bytes.toString("base64url")); ballots.set(name,{name,bytes,digest});}
function h(x){return createHash("sha256").update(x).digest("hex");}
function row(name,seq,lifecycle){const b=ballots.get(name);return {submission_id:`${String(seq).padStart(8,"0")}-0000-4000-8000-${String(seq).padStart(12,"0")}`,ballot_digest:b.digest,ledger_seq:String(seq),event_hash:h(`i05-event-${name}-${seq}`),accepted_at:closedAt,lifecycle_handle:h(`i05-lifecycle-${lifecycle}`),lifecycle_election_instance_id:context.election_instance_id};}
const cases={
 "I05-V01-one-ballot":[row("A2",1,"A")],
 "I05-V02-three-independent-ballots":[row("A2",1,"A"),row("B1",2,"B"),row("C3",3,"C")],
 "I05-V03-revotes-effective-final-set":[row("A1",1,"A"),row("A2",2,"A"),row("B1",3,"B"),row("C1",4,"C"),row("C2",5,"C"),row("C3",6,"C")],
 "I05-V04-empty-final-set":[],
};
const index={schema_version:"epd2.pb01.i05-vector-index/1",key_id:keyId,closure_public_jwk:publicKey.export({format:"jwk"}),election_context:context,cases:[]};
for(const [caseName,ledgerRows] of Object.entries(cases)){
 const acceptedManifest=buildAcceptedManifestAtCheckpoint({election,ledgerRows,checkpointTime:closedAt});
 const {checkpoint}=buildClosureCheckpoint({electionInstanceId:context.election_instance_id,acceptedManifest});
 const statement=buildClosureAuthorizationStatement({electionInstanceId:context.election_instance_id,checkpoint,closedAt});
 const authorizationEvidence=issueClosureAuthorization({statement,privateKey,keyId});
 const resolutionRecords=resolveLatestValid({electionInstanceId:context.election_instance_id,rows:ledgerRows,resolvedAt:closedAt});
 const a=buildFinalArtifacts({election,acceptedManifest,authorizationEvidence,resolutionRecords});
 const finalization={accepted_manifest_at_closure:acceptedManifest,cset_final:a.csetFinal,cset_root:a.csetRoot,final_set_envelope:a.finalSetEnvelope,final_set_envelope_digest:a.finalSetEnvelopeDigest,f_final:a.fFinal,public_evidence:a.publicEvidence,public_evidence_digest:a.publicEvidenceDigest};
 const selected=new Map(resolutionRecords.map(r=>[r.effective_ballot_digest,r]));
 const exactRows=a.csetFinal.ordered_ballot_digests.map(d=>{const rec=selected.get(d);const source=ledgerRows.find(r=>r.submission_id===rec.effective_submission_id);const b=[...ballots.values()].find(x=>x.digest===d);return {submission_id:source.submission_id,ballot_digest:d,encrypted_ballot_bytes:b.bytes};});
 const authorizedSet=buildAuthorizedFinalBallotSet({election,finalization,exactRows});
 const orderedBytes=authorizedSet.ordered_ballot_digests.map(d=>exactRows.find(x=>x.ballot_digest===d).encrypted_ballot_bytes);
 for(const bytes of orderedBytes) await aggregator.verifyBallot({electionDir:fixtureDir,ballotBytes:bytes});
 const aggregate=await aggregator.aggregate({orderedBallotBytes:orderedBytes});
 const tally=buildTallyArtifacts({finalization,authorizedSet,aggregate});
 const vector={
  schema_version:"epd2.pb01.i05-real-tally-vector/1",case:caseName,election_context:context,
  i04_public_evidence:a.publicEvidence,authorized_final_ballot_set:authorizedSet,
  exact_ballots:authorizedSet.ordered_ballot_digests.map(d=>({ballot_digest:d,encrypted_ballot_base64url:exactRows.find(x=>x.ballot_digest===d).encrypted_ballot_bytes.toString("base64url")})),
  accepted_ballot_names:ledgerRows.map(r=>[...ballots.values()].find(x=>x.digest===r.ballot_digest)?.name ?? "unknown"),
  effective_ballot_names:authorizedSet.ordered_ballot_digests.map(d=>[...ballots.values()].find(x=>x.digest===d)?.name ?? "unknown"),
  expected_aggregate_ciphertext_base64url:aggregate.aggregateBytes.toString("base64url"),
  expected_aggregate_ciphertext_digest:tally.homomorphicTallyRecord.aggregate_ciphertext_digest,
  expected_tally_input_digest:tally.tallyInputDigest,
  expected_tally_record_digest:tally.tallyRecordDigest,
  expected_tally_evidence_digest:tally.tallyEvidenceDigest,
  tally_evidence_bundle:tally.tallyEvidenceBundle,
  authorized_encrypted_tally_i06_handoff:tally.authorizedEncryptedTally,
 };
 await writeFile(join(root,"test-vectors/i05/vectors",`${caseName}.json`),`${canonicalize(vector)}\n`);
 index.cases.push({case:caseName,file:`${caseName}.json`,ballot_count_decimal:String(orderedBytes.length),f_final:a.fFinal,tally_record_digest:tally.tallyRecordDigest,aggregate_ciphertext_digest:tally.homomorphicTallyRecord.aggregate_ciphertext_digest});
}
await writeFile(join(root,"test-vectors/i05/index.json"),`${canonicalize(index)}\n`);
const manifest={schema_version:"epd2.pb01.i05-ballot-digest-manifest/1",ballots:Object.fromEntries([...ballots].map(([n,b])=>[n,b.digest]))};
await writeFile(join(root,"test-vectors/i05/ballot-digests.json"),`${canonicalize(manifest)}\n`);
process.stdout.write(JSON.stringify(index,null,2)+"\n");
