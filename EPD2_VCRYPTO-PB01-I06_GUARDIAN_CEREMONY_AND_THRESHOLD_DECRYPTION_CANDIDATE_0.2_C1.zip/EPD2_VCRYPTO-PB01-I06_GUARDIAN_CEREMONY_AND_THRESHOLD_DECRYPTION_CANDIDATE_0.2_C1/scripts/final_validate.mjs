import { readFile, stat, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const required = [
  ...Array.from({ length: 29 }, (_, index) => `${String(index + 1).padStart(2, "0")}_`),
  "30_CHANGED_FILE_INVENTORY.csv",
  "31_OPEN_GAPS.md",
  "32_NEXT_GATE_RECOMMENDATION.md",
  "33_POSTGRESQL_PRODUCTION_STORAGE_CLOSURE.md",
  "src/i03/http_service.mjs",
  "src/i03/postgres_store.mjs",
  "src/i03/sqlite_store.mjs",
  "server/i03-receiver.mjs",
  "schemas/i03-encrypted-submission.schema.json",
  "migrations/001_i03_sqlite.sql",
  "migrations/postgresql/001_i03_submission_ledger.sql",
  "migrations/postgresql/002_i03_roles.sql",
  "tests/postgres.integration.test.mjs",
  "tests/postgres-crash-concurrency.test.mjs",
  "tests/postgres-tamper-backup-roles.test.mjs",
  "tests/browser-to-ledger.e2e.mjs",
  "evidence/results/browser-to-ledger-e2e.json",
  "evidence/results/node-tests.tap",
  "evidence/results/postgresql-tests.tap",
  "evidence/results/postgresql-dependency-audit.json",
  "evidence/results/i03-semantic-preservation.json",
  "evidence/postgresql/POSTGRESQL_SOURCE_PROVENANCE.json",
];
const rootEntries = await (await import("node:fs/promises")).readdir(root);
const missing = [];
for (const item of required) {
  if (item.endsWith("_")) {
    if (!rootEntries.some((entry) => entry.startsWith(item))) missing.push(item);
  } else {
    try { await stat(join(root, item)); } catch { missing.push(item); }
  }
}
const browser = JSON.parse(await readFile(join(root, "evidence/results/browser-to-ledger-e2e.json"), "utf8"));
const tap = await readFile(join(root, "evidence/results/node-tests.tap"), "utf8");
const pgTap = await readFile(join(root, "evidence/results/postgresql-tests.tap"), "utf8");
const security = JSON.parse(await readFile(join(root, "evidence/results/security-scan.json"), "utf8"));
const dependencyAudit = JSON.parse(await readFile(join(root, "evidence/results/postgresql-dependency-audit.json"), "utf8"));
const preservation = JSON.parse(await readFile(join(root, "evidence/results/i03-semantic-preservation.json"), "utf8"));
const receiver = await readFile(join(root, "server/i03-receiver.mjs"), "utf8");
const lock = JSON.parse(await readFile(join(root, "package-lock.json"), "utf8"));
const lockExternal = Object.values(lock.packages).some((pkg) => typeof pkg.resolved === "string" && !pkg.resolved.startsWith("file:"));
const outcome = "Outcome A — PB01-I03 ENCRYPTED BALLOT ACCEPTANCE AND SUBMISSION LEDGER ESTABLISHED";
const result = {
  outcome,
  required_artifacts: missing.length === 0 ? "PASS" : "FAIL",
  missing,
  real_i02_browser_ballot_accepted: browser.browser_to_ledger.status,
  native_belenios_before_acceptance: browser.native_verification.status,
  exact_bytes_and_i01_digest: browser.exact_bytes_and_digest.status,
  mutation_rejection: browser.mutation_rejection.status,
  revote_preparation_without_finalization: browser.revote_preparation.status,
  public_lifecycle_linkage_exposed: browser.revote_preparation.public_linkage_exposed ? "YES" : "NO",
  node_tests: /# fail 0/u.test(tap) && /# pass /u.test(tap) ? "PASS" : "FAIL",
  postgresql_tests: /# fail 0/u.test(pgTap) && /# pass 10/u.test(pgTap) ? "PASS" : "FAIL",
  postgresql_browser_e2e: browser.browser_to_ledger.storage_backend === "PostgreSQL 16.10" ? "PASS" : "FAIL",
  postgresql_production_receiver: receiver.includes("PostgresSubmissionStore") && !receiver.includes("SqliteSubmissionStore") ? "PASS" : "FAIL",
  runtime_ddl_privileges: /submission runtime and evidence reader have no DDL or mutation authority/u.test(pgTap) ? "NONE_PASS" : "FAIL",
  dependency_audit: dependencyAudit.status,
  i03_semantic_preservation: preservation.status,
  security_scan: security.status,
  external_package_lock_resolution: lockExternal ? "FAIL" : "PASS",
  belenios_crypto_algorithm_changes: "0",
  i01_i02_semantic_changes: "NO",
  i04_work_performed: "NO",
  tally_or_decryption_work: "NO",
  tfcar_or_prdci_work: "NO",
  production_election_authorized: "NO",
  i04_gate_authorized: "YES",
};
const pass = missing.length === 0
  && Object.values(browser).every((entry) => entry.status === "PASS")
  && result.node_tests === "PASS"
  && result.postgresql_tests === "PASS"
  && result.postgresql_browser_e2e === "PASS"
  && result.postgresql_production_receiver === "PASS"
  && result.runtime_ddl_privileges === "NONE_PASS"
  && dependencyAudit.status === "PASS"
  && preservation.status === "PASS"
  && security.status === "PASS"
  && !lockExternal;
result.validation = pass ? "PASS" : "FAIL";
await writeFile(join(root, "evidence/results/final-validation.json"), `${JSON.stringify(result, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
if (!pass) process.exitCode = 1;
