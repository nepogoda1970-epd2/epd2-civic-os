import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

const { Client } = pg;
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const connectionString = process.env.EPD2_I04_POSTGRES_BOOTSTRAP_URL;
if (!connectionString) throw new Error("EPD2_I04_POSTGRES_BOOTSTRAP_URL is required");
const client = new Client({ connectionString, application_name: "epd2-pb01-i04-governed-migrator" });
await client.connect();
try {
  for (const relative of [
    "migrations/postgresql/003_i04_finalization.sql",
    "migrations/postgresql/004_i04_roles.sql",
  ]) {
    await client.query(await readFile(resolve(root, relative), "utf8"));
    process.stdout.write(`applied ${relative}\n`);
  }
} finally {
  await client.end();
}

