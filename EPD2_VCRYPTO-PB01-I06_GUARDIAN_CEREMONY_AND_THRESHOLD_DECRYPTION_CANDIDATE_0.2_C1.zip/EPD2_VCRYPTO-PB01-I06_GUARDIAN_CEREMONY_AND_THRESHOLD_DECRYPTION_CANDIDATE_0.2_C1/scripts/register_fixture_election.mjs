import { resolve } from "node:path";
import { loadFixture } from "../src/i02_accepted/shared/load_fixture.mjs";
import { SqliteSubmissionStore } from "../src/i03/sqlite_store.mjs";

const [databasePath, candidateRoot, fixtureName] = process.argv.slice(2);
if (!databasePath || !candidateRoot || !fixtureName) throw new Error("usage: node scripts/register_fixture_election.mjs DATABASE_PATH CANDIDATE_ROOT FIXTURE_NAME");
const fixture = await loadFixture(resolve(candidateRoot), fixtureName);
const store = new SqliteSubmissionStore(resolve(databasePath));
try {
  store.registerElection(fixture.context);
  process.stdout.write(`${fixture.context.election_instance_id}\n`);
} finally {
  store.close();
}
