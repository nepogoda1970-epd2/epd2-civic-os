import { readdir, readFile, stat, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const required = [
  "01_EXECUTIVE_RESULT.md", "02_REVOTE_POLICY.md", "03_PRIVATE_LIFECYCLE_MODEL.md", "04_DETERMINISTIC_ORDERING.md",
  "05_CLOSURE_AUTHORITY_BOUNDARY.md", "06_CLOSURE_CHECKPOINT.md", "07_FINALIZATION_TRANSACTION.md",
  "08_REVOTE_RESOLUTION_RECORD.md", "09_CSET_FINAL_CONSTRUCTION.md", "10_CSET_ROOT.md", "11_FINAL_SET_ENVELOPE.md",
  "12_F_FINAL.md", "13_POSTGRESQL_SCHEMA_AND_ROLES.md", "14_FINALIZATION_API.md", "15_PUBLIC_FINAL_SET_EVIDENCE.md",
  "16_PRIVATE_AUDIT_EVIDENCE.md", "17_RECOMPUTATION_VERIFIER.md", "18_VERIFIER_B_EXTENSION.md",
  "19_CONCURRENCY_RESULTS.md", "20_CLOSURE_RACE_RESULTS.md", "21_CRASH_CONSISTENCY_RESULTS.md", "22_TAMPER_RESULTS.md",
  "23_BACKUP_RESTORE_RESULTS.md", "24_LEAST_PRIVILEGE_RESULTS.md", "25_REAL_I03_TO_I04_E2E.md",
  "26_MULTI_LIFECYCLE_REVOTE_E2E.md", "27_NEGATIVE_E2E_RESULTS.md", "28_PERFORMANCE_RESULTS.md",
  "29_SECURITY_SCAN_RESULTS.md", "30_I05_TALLY_INPUT_CONTRACT.md", "31_CHANGED_FILE_INVENTORY.csv",
  "32_OPEN_GAPS.md", "33_NEXT_GATE_RECOMMENDATION.md", "src", "server", "schemas", "migrations", "verifier",
  "tests", "test-vectors", "evidence", "SBOM",
];
const missing = [];
for (const path of required) {
  try { await stat(join(root, path)); } catch { missing.push(path); }
}
const readJson = async (path) => JSON.parse(await readFile(join(root, path), "utf8"));
const security = await readJson("evidence/results/i04-security-scan.json");
const performance = await readJson("evidence/results/i04-performance.json");
const preservation = await readJson("evidence/results/i04-predecessor-preservation.json");
const crossLanguage = await readJson("evidence/results/i04-cross-language-verifier.json");
const vectorPreservation = await readJson("evidence/results/i04-vector-preservation.json");
const scopePreservation = await readJson("evidence/results/i04-c1-scope-preservation.json");
const e2e = await readJson("evidence/results/real-i03-to-i04-e2e.json");
const taps = {
  i04: await readFile(join(root, "evidence/results/i04-postgresql-tests.tap"), "utf8"),
  i03_node: await readFile(join(root, "evidence/results/i03-regression-node.tap"), "utf8"),
  i03_postgres: await readFile(join(root, "evidence/results/i03-regression-postgresql.tap"), "utf8"),
};
const inventory = await readFile(join(root, "31_CHANGED_FILE_INVENTORY.csv"), "utf8");
const packageJson = JSON.parse(await readFile(join(root, "package.json"), "utf8"));
const checks = {
  required_artifacts: missing.length === 0,
  i04_tests_15_of_15: /ℹ pass 15/u.test(taps.i04) && /ℹ fail 0/u.test(taps.i04),
  i03_node_regression_34_of_34: /ℹ pass 34/u.test(taps.i03_node) && /ℹ fail 0/u.test(taps.i03_node),
  i03_postgres_regression_10_of_10: /ℹ pass 10/u.test(taps.i03_postgres) && /ℹ fail 0/u.test(taps.i03_postgres),
  security_scan: security.status === "PASS",
  performance: performance.status === "PASS" && performance.samples.some((sample) => sample.accepted_submissions === "10000"),
  predecessor_semantics: preservation.status === "PASS" && preservation.accepted_i03_package_sha256 === "8034c48673fd0ddd7a2ee65651887ba6ad16d6efc3a1e0949e839ed7ca5ce84a",
  real_browser_i03_i04_e2e: e2e.status === "PASS" && e2e.native_belenios_verification.startsWith("PASS"),
  changed_inventory: inventory.startsWith("change_type,classification,path,sha256,semantic_scope\n") && inventory.split("\n").length > 20,
  package_identity: packageJson.name === "epd2-pb01-i04-candidate" && packageJson.version === "0.2.0-c1",
  verifier_vectors: (await readdir(join(root, "test-vectors/i04-verifier-b"))).filter((name) => name.endsWith(".json")).length === 5,
  cross_language_verifier: crossLanguage.status === "PASS" && crossLanguage.byte_for_byte_agreement === true && crossLanguage.producer_code_imports === false && crossLanguage.vectors.length === 4 && crossLanguage.mutations.length === 6 && crossLanguage.mutations.every((item) => item.observed === "REJECT"),
  frozen_i04_vectors_unchanged: vectorPreservation.status === "PASS" && vectorPreservation.vectors.length === 5 && vectorPreservation.vectors.every((item) => item.byte_identical === true),
  accepted_i04_product_scope_unchanged: scopePreservation.status === "PASS" && scopePreservation.areas.every((item) => item.byte_identical === true),
};
const validation = missing.length === 0 && Object.values(checks).every(Boolean) ? "PASS" : "FAIL";
const result = {
  outcome: validation === "PASS" ? "Outcome A — PB01-I04 REVOTE LIFECYCLE AND CANONICAL FINAL SET ESTABLISHED" : "Outcome B — PB01-I04 PARTIAL — ONE BOUNDED IMPLEMENTATION BLOCKER",
  accepted_predecessor_sha256: "8034c48673fd0ddd7a2ee65651887ba6ad16d6efc3a1e0949e839ed7ca5ce84a",
  missing,
  checks,
  no_tally_or_decryption: true,
  no_i01_i02_i03_semantic_drift: preservation.status === "PASS",
  production_election_authorized: false,
  next_gate_authorized: validation === "PASS" ? "PB01-I05_ONLY" : "NO",
  validation,
};
await writeFile(join(root, "evidence/results/i04-final-validation.json"), `${JSON.stringify(result, null, 2)}\n`);
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
if (validation !== "PASS") process.exitCode = 1;
