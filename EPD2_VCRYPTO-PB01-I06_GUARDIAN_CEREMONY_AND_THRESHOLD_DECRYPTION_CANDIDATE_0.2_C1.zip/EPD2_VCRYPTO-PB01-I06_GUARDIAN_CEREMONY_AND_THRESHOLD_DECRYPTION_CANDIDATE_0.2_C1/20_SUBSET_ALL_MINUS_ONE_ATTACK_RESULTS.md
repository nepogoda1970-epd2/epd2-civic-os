# Subset / All-minus-one Attack Results

A real two-of-three upstream Belenios aggregate was formed from I05-V03 and wrapped into an internally self-consistent alternate tally record. Verifier A rejected it with `AGGREGATE_BYTE_MISMATCH` after recomputing the authorized A2/B1/C3 aggregate. A real four-ballot superset aggregate using extra valid D1 was likewise rejected. Superseded A1 is rejected at the exact-set boundary. Report: `evidence/results/i05/adversarial-composition.json`.

Security claim preserved: alternate aggregates can be mathematically valid; EPD² makes them unauthorized/detectable, not cryptographically impossible.
