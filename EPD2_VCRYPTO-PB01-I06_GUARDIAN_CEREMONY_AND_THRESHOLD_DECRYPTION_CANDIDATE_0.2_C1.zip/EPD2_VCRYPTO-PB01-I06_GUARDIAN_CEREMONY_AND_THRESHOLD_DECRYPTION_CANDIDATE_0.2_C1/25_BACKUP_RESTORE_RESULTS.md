# Backup / Restore Results

Executed live against PostgreSQL 16.14. `PostgresTallyStore.backupTo()` writes a custom-format `pg_dump` under the administrative credential; the dump is restored with `pg_restore --no-owner --no-privileges` into a freshly created database and compared against the source rows.

Preserved exactly across backup and restore:

- every digest — `f_final`, `cset_root`, `final_set_envelope_digest`, `tally_input_digest`, `aggregate_ciphertext_digest`, `tally_record_digest`, `tally_evidence_digest` — and `ballot_count`;
- exact bytes — `aggregate_ciphertext_bytes` and `upstream_sized_tally_bytes` deep-equal the source `bytea`, and the restored aggregate bytes still hash to the committed `aggregate_ciphertext_digest`;
- canonical JSON — the tally input manifest, homomorphic tally record and tally evidence bundle survive byte-for-byte, and the restored evidence bundle independently re-verifies with `verifyTallyEvidence()`.
