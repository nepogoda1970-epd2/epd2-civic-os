# Multi-lifecycle revote E2E

PASS: Lifecycle 1 A1→A2, Lifecycle 2 B1, Lifecycle 3 C1→C2→C3 resolved to A2/B1/C3; public ordering was digest-canonical and independent of lifecycle ordering.
