# Exact ballot byte preservation

The service decodes the I02 base64url once and stores that exact byte sequence
as immutable PostgreSQL `bytea` (or SQLite BLOB in local tests). The same bytes are passed to the native verifier. They are
never parsed and regenerated, pretty-printed, reordered or normalized for
storage.

Tests compare the persisted PostgreSQL `bytea` with the browser-produced byte
buffer and repeat the comparison after `pg_dump`/`pg_restore`. The future tally/evidence layer
must read these bytes, not a reconstructed object.
