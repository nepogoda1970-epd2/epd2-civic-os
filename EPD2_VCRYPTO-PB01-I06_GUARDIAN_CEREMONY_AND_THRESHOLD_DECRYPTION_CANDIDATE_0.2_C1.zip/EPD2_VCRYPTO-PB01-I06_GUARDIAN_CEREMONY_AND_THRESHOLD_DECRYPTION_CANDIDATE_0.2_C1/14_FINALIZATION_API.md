# Finalization API

`GET /v1/elections/{id}/closure-preview`, `POST /v1/elections/{id}/finalize`, `GET .../final-set-evidence`, and the narrow `GET .../authorized-final-ballot-set`. Final digests are never client supplied. Strict canonical JSON, bounded body, exact operator origin and HTTPS-by-default apply.
