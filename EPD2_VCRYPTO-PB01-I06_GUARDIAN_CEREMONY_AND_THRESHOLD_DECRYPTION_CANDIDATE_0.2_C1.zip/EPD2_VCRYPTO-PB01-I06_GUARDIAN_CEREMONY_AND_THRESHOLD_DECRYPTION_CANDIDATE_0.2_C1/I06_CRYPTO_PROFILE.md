# I06 Cryptographic Profile

- PB01 profile: `epd2.belenios-homomorphic/1`
- Belenios: 3.3.0
- Group: Ed25519, protocol v1
- Pinned tool SHA-256: `b2a95000d857079260fba2e8b7bb9a8221a117b81560cf1da645b7b316749134`
- Pinned source tarball SHA-256: `bd8d0741862d8a59736042f81b163df7efa87e540c7d3c19d5ff08a283eb432c`
- Belenios crypto algorithm patch count: **0**

I06 uses upstream threshold trustee operations and upstream result computation. It does not reimplement ElGamal group arithmetic, partial-decryption proof mathematics, Lagrange/threshold combination, or plaintext extraction.

New EPD² domain tags are versioned and limited to composition/evidence objects: guardian public key, guardian set, guardian ceremony, partial decryption share, plaintext tally, threshold decryption record, and I07 handoff. Frozen I01–I05 digest domains are unchanged.

`GuardianCeremonyRecord`, share artifacts, and `ThresholdDecryptionRecord` use the accepted restricted PB01 canonicalization profile. Exact upstream Belenios public bytes are preserved separately in base64url fields where evidence byte identity matters.
