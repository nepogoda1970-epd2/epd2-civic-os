# Finalization Integrity Precheck

`TallyEngine.deriveAuthorizedInput()` first runs the accepted I04 PostgreSQL `recompute()` path. Production wiring supplies `ClosureAuthorizationVerifier`, so the closure Ed25519 signature is rechecked together with checkpoint, accepted manifest, ledger prefix/hash chain, CSet, cset root, FinalSetEnvelope, `F_final`, public evidence, and private resolution audit. Any failure maps to `FINALIZATION_INTEGRITY_FAILURE`; no aggregate is committed.
