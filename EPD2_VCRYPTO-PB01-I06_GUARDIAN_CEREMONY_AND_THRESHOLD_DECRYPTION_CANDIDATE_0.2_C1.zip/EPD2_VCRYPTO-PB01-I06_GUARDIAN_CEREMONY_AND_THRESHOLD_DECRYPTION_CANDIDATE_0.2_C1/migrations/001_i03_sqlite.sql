PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
PRAGMA synchronous = FULL;
PRAGMA busy_timeout = 5000;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version TEXT PRIMARY KEY,
  applied_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS elections (
  election_instance_id TEXT PRIMARY KEY CHECK (election_instance_id GLOB 'ei1_[0-9a-f]*' AND length(election_instance_id) = 36),
  crypto_profile TEXT NOT NULL CHECK (crypto_profile = 'epd2.belenios-homomorphic/1'),
  tally_function_id TEXT NOT NULL CHECK (tally_function_id = 'epd2.pb01.tally.single-choice.v1'),
  belenios_election_uuid TEXT NOT NULL UNIQUE,
  belenios_election_hash TEXT NOT NULL,
  context_json TEXT NOT NULL,
  context_sha256 TEXT NOT NULL CHECK (length(context_sha256) = 64),
  election_state TEXT NOT NULL CHECK (election_state IN ('OPEN', 'CLOSED')),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS encrypted_submissions (
  submission_id TEXT PRIMARY KEY,
  election_instance_id TEXT NOT NULL REFERENCES elections(election_instance_id),
  ballot_digest TEXT NOT NULL CHECK (length(ballot_digest) = 64),
  crypto_profile TEXT NOT NULL CHECK (crypto_profile = 'epd2.belenios-homomorphic/1'),
  tally_function_id TEXT NOT NULL CHECK (tally_function_id = 'epd2.pb01.tally.single-choice.v1'),
  encrypted_ballot_bytes BLOB NOT NULL CHECK (length(encrypted_ballot_bytes) BETWEEN 1 AND 1048576),
  upstream_format_version TEXT NOT NULL,
  received_at TEXT NOT NULL,
  accepted_at TEXT NOT NULL,
  verification_result TEXT NOT NULL CHECK (verification_result = 'PASS_NATIVE_BELENIOS_3.3.0'),
  client_crypto_build_id TEXT NOT NULL,
  ledger_event_id TEXT NOT NULL UNIQUE,
  receipt_json TEXT NOT NULL,
  UNIQUE (election_instance_id, ballot_digest)
);

CREATE TABLE IF NOT EXISTS private_submission_lifecycle (
  submission_id TEXT PRIMARY KEY REFERENCES encrypted_submissions(submission_id),
  election_instance_id TEXT NOT NULL REFERENCES elections(election_instance_id),
  lifecycle_handle TEXT NOT NULL CHECK (length(lifecycle_handle) = 64),
  credential_expires_at TEXT NOT NULL,
  bound_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS private_lifecycle_lookup
  ON private_submission_lifecycle(election_instance_id, lifecycle_handle, bound_at);

CREATE TABLE IF NOT EXISTS submission_ledger_events (
  ledger_event_id TEXT PRIMARY KEY,
  election_instance_id TEXT NOT NULL REFERENCES elections(election_instance_id),
  ledger_seq INTEGER NOT NULL CHECK (ledger_seq > 0),
  submission_id TEXT NOT NULL UNIQUE REFERENCES encrypted_submissions(submission_id) DEFERRABLE INITIALLY DEFERRED,
  ballot_digest TEXT NOT NULL CHECK (length(ballot_digest) = 64),
  accepted_at TEXT NOT NULL,
  event_version TEXT NOT NULL CHECK (event_version = 'epd2.pb01.submission-accepted/1'),
  previous_event_hash TEXT NOT NULL CHECK (length(previous_event_hash) = 64),
  event_hash TEXT NOT NULL CHECK (length(event_hash) = 64),
  event_json TEXT NOT NULL,
  UNIQUE (election_instance_id, ledger_seq),
  UNIQUE (election_instance_id, event_hash)
);

CREATE TABLE IF NOT EXISTS idempotency_records (
  election_instance_id TEXT NOT NULL REFERENCES elections(election_instance_id),
  idempotency_key_hash TEXT NOT NULL CHECK (length(idempotency_key_hash) = 64),
  semantic_request_hash TEXT NOT NULL CHECK (length(semantic_request_hash) = 64),
  submission_id TEXT NOT NULL REFERENCES encrypted_submissions(submission_id),
  response_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (election_instance_id, idempotency_key_hash)
);

CREATE TABLE IF NOT EXISTS security_audit_events (
  audit_seq INTEGER PRIMARY KEY AUTOINCREMENT,
  audit_event_id TEXT NOT NULL UNIQUE,
  election_instance_id TEXT,
  event_code TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  detail_json TEXT NOT NULL
);

CREATE TRIGGER IF NOT EXISTS no_update_encrypted_submissions
BEFORE UPDATE ON encrypted_submissions BEGIN SELECT RAISE(ABORT, 'APPEND_ONLY_VIOLATION'); END;
CREATE TRIGGER IF NOT EXISTS no_delete_encrypted_submissions
BEFORE DELETE ON encrypted_submissions BEGIN SELECT RAISE(ABORT, 'APPEND_ONLY_VIOLATION'); END;
CREATE TRIGGER IF NOT EXISTS no_update_private_lifecycle
BEFORE UPDATE ON private_submission_lifecycle BEGIN SELECT RAISE(ABORT, 'APPEND_ONLY_VIOLATION'); END;
CREATE TRIGGER IF NOT EXISTS no_delete_private_lifecycle
BEFORE DELETE ON private_submission_lifecycle BEGIN SELECT RAISE(ABORT, 'APPEND_ONLY_VIOLATION'); END;
CREATE TRIGGER IF NOT EXISTS no_update_submission_ledger
BEFORE UPDATE ON submission_ledger_events BEGIN SELECT RAISE(ABORT, 'APPEND_ONLY_VIOLATION'); END;
CREATE TRIGGER IF NOT EXISTS no_delete_submission_ledger
BEFORE DELETE ON submission_ledger_events BEGIN SELECT RAISE(ABORT, 'APPEND_ONLY_VIOLATION'); END;
CREATE TRIGGER IF NOT EXISTS no_update_idempotency
BEFORE UPDATE ON idempotency_records BEGIN SELECT RAISE(ABORT, 'APPEND_ONLY_VIOLATION'); END;
CREATE TRIGGER IF NOT EXISTS no_delete_idempotency
BEFORE DELETE ON idempotency_records BEGIN SELECT RAISE(ABORT, 'APPEND_ONLY_VIOLATION'); END;

INSERT OR IGNORE INTO schema_migrations(version, applied_at)
VALUES ('001_i03_sqlite', '2026-08-17T00:00:00Z');
