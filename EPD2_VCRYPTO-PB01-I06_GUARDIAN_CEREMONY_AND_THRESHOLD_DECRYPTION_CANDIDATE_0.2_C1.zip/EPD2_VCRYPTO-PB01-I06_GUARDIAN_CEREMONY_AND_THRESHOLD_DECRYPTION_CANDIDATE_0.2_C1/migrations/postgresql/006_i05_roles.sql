BEGIN;

DO $roles$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'epd2_pb01_tally_runtime') THEN
    CREATE ROLE epd2_pb01_tally_runtime NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS;
  END IF;
END
$roles$;

REVOKE ALL ON SCHEMA pb01_i05 FROM PUBLIC;
GRANT USAGE ON SCHEMA pb01_i03, pb01_i04, pb01_i05 TO epd2_pb01_tally_runtime;
GRANT SELECT ON pb01_i03.elections, pb01_i03.encrypted_submissions,
  pb01_i03.private_submission_lifecycle, pb01_i03.submission_ledger_events,
  pb01_i04.closure_records, pb01_i04.revote_resolution_records,
  pb01_i04.effective_submissions, pb01_i04.finalizations
  TO epd2_pb01_tally_runtime;
GRANT SELECT, INSERT ON pb01_i05.aggregates, pb01_i05.tally_records, pb01_i05.tally_audit_events
  TO epd2_pb01_tally_runtime;
GRANT USAGE, SELECT ON SEQUENCE pb01_i05.tally_audit_events_audit_seq_seq TO epd2_pb01_tally_runtime;

GRANT USAGE ON SCHEMA pb01_i05 TO epd2_pb01_evidence_reader;
GRANT SELECT ON pb01_i05.public_tallies TO epd2_pb01_evidence_reader;

REVOKE ALL ON ALL TABLES IN SCHEMA pb01_i05 FROM epd2_pb01_submission_runtime, epd2_pb01_finalization_runtime;
REVOKE UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA pb01_i03, pb01_i04, pb01_i05 FROM epd2_pb01_tally_runtime;
REVOKE INSERT ON ALL TABLES IN SCHEMA pb01_i03, pb01_i04 FROM epd2_pb01_tally_runtime;
REVOKE CREATE ON SCHEMA pb01_i03, pb01_i04, pb01_i05, public
  FROM epd2_pb01_submission_runtime, epd2_pb01_finalization_runtime,
    epd2_pb01_tally_runtime, epd2_pb01_evidence_reader;

DO $database_privileges$
BEGIN
  EXECUTE format('REVOKE TEMPORARY ON DATABASE %I FROM epd2_pb01_tally_runtime, epd2_pb01_evidence_reader', current_database());
END
$database_privileges$;

ALTER SCHEMA pb01_i05 OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i05.aggregates OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i05.tally_records OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i05.tally_audit_events OWNER TO epd2_pb01_migrator;
ALTER SEQUENCE pb01_i05.tally_audit_events_audit_seq_seq OWNER TO epd2_pb01_migrator;
ALTER VIEW pb01_i05.public_tallies OWNER TO epd2_pb01_migrator;
ALTER FUNCTION pb01_i05.reject_mutation() OWNER TO epd2_pb01_migrator;
REVOKE ALL ON FUNCTION pb01_i05.reject_mutation() FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE epd2_pb01_migrator IN SCHEMA pb01_i05 REVOKE ALL ON TABLES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE epd2_pb01_migrator IN SCHEMA pb01_i05 REVOKE ALL ON SEQUENCES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE epd2_pb01_migrator IN SCHEMA pb01_i05 REVOKE ALL ON FUNCTIONS FROM PUBLIC;

COMMIT;
