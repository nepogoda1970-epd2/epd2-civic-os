BEGIN;

CREATE SCHEMA IF NOT EXISTS pb01_i04;

CREATE TABLE pb01_i04.closure_records (
  election_instance_id text PRIMARY KEY REFERENCES pb01_i03.elections,
  finalization_id uuid NOT NULL UNIQUE,
  closed_at timestamptz NOT NULL,
  closure_ledger_seq bigint NOT NULL CHECK (closure_ledger_seq >= 0),
  closure_ledger_event_hash char(64) NOT NULL CHECK (closure_ledger_event_hash ~ '^[0-9a-f]{64}$'),
  closure_checkpoint_digest char(64) NOT NULL CHECK (closure_checkpoint_digest ~ '^[0-9a-f]{64}$'),
  closure_record_digest char(64) NOT NULL CHECK (closure_record_digest ~ '^[0-9a-f]{64}$'),
  authorization_evidence_digest char(64) NOT NULL CHECK (authorization_evidence_digest ~ '^[0-9a-f]{64}$'),
  revote_policy_version text NOT NULL CHECK (revote_policy_version = 'epd2.pb01.revote.latest-valid.v1'),
  closure_record_canonical text NOT NULL CHECK (closure_record_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  closure_checkpoint_canonical text NOT NULL CHECK (closure_checkpoint_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  authorization_evidence_canonical text NOT NULL CHECK (authorization_evidence_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  committed_at timestamptz NOT NULL
);

CREATE TABLE pb01_i04.revote_resolution_records (
  election_instance_id text NOT NULL REFERENCES pb01_i03.elections,
  finalization_id uuid NOT NULL REFERENCES pb01_i04.closure_records(finalization_id),
  lifecycle_handle char(64) NOT NULL,
  effective_submission_id uuid NOT NULL REFERENCES pb01_i03.encrypted_submissions(submission_id),
  effective_ballot_digest char(64) NOT NULL CHECK (effective_ballot_digest ~ '^[0-9a-f]{64}$'),
  source_ledger_position bigint NOT NULL CHECK (source_ledger_position > 0),
  candidate_submission_ids uuid[] NOT NULL CHECK (cardinality(candidate_submission_ids) > 0),
  policy_version text NOT NULL CHECK (policy_version = 'epd2.pb01.revote.latest-valid.v1'),
  resolution_digest char(64) NOT NULL CHECK (resolution_digest ~ '^[0-9a-f]{64}$'),
  resolution_canonical text NOT NULL CHECK (resolution_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  PRIMARY KEY (election_instance_id, lifecycle_handle),
  UNIQUE (election_instance_id, effective_submission_id),
  UNIQUE (election_instance_id, effective_ballot_digest)
);

CREATE TABLE pb01_i04.effective_submissions (
  election_instance_id text NOT NULL REFERENCES pb01_i03.elections,
  finalization_id uuid NOT NULL REFERENCES pb01_i04.closure_records(finalization_id),
  canonical_ordinal bigint NOT NULL CHECK (canonical_ordinal >= 0),
  submission_id uuid NOT NULL REFERENCES pb01_i03.encrypted_submissions(submission_id),
  ballot_digest char(64) NOT NULL CHECK (ballot_digest ~ '^[0-9a-f]{64}$'),
  source_ledger_position bigint NOT NULL CHECK (source_ledger_position > 0),
  PRIMARY KEY (election_instance_id, canonical_ordinal),
  UNIQUE (election_instance_id, submission_id),
  UNIQUE (election_instance_id, ballot_digest)
);

CREATE TABLE pb01_i04.finalizations (
  election_instance_id text PRIMARY KEY REFERENCES pb01_i03.elections,
  finalization_id uuid NOT NULL UNIQUE REFERENCES pb01_i04.closure_records(finalization_id),
  finalization_state text NOT NULL CHECK (finalization_state = 'FINALIZED'),
  accepted_manifest_canonical text NOT NULL CHECK (accepted_manifest_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  cset_final_canonical text NOT NULL CHECK (cset_final_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  cset_root char(64) NOT NULL CHECK (cset_root ~ '^[0-9a-f]{64}$'),
  final_set_envelope_canonical text NOT NULL CHECK (final_set_envelope_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  final_set_envelope_digest char(64) NOT NULL CHECK (final_set_envelope_digest ~ '^[0-9a-f]{64}$'),
  f_final char(64) NOT NULL CHECK (f_final ~ '^[0-9a-f]{64}$'),
  public_evidence_canonical text NOT NULL CHECK (public_evidence_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  public_evidence_digest char(64) NOT NULL CHECK (public_evidence_digest ~ '^[0-9a-f]{64}$'),
  committed_at timestamptz NOT NULL
);

CREATE TABLE pb01_i04.finalization_audit_events (
  audit_seq bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  audit_event_id uuid NOT NULL UNIQUE,
  election_instance_id text,
  event_code text NOT NULL,
  occurred_at timestamptz NOT NULL,
  detail_canonical text NOT NULL CHECK (detail_canonical IS JSON OBJECT WITH UNIQUE KEYS)
);

CREATE OR REPLACE FUNCTION pb01_i04.reject_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'FINALIZATION_APPEND_ONLY_VIOLATION'; END $$;

CREATE TRIGGER no_mutate_closure_records BEFORE UPDATE OR DELETE ON pb01_i04.closure_records FOR EACH ROW EXECUTE FUNCTION pb01_i04.reject_mutation();
CREATE TRIGGER no_mutate_revote_resolution BEFORE UPDATE OR DELETE ON pb01_i04.revote_resolution_records FOR EACH ROW EXECUTE FUNCTION pb01_i04.reject_mutation();
CREATE TRIGGER no_mutate_effective_submissions BEFORE UPDATE OR DELETE ON pb01_i04.effective_submissions FOR EACH ROW EXECUTE FUNCTION pb01_i04.reject_mutation();
CREATE TRIGGER no_mutate_finalizations BEFORE UPDATE OR DELETE ON pb01_i04.finalizations FOR EACH ROW EXECUTE FUNCTION pb01_i04.reject_mutation();

CREATE OR REPLACE FUNCTION pb01_i04.enforce_open_to_closed_only() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.election_state = 'OPEN' AND NEW.election_state = 'CLOSED'
     AND OLD.election_instance_id = NEW.election_instance_id
     AND OLD.crypto_profile = NEW.crypto_profile
     AND OLD.tally_function_id = NEW.tally_function_id
     AND OLD.belenios_election_uuid = NEW.belenios_election_uuid
     AND OLD.belenios_election_hash = NEW.belenios_election_hash
     AND OLD.context_json = NEW.context_json
     AND OLD.context_sha256 = NEW.context_sha256
     AND OLD.created_at = NEW.created_at THEN
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'ELECTION_STATE_TRANSITION_VIOLATION';
END $$;

CREATE TRIGGER open_to_closed_only BEFORE UPDATE ON pb01_i03.elections FOR EACH ROW EXECUTE FUNCTION pb01_i04.enforce_open_to_closed_only();

CREATE VIEW pb01_i04.public_finalizations AS
SELECT election_instance_id, finalization_id, finalization_state, cset_final_canonical,
  cset_root, final_set_envelope_canonical, final_set_envelope_digest, f_final,
  public_evidence_canonical, public_evidence_digest, committed_at
FROM pb01_i04.finalizations;

COMMIT;

