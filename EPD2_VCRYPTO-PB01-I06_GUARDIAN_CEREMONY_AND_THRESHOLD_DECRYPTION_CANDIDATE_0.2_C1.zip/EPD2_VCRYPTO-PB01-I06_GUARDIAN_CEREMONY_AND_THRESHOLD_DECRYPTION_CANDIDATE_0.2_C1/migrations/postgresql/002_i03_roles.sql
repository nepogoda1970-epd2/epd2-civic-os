BEGIN;

DO $roles$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'epd2_pb01_submission_runtime') THEN
    CREATE ROLE epd2_pb01_submission_runtime NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'epd2_pb01_evidence_reader') THEN
    CREATE ROLE epd2_pb01_evidence_reader NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'epd2_pb01_migrator') THEN
    CREATE ROLE epd2_pb01_migrator NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS;
  END IF;
END
$roles$;

REVOKE ALL ON SCHEMA pb01_i03 FROM PUBLIC;
GRANT USAGE ON SCHEMA pb01_i03 TO epd2_pb01_submission_runtime, epd2_pb01_evidence_reader;
GRANT SELECT, INSERT ON pb01_i03.encrypted_submissions, pb01_i03.private_submission_lifecycle,
  pb01_i03.submission_ledger_events, pb01_i03.idempotency_records, pb01_i03.security_audit_events
  TO epd2_pb01_submission_runtime;
GRANT USAGE, SELECT ON SEQUENCE pb01_i03.security_audit_events_audit_seq_seq
  TO epd2_pb01_submission_runtime;
GRANT SELECT ON pb01_i03.elections TO epd2_pb01_submission_runtime;
GRANT SELECT ON pb01_i03.encrypted_submissions, pb01_i03.submission_ledger_events, pb01_i03.elections
  TO epd2_pb01_evidence_reader;
REVOKE UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA pb01_i03 FROM epd2_pb01_submission_runtime, epd2_pb01_evidence_reader;
REVOKE CREATE ON SCHEMA pb01_i03 FROM epd2_pb01_submission_runtime, epd2_pb01_evidence_reader;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;

DO $database_privileges$
BEGIN
  EXECUTE format('REVOKE TEMPORARY ON DATABASE %I FROM PUBLIC', current_database());
END
$database_privileges$;

ALTER SCHEMA pb01_i03 OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i03.elections OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i03.encrypted_submissions OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i03.private_submission_lifecycle OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i03.submission_ledger_events OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i03.idempotency_records OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i03.security_audit_events OWNER TO epd2_pb01_migrator;
ALTER SEQUENCE pb01_i03.security_audit_events_audit_seq_seq OWNER TO epd2_pb01_migrator;
ALTER FUNCTION pb01_i03.reject_mutation() OWNER TO epd2_pb01_migrator;

REVOKE ALL ON FUNCTION pb01_i03.reject_mutation() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION pb01_i03.reject_mutation() TO epd2_pb01_submission_runtime;

ALTER DEFAULT PRIVILEGES FOR ROLE epd2_pb01_migrator IN SCHEMA pb01_i03
  REVOKE ALL ON TABLES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE epd2_pb01_migrator IN SCHEMA pb01_i03
  REVOKE ALL ON SEQUENCES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE epd2_pb01_migrator IN SCHEMA pb01_i03
  REVOKE ALL ON FUNCTIONS FROM PUBLIC;

COMMIT;
