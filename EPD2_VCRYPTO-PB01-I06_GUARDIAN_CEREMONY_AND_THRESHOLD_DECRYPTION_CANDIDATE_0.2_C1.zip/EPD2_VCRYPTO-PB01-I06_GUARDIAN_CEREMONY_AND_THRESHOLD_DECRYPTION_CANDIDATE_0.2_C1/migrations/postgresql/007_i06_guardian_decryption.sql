BEGIN;
CREATE SCHEMA IF NOT EXISTS pb01_i06;

CREATE TABLE pb01_i06.guardian_ceremonies (
  election_instance_id text PRIMARY KEY REFERENCES pb01_i03.elections,
  guardian_count integer NOT NULL CHECK (guardian_count >= 2),
  threshold integer NOT NULL CHECK (threshold >= 2 AND threshold <= guardian_count),
  ceremony_state text NOT NULL CHECK (ceremony_state IN ('CREATED','GUARDIANS_REGISTERED','PUBLIC_KEYS_SUBMITTED','CEREMONY_VERIFIED','CEREMONY_FROZEN')),
  belenios_election_uuid text NOT NULL,
  election_public_key text,
  guardian_set_digest char(64) CHECK (guardian_set_digest IS NULL OR guardian_set_digest ~ '^[0-9a-f]{64}$'),
  guardian_ceremony_digest char(64) CHECK (guardian_ceremony_digest IS NULL OR guardian_ceremony_digest ~ '^[0-9a-f]{64}$'),
  threshold_parameters_bytes bytea,
  trustees_public_bytes bytea,
  election_public_bytes bytea,
  ceremony_record_canonical text CHECK (ceremony_record_canonical IS NULL OR ceremony_record_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  created_at timestamptz NOT NULL,
  frozen_at timestamptz,
  CHECK ((ceremony_state='CEREMONY_FROZEN') = (guardian_ceremony_digest IS NOT NULL AND guardian_set_digest IS NOT NULL AND ceremony_record_canonical IS NOT NULL AND frozen_at IS NOT NULL))
);

CREATE TABLE pb01_i06.guardians (
  election_instance_id text NOT NULL REFERENCES pb01_i06.guardian_ceremonies(election_instance_id),
  guardian_index integer NOT NULL CHECK (guardian_index >= 1),
  guardian_id text NOT NULL,
  public_key text,
  public_key_digest char(64) CHECK (public_key_digest IS NULL OR public_key_digest ~ '^[0-9a-f]{64}$'),
  registered_at timestamptz NOT NULL,
  public_key_submitted_at timestamptz,
  PRIMARY KEY (election_instance_id, guardian_index),
  UNIQUE (election_instance_id, guardian_id),
  UNIQUE (election_instance_id, public_key_digest),
  CHECK ((public_key IS NULL) = (public_key_digest IS NULL))
);

CREATE TABLE pb01_i06.share_inbox (
  share_submission_id uuid PRIMARY KEY,
  election_instance_id text NOT NULL REFERENCES pb01_i06.guardian_ceremonies(election_instance_id),
  guardian_index integer NOT NULL,
  guardian_id text NOT NULL,
  tally_record_digest char(64) NOT NULL CHECK (tally_record_digest ~ '^[0-9a-f]{64}$'),
  aggregate_ciphertext_digest char(64) NOT NULL CHECK (aggregate_ciphertext_digest ~ '^[0-9a-f]{64}$'),
  guardian_ceremony_digest char(64) NOT NULL CHECK (guardian_ceremony_digest ~ '^[0-9a-f]{64}$'),
  share_digest char(64) NOT NULL CHECK (share_digest ~ '^[0-9a-f]{64}$'),
  share_bytes bytea NOT NULL,
  share_artifact_canonical text NOT NULL CHECK (share_artifact_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  received_at timestamptz NOT NULL,
  UNIQUE (election_instance_id, guardian_index),
  UNIQUE (share_digest),
  FOREIGN KEY (election_instance_id, guardian_index) REFERENCES pb01_i06.guardians(election_instance_id, guardian_index)
);

CREATE TABLE pb01_i06.accepted_shares (
  election_instance_id text NOT NULL REFERENCES pb01_i06.guardian_ceremonies(election_instance_id),
  guardian_index integer NOT NULL,
  guardian_id text NOT NULL,
  share_digest char(64) NOT NULL CHECK (share_digest ~ '^[0-9a-f]{64}$'),
  share_artifact_canonical text NOT NULL CHECK (share_artifact_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  accepted_at timestamptz NOT NULL,
  PRIMARY KEY (election_instance_id, guardian_index),
  UNIQUE (share_digest),
  FOREIGN KEY (election_instance_id, guardian_index) REFERENCES pb01_i06.guardians(election_instance_id, guardian_index)
);

CREATE TABLE pb01_i06.decryption_records (
  election_instance_id text PRIMARY KEY REFERENCES pb01_i06.guardian_ceremonies(election_instance_id),
  tally_record_digest char(64) NOT NULL CHECK (tally_record_digest ~ '^[0-9a-f]{64}$'),
  f_final char(64) NOT NULL CHECK (f_final ~ '^[0-9a-f]{64}$'),
  aggregate_ciphertext_digest char(64) NOT NULL CHECK (aggregate_ciphertext_digest ~ '^[0-9a-f]{64}$'),
  guardian_ceremony_digest char(64) NOT NULL CHECK (guardian_ceremony_digest ~ '^[0-9a-f]{64}$'),
  threshold integer NOT NULL CHECK (threshold >= 2),
  threshold_share_digests_canonical text NOT NULL CHECK (threshold_share_digests_canonical IS JSON ARRAY),
  plaintext_tally_bytes bytea NOT NULL,
  plaintext_tally_digest char(64) NOT NULL CHECK (plaintext_tally_digest ~ '^[0-9a-f]{64}$'),
  decryption_record_digest char(64) NOT NULL UNIQUE CHECK (decryption_record_digest ~ '^[0-9a-f]{64}$'),
  decryption_record_canonical text NOT NULL CHECK (decryption_record_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  completion_state text NOT NULL CHECK (completion_state='CRYPTOGRAPHICALLY_DECRYPTED_NOT_YET_PUBLISHED'),
  committed_at timestamptz NOT NULL,
  UNIQUE (election_instance_id, tally_record_digest, aggregate_ciphertext_digest)
);

CREATE OR REPLACE FUNCTION pb01_i06.reject_if_frozen() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.ceremony_state='CEREMONY_FROZEN' THEN RAISE EXCEPTION 'I06_CEREMONY_FROZEN'; END IF;
  RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION pb01_i06.reject_guardian_mutation_if_frozen() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE s text;
BEGIN
  SELECT ceremony_state INTO s FROM pb01_i06.guardian_ceremonies WHERE election_instance_id=OLD.election_instance_id;
  IF s='CEREMONY_FROZEN' THEN RAISE EXCEPTION 'I06_CEREMONY_FROZEN'; END IF;
  IF TG_OP='DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END $$;
CREATE OR REPLACE FUNCTION pb01_i06.reject_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'I06_APPEND_ONLY_VIOLATION'; END $$;
CREATE TRIGGER guardian_ceremony_freeze_guard BEFORE UPDATE OR DELETE ON pb01_i06.guardian_ceremonies FOR EACH ROW EXECUTE FUNCTION pb01_i06.reject_if_frozen();
CREATE TRIGGER guardian_freeze_guard BEFORE UPDATE OR DELETE ON pb01_i06.guardians FOR EACH ROW EXECUTE FUNCTION pb01_i06.reject_guardian_mutation_if_frozen();
CREATE TRIGGER no_mutate_share_inbox BEFORE UPDATE OR DELETE ON pb01_i06.share_inbox FOR EACH ROW EXECUTE FUNCTION pb01_i06.reject_mutation();
CREATE TRIGGER no_mutate_accepted_shares BEFORE UPDATE OR DELETE ON pb01_i06.accepted_shares FOR EACH ROW EXECUTE FUNCTION pb01_i06.reject_mutation();
CREATE TRIGGER no_mutate_decryption_records BEFORE UPDATE OR DELETE ON pb01_i06.decryption_records FOR EACH ROW EXECUTE FUNCTION pb01_i06.reject_mutation();

CREATE VIEW pb01_i06.public_decryption_evidence AS
SELECT c.election_instance_id,c.guardian_count,c.threshold,c.election_public_key,c.guardian_set_digest,c.guardian_ceremony_digest,c.ceremony_record_canonical,
 d.tally_record_digest,d.f_final,d.aggregate_ciphertext_digest,d.threshold_share_digests_canonical,d.plaintext_tally_bytes,d.plaintext_tally_digest,d.decryption_record_digest,d.decryption_record_canonical,d.completion_state
FROM pb01_i06.guardian_ceremonies c JOIN pb01_i06.decryption_records d USING (election_instance_id)
WHERE c.ceremony_state='CEREMONY_FROZEN';
COMMIT;
