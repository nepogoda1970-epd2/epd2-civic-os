BEGIN;

CREATE SCHEMA IF NOT EXISTS pb01_i03;

CREATE TABLE pb01_i03.elections (
  election_instance_id text PRIMARY KEY CHECK (election_instance_id ~ '^ei1_[0-9a-f]{32}$'),
  crypto_profile text NOT NULL CHECK (crypto_profile = 'epd2.belenios-homomorphic/1'),
  tally_function_id text NOT NULL CHECK (tally_function_id = 'epd2.pb01.tally.single-choice.v1'),
  belenios_election_uuid text NOT NULL UNIQUE,
  belenios_election_hash text NOT NULL,
  context_json jsonb NOT NULL,
  context_sha256 char(64) NOT NULL,
  election_state text NOT NULL CHECK (election_state IN ('OPEN', 'CLOSED')),
  created_at timestamptz NOT NULL
);

CREATE TABLE pb01_i03.encrypted_submissions (
  submission_id uuid PRIMARY KEY,
  election_instance_id text NOT NULL REFERENCES pb01_i03.elections,
  ballot_digest char(64) NOT NULL,
  crypto_profile text NOT NULL CHECK (crypto_profile = 'epd2.belenios-homomorphic/1'),
  tally_function_id text NOT NULL CHECK (tally_function_id = 'epd2.pb01.tally.single-choice.v1'),
  encrypted_ballot_bytes bytea NOT NULL CHECK (octet_length(encrypted_ballot_bytes) BETWEEN 1 AND 1048576),
  upstream_format_version text NOT NULL,
  received_at timestamptz NOT NULL,
  accepted_at timestamptz NOT NULL,
  verification_result text NOT NULL CHECK (verification_result = 'PASS_NATIVE_BELENIOS_3.3.0'),
  client_crypto_build_id text NOT NULL,
  ledger_event_id uuid NOT NULL UNIQUE,
  receipt_json jsonb NOT NULL,
  UNIQUE (election_instance_id, ballot_digest)
);

CREATE TABLE pb01_i03.private_submission_lifecycle (
  submission_id uuid PRIMARY KEY REFERENCES pb01_i03.encrypted_submissions,
  election_instance_id text NOT NULL REFERENCES pb01_i03.elections,
  lifecycle_handle char(64) NOT NULL,
  credential_expires_at timestamptz NOT NULL,
  bound_at timestamptz NOT NULL
);
CREATE INDEX private_lifecycle_lookup ON pb01_i03.private_submission_lifecycle(election_instance_id, lifecycle_handle, bound_at);

CREATE TABLE pb01_i03.submission_ledger_events (
  ledger_event_id uuid PRIMARY KEY,
  election_instance_id text NOT NULL REFERENCES pb01_i03.elections,
  ledger_seq bigint NOT NULL CHECK (ledger_seq > 0),
  submission_id uuid NOT NULL UNIQUE DEFERRABLE INITIALLY DEFERRED REFERENCES pb01_i03.encrypted_submissions,
  ballot_digest char(64) NOT NULL,
  accepted_at timestamptz NOT NULL,
  event_version text NOT NULL CHECK (event_version = 'epd2.pb01.submission-accepted/1'),
  previous_event_hash char(64) NOT NULL,
  event_hash char(64) NOT NULL,
  event_json jsonb NOT NULL,
  UNIQUE (election_instance_id, ledger_seq),
  UNIQUE (election_instance_id, event_hash)
);

CREATE TABLE pb01_i03.idempotency_records (
  election_instance_id text NOT NULL REFERENCES pb01_i03.elections,
  idempotency_key_hash char(64) NOT NULL,
  semantic_request_hash char(64) NOT NULL,
  submission_id uuid NOT NULL REFERENCES pb01_i03.encrypted_submissions,
  response_json jsonb NOT NULL,
  created_at timestamptz NOT NULL,
  PRIMARY KEY (election_instance_id, idempotency_key_hash)
);

CREATE TABLE pb01_i03.security_audit_events (
  audit_seq bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  audit_event_id uuid NOT NULL UNIQUE,
  election_instance_id text,
  event_code text NOT NULL,
  occurred_at timestamptz NOT NULL,
  detail_json jsonb NOT NULL
);

CREATE OR REPLACE FUNCTION pb01_i03.reject_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'APPEND_ONLY_VIOLATION'; END $$;

CREATE TRIGGER no_mutate_encrypted_submissions BEFORE UPDATE OR DELETE ON pb01_i03.encrypted_submissions FOR EACH ROW EXECUTE FUNCTION pb01_i03.reject_mutation();
CREATE TRIGGER no_mutate_private_lifecycle BEFORE UPDATE OR DELETE ON pb01_i03.private_submission_lifecycle FOR EACH ROW EXECUTE FUNCTION pb01_i03.reject_mutation();
CREATE TRIGGER no_mutate_submission_ledger BEFORE UPDATE OR DELETE ON pb01_i03.submission_ledger_events FOR EACH ROW EXECUTE FUNCTION pb01_i03.reject_mutation();
CREATE TRIGGER no_mutate_idempotency BEFORE UPDATE OR DELETE ON pb01_i03.idempotency_records FOR EACH ROW EXECUTE FUNCTION pb01_i03.reject_mutation();

COMMIT;
