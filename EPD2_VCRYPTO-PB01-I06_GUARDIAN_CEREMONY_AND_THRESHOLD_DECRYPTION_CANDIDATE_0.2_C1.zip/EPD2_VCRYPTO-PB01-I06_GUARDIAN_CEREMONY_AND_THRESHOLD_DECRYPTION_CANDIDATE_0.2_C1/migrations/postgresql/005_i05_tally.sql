BEGIN;

CREATE SCHEMA IF NOT EXISTS pb01_i05;

CREATE TABLE pb01_i05.aggregates (
  election_instance_id text PRIMARY KEY REFERENCES pb01_i03.elections,
  f_final char(64) NOT NULL CHECK (f_final ~ '^[0-9a-f]{64}$'),
  ballot_count bigint NOT NULL CHECK (ballot_count >= 0),
  aggregate_ciphertext_bytes bytea NOT NULL,
  aggregate_ciphertext_digest char(64) NOT NULL CHECK (aggregate_ciphertext_digest ~ '^[0-9a-f]{64}$'),
  upstream_sized_tally_bytes bytea NOT NULL,
  created_at timestamptz NOT NULL
);

CREATE TABLE pb01_i05.tally_records (
  election_instance_id text PRIMARY KEY REFERENCES pb01_i05.aggregates(election_instance_id),
  f_final char(64) NOT NULL CHECK (f_final ~ '^[0-9a-f]{64}$'),
  cset_root char(64) NOT NULL CHECK (cset_root ~ '^[0-9a-f]{64}$'),
  final_set_envelope_digest char(64) NOT NULL CHECK (final_set_envelope_digest ~ '^[0-9a-f]{64}$'),
  tally_input_digest char(64) NOT NULL CHECK (tally_input_digest ~ '^[0-9a-f]{64}$'),
  aggregate_ciphertext_digest char(64) NOT NULL CHECK (aggregate_ciphertext_digest ~ '^[0-9a-f]{64}$'),
  tally_record_digest char(64) NOT NULL CHECK (tally_record_digest ~ '^[0-9a-f]{64}$'),
  tally_evidence_digest char(64) NOT NULL CHECK (tally_evidence_digest ~ '^[0-9a-f]{64}$'),
  tally_input_manifest_canonical text NOT NULL CHECK (tally_input_manifest_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  tally_record_canonical text NOT NULL CHECK (tally_record_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  tally_evidence_canonical text NOT NULL CHECK (tally_evidence_canonical IS JSON OBJECT WITH UNIQUE KEYS),
  committed_at timestamptz NOT NULL,
  UNIQUE (election_instance_id, f_final),
  UNIQUE (tally_record_digest)
);

CREATE TABLE pb01_i05.tally_audit_events (
  audit_seq bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  audit_event_id uuid NOT NULL UNIQUE,
  election_instance_id text,
  event_code text NOT NULL,
  occurred_at timestamptz NOT NULL,
  detail_canonical text NOT NULL CHECK (detail_canonical IS JSON OBJECT WITH UNIQUE KEYS)
);

CREATE OR REPLACE FUNCTION pb01_i05.reject_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'TALLY_APPEND_ONLY_VIOLATION'; END $$;

CREATE TRIGGER no_mutate_aggregates BEFORE UPDATE OR DELETE ON pb01_i05.aggregates FOR EACH ROW EXECUTE FUNCTION pb01_i05.reject_mutation();
CREATE TRIGGER no_mutate_tally_records BEFORE UPDATE OR DELETE ON pb01_i05.tally_records FOR EACH ROW EXECUTE FUNCTION pb01_i05.reject_mutation();

CREATE VIEW pb01_i05.public_tallies AS
SELECT r.election_instance_id, r.f_final, r.cset_root, r.final_set_envelope_digest,
  r.tally_input_digest, r.aggregate_ciphertext_digest, r.tally_record_digest,
  r.tally_evidence_digest, r.tally_input_manifest_canonical,
  r.tally_record_canonical, r.tally_evidence_canonical, r.committed_at,
  a.ballot_count, a.aggregate_ciphertext_bytes
FROM pb01_i05.tally_records r JOIN pb01_i05.aggregates a USING (election_instance_id);

COMMIT;
