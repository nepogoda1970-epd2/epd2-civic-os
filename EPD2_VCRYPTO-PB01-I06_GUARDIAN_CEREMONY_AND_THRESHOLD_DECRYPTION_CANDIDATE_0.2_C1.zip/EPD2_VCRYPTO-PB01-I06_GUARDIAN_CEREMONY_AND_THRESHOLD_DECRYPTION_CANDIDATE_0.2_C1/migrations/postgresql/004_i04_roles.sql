BEGIN;

DO $roles$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'epd2_pb01_finalization_runtime') THEN
    CREATE ROLE epd2_pb01_finalization_runtime NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'epd2_pb01_private_auditor') THEN
    CREATE ROLE epd2_pb01_private_auditor NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS;
  END IF;
END
$roles$;

REVOKE ALL ON SCHEMA pb01_i04 FROM PUBLIC;
GRANT USAGE ON SCHEMA pb01_i03, pb01_i04 TO epd2_pb01_finalization_runtime;
GRANT SELECT ON pb01_i03.elections, pb01_i03.encrypted_submissions,
  pb01_i03.private_submission_lifecycle, pb01_i03.submission_ledger_events
  TO epd2_pb01_finalization_runtime;
GRANT UPDATE (election_state) ON pb01_i03.elections TO epd2_pb01_finalization_runtime;
GRANT SELECT, INSERT ON pb01_i04.closure_records, pb01_i04.revote_resolution_records,
  pb01_i04.effective_submissions, pb01_i04.finalizations, pb01_i04.finalization_audit_events
  TO epd2_pb01_finalization_runtime;
GRANT USAGE, SELECT ON SEQUENCE pb01_i04.finalization_audit_events_audit_seq_seq
  TO epd2_pb01_finalization_runtime;

GRANT USAGE ON SCHEMA pb01_i04 TO epd2_pb01_evidence_reader;
GRANT SELECT ON pb01_i04.public_finalizations, pb01_i04.effective_submissions,
  pb01_i04.closure_records TO epd2_pb01_evidence_reader;

GRANT USAGE ON SCHEMA pb01_i03, pb01_i04 TO epd2_pb01_private_auditor;
GRANT SELECT ON pb01_i03.elections, pb01_i03.encrypted_submissions,
  pb01_i03.private_submission_lifecycle, pb01_i03.submission_ledger_events,
  pb01_i04.closure_records, pb01_i04.revote_resolution_records,
  pb01_i04.effective_submissions, pb01_i04.finalizations
  TO epd2_pb01_private_auditor;

REVOKE ALL ON ALL TABLES IN SCHEMA pb01_i04 FROM epd2_pb01_submission_runtime;
REVOKE UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA pb01_i03, pb01_i04
  FROM epd2_pb01_finalization_runtime, epd2_pb01_evidence_reader, epd2_pb01_private_auditor;
GRANT UPDATE (election_state) ON pb01_i03.elections TO epd2_pb01_finalization_runtime;
REVOKE INSERT ON ALL TABLES IN SCHEMA pb01_i03 FROM epd2_pb01_finalization_runtime;
REVOKE CREATE ON SCHEMA pb01_i03, pb01_i04, public
  FROM epd2_pb01_submission_runtime, epd2_pb01_finalization_runtime,
    epd2_pb01_evidence_reader, epd2_pb01_private_auditor;

DO $database_privileges$
BEGIN
  EXECUTE format('REVOKE TEMPORARY ON DATABASE %I FROM epd2_pb01_finalization_runtime, epd2_pb01_evidence_reader, epd2_pb01_private_auditor', current_database());
END
$database_privileges$;

ALTER SCHEMA pb01_i04 OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i04.closure_records OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i04.revote_resolution_records OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i04.effective_submissions OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i04.finalizations OWNER TO epd2_pb01_migrator;
ALTER TABLE pb01_i04.finalization_audit_events OWNER TO epd2_pb01_migrator;
ALTER SEQUENCE pb01_i04.finalization_audit_events_audit_seq_seq OWNER TO epd2_pb01_migrator;
ALTER VIEW pb01_i04.public_finalizations OWNER TO epd2_pb01_migrator;
ALTER FUNCTION pb01_i04.reject_mutation() OWNER TO epd2_pb01_migrator;
ALTER FUNCTION pb01_i04.enforce_open_to_closed_only() OWNER TO epd2_pb01_migrator;

REVOKE ALL ON FUNCTION pb01_i04.reject_mutation() FROM PUBLIC;
REVOKE ALL ON FUNCTION pb01_i04.enforce_open_to_closed_only() FROM PUBLIC;

ALTER DEFAULT PRIVILEGES FOR ROLE epd2_pb01_migrator IN SCHEMA pb01_i04 REVOKE ALL ON TABLES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE epd2_pb01_migrator IN SCHEMA pb01_i04 REVOKE ALL ON SEQUENCES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE epd2_pb01_migrator IN SCHEMA pb01_i04 REVOKE ALL ON FUNCTIONS FROM PUBLIC;

COMMIT;
