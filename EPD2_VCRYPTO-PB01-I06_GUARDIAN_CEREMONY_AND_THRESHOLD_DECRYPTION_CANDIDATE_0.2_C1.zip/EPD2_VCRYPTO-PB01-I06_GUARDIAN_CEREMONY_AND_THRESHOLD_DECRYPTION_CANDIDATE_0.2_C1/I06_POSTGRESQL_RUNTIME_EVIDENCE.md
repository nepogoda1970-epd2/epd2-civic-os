# I06 PostgreSQL Runtime Evidence

## Runtime

- PostgreSQL: **16.14**, real server binaries.
- Storage: real PostgreSQL; no mock or SQLite substitute for the production acceptance gate.
- Isolation: each acceptance class receives a fresh `initdb` cluster.
- Migrations: **001–008 from zero** on every class cluster.
- Execution command: `EPD2_I06_PG_BIN=<postgresql-16.14-bin> npm run test:i06:postgres`.

## Result

`PB01-I06 PostgreSQL acceptance: 22/22 PASS`

| Class | Result |
|---|---:|
| privileged tamper + role separation | 11/11 PASS |
| concurrency + CRASH-01..04 | 6/6 PASS |
| ceremony + threshold | 3/3 PASS |
| hard restart + backup/restore | 2/2 PASS |
| **Total** | **22/22 PASS** |

The suite separately establishes:

- N=3/T=2 ceremony and immutable freeze;
- T-1 exposes no plaintext; exact threshold completes; extra valid share does not change plaintext;
- duplicate guardian and invalid share/proof rejection;
- concurrent threshold-forming shares converge to one immutable record;
- same-guardian race cannot double-count threshold;
- CRASH-01, CRASH-02, CRASH-03, CRASH-04 recovery;
- hard PostgreSQL stop/restart with identical plaintext and decryption-record digest;
- backup/restore preserving public ceremony/share/decryption evidence;
- mandatory I05 aggregate-byte-only privileged tamper detection and I06 refusal;
- all declared privileged tamper classes;
- coordinator/ingester/finalizer/reader least-privilege separation.

## C1 binding closure exercised by the production path

Before `registerElection()`, `createThresholdChain()` loads the exact persisted Belenios election bytes and applies `verifyPersistedElectionBinding()`. The authoritative fixture is 344 bytes and has:

- SHA-256 hex: `3a4b152f2f34b9f78318619b64c5d282d5d497ba9cb3a01618fadac6162d3d27`;
- Belenios election fingerprint: `OksVLy80ufeDGGGbZMXSgtXUl7qcs6AWGPraxhYtPSc`.

The previous 345-byte transport representation with trailing LF hashed to a different fingerprint and is rejected. `FOREIGN_ELECTION_BALLOT` remains unchanged and foreign election ballots remain rejected.

## Test execution note

The PostgreSQL battery repeatedly constructs the same fixed public cryptographic fixture. To avoid hundreds of redundant external `belenios-tool` launches in a long DB test run, `tests/i06_postgres_helpers.mjs` keeps an exact-byte test-only cache inside each Node test class. Every distinct fixed ballot and aggregate still passes the pinned Belenios 3.3.0 path at least once per class. No production verifier, tally engine, cryptographic adapter, digest rule, or accepted I01–I05 semantic is changed by this test optimization.

Machine-readable evidence: `evidence/results/i06/postgresql-runtime.json`.
Full execution log: `evidence/results/i06/I06_C1_POSTGRESQL_16_14_22_OF_22.log`.
