# Recompute Tally

`TallyEngine.recompute(election_instance_id)` re-runs I04 integrity verification, exact-byte resolution, native Belenios re-verification, and upstream aggregation, then compares `f_final`, input digest, aggregate digest and tally record digest against persisted I05 state. `server/recompute-tally.mjs` is the governed PostgreSQL CLI entry and accepts only an election instance ID.
