# Independent Verifier B extension — I04 cross-language closure

Candidate `0.2_C1` closes only the independent cross-language verifier gap. Producer, PostgreSQL, closure, checkpoint, revote, `CSet_final`, `FinalSetEnvelope` and `F_final` semantics are unchanged.

## Independent implementations

- `verifier/reference-go/` is the executed cross-language acceptance verifier. It uses only the Go standard library and imports no producer module. It independently implements restricted canonicalization, UTF-16 member ordering, SHA-256 domain separation and Ed25519 verification.
- `verifier/rust/` extends the accepted Rust/reference Verifier B lineage with the same I04 composition checks. It imports no Node/producer hashing or canonicalization code.
- `verifier/i04_verifier_b.mjs` is retained unchanged as the pre-existing JS verifier and is not used to establish cross-language independence.

## Frozen vectors consumed unchanged

The verifier consumes the existing four vectors under `test-vectors/i04-verifier-b/`:

1. one lifecycle / one ballot;
2. one lifecycle / two revotes;
3. three lifecycles / mixed revotes;
4. empty final set.

`evidence/results/i04-vector-preservation.json` records SHA-256 equality against candidate `0.1`; all vector files and `index.json` are byte-identical.

## Independently verified composition

For each vector the reference verifier independently checks:

- restricted canonicalization and producer canonical-byte equality;
- closure authorization evidence digest;
- Ed25519 closure signature over `epd2.pb01.closure-authorization.v1 || 0x00 || canonical(statement)`;
- closure checkpoint digest and exact equality to the signed checkpoint;
- accepted-manifest digest and checkpoint binding;
- canonical `CSet_final` ordering, uniqueness and accepted-manifest membership;
- `cset_root`;
- `closure_record_digest`;
- `FinalSetEnvelope` linkage and digest;
- `F_final`;
- public evidence digest;
- absence of `lifecycle_handle` from public evidence.

The producer canonical public-evidence bytes and the independent verifier canonical bytes agree byte-for-byte for all four vectors. `cset_root`, `F_final` and public-evidence digest also agree exactly.

## Mutation negatives

The cross-language verifier rejects all required targeted mutations: checkpoint, accepted set, CSet order, closure signature, FinalSetEnvelope and `F_final`. The closure-signature mutation reseals all downstream hashes so that rejection depends on Ed25519 verification rather than a stale outer digest.

Execution evidence is in `evidence/results/i04-cross-language-verifier.json` and `evidence/results/i04-cross-language-verifier.tap`.
