# I06 Threat Model

## Authority boundary

Operational capability is not decryption authority. Administrator, DBA, runtime, infrastructure operator, ceremony coordinator, and contribution ingester roles do not become threshold guardians by holding those roles. No singleton application-side private election key is introduced.

The decryption service cannot accept arbitrary aggregate ciphertext. Every operation resolves one persisted authoritative I05 tally and requires the I05 recomputation gate, exact aggregate-byte digest, frozen ceremony digest, and Belenios archive aggregate equality.

## Attacks addressed

- substituted/all-minus-one/superset/stale aggregate: rejected by I05 recomputation and internal tally resolution;
- wrong-election or wrong-aggregate share: rejected by artifact binding;
- non-member guardian: rejected by frozen ceremony membership;
- duplicate guardian: uniqueness plus explicit guardian index prevents double counting;
- malformed/corrupted proof: rejected by upstream Belenios threshold result verification;
- T-1 shares or one invalid among T: no plaintext result;
- post-freeze ceremony mutation: database guard plus canonical ceremony re-verification;
- committed plaintext/decryption-record mutation: record and plaintext digest recomputation;
- I05 aggregate byte-only privileged mutation: newly recomputed directly from persisted bytes before I06 can start.

## Non-claim

A malicious threshold quorum is not cryptographically impossible. Threshold-quorum collusion, key compromise, evidence withholding, and some coherent privileged infrastructure rewrites remain residual trust/governance risks. The PB01 goal is to make the official result bound to public evidence and unauthorized alternatives detectable, not to claim collusion cannot occur.
