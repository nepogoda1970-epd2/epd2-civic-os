# Closure checkpoint

The checkpoint commits `ledger_event_count`, `ledger_seq`, last I03 ledger hash and accepted-manifest digest under domain `epd2.pb01.closure-ledger-checkpoint.v1`. I04 verifies the complete I03 hash chain before resolving. Timestamp is informational only.
