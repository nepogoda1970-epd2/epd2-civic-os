# Native Ballot Re-verification

Every authorized final ballot is written byte-for-byte to a temporary file and passed to pinned `belenios-tool 3.3.0 election verify-ballot` against the authoritative election fixture/context. Failure is `BALLOT_REVERIFICATION_FAILED`; no skip/fallback to an older revote exists. Verifier A independently repeats this step on all four real vectors.
