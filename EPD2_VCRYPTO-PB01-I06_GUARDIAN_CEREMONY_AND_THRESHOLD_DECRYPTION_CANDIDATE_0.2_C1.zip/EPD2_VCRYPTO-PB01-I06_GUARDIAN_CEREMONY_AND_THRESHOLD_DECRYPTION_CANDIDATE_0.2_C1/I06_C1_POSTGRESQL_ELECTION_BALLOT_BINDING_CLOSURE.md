# PB01-I06 C1 — PostgreSQL election/ballot binding closure

## Exact root cause

The I06 PostgreSQL production fixture persisted the Belenios election artifact with a filesystem transport line-feed (`0x0A`), while Belenios ballots bind `election_hash` to the exact election JSON artifact without that transport byte.

For election UUID `MjBWDwVrtkXCCq`:

- erroneous 345-byte representation including LF → SHA-256/base64-no-padding `RQx2HdiXUw7Attn0pNi22DWSRr63dJ2EiBJQQ/mDtCI`;
- authoritative 344-byte Belenios election artifact → SHA-256/base64-no-padding `OksVLy80ufeDGGGbZMXSgtXUl7qcs6AWGPraxhYtPSc`;
- accepted B1…B5 ballots bind to the latter value.

The existing `FOREIGN_ELECTION_BALLOT` check was therefore behaving correctly. C1 does not weaken or bypass it.

## Corrective

The production fixture now persists the exact Belenios election bytes, without the transport LF. Its persisted context commits the same bytes and fingerprint.

`src/i06/election_binding.mjs` adds a fail-closed pre-registration assertion verifying:

1. no transport CR/LF is present at the end of the exact election artifact;
2. SHA-256/base64-no-padding equals `belenios_election_fingerprint`;
3. exact-byte base64url equals `upstream_election_json_base64url`;
4. embedded Belenios UUID equals the persisted context UUID;
5. embedded election public key equals the persisted context public key.

`createThresholdChain()` invokes this check before persisting the election context used by I03 ballot acceptance and the I04→I05→I06 production chain.

## Preservation

- `src/i03/validation.mjs` and `FOREIGN_ELECTION_BALLOT` semantics: byte-for-byte unchanged.
- accepted I01–I05 source/schema/migrations: byte-for-byte unchanged versus I06 0.1.
- frozen `test-vectors/i06/**`: byte-for-byte unchanged.
- `verifier/**`: byte-for-byte unchanged.
- frozen Verifier A and Verifier B result JSON: byte-for-byte unchanged.

Evidence is in:

- `evidence/results/i06/I06_C1_I01_I05_SEMANTIC_PRESERVATION.json`;
- `evidence/results/i06/I06_C1_FROZEN_VECTOR_AND_VERIFIER_PRESERVATION.json`.

## Real PostgreSQL closure

PostgreSQL 16.14, fresh databases, migrations 001–008 from zero:

`npm run test:i06:postgres` → **22/22 PASS**.

The run includes ceremony N=3/T=2, T-1, duplicate/invalid share, concurrency, same-guardian race, CRASH-01..04, hard restart, backup/restore, I05 aggregate-byte tamper refusal, privileged tamper classes and role separation.
