# TallyInputManifest

Schema `epd2.pb01.tally-input-manifest/1` binds election ID, profile, tally function, `f_final`, `cset_root`, canonical ordered ballot digests, FinalSetEnvelope digest, and decimal ballot count. `tally_input_digest = SHA-256(DOMAIN_TALLY_INPUT || 0x00 || canonical(manifest))` using the existing restricted PB01 canonicalization. No lifecycle handles or credentials are present.
