# Dependency and security results

Production storage adds pinned `pg` 8.16.3 and its exact transitive dependency
set. Every npm archive is vendored; `package-lock.json` resolves all production
and browser-test packages only from local archives. PostgreSQL 16.10 is pinned
to official archive SHA-256
`91ede566d6c35db9617a619a5e015c985242144ad27fccae63d11c91cd8c3eed`
and tag commit `c13dd7d50f21268dc64b4b3edbce31993985ab12`.

Static secret/prohibited-route scans, JSON/schema checks, semantic-preservation
hash checks and all security tests passed. `npm audit --omit=dev` reported zero
findings. PostgreSQL and npm dependency licenses/inventories are carried in
`SBOM/`. No automatic dependency upgrade occurred.
