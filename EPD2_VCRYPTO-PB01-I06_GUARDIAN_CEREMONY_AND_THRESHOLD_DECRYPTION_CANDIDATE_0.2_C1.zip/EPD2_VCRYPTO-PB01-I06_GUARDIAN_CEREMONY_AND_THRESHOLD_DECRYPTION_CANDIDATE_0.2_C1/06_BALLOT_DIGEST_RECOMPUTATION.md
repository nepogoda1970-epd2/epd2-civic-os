# BallotDigest recomputation

The receiver imports the unchanged accepted I02/I01 implementation and computes
the frozen `epd2.pb01.ballot-digest.v1` digest from the authoritative election
context and received `encrypted_ballot` base64url. The browser-provided digest
is only a comparison value.

A mismatch produces `BALLOT_DIGEST_MISMATCH` before native verification or any
acceptance write. The actual browser E2E proves byte-for-byte agreement between
the browser value and the unchanged server recomputation.
