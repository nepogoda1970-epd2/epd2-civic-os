# Concurrency and crash consistency

Executed tests cover:

- concurrent same key/same request: one acceptance, one receipt;
- concurrent same digest/different keys: no duplicate event;
- concurrent distinct revotes/same lifecycle: two immutable records;
- failure after crypto/before transaction: zero accepted state;
- response loss after commit: accepted state retained;
- client disconnect after body: commit retained;
- service/store restart then retry: original receipt returned.

All listed cases were re-executed against PostgreSQL 16.10. The original
SQLite suite remains green as an independent semantic regression.

Unique constraints are the final race arbiter. No receipt is constructed from
uncommitted state, and a retry can always recover the committed response.
