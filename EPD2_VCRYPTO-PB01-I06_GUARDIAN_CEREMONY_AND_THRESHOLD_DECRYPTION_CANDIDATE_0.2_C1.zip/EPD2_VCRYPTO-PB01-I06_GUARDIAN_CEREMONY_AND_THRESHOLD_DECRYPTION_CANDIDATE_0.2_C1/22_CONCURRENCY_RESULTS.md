# Concurrency Results

Executed against real PostgreSQL 16.14, not an in-memory commit harness.

Two-way concurrency (`tests/i05-postgres.integration.test.mjs`) yields one logical record with identical `tally_record_digest`. Four-way concurrency (`tests/i05-postgres-runtime.test.mjs`) asserts the safety property directly: at least one caller commits, exactly one `aggregates` row and one `tally_records` row exist, every successful caller observes the same `tally_record_digest` and `aggregate_ciphertext_digest`, and exactly one caller is the non-replay writer.

The store uses `BEGIN ISOLATION LEVEL SERIALIZABLE` plus `pg_advisory_xact_lock`. Under four-way load PostgreSQL may abort a writer with SQLSTATE `40001` ("canceled on identification as a pivot, during write"). The test tolerates **only** `40001` as a rejection reason and then requires every rejected caller to converge on the identical committed tally when retried. A serialization failure is therefore a retryable transport outcome, never a divergent tally. The absence of an in-store retry loop is recorded as `PB01-DEBT-I05-PG-SERIALIZATION-RETRY-01`.
