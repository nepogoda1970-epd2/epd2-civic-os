# Verifier A Extension

`verifier/i05_verifier_a.mjs` verifies complete I04 public evidence, I05 evidence digests/linkages, exact ballot digest set, native Belenios validity, and independently recomputes the aggregate through pinned Belenios. All four I05 vectors pass byte-for-byte; report: `evidence/results/i05/verifier-a.json`.
