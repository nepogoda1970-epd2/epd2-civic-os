# Private lifecycle binding

The lifecycle handle is `HMAC-SHA-256` over the I03 domain, election instance
and an authorization-side random lifecycle nonce. It is opaque, election-local,
not derived from ballot bytes and not a person identifier.

`private_submission_lifecycle` is logically/access-control separated from
public submission/status/manifest data. Multiple submissions may point to the
same handle; no current winner is selected. Tests show two related submissions
privately and no relationship in public evidence.
