"""CT-00-08 Identity Leakage (canon section 27) and the pack's identity-
leakage suite (pack section 12.2): a participation response never
contains identity fields.

Checked here, per pack section 12.2's explicit list:
- credential schema does not contain forbidden identity fields;
- credential events do not contain identity fields;
- validation result does not contain identity fields;
- the OpenAPI contract's credential-related responses do not reference
  identity fields;
- the audit event *payload* for credential operations does not contain
  identity claims (only structural target_type/target_id references);
- a serialized credential cannot be linked to an account or identity
  record through an explicit ID (no shared identifier field at all).
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from uuid import uuid4

import pytest
from _schema_helpers import OPENAPI_PATH, load_event_schema, load_schema, to_jsonable

from epd2_audit_core.storage import InMemoryAuditEventStore
from epd2_core.clock import FixedClock
from epd2_core.event_envelope import ActorRef
from epd2_credential_service.application import (
    IssueResult,
    issue_participation_credential,
    revoke_participation_credential,
    validate_participation_credential,
)
from epd2_credential_service.domain import FORBIDDEN_FIELD_NAMES, CredentialType
from epd2_credential_service.events import credential_full_state_payload
from epd2_credential_service.storage import InMemoryCredentialStore


def _issue(
    credential_store: InMemoryCredentialStore,
    audit_store: InMemoryAuditEventStore,
    actor: ActorRef,
    clock: FixedClock,
    **overrides: object,
) -> IssueResult:
    defaults = dict(
        credential_id=uuid4(),
        credential_type=CredentialType.SPACE_ACCESS,
        scope_type="civic_space",
        scope_id=uuid4(),
        valid_from=datetime(2026, 1, 1, tzinfo=UTC),
        expires_at=datetime(2027, 1, 1, tzinfo=UTC),
        usage_limit=None,
        rule_version=1,
        eligibility_snapshot_digest="a" * 64,
        actor=actor,
        actor_is_authorized=True,
        correlation_id=uuid4(),
        clock=clock,
    )
    defaults.update(overrides)
    return issue_participation_credential(
        credential_store,
        audit_store,
        **defaults,  # type: ignore[arg-type]
    )


def test_credential_schema_forbids_identity_fields() -> None:
    schema = load_schema("participation-credential.schema.json")
    assert schema["additionalProperties"] is False
    for forbidden in FORBIDDEN_FIELD_NAMES:
        assert forbidden not in schema["properties"]


def test_credential_issued_event_payload_has_no_identity_fields(
    credential_store: InMemoryCredentialStore,
    audit_store: InMemoryAuditEventStore,
    actor: ActorRef,
    clock: FixedClock,
) -> None:
    result = _issue(credential_store, audit_store, actor, clock)
    payload_text = json.dumps(to_jsonable(result.event.payload))
    for forbidden in FORBIDDEN_FIELD_NAMES:
        assert forbidden not in payload_text


def test_credential_revoked_event_payload_has_no_identity_fields(
    credential_store: InMemoryCredentialStore,
    audit_store: InMemoryAuditEventStore,
    actor: ActorRef,
    clock: FixedClock,
) -> None:
    issued = _issue(credential_store, audit_store, actor, clock)
    result = revoke_participation_credential(
        credential_store,
        audit_store,
        credential_id=issued.credential.credential_id,
        actor=actor,
        actor_is_authorized=True,
        correlation_id=uuid4(),
        causation_id=None,
        clock=clock,
    )
    payload_text = json.dumps(to_jsonable(result.event.payload))
    for forbidden in FORBIDDEN_FIELD_NAMES:
        assert forbidden not in payload_text


def test_credential_event_payload_schemas_forbid_identity_fields() -> None:
    for name in (
        "credential-issued-or-revoked-payload.v1.schema.json",
        "credential-validation-failed-payload.v1.schema.json",
    ):
        schema = load_event_schema(name)
        assert schema["additionalProperties"] is False
        for forbidden in FORBIDDEN_FIELD_NAMES:
            assert forbidden not in schema["properties"]


def test_validation_result_has_no_identity_fields(
    credential_store: InMemoryCredentialStore,
    audit_store: InMemoryAuditEventStore,
    actor: ActorRef,
    clock: FixedClock,
) -> None:
    issued = _issue(credential_store, audit_store, actor, clock)
    result = validate_participation_credential(
        credential_store,
        credential_id=issued.credential.credential_id,
        required_scope_type=None,
        required_scope_id=None,
        expected_rule_version=None,
        expected_digest=None,
        actor=actor,
        correlation_id=uuid4(),
        clock=clock,
    )
    field_names = set(result.result.__dataclass_fields__)
    assert not (field_names & FORBIDDEN_FIELD_NAMES)


def test_audit_event_payload_for_credential_operations_has_no_identity_claims(
    credential_store: InMemoryCredentialStore,
    audit_store: InMemoryAuditEventStore,
    actor: ActorRef,
    clock: FixedClock,
) -> None:
    """The AuditEvent itself (docs/canonical/TZ-00-domain-event-canon.md,
    section 18.1) only ever carries structural target_type/target_id
    references (e.g. "participation_credential" + a credential UUID) -
    never an identity claim such as a name, email, or identity_record_id."""
    result = _issue(credential_store, audit_store, actor, clock)
    audit_event = result.audit_event
    assert audit_event.target_type == "participation_credential"
    # The audit entry's own hashed state snapshot (before/after) is
    # derived from credential_full_state_payload, which structurally
    # cannot contain identity fields either.
    state_text = json.dumps(to_jsonable(credential_full_state_payload(result.credential)))
    for forbidden in FORBIDDEN_FIELD_NAMES:
        assert forbidden not in state_text


def test_serialized_credential_has_no_id_shared_with_identity_or_account(
    credential_store: InMemoryCredentialStore,
    audit_store: InMemoryAuditEventStore,
    actor: ActorRef,
    clock: FixedClock,
) -> None:
    """A serialized credential cannot be linked to an account or identity
    record via an explicit shared identifier - the only IDs present are
    the credential's own (credential_id, scope_id), neither of which is
    ever an account_id or identity_record_id (structural boundary, see
    services/credential-service/README.md)."""
    result = _issue(credential_store, audit_store, actor, clock)
    payload = to_jsonable(credential_full_state_payload(result.credential))
    assert set(payload) & {"account_id", "identity_record_id", "person_id"} == set()


def test_openapi_credential_responses_do_not_reference_identity_fields() -> None:
    pytest.importorskip("yaml")
    import yaml

    spec = yaml.safe_load(OPENAPI_PATH.read_text(encoding="utf-8"))
    spec_text = json.dumps(spec)
    for forbidden in FORBIDDEN_FIELD_NAMES:
        assert forbidden not in spec_text, (
            f"OpenAPI contract must never reference forbidden identity field {forbidden!r}"
        )
