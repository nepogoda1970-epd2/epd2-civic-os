# CLAUDE-PACK-02 — Identity Separation and Audit Kernel: Handover Report

**Revision 1.** Every check this sandbox can run (structure, forbidden
paths, version consistency, Ruff format, Ruff lint, mypy across every
service and the shared test suites, pytest, JSON/YAML validity) passes
cleanly and honestly, with no weakened, skipped, or disabled check. The one
Definition-of-Done item this repository cannot yet satisfy is `uv.lock`
being regenerated to include PACK-02's five new workspace members and three
new dev dependencies — this sandbox's network egress to `pypi.org` /
`files.pythonhosted.org` is blocked, and the required `hypothesis` package
is not present in the local `uv` cache either, so `uv lock` fails both
online and with `--offline`. This is the same class of blocker
`docs/handover/PACK-01-REPORT.md` hit in its revision 3, resolved there by
running `.github/workflows/verify-and-package.yml` on GitHub Actions (real
network access). That workflow already exists, has been generalized in this
pass to not be PACK-01-specific, and is the recorded remediation path
(section 3). Per the pack's own rule against a "conditional PASS," this
revision honestly records:

```text
PACK-02 FAIL — blocked solely by an unregenerated uv.lock
(see section 3 for the exact, narrow gap and remediation path)
```

## 0. What CLAUDE-PACK-02 adds

Five new Python services, each an independent `uv` workspace member with
its own `pyproject.toml`, `src/`, and `tests/`:

- `services/account-service` (`epd2_account_service`) — owns `Account`.
- `services/identity-service` (`epd2_identity_service`) — owns
  `IdentityRecord`.
- `services/eligibility-service` (`epd2_eligibility_service`) — owns
  `EligibilityRule`, `EligibilityDecision`, `EligibilitySnapshot`.
- `services/credential-service` (`epd2_credential_service`) — owns
  `ParticipationCredential`.
- `services/audit-core` (`epd2_audit_core`) — owns `AuditEvent`, the
  append-only, hash-chained audit ledger every other service writes to.

Plus: three new ADRs (identity/participation separation, the audit hash
chain, the reason-code registry), a repository-wide JSON Schema + OpenAPI
contract for all seven entities above, a 43-entry reason-code registry (22
canon-inherited + 21 PACK-02-additive, see `contracts/reason-codes/pack-02.yml`
and ADR-004), the full CT-00-01..12 contract test suite, an identity-leakage
test suite, a full state-transition matrix test, a threat model
(`docs/review/PACK-02-THREAT-MODEL.md`), and updated architecture docs.

## 1. Environment and network status

```text
$ python3.12 --version
Python 3.12.3
$ uv --version
uv 0.8.17
$ node --version
v22.22.2
$ npm --version
10.9.7
```

This sandbox's network egress is unchanged from PACK-01 and still blocks
`pypi.org` / `files.pythonhosted.org` / `registry.npmjs.org`
(`403 host_not_allowed`), reconfirmed this pass via a direct `uv lock`
attempt (section 3). Because of this, all local verification in this
report was run using the pre-existing standalone tool binaries at
`/root/.local/share/uv/tools/{pytest,mypy,ruff}/bin/` (each in its own
isolated venv, none matching the project's own dependency set exactly —
see section 6's notes on `pytest`/`yaml`/`hypothesis` availability) rather
than through `uv run`, which requires a synced project venv this sandbox
cannot produce.

## 2. Canon integrity

`docs/canonical/TZ-00-domain-event-canon.md` was not opened for editing
this pass. `CANON_VERSION` remains `"0.1.0"` everywhere it is declared
(`epd2_core/version.py`, `epd2-types/version.ts`,
`docs/canonical/canon-version.json`). No ADR was required to touch it,
since PACK-02 adds new services and contracts, not new canon content.

```text
sha256(docs/canonical/TZ-00-domain-event-canon.md) =
  c731a24477d91010b5c6bc41a00253c8e30279b7f03394e53481ef0d8975e18b
```

`REPOSITORY_VERSION` was bumped `0.1.0` → `0.2.0` to reflect PACK-02's
addition (tracked consistently across `epd2_core/version.py`,
`epd2-types/version.ts`, `CHANGELOG.md`'s newest entry, and enforced by
`scripts/verify_versions.py`, which passes). `canon-version.json`'s
`repository_compatibility` field (repository-side bookkeeping, not
canon-immutable content — see `docs/canonical/README.md`) was widened from
`">=0.1.0 <0.2.0"` to `">=0.1.0 <0.3.0"` to admit the new repository
version.

## 3. Lock files — the one open Definition-of-Done gap

```text
uv.lock:            STALE — present, but missing all 5 PACK-02 workspace
                     members and 3 new dev dependencies
package-lock.json:  UP TO DATE — PACK-02 added no new npm dependency;
                     package.json's dependencies/devDependencies and
                     package-lock.json's root package entry are identical,
                     and package.json's `workspaces` list is unchanged
                     (still just packages/typescript/epd2-types and
                     frontend/web-shell) - verified programmatically this
                     pass, not merely assumed
```

Verification performed this pass (both commands run from the repository
root, `pyproject.toml` as currently committed):

```text
$ uv lock
  × No solution found when resolving dependencies for split
    (markers: python_full_version >= '3.15'):
  ╰─▶ Because hypothesis was not found in the package registry ...
      hint: An index URL (https://pypi.org/simple) could not be queried
      due to a lack of valid authentication credentials (403 Forbidden).

$ uv lock --offline
  × No solution found when resolving dependencies ...
  ╰─▶ Because hypothesis was not found in the cache ...
      hint: Packages were unavailable because the network was disabled.
```

`jsonschema` and `types-PyYAML` wheels happen to already be present in this
sandbox's local `uv` cache (residue from other work), but `hypothesis` is
not, so even a fully offline resolution fails on the very first new
dependency it needs. There is no partial or manual workaround that
produces a genuine, tool-generated `uv.lock` here — writing one by hand
would not be a real lock file and was not attempted.

**Remediation path (identical in kind to `docs/handover/PACK-01-REPORT.md`
section 0's revision-3-to-4 transition):** run
`.github/workflows/verify-and-package.yml` via **Actions → Verify and
Package → Run workflow** on a fork/clone with normal GitHub Actions network
access (see `GITHUB_ACTIONS_START.md`, updated this pass). That workflow:
runs `uv lock` for real, installs and runs `npm install`, runs the full
`make verify` pipeline, and uploads a `epd2-civic-os-verification-result`
artifact regardless of outcome. This pass also **generalized the workflow
away from being PACK-01-specific** (it previously hardcoded
`PACK-01-RESULT.md` / `PACK-01-VERIFICATION.log` / a
`epd2-civic-os-PACK-01-result` artifact name and status string; now emits
pack-agnostic `VERIFICATION-RESULT.md` / `VERIFICATION.log` /
`epd2-civic-os-verification-result`, since it will need to be re-run again
for future packs) and **hardened its canon-file safety step**: the
existing `npx prettier --write` step against the canon file (which is
supposed to be a no-op because `.prettierignore` excludes that path — the
exact mechanism whose *absence* caused the PACK-01 revision-3→4 incident)
now hashes the file before and after and fails the workflow loudly if the
hash ever changes, instead of silently trusting `.prettierignore`.

Once that run produces a genuine `uv.lock`, it should be diffed
file-by-file against the current tree before being accepted (per the exact
lesson of the PACK-01 incident), then this report revised to a genuine,
non-conditional PACK-02 PASS.

## 4. Files added or changed this pass

New:

- `services/account-service/`, `services/identity-service/`,
  `services/eligibility-service/`, `services/credential-service/`,
  `services/audit-core/` — full `src/`, `tests/`, `pyproject.toml`,
  `README.md` each.
- `docs/adr/ADR-002-identity-participation-separation.md`,
  `docs/adr/ADR-003-append-only-audit-hash-chain.md`,
  `docs/adr/ADR-004-reason-code-registry.md`.
- `contracts/reason-codes/pack-02.yml`, `contracts/schemas/*.json` (8
  files), `contracts/events/*.json` (6 files), `contracts/openapi/pack-02.yaml`.
- `tests/contract/` — `conftest.py`, `_schema_helpers.py`, all
  `test_ct00_01..12*.py`, `test_state_transitions.py`, `test_audit.py`,
  `test_reason_codes_registry.py`, `test_openapi_contract.py`,
  `test_property_based.py`.
- `tests/repository/test_service_boundaries.py` (new this pass, see
  section 5) — the repository-wide, N×N structural boundary check.
- `docs/architecture/identity-participation-separation.md`,
  `docs/architecture/audit-kernel.md`, `docs/review/PACK-02-THREAT-MODEL.md`.
- `docs/handover/PACK-02-REPORT.md` — this report.

Changed:

- `pyproject.toml` — workspace members, dev dependencies
  (`types-PyYAML`, `jsonschema`, `hypothesis`), mypy overrides for
  `yaml`/`jsonschema`/`hypothesis`/`pytest`/`_pytest.*`
  (`ignore_missing_imports`, all sandbox-network-restriction workarounds
  that are no-ops once CI's `uv sync --all-groups` installs the real
  packages and their stubs).
- `scripts/check_repository.py` — `REQUIRED_PATHS` extended for every
  PACK-02 path above.
- `scripts/check_forbidden_files.py` — new central
  identity-participation-mapping-filename heuristic (pack section 15;
  `_is_forbidden_identity_link_filename`), tested in
  `tests/repository/test_forbidden_paths.py`.
- `Makefile` — `typecheck` target rewritten from a single `uv run mypy .`
  into scoped per-group invocations (section 5 explains why).
- `.github/workflows/verify-and-package.yml`, `GITHUB_ACTIONS_START.md` —
  generalized and hardened, see section 3.
- `docs/architecture/data-ownership.md`, `docs/architecture/service-boundaries.md`
  — updated to describe the five implemented services and the
  now-comprehensive structural boundary test.
- `docs/review/OPEN_QUESTIONS.md` — fixed a stale reason-code count (16 →
  21 additive codes, verified against the actual registry), added item 12
  (the mapping-filename heuristic's known detection limits).
- `docs/review/KNOWN_LIMITATIONS.md` — restructured into a PACK-02-current
  section and a PACK-01-inherited section.
- `packages/python/epd2-core/src/epd2_core/version.py`,
  `packages/typescript/epd2-types/src/version.ts`, `CHANGELOG.md`,
  `docs/canonical/canon-version.json` — version bump, section 2.
- `README.md` — status line and doc links updated for PACK-02 (section 8).

Not changed: `docs/canonical/TZ-00-domain-event-canon.md` (byte-identical,
section 2); `package.json` / `package-lock.json` (no npm-side change, see
section 3); `frontend/web-shell/`, `CODEOWNERS`, `LICENSE` (still
PACK-01-era placeholders, unchanged, see `docs/review/KNOWN_LIMITATIONS.md`).

## 5. A gap found and fixed during this pass's own verification

Two real problems were found while producing this report, not before it —
recorded here in full rather than quietly folded into the file list above,
per the pack's demand for honest verification:

1. **A single, repository-wide `uv run mypy .` cannot run at all.** The
   five services deliberately share identically-named test files (e.g.
   every service has its own `tests/test_domain.py`) with no `__init__.py`,
   so pytest can resolve them via `--import-mode=importlib`. mypy has no
   equivalent mode: one whole-repo invocation fails immediately with
   `Duplicate module named 'test_domain'` before checking a single real
   type. This was **not caught by earlier verification passes in this
   session** because the collision aborts before producing any per-file
   errors, which read superficially like "nothing to check" rather than
   "checking never happened." Fixed by invoking mypy once per group of
   files whose basenames cannot collide within that invocation
   (`packages/python/epd2-core scripts tests/repository conftest.py`;
   `tests/contract`; one call per service) — reflected in the `Makefile`'s
   `typecheck` target (section 4) and in section 6's commands below. Once
   the collision was worked around, mypy surfaced roughly 140 real,
   previously-unchecked errors across `tests/contract/*.py` (missing
   function annotations, `**dict`-splat argument-type mismatches once
   annotations were added, and two genuine `AuditEvent | None` `union-attr`
   bugs in `test_ct00_07_audit_creation.py` that needed an actual
   `assert result.audit_event is not None` fix, not a type-ignore) — all
   fixed for real; none suppressed.
2. **The structural service-boundary check only covered one direction.**
   Before this pass, the only AST-based cross-service import check lived
   in `services/eligibility-service/tests/test_domain.py`
   (`test_eligibility_service_has_no_import_dependency_on_identity_service`),
   checking just that one service against two others — not the full 5×5
   matrix `docs/architecture/service-boundaries.md` describes. Fixed by
   adding `tests/repository/test_service_boundaries.py`, which walks every
   service's actual `src/` AST and asserts the complete forbidden-pair
   matrix (every service may only import its own package,
   `epd2_core`, and `epd2_audit_core`; `epd2_audit_core` itself may import
   neither `epd2_core` peers nor any domain service). Currently zero
   violations exist in the real codebase — this test would have caught
   none retroactively, but it is now a real regression guard where before
   there was only a partial, one-directional one.
3. **A PEP 695 generic (`def f[T](...)`) syntax choice, made to satisfy
   Ruff's `UP047`, was silently unverifiable by this sandbox's own mypy
   tool.** mypy can only parse that syntax when the Python interpreter
   running mypy itself is 3.12+; this sandbox's standalone mypy binary
   runs under Python 3.11.15 (confirmed: `mypy --python-version 3.12` on a
   two-line PEP-695 file still fails with a hard parser `SyntaxError`,
   independent of the `--python-version` target flag). Reverted
   `tests/contract/test_state_transitions.py`'s `_all_forbidden_pairs` to
   a classic module-level `TypeVar`, which type-checks identically under
   Python 3.11 and 3.12, with a documented, narrow `# noqa: UP047` (Ruff's
   established local convention for this kind of tool-version conflict;
   see also the pre-existing `# noqa: E402` precedent in
   `packages/python/epd2-core/tests/test_reason_codes.py`).

## 6. Commands executed this pass, and results

**Post-write re-verification:** after this report was written (which
satisfies the one path `check_repository.py` and
`test_no_required_paths_are_missing` were waiting on), both were re-run:

```text
✅ python3 scripts/check_repository.py
   → OK: all 166 required paths are present.

✅ PYTHONPATH=<all 6 src/ dirs> pytest -q
   → 339 passed, 7 skipped, 0 failed
```

Zero unexplained failures remain; the 7 skips are exactly the ones
itemized below (5 sandbox-dependency skips expected to run green in CI, 2
genuine pack-scope not-applicable markers).

```text
✅ python3 scripts/check_forbidden_files.py
   → OK: no forbidden paths found.

✅ python3 scripts/verify_versions.py
   → OK: all version sources are consistent.

⏳ python3 scripts/check_repository.py
   → Missing required paths: ['docs/handover/PACK-02-REPORT.md']
   (this is the file being written; re-running after this report is
   committed makes this check pass — see section 9)

✅ ruff format --check .
   → 87 files already formatted

✅ ruff check .
   → All checks passed!

✅ mypy packages/python/epd2-core scripts tests/repository conftest.py
   → Success: no issues found in 24 source files
✅ mypy tests/contract
   → Success: no issues found in 18 source files
✅ mypy services/account-service
   → Success: no issues found in 8 source files
✅ mypy services/identity-service
   → Success: no issues found in 8 source files
✅ mypy services/eligibility-service
   → Success: no issues found in 8 source files
✅ mypy services/credential-service
   → Success: no issues found in 11 source files
✅ mypy services/audit-core
   → Success: no issues found in 10 source files

✅ PYTHONPATH=<all 6 src/ dirs> pytest -q
   → 338 passed, 7 skipped, 1 failed
     (the 1 failure is test_no_required_paths_are_missing, for the same
     not-yet-written PACK-02-REPORT.md reason as check_repository.py
     above — the only non-environmental failure in the entire suite)

⏳ JSON/YAML parse validation (every *.json / *.yml / *.yaml)
   → all files parse without error (checked programmatically this pass)

❌ uv lock / uv lock --offline
   → fails, see section 3 (the one genuine, unresolved gap)

⏳ Not run this pass (same network restriction as PACK-01, and PACK-02
   makes no frontend/TypeScript change that would affect their result):
   npm run typecheck (both workspaces), npm run lint (frontend ESLint),
   npm run test (both workspaces), npm run build (frontend). PACK-01's own
   verification of these (`docs/handover/PACK-01-VERIFICATION.log`) is
   unaffected by PACK-02, which added no TypeScript/npm dependency or
   frontend code change.
```

### Why 7 tests are skipped, not failing

```text
SKIPPED  packages/python/epd2-core/tests/test_reason_codes.py       (no yaml)
SKIPPED  tests/contract/test_openapi_contract.py                    (no yaml)
SKIPPED  tests/contract/test_reason_codes_registry.py                (no yaml)
SKIPPED  tests/contract/test_ct00_08_identity_leakage.py (1 test)     (no yaml)
SKIPPED  tests/contract/test_property_based.py                 (no hypothesis)
SKIPPED  tests/contract/test_ct00_11_12_not_applicable.py (2 tests)
```

The first five are `pytest.importorskip(...)` guards: this sandbox's
standalone `pytest` tool venv has neither `PyYAML` nor `hypothesis`
installed (same root network restriction as section 3), so these tests are
honestly reported as skipped rather than silently deleted or their
assertions weakened — CI's `uv sync --all-groups` installs both, and they
are expected to run and pass there. All five were manually re-read in full
during this pass to confirm their logic is sound independent of the
runtime skip (see conversation history; not re-transcribed here). The last
two are genuine, pack-scoped **not-applicable** markers, not skips due to
a missing dependency: CT-00-11 (AI-produced-result human-control gate) and
CT-00-12 (forbidden-operation-during-freeze) both require canon entities
(`AIProcessingRecord`, `EmergencyAction`) that are explicitly out of
PACK-02's scope per the pack's own section 3.2 — there is nothing in this
pack for either test to exercise, and `test_ct00_11_12_not_applicable.py`
documents why rather than silently omitting CT-00-11/12 from the suite.

## 7. Reason-code registry

`contracts/reason-codes/pack-02.yml`: 43 entries total — 22 inherited
verbatim from the canon's own reason-code standard (canon section 24) and
21 new, PACK-02-additive codes introduced under ADR-004 (verified
programmatically this pass: `Counter(source for source in registry) ==
{"canon": 22, "pack-02-adr-004": 21}`). Every code used in a service's
`raise ...Error(reason_code=...)` call is checked against the registry by
`tests/contract/test_reason_codes_registry.py::test_every_reason_code_literal_used_in_services_is_registered`
(currently sandbox-skipped only because that test needs `yaml`, section 6;
not because the check itself is disabled).

## 8. Identity/participation separation (INV-01) and the audit kernel (INV-04/05)

See `docs/architecture/identity-participation-separation.md` and
`docs/architecture/audit-kernel.md` for the full account. In summary:
`ParticipationCredential` (credential-service), `EligibilityDecision`/
`EligibilitySnapshot` (eligibility-service), and every canonical event
payload schema structurally forbid identity-linking fields
(`FORBIDDEN_FIELD_NAMES`, enforced via `additionalProperties: false` in
every relevant JSON Schema and exercised end-to-end in
`tests/contract/test_ct00_08_identity_leakage.py` and
`test_ct00_09_vote_linkability.py`). This is a **structural**, tested
guarantee (no field, no shared ID, no schema property) — it is explicitly
**not** a cryptographic-anonymity or unlinkability-under-collusion claim;
`docs/architecture/identity-participation-separation.md`'s final section
says so directly, and `docs/review/PACK-02-THREAT-MODEL.md` records the
residual risk of a privileged insider correlating records through
side channels (timestamps, request metadata) that this pack's scope does
not close.

`epd2_audit_core`'s `AuditEventStore` interface
(`services/audit-core/src/epd2_audit_core/storage.py`) has exactly four
methods — `append`, `get_by_event_id`, `list_by_aggregate`,
`verify_chain` — and **no update or delete method exists at all**
(confirmed by reading the interface, not merely asserted); every append is
SHA-256 hash-chained to the previous entry
(`services/audit-core/src/epd2_audit_core/hash_chain.py`), and tamper /
broken-link detection is exercised in
`services/audit-core/tests/test_storage.py`.

## 9. Readiness conclusion

```text
PACK-02 FAIL
```

Every check this repository and sandbox can genuinely execute passes:
required structure (once this report is added — the only missing path),
forbidden-paths, version consistency, Ruff format, Ruff lint, mypy across
all 7 scoped groups (24 + 18 + 8 + 8 + 8 + 11 + 10 = 87 source files,
zero errors, zero suppressed via blanket ignores), 338 passing tests with
only the report's own absence and expected sandbox-dependency skips
accounting for the rest, and JSON/YAML validity across every contract
file. No check was weakened, no empty file was written to satisfy a path
requirement, no reason code was hidden, and no unlinkability claim is made
without the automated test that backs it (section 8).

The sole reason this is **FAIL** and not **PASS** is Definition-of-Done
item 12: `uv.lock` has not been regenerated to include PACK-02's five new
workspace members and three new dev dependencies, because this sandbox's
network access to PyPI is blocked and the one missing dependency
(`hypothesis`) is not in the local cache either (section 3, with the exact
commands and their exact failures shown). `package-lock.json` needs no
change (verified programmatically, section 3). The remediation is
already-prepared and mechanical: run the generalized, hardened
`.github/workflows/verify-and-package.yml` on GitHub Actions (real
network), diff the result against this tree before accepting it (per the
PACK-01 incident's lesson), and revise this report to PACK-02 PASS once
that lock file is genuine and committed. Nothing else stands between this
repository and a real PASS.
