import "../../member/member.css";
export default function MemberLayout({ children }: { children: React.ReactNode }) {
  return children;
}
