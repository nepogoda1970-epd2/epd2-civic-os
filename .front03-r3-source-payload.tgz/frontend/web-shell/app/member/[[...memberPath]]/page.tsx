import { cookies } from "next/headers";
import { MemberWorkspace } from "../../../member/MemberWorkspace";
export const dynamic="force-dynamic";
export default async function MemberRoute({params}:{params:Promise<{memberPath?:string[]}>}){
 const {memberPath=[]}=await params;
 const fixtureEnabled=process.env.NEXT_PUBLIC_FRONT03_FIXTURE==="1"&&process.env.EPD2_FRONT03_GOVERNED_TEST_CONTEXT==="1";
 const jar=await cookies();
 const fixtureActor=fixtureEnabled&&jar.get("front03_fixture_principal")?.value==="applicant"?"applicant":"member";
 const assurance=fixtureEnabled&&jar.get("front03_fixture_assurance")?.value;
 return <MemberWorkspace path={`/member/${memberPath.join("/")}`.replace(/\/$/,"")} runtimeMode={fixtureEnabled?"fixture":"production"} fixtureActor={fixtureActor} fixtureAssurance={assurance==="expired"||assurance==="revoked"||assurance==="step-up-required"?assurance:"standard"}/>;
}
